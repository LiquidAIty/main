"""Per-strategy technical indicator accessor.

Usage inside a Strategy::

    # Built-in pandas-ta-classic passthrough (~130 indicators available)
    sma200 = self.indicators.sma(asset, length=200)           # float
    rsi14  = self.indicators.rsi(asset, length=14)            # float
    bb     = self.indicators.bbands(asset, length=20, std=2)  # IndicatorRow
    print(bb.BBL_20_2_0, bb.BBM_20_2_0, bb.BBU_20_2_0)

    # Custom user-defined indicator (takes df, returns Series or DataFrame)
    latest = self.indicators.custom(
        "my_signal", my_signal_fn, asset, timestep="day", length=50,
    )

Only rows at or before the strategy datetime enter a calculation. Results are
memoized for identical observed input and parameters, not for the whole future
backtest dataset. Negative offsets and explicitly noncausal parameters fail
visibly. Source adapters retain ownership of bar timestamp/completion semantics.
"""

from __future__ import annotations

import hashlib
import logging
from typing import Any, Callable

import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)

_TA_MODULE: Any = None


def _get_ta_module():
    """Lazy import pandas-ta-classic so the indicators module is importable
    even in environments where the indicator backend is missing (e.g. slim
    installs that never call ``self.indicators``).
    """
    global _TA_MODULE
    if _TA_MODULE is None:
        if not hasattr(np, "NaN"):
            np.NaN = np.nan
        import pandas_ta_classic as ta

        _TA_MODULE = ta
    return _TA_MODULE


class IndicatorRow:
    """Attribute-style read-only view over a single pandas Series (one row of
    a multi-column indicator output).

    Given a DataFrame indicator result like pandas-ta's ``bbands``
    (columns ``BBL_20_2.0``, ``BBM_20_2.0``, ``BBU_20_2.0`` …), this wrapper
    lets the strategy write ``bb.BBL_20_2_0`` or ``bb["BBL_20_2.0"]``.
    """

    __slots__ = ("_data",)

    def __init__(self, data: pd.Series):
        self._data = data

    def __getattr__(self, name: str):
        data = object.__getattribute__(self, "_data")
        if name in data.index:
            return data[name]
        normalized = {str(col).replace(".", "_").replace("-", "_"): col for col in data.index}
        if name in normalized:
            return data[normalized[name]]
        raise AttributeError(name)

    def __getitem__(self, key):
        return self._data[key]

    def __contains__(self, key):
        return key in self._data.index

    def as_dict(self) -> dict:
        return dict(self._data)

    def __repr__(self) -> str:
        return f"IndicatorRow({dict(self._data)!r})"


class Indicators:
    """Per-strategy indicator accessor. See module docstring for usage."""

    def __init__(self, strategy):
        self._strategy = strategy
        self._cache: dict = {}
        # Indicator v2 streaming state for get(): one live instance per
        # (asset, timestep, key, version, inputs, quote, exchange).
        self._streams: dict = {}
        self._fallback_length: int = 10_000

    def __getattr__(self, name: str):
        if name.startswith("_"):
            raise AttributeError(name)
        ta = _get_ta_module()
        if not hasattr(ta, name):
            raise AttributeError(
                f"pandas_ta_classic has no indicator named {name!r}. "
                f"For user-defined indicators use self.indicators.custom(name, fn, asset, ...)."
            )

        def _call(asset, timestep: str = "day", **kwargs):
            return self._dispatch(asset, timestep, name, kwargs, custom_fn=None)

        _call.__name__ = f"indicators.{name}"
        _call.__doc__ = (
            f"As-of pandas-ta-classic ``{name}`` indicator for the given "
            f"asset+timestep. Identical observed input reuses the cached result."
        )
        return _call

    def custom(
        self,
        name: str,
        fn: Callable[..., Any],
        asset,
        timestep: str = "day",
        **kwargs,
    ):
        """Register-and-evaluate a user-defined indicator.

        Parameters
        ----------
        name : str
            Arbitrary label used in the cache key. Give each distinct user
            indicator a stable label so repeat calls hit the memo.
        fn : callable
            ``fn(df, **kwargs) -> pandas.Series | pandas.DataFrame``.
            Function to run over a copy of history available as of strategy time.
        asset : Asset
            Underlying asset.
        timestep : str
            ``"day"``, ``"minute"``, etc. — matched against the data source.
        **kwargs
            Forwarded to ``fn`` and included in the cache key.
        """
        if not callable(fn):
            raise TypeError(f"custom indicator fn must be callable, got {type(fn).__name__}")
        return self._dispatch(asset, timestep, name, kwargs, custom_fn=fn)

    def fibonacci(self, asset, timestep="day", *, direction="up", length=None, **kwargs):
        """Range retracements: up measures down from the high, down up from the low.

        Uses only observed OHLC bars. Omit length for the full available range,
        or use calculate_window/get_indicator start+end for a month or year.
        This does not infer trend direction, swing pivots, or trading signals.
        """
        return self._dispatch(
            asset, timestep, "fibonacci", {"direction": direction, "length": length, **kwargs}, None
        )

    def get(self, key, asset, *, version=None, timestep="day", quote=None, exchange=None, **inputs):
        """Current-bar outputs of an Indicator v2 from the registry.

        ``self.indicators.get("rsi", asset, length=14)`` returns
        ``{"rsi": 55.1}`` (``None`` values while warming up, ``None`` overall
        when no bars exist yet). ``version`` pins the indicator math; omit it
        for the latest registered version. Custom indicators registered with
        ``lumibot.indicators.register`` work the same way.

        Only bars at or before strategy time are fed. The indicator keeps its
        streaming state between calls, so each new bar costs one ``update``
        instead of a full-history recompute. If time moves backwards or the
        last bar it saw has changed, it rebuilds from the observed history.
        """
        from lumibot.indicators.base import iter_bars
        from lumibot.indicators.indicator_registry import registry

        cls = registry.get(key, version)
        resolved = cls.resolve_inputs(inputs)
        stream_key = (
            self._asset_key(asset),
            timestep,
            cls.key,
            cls.version,
            tuple(sorted((k, repr(v)) for k, v in resolved.items())),
            self._asset_key(quote) if quote is not None else None,
            exchange,
        )
        df = self._full_history(asset, timestep, quote=quote, exchange=exchange)
        if df is None or df.empty:
            self._record_consumed_input(asset, timestep, None, quote=quote)
            return None
        if not isinstance(df.index, pd.DatetimeIndex) or not df.index.is_monotonic_increasing or not df.index.is_unique:
            raise ValueError("Indicator history requires a unique, increasing DatetimeIndex.")
        end = self._position_at(df.index, self._strategy.get_datetime()) + 1
        observed = df.iloc[:end]
        self._record_consumed_input(asset, timestep, observed, quote=quote)
        if end <= 0:
            return None

        entry = self._streams.get(stream_key)
        if entry is not None:
            count = entry["count"]
            last_seen = next(iter(iter_bars(observed.iloc[count - 1 : count]))) if 0 < count <= end else None
            if last_seen is None or last_seen != entry["last_bar"]:
                entry = None  # rewound or corrected: rebuild from observed history
        if entry is None:
            from lumibot.indicators.execution import prepare_indicator

            entry = {"indicator": prepare_indicator(cls(**resolved)), "count": 0, "last_bar": None, "values": None}
            self._streams[stream_key] = entry
        if entry["count"] < end:
            indicator = entry["indicator"]
            bar = None
            for bar in iter_bars(observed.iloc[entry["count"] : end]):
                entry["values"] = indicator.update(bar, closed=True)
            entry["count"], entry["last_bar"] = end, bar
        return dict(entry["values"])

    def invalidate(self, asset=None) -> None:
        """Drop memoized indicator results.

        With no argument, clears everything. With an asset, drops only that
        asset's entries (useful if a user ever needs to force a recompute —
        should be rare since the memo is per-strategy-instance).
        """
        if asset is None:
            self._cache.clear()
            self._streams.clear()
            return
        asset_key = self._asset_key(asset)
        for key in [k for k in self._cache if k[0] == asset_key]:
            self._cache.pop(key, None)
        for key in [k for k in self._streams if k[0] == asset_key]:
            self._streams.pop(key, None)

    @property
    def cache_size(self) -> int:
        """Number of memoized indicator results currently held."""
        return len(self._cache)

    def validate_window(self, start, end):
        """Validate an inclusive, explicitly zoned historical calculation window."""
        try:
            bounds = [pd.Timestamp(value) for value in (start, end)]
            now = pd.Timestamp(self._strategy.get_datetime())
            if any(pd.isna(value) or value.tzinfo is None for value in bounds) or now.tzinfo is None:
                raise ValueError("timezone required")
            if bounds[0] > bounds[1] or bounds[1] > now:
                raise ValueError("reversed or future bounds")
        except (TypeError, ValueError, OverflowError) as exc:
            raise ValueError("Indicator window requires zoned start <= end <= strategy time.") from exc
        return tuple(value.tz_convert("UTC") for value in bounds)

    def calculate(
        self,
        asset,
        indicator,
        *,
        timestep="day",
        parameters=None,
        quote=None,
        exchange=None,
    ):
        """Calculate one indicator while retaining the complete market identity."""
        if not isinstance(indicator, str) or indicator.startswith("_") or (
            indicator != "fibonacci" and not callable(getattr(_get_ta_module(), indicator, None))
        ):
            raise ValueError("Unknown indicator.")
        return self._dispatch(
            asset,
            timestep,
            indicator,
            parameters or {},
            None,
            quote=quote,
            exchange=exchange,
        )

    def calculate_window(
        self,
        asset,
        indicator,
        *,
        start,
        end,
        timestep="day",
        parameters=None,
        quote=None,
        exchange=None,
    ):
        """Calculate using only bars inside an inclusive window, with no borrowed warmup.

        Bounds must include timezones and end no later than strategy time. An
        insufficient window returns the indicator's missing value, never zero.
        Source adapters still own bar completion and timestamp conventions.
        """
        bounds = self.validate_window(start, end)
        if not isinstance(indicator, str) or indicator.startswith("_") or (
            indicator != "fibonacci" and not callable(getattr(_get_ta_module(), indicator, None))
        ):
            raise ValueError("Unknown window indicator.")
        return self._dispatch(
            asset,
            timestep,
            indicator,
            parameters or {},
            None,
            window=bounds,
            quote=quote,
            exchange=exchange,
        )

    def _dispatch(self, asset, timestep, name, kwargs, custom_fn, *, window=None, quote=None, exchange=None):
        self._validate_causal_parameters(kwargs)
        key = self._cache_key(asset, timestep, name, kwargs) + (
            window,
            self._asset_key(quote) if quote is not None else None,
            exchange,
        )
        # SMA is a finite rolling calculation. Recursive/custom indicators
        # retain their existing full-history seeding contract; a period alone
        # is not sufficient to bound those calculations safely.
        history_length = None
        length = kwargs.get("length", 10)
        if (name == "sma" and custom_fn is None and window is None
                and isinstance(length, int) and not isinstance(length, bool) and length > 0):
            history_length = length + int(kwargs.get("offset") or 0)
        df = self._full_history(asset, timestep, quote=quote, exchange=exchange,
                                required_length=history_length)
        if df is None or df.empty:
            self._record_consumed_input(asset, timestep, None, quote=quote)
            return None
        if not isinstance(df.index, pd.DatetimeIndex) or not df.index.is_monotonic_increasing or not df.index.is_unique:
            raise ValueError("Indicator history requires a unique, increasing DatetimeIndex.")
        # Slicing OUTPUT cannot make an arbitrary calculation causal: negative
        # shifts, centered windows and custom functions can use later rows.
        # Copy also prevents a custom function from mutating the provider cache.
        now = self._strategy.get_datetime()
        end = self._position_at(df.index, now) + 1
        df = df.iloc[:end].copy()
        if window is not None:
            if df.index.tz is None:
                raise ValueError("Indicator window history requires timezone-aware timestamps.")
            df = df.loc[(df.index >= window[0]) & (df.index <= window[1])]
        elif history_length is not None:
            df = df.iloc[-history_length:]
        self._record_consumed_input(asset, timestep, df, quote=quote)
        if df.empty:
            return None
        digest = hashlib.sha256(pd.util.hash_pandas_object(df, index=True).values.tobytes()).hexdigest()
        data_tag = (tuple(df.columns), digest, custom_fn)
        cached = self._cache.get(key)
        if cached is None or cached[0] != data_tag:
            result = self._compute(df, name, kwargs, custom_fn)
            self._cache[key] = (data_tag, result)
        return self._at_current_bar(self._cache[key][1])

    def _record_consumed_input(self, asset, timestep, frame, *, quote=None):
        normalize = getattr(self._strategy, "_sanitize_user_asset", None)
        asset = normalize(asset) if callable(normalize) else asset
        broker = getattr(self._strategy, "broker", None)
        source = getattr(broker, "data_source", None)
        if getattr(broker, "option_source", None) is not None and getattr(asset, "asset_type", None) == "option":
            source = broker.option_source
        pair = getattr(self._strategy, "crypto_assets_to_tuple", None)
        if callable(pair):
            asset = pair(asset, quote if quote is not None else getattr(self._strategy, "quote_asset", None))
        record = getattr(source, "record_indicator_input", None)
        if getattr(self._strategy, "is_backtesting", False):
            from lumibot.backtesting.market_input_evidence import record_market_input

            effective_quote = quote if quote is not None else getattr(self._strategy, "quote_asset", None)
            record_market_input(source=source, asset=asset, quote=effective_quote,
                timestep=timestep, when=self._strategy.get_datetime(), frame=frame, purpose="indicator")
        if callable(record):
            record(asset=asset, timestep=timestep, frame=frame)

    @staticmethod
    def _validate_causal_parameters(kwargs):
        offset = kwargs.get("offset", 0)
        if offset is not None:
            try:
                valid_offset = np.isfinite(float(offset)) and float(offset) >= 0 and float(offset).is_integer()
            except (TypeError, ValueError, OverflowError):
                valid_offset = False
            if not valid_offset:
                raise ValueError("Only causal indicators are supported: offset must be a nonnegative integer.")
        if kwargs.get("center") or kwargs.get("lookahead"):
            raise ValueError("Only causal indicators are supported: center and lookahead must be false.")

    def _asset_key(self, asset):
        if hasattr(asset, "symbol"):
            return (asset.symbol, getattr(asset, "asset_type", None))
        return (str(asset), None)

    def _cache_key(self, asset, timestep, name, kwargs):
        kw_items = []
        for k, v in sorted(kwargs.items()):
            try:
                hash(v)
                kw_items.append((k, v))
            except TypeError:
                kw_items.append((k, repr(v)))
        return (self._asset_key(asset), timestep, name, tuple(kw_items))

    def _full_history(self, asset, timestep, *, quote=None, exchange=None,
                      required_length=None) -> pd.DataFrame | None:
        """Return the full known bar series DataFrame for ``asset``.

        In backtest mode this may contain the entire simulated dataset.
        ``_dispatch`` restricts the INPUT before computing, never just output.

        In routed/live modes ``_data_store`` is populated lazily. If it is
        empty we prefetch, then re-read the resulting full series. Known finite
        calculations request their required bars; arbitrary calculations retain
        the generous optional-history fallback. Future rows do not satisfy a
        required current window.
        """
        broker = getattr(self._strategy, "broker", None)
        data_source = getattr(broker, "data_source", None) if broker is not None else None

        df = self._read_store_df(data_source, asset, timestep, quote=quote)
        if df is not None:
            if required_length is None or not isinstance(df.index, pd.DatetimeIndex):
                return df
            if self._position_at(df.index, self._strategy.get_datetime()) + 1 >= required_length:
                return df

        try:
            history_kwargs = {"length": required_length or self._fallback_length, "timestep": timestep}
            if quote is not None:
                history_kwargs["quote"] = quote
            if exchange is not None:
                history_kwargs["exchange"] = exchange
            # Keep the Strategy owner's asset identity and resampling behavior.
            # Lightweight strategy-like clients without the private cache API
            # retain their existing public getter contract.
            prefetch = (self._strategy.get_historical_prices if required_length is not None
                        else getattr(self._strategy, "_prefetch_indicator_history", self._strategy.get_historical_prices))
            bars = prefetch(asset, **history_kwargs)
        except Exception as exc:
            logger.debug("indicators: get_historical_prices fallback failed for %s: %s", asset, exc)
            bars = None

        df = self._read_store_df(data_source, asset, timestep, quote=quote)
        if df is not None:
            return df

        if bars is None:
            return None
        return getattr(bars, "df", None)

    def _read_store_df(self, data_source, asset, timestep, *, quote=None) -> pd.DataFrame | None:
        if data_source is None or getattr(data_source, "_data_store", None) is None:
            return None
        data_obj = self._find_in_store(data_source, asset, timestep, quote=quote)
        if data_obj is None or not hasattr(data_obj, "df"):
            return None
        df = data_obj.df
        if df is None or df.empty:
            return None
        # A stored Data frame contains eventual OHLCV for the forming bar too.
        # Reuse its history-read boundary rather than treating a bar's opening
        # timestamp as the time when its final close became observable. Bare
        # provider frames keep their existing at-or-before timestamp contract.
        from lumibot.entities import Data

        if isinstance(data_obj, Data):
            _, visible_end, _ = data_obj._get_bars_row_bounds(
                self._strategy.get_datetime(), length=len(df)
            )
            return df.iloc[:visible_end]
        return df

    def _find_in_store(self, data_source, asset, timestep=None, *, quote=None):
        store = data_source._data_store

        def matches_timeframe(data):
            stored_timestep = getattr(data, "timestep", None)
            # Older/custom stores can omit timeframe metadata. When it is
            # present, never relabel daily bars as intraday (or vice versa).
            # Resampling belongs to the selected data source's history method.
            return stored_timestep is None or timestep is None or stored_timestep == timestep

        if hasattr(data_source, "find_asset_in_data_store"):
            for ts_arg in (timestep, None):
                try:
                    key = (
                        data_source.find_asset_in_data_store(asset, timestep=ts_arg)
                        if ts_arg
                        else data_source.find_asset_in_data_store(asset)
                    )
                except TypeError:
                    try:
                        key = data_source.find_asset_in_data_store(asset)
                    except Exception:
                        key = None
                except Exception:
                    key = None
                if key is not None and key in store and matches_timeframe(store[key]):
                    return store[key]
        for stored_key, data in store.items():
            stored_asset = stored_key[0] if isinstance(stored_key, tuple) else stored_key
            stored_quote = None
            if isinstance(stored_asset, tuple) and stored_asset:
                stored_asset, stored_quote = stored_asset[0], stored_asset[1] if len(stored_asset) > 1 else None
            if stored_asset == asset and (quote is None or stored_quote == quote) and matches_timeframe(data):
                return data
        return None

    def _compute(self, df, name, kwargs, custom_fn):
        if custom_fn is not None:
            return custom_fn(df, **kwargs)
        if name == "fibonacci":
            return self._fibonacci_range(df, **kwargs)
        ta = _get_ta_module()
        fn = getattr(ta, name)
        call_args = {}
        for col in ("open", "high", "low", "close", "volume"):
            if col in df.columns:
                call_args[col] = df[col]
        call_args.update(kwargs)
        # These pandas-ta indicators otherwise enable noncausal components by
        # default. An explicit true is rejected before reaching this boundary.
        if name in {"dpo", "ichimoku"}:
            call_args["lookahead"] = False
        return fn(**call_args)

    @staticmethod
    def _fibonacci_range(df, *, direction="up", length=None, **unsupported):
        if unsupported or direction not in {"up", "down"}:
            raise ValueError("Fibonacci supports direction='up'/'down' and optional positive integer length only.")
        if length is not None:
            if type(length) is not int or length <= 0:
                raise ValueError("Fibonacci length must be a positive integer.")
            if len(df) < length:
                return None
            df = df.iloc[-length:]
        if not {"high", "low"}.issubset(df.columns):
            raise ValueError("Fibonacci requires high and low observations.")
        prices = df[["high", "low"]].to_numpy(dtype=float)
        if not np.isfinite(prices).all() or (df.high < df.low).any():
            raise ValueError("Fibonacci requires finite, non-crossed high/low observations.")
        high, low = float(df.high.max()), float(df.low.min())
        values = {"high": high, "low": low}
        for ratio in (0, 0.236, 0.382, 0.5, 0.618, 0.786, 1):
            values[f"retracement_{ratio:g}"] = (
                high - (high - low) * ratio if direction == "up" else low + (high - low) * ratio
            )
        return pd.DataFrame([values], index=df.index[-1:])

    def _at_current_bar(self, result):
        now = self._strategy.get_datetime()
        if isinstance(result, pd.Series):
            return self._latest_scalar(result, now)
        if isinstance(result, pd.DataFrame):
            row = self._latest_row(result, now)
            if row is None:
                return None
            return IndicatorRow(row)
        return result

    @staticmethod
    def _position_at(index: pd.Index, now) -> int:
        """Return the integer position of the most recent bar at-or-before ``now``.

        Uses ``searchsorted`` for O(log N) lookup without allocating a slice.
        Returns -1 if no bar is on-or-before ``now``.
        """
        try:
            pos = index.searchsorted(now, side="right") - 1
        except TypeError:
            idx = index.get_indexer([now], method="pad")
            return int(idx[0]) if len(idx) else -1
        return int(pos)

    @staticmethod
    def _latest_scalar(series: pd.Series, now):
        if series.empty:
            return np.nan
        pos = Indicators._position_at(series.index, now)
        if pos < 0:
            return np.nan
        return series.iloc[pos]

    @staticmethod
    def _latest_row(df: pd.DataFrame, now):
        if df.empty:
            return None
        pos = Indicators._position_at(df.index, now)
        if pos < 0:
            return None
        return df.iloc[pos]
