"""Built-in, progressively loaded trading skills for LumiBot agents."""

from __future__ import annotations

import hashlib
from functools import lru_cache
from pathlib import Path
from typing import Any

BUILTIN_SKILL_NAMES = ("options-trading", "research-data", "stock-trading", "web-documents")
BUILTIN_SKILLS_ROOT = Path(__file__).with_name("skills")

BUILTIN_SKILL_LOADING_INSTRUCTION = (
    "Built-in skills are available through list_skills, load_skill, and "
    "load_skill_resource. Before researching, selecting, opening, modifying, "
    "closing, or managing any stock, ETF, or option position or related pending "
    "order, you MUST load the matching asset-class skill and follow it. If a broad "
    "mandate leads you to consider an asset class later, load its skill at that "
    "point before acting on the asset. Before using managed BotSpot public macro or "
    "SEC research tools, you MUST load the research-data skill and follow it. Call "
    "load_skill with the exact name: `stock-trading` for stocks and ETFs, "
    "`options-trading` for options, and `research-data` for managed research "
    "tools. Before reading websites or files (PDF, Word, Excel, CSV, ZIP) with "
    "network tools, load `web-documents` and follow it. Skill loading supplies knowledge; it does not choose a trade or "
    "override active strategy rules. Skill tools are registered separately from domain tools. "
    "If skill availability is uncertain, call list_skills or attempt load_skill with the exact built-in name "
    "before claiming it is unavailable. An omitted name in a domain-tool summary is not a failed skill lookup; "
    "report an unavailable skill only from an observed catalog or loading result."
)


def builtin_skill_directories() -> tuple[Path, ...]:
    """Return built-in skill folders in stable catalog order."""
    return tuple(BUILTIN_SKILLS_ROOT / name for name in BUILTIN_SKILL_NAMES)


@lru_cache(maxsize=1)
def builtin_skill_fingerprint() -> str:
    """Hash every model-visible built-in skill file for cache/eval provenance."""
    digest = hashlib.sha256()
    for skill_dir in builtin_skill_directories():
        for path in sorted(skill_dir.rglob("*")):
            if not path.is_file() or path.name == "openai.yaml":
                continue
            digest.update(path.relative_to(BUILTIN_SKILLS_ROOT).as_posix().encode("utf-8"))
            digest.update(b"\0")
            digest.update(path.read_bytes())
            digest.update(b"\0")
    return digest.hexdigest()


@lru_cache(maxsize=1)
def load_builtin_skills() -> tuple[Any, ...]:
    """Load the packaged ADK skill definitions once per process."""
    try:
        from google.adk.skills import load_skill_from_dir
    except ImportError as exc:  # pragma: no cover - dependency error surfaced to users
        raise RuntimeError(
            "LumiBot agent skills require google-adk 2.1.0 or newer."
        ) from exc

    skills = []
    for skill_dir in builtin_skill_directories():
        if not (skill_dir / "SKILL.md").is_file():
            raise RuntimeError(f"Packaged LumiBot skill is missing SKILL.md: {skill_dir}")
        skills.append(load_skill_from_dir(skill_dir))
    return tuple(skills)


def build_builtin_skill_toolset() -> Any:
    """Build an isolated ADK SkillToolset for one agent run."""
    try:
        from google.adk.tools.skill_toolset import SkillToolset
    except ImportError as exc:  # pragma: no cover - dependency error surfaced to users
        raise RuntimeError(
            "LumiBot agent skills require google-adk 2.1.0 or newer."
        ) from exc
    return SkillToolset(skills=list(load_builtin_skills()))


def resolve_skill_directories(
    *,
    skill_dirs: "list[str | Path] | tuple[str | Path, ...] | None" = None,
    include_builtin: bool = True,
) -> tuple[Path, ...]:
    """Resolve the skill folders one agent should load, built-ins first.

    Built-ins keep their catalog order and user skills come last, so a user
    skill can build on ours rather than being shadowed by them. Pass
    ``include_builtin=False`` to run on your own skills alone.

    Raises ValueError naming the offending path when a directory is missing or
    has no SKILL.md, because a silently ignored skill is worse than an error.
    """
    resolved: list[Path] = list(builtin_skill_directories()) if include_builtin else []
    for entry in skill_dirs or ():
        path = Path(entry).expanduser()
        if not path.is_dir():
            raise ValueError(f"Skill directory does not exist: {path}")
        if not (path / "SKILL.md").is_file():
            raise ValueError(f"Skill directory has no SKILL.md: {path}")
        resolved.append(path)
    return tuple(resolved)


def skill_fingerprint(skill_dirs: "tuple[Path, ...]") -> str:
    """Hash every model-visible file across the given skill folders.

    Used for cache keys and eval provenance. A user skill must change this or a
    receipt would claim a run used skills it did not.
    """
    digest = hashlib.sha256()
    for skill_dir in skill_dirs:
        for path in sorted(skill_dir.rglob("*")):
            if not path.is_file() or path.name == "openai.yaml":
                continue
            digest.update(str(skill_dir.name).encode("utf-8"))
            digest.update(b"\0")
            digest.update(path.relative_to(skill_dir).as_posix().encode("utf-8"))
            digest.update(b"\0")
            digest.update(path.read_bytes())
            digest.update(b"\0")
    return digest.hexdigest()


def load_skills_from_dirs(skill_dirs: "tuple[Path, ...]") -> tuple[Any, ...]:
    """Load ADK skill definitions from arbitrary folders."""
    try:
        from google.adk.skills import load_skill_from_dir
    except ImportError as exc:  # pragma: no cover - dependency error surfaced to users
        raise RuntimeError(
            "LumiBot agent skills require google-adk 2.1.0 or newer."
        ) from exc

    skills = []
    for skill_dir in skill_dirs:
        if not (skill_dir / "SKILL.md").is_file():
            raise RuntimeError(f"Skill folder is missing SKILL.md: {skill_dir}")
        skills.append(load_skill_from_dir(skill_dir))
    return tuple(skills)


def build_skill_toolset(
    *,
    skill_dirs: "list[str | Path] | tuple[str | Path, ...] | None" = None,
    include_builtin: bool = True,
) -> Any:
    """Build an isolated ADK SkillToolset from built-in and user skills."""
    try:
        from google.adk.tools.skill_toolset import SkillToolset
    except ImportError as exc:  # pragma: no cover - dependency error surfaced to users
        raise RuntimeError(
            "LumiBot agent skills require google-adk 2.1.0 or newer."
        ) from exc
    resolved = resolve_skill_directories(skill_dirs=skill_dirs, include_builtin=include_builtin)
    return SkillToolset(skills=list(load_skills_from_dirs(resolved)))
