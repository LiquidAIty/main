from __future__ import annotations

import asyncio
import contextlib
import hashlib
import importlib
import inspect
import json
import logging
import math
import os
import re
import sys
import time
import warnings
from collections.abc import Callable, Collection, Sequence
from dataclasses import dataclass
from datetime import date, datetime, timezone
from enum import Enum
from typing import Any
from uuid import UUID, uuid4

from .schemas import AgentRunResult, AgentTraceEvent, BoundTool, MCPServer
from .tool_context import agent_tool_context

_GOOGLE_SDK_NOISE_FILTERS_CONFIGURED = False
ClientSession = None
StdioServerParameters = None
stdio_client = None
streamablehttp_client = None
streamablehttp_client_uses_http_client = False


def _ensure_mcp_client_imports():
    global ClientSession, StdioServerParameters, stdio_client
    global streamablehttp_client, streamablehttp_client_uses_http_client
    if ClientSession is None or StdioServerParameters is None:
        from mcp import ClientSession as _ClientSession
        from mcp import StdioServerParameters as _StdioServerParameters

        ClientSession = _ClientSession
        StdioServerParameters = _StdioServerParameters
    if stdio_client is None:
        from mcp.client.stdio import stdio_client as _stdio_client

        stdio_client = _stdio_client
    if streamablehttp_client is None:
        try:
            from mcp.client.streamable_http import streamable_http_client as _streamablehttp_client

            streamablehttp_client_uses_http_client = True
        except ImportError:
            from mcp.client.streamable_http import streamablehttp_client as _streamablehttp_client

        streamablehttp_client = _streamablehttp_client


class _GoogleGenAITypesNoiseFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        message = record.getMessage()
        return "there are non-text parts in the response" not in message


def _configure_google_sdk_noise_filters() -> None:
    global _GOOGLE_SDK_NOISE_FILTERS_CONFIGURED
    if _GOOGLE_SDK_NOISE_FILTERS_CONFIGURED:
        return
    warnings.filterwarnings(
        "ignore",
        message="deprecated",
        category=DeprecationWarning,
        module=r"google\.adk\.runners",
    )
    warnings.filterwarnings(
        "ignore",
        message=r"Inheritance class AiohttpClientSession from ClientSession is discouraged",
        category=DeprecationWarning,
        module=r"google\.genai\._api_client",
    )
    logging.getLogger("google.genai.types").addFilter(_GoogleGenAITypesNoiseFilter())
    logging.getLogger("google_genai.types").addFilter(_GoogleGenAITypesNoiseFilter())
    _GOOGLE_SDK_NOISE_FILTERS_CONFIGURED = True


def _tool_error_payload(tool_name: str, args: dict[str, Any], exc: Exception) -> dict[str, Any]:
    payload = {
        "ok": False,
        "tool_error": True,
        "tool_name": tool_name,
        "error": {
            "type": exc.__class__.__name__,
            "message": str(exc),
        },
        "arguments": _json_safe_value(dict(args or {})),
    }
    if isinstance(exc, ToolJournalError):
        payload["error"]["code"] = "tool_journal_unavailable"
    if isinstance(exc, RemoteMCPToolError):
        payload["isError"] = True
        payload["error"]["code"] = exc.code
        if getattr(exc, "applied_arguments", None):
            payload["applied_arguments"] = _json_safe_value(exc.applied_arguments)
    return payload


def _utc_iso_timestamp() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _tool_function_name(value: str) -> str:
    normalized = re.sub(r"[^0-9a-zA-Z_]+", "_", value).strip("_")
    if not normalized:
        normalized = "tool"
    if normalized[0].isdigit():
        normalized = f"tool_{normalized}"
    return normalized


def _tool_name_space_aliases(canonical_name: str) -> list[str]:
    """Common LLM typos: a space after an underscore in the tool name.

    Example: options_find_expiration -> options_find_ expiration
    """
    parts = [part for part in str(canonical_name or "").split("_") if part != ""]
    if len(parts) < 2:
        return []
    aliases: list[str] = []
    for index in range(1, len(parts)):
        alias = "_".join(parts[:index]) + "_ " + "_".join(parts[index:])
        if alias and alias != canonical_name and alias not in aliases:
            aliases.append(alias)
    return aliases


def _clone_tool_callable(wrapper: Any, name: str) -> Any:
    def alias(*args, **kwargs):
        return wrapper(*args, **kwargs)

    alias.__name__ = name
    alias.__qualname__ = name
    alias.__doc__ = getattr(wrapper, "__doc__", None)
    signature = getattr(wrapper, "__signature__", None)
    if signature is not None:
        alias.__signature__ = signature
    annotations = getattr(wrapper, "__annotations__", None)
    if isinstance(annotations, dict):
        alias.__annotations__ = dict(annotations)
    return alias


class ToolJournalError(RuntimeError):
    """A private caller-owned audit write failed; never expose sink details."""


def agent_purpose_parameter_name(existing_names: Collection[str]) -> str:
    """Return the reserved agent-only field without consuming domain names."""
    name, suffix = "agent_purpose", 2
    while name in existing_names:
        name = f"agent_purpose_{suffix}"
        suffix += 1
    return name


def _validate_agent_purpose(supplied: Any, name: str) -> str:
    if not isinstance(supplied, str) or not supplied.strip():
        raise ValueError(f"{name} requires an explicit nonempty private purpose.")
    purpose = supplied.strip()
    try:
        byte_count = len(purpose.encode("utf-8"))
    except UnicodeEncodeError as exc:
        raise ValueError(f"{name} must be valid UTF-8 text.") from exc
    if byte_count > 500 or any(ord(char) < 32 or 127 <= ord(char) <= 159 for char in purpose):
        raise ValueError(f"{name} must be a short single-line purpose within 500 UTF-8 bytes.")
    return purpose


def _write_private_tool_audit(context: dict[str, Any], record: dict[str, Any], *, before: bool) -> None:
    callback = context.get("tool_journal_callback")
    if callback is None:
        return
    try:
        result = callback(dict(record))
        if inspect.isawaitable(result):
            # MemoryStore's existing append owner is synchronous. Reject an
            # accidental coroutine rather than pretending it was persisted.
            if inspect.iscoroutine(result):
                result.close()
            raise TypeError("The private tool journal callback must be synchronous.")
    except Exception:
        phase = "before invocation" if before else "after invocation; completion was not confirmed"
        raise ToolJournalError(f"Private tool journal write failed {phase}.") from None


def _start_agent_tool_audit(
    tool_name: str, arguments: dict[str, Any], args: tuple[Any, ...], purpose: str, context: dict[str, Any]
) -> dict[str, Any]:
    calls = context.setdefault("tool_calls", [])
    if not isinstance(calls, list):
        raise ValueError("Agent tool attempt trace is unavailable; the tool was not invoked.")
    call = {
        "tool_name": tool_name,
        "arguments": _json_safe_value(arguments),
        "purpose": purpose,
        "status": "started",
    }
    calls.append(call)
    if context.get("tool_journal_callback") is not None:
        encoded = json.dumps(
            _json_safe_value({"args": args, "kwargs": arguments}),
            sort_keys=True, separators=(",", ":"), ensure_ascii=True,
        ).encode("utf-8")
        audit = {
            "action_id": str(uuid4()), "tool_name": tool_name, "purpose": purpose,
            "status": "started", "arguments_sha256": hashlib.sha256(encoded).hexdigest(),
        }
        call["action_id"] = audit["action_id"]
        call["arguments_sha256"] = audit["arguments_sha256"]
        try:
            _write_private_tool_audit(context, audit, before=True)
        except ToolJournalError:
            call.update(status="journal_failed", ok=False)
            raise
    return call


def _finish_agent_tool_audit(call: dict[str, Any], result: Any, context: dict[str, Any], *, native: bool = False) -> None:
    if isinstance(result, dict) and isinstance(result.get("execution_outcome"), dict):
        if result["execution_outcome"].get("broker_state_certainty") == "unknown":
            call["broker_state_certainty"] = "unknown"
    failed = isinstance(result, dict) and (result.get("tool_error") is True or (native and bool(result.get("error"))))
    status = "failed" if failed else "completed"
    if "action_id" in call:
        audit = {key: call[key] for key in ("action_id", "tool_name", "purpose", "arguments_sha256")}
        audit.update(status=status, ok=not failed)
        error = result.get("error") if isinstance(result, dict) else None
        code = error.get("code") if isinstance(error, dict) else result.get("error_code") if native and isinstance(result, dict) else None
        if isinstance(code, str) and code:
            audit["error_code"] = code[:128]
        try:
            _write_private_tool_audit(context, audit, before=False)
        except ToolJournalError:
            call.update(status="journal_failed", ok=False, invocation_completed=True)
            raise
    call.update(status=status, ok=not failed)


def _wrap_tool_callable(
    tool: BoundTool,
    tool_context: dict[str, Any] | None = None,
    *,
    _purpose: str | None = None,
):
    original = tool.function

    def wrapper(*args, **kwargs):
        call_record = None
        if _purpose is not None and isinstance(tool_context, dict):
            try:
                call_record = _start_agent_tool_audit(tool.name, dict(kwargs), args, _purpose, tool_context)
            except (ValueError, ToolJournalError) as exc:
                return _tool_error_payload(tool.name, kwargs, exc)
        invocation_context = tool_context
        if _purpose is not None:
            invocation_context = {**(tool_context or {}), "tool_purpose": _purpose}
        try:
            with agent_tool_context(invocation_context):
                result = _json_safe_value(original(*args, **kwargs))
        except Exception as exc:
            result = _tool_error_payload(tool.name, kwargs, exc)
        if isinstance(tool_context, dict):
            calls = tool_context.setdefault("tool_calls", [])
            if isinstance(calls, list):
                if call_record is None:
                    call_record = {
                        "tool_name": tool.name,
                        "arguments": _json_safe_value(dict(kwargs)),
                        "ok": not (isinstance(result, dict) and result.get("tool_error") is True),
                    }
                    calls.append(call_record)
                    if isinstance(result, dict) and isinstance(result.get("execution_outcome"), dict):
                        if result["execution_outcome"].get("broker_state_certainty") == "unknown":
                            call_record["broker_state_certainty"] = "unknown"
                else:
                    try:
                        _finish_agent_tool_audit(call_record, result, tool_context)
                    except ToolJournalError as exc:
                        return _tool_error_payload(tool.name, kwargs, exc)
                if tool.name in {"account_positions", "orders_open_orders"} and isinstance(result, dict):
                    call_record["coverage"] = {
                        key: _json_safe_value(result.get(key))
                        for key in (
                            "total", "matched", "returned", "offset", "limit", "complete",
                            "next_offset", "filters", "snapshot_id",
                        )
                    }
                if tool.name in {"market_quote", "market_quotes"} and isinstance(result, dict):
                    rows = result.get("quotes", []) if tool.name == "market_quotes" else [result]
                    call_record["market_coverage"] = [row["asset"] for row in rows
                                                      if row.get("available") is True and isinstance(row.get("asset"), dict)]
        return result

    wrapper.__name__ = _tool_function_name(tool.name)
    wrapper.__qualname__ = wrapper.__name__
    wrapper.__doc__ = tool.description
    try:
        wrapper.__signature__ = inspect.signature(original)
    except (TypeError, ValueError):
        pass
    annotations = getattr(original, "__annotations__", None)
    if isinstance(annotations, dict):
        wrapper.__annotations__ = dict(annotations)
    return wrapper


def _wrap_agent_tool_callable(tool: BoundTool, tool_context: dict[str, Any] | None = None):
    """Add private purpose only to the agent-facing callable declaration.

    Public MCP schemas and ordinary BoundTool functions retain their contracts.
    Colliding domain arguments retain their names and values; only this adapter's
    independently named argument is consumed before entering cache/domain code.
    """
    ordinary = _wrap_tool_callable(tool, tool_context)
    signature = inspect.signature(ordinary)
    purpose_name = agent_purpose_parameter_name(signature.parameters)
    parameters = list(signature.parameters.values())
    purpose_parameter = inspect.Parameter(purpose_name, inspect.Parameter.KEYWORD_ONLY, annotation=str)
    position = next((i for i, parameter in enumerate(parameters) if parameter.kind is inspect.Parameter.VAR_KEYWORD), len(parameters))
    parameters.insert(position, purpose_parameter)
    context = tool_context if tool_context is not None else {}

    def wrapper(*args, **kwargs):
        supplied = kwargs.pop(purpose_name, None)
        try:
            purpose = _validate_agent_purpose(supplied, purpose_name)
            if not isinstance(context.setdefault("tool_calls", []), list):
                raise ValueError("Agent tool attempt trace is unavailable; the tool was not invoked.")
        except ValueError as exc:
            result = _tool_error_payload(tool.name, kwargs, exc)
            calls = context.setdefault("tool_calls", [])
            if isinstance(calls, list):
                calls.append({"tool_name": tool.name, "arguments": _json_safe_value(dict(kwargs)), "status": "failed", "ok": False})
            return result
        return _wrap_tool_callable(tool, context, _purpose=purpose)(*args, **kwargs)

    wrapper.__name__ = ordinary.__name__
    wrapper.__qualname__ = ordinary.__qualname__
    wrapper.__signature__ = signature.replace(parameters=parameters)
    wrapper.__annotations__ = {**getattr(ordinary, "__annotations__", {}), purpose_name: str}
    wrapper.__doc__ = (
        f"{tool.description}\n\nAgent-only argument {purpose_name}: Provide a short explicit private purpose "
        "before invoking this tool (one line, at most 500 UTF-8 bytes). This is private audit metadata, "
        "not a domain argument or a public Community reason."
    )
    return wrapper


def _agent_toolset_with_purpose(toolset: Any, context: dict[str, Any]) -> Any:
    """Adapt native ADK skills without replacing their state or resource owner."""
    from google.adk.tools.base_tool import BaseTool
    from google.adk.tools.base_toolset import BaseToolset

    class AgentPurposeTool(BaseTool):
        def __init__(self, original):
            super().__init__(
                name=original.name, description=original.description,
                is_long_running=original.is_long_running, custom_metadata=original.custom_metadata,
                behavior=original.behavior, response_scheduling=original.response_scheduling,
            )
            self.original = original
            self._defers_response = original._defers_response
            declaration = original._get_declaration()
            schema = declaration.parameters_json_schema or (declaration.parameters.model_dump(mode="json", exclude_none=True) if declaration.parameters else {})
            self.purpose_name = agent_purpose_parameter_name(schema.get("properties", {}))

        def __getattr__(self, name):
            return getattr(self.original, name)

        def _get_declaration(self):
            declaration = self.original._get_declaration().model_copy(deep=True)
            schema = declaration.parameters_json_schema
            if schema is None:
                schema = declaration.parameters.model_dump(mode="json", exclude_none=True) if declaration.parameters else {"type": "object"}
            schema.setdefault("properties", {})[self.purpose_name] = {
                "type": "string", "description": "Required short explicit private purpose (one line, at most 500 UTF-8 bytes); never public Community content."
            }
            schema["required"] = [*schema.get("required", []), self.purpose_name]
            declaration.parameters = None
            declaration.parameters_json_schema = schema
            return declaration

        async def run_async(self, *, args, tool_context):
            arguments = dict(args)
            supplied = arguments.pop(self.purpose_name, None)
            try:
                purpose = _validate_agent_purpose(supplied, self.purpose_name)
                call = _start_agent_tool_audit(self.name, arguments, (), purpose, context)
            except (ValueError, ToolJournalError) as exc:
                return _tool_error_payload(self.name, arguments, exc)
            try:
                with agent_tool_context({**context, "tool_purpose": purpose}):
                    result = await self.original.run_async(args=arguments, tool_context=tool_context)
            except Exception as exc:
                result = _tool_error_payload(self.name, arguments, exc)
            try:
                _finish_agent_tool_audit(call, result, context, native=True)
            except ToolJournalError as exc:
                return _tool_error_payload(self.name, arguments, exc)
            return result

        async def check_require_confirmation(self, args, tool_context):
            original_args = {key: value for key, value in args.items() if key != self.purpose_name}
            return await self.original.check_require_confirmation(original_args, tool_context)

        async def process_llm_request(self, *, tool_context, llm_request):
            # Preserve native resource processing (including binary resources),
            # but register this audited callable/declaration with the request.
            wrapper = self

            class RequestProxy:
                def __getattr__(self, name):
                    return getattr(llm_request, name)

                def __setattr__(self, name, value):
                    setattr(llm_request, name, value)

                def append_tools(self, tools):
                    llm_request.append_tools([wrapper if tool is wrapper.original else tool for tool in tools])

            await self.original.process_llm_request(tool_context=tool_context, llm_request=RequestProxy())

    class AgentPurposeToolset(BaseToolset):
        def __init__(self):
            # The native owner retains prefix/filter/lifecycle caches. This
            # adapter contributes every tool that owner normally exposes.
            super().__init__()
            self.wrappers = {}

        async def get_tools(self, readonly_context=None):
            tools = await toolset.get_tools(readonly_context)
            return self._wrap(tools)

        async def get_tools_with_prefix(self, readonly_context=None):
            return self._wrap(await toolset.get_tools_with_prefix(readonly_context))

        def _wrap(self, tools):
            result = []
            for tool in tools:
                key = id(tool)
                if key not in self.wrappers:
                    self.wrappers[key] = AgentPurposeTool(tool)
                result.append(self.wrappers[key])
            return result

        async def process_llm_request(self, *, tool_context, llm_request):
            await toolset.process_llm_request(tool_context=tool_context, llm_request=llm_request)

        def get_auth_config(self):
            return toolset.get_auth_config()

        async def close(self):
            await toolset.close()

    return AgentPurposeToolset()


def _is_provider_safe_function_name(name: str) -> bool:
    """Gemini function_declarations reject spaces and most punctuation."""
    text = str(name or "")
    if not text or len(text) > 128:
        return False
    if not re.match(r"^[A-Za-z_][A-Za-z0-9_.:-]*$", text):
        return False
    return True


def _normalize_tool_name_typo(name: str) -> str:
    """Collapse common LLM typos such as a space after an underscore."""
    text = str(name or "").strip()
    if not text:
        return text
    # options_find_ expiration -> options_find_expiration
    collapsed = re.sub(r"_ +", "_", text)
    collapsed = re.sub(r" +_", "_", collapsed)
    collapsed = re.sub(r"\s+", "", collapsed)
    return collapsed


def _function_tools_with_name_aliases(
    function_tool_type: Any, bound_tools: Sequence[BoundTool], tool_context: dict[str, Any] | None = None
) -> list[Any]:
    """Register only provider-safe canonical tool names.

    Space-after-underscore typos are tolerated by normalizing inbound tool names
    (see ``_normalize_tool_name_typo``). They must not be registered as Gemini
    ``function_declarations`` because names with spaces are rejected with 400
    INVALID_ARGUMENT and abort the entire agent run.
    """
    tools: list[Any] = []
    seen_names: set[str] = set()
    for bound in bound_tools:
        wrapper = _wrap_agent_tool_callable(bound, tool_context)
        canonical = wrapper.__name__
        if canonical in seen_names or not _is_provider_safe_function_name(canonical):
            continue
        tools.append(function_tool_type(wrapper))
        seen_names.add(canonical)
    return tools


def _json_safe_value(value: Any) -> Any:
    if value is None:
        return None
    if isinstance(value, bool):
        return value
    if isinstance(value, (str, int)):
        return value
    if isinstance(value, float):
        return value if math.isfinite(value) else None
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    if isinstance(value, UUID):
        return str(value)
    if isinstance(value, Enum):
        return _json_safe_value(value.value)
    if isinstance(value, list):
        return [_json_safe_value(item) for item in value]
    if isinstance(value, tuple):
        return [_json_safe_value(item) for item in value]
    if isinstance(value, dict):
        return {str(k): _json_safe_value(v) for k, v in value.items()}
    model_dump = getattr(value, "model_dump", None)
    if callable(model_dump):
        return _json_safe_value(model_dump(mode="json"))
    serializable = _to_serializable_dict(value)
    if serializable is not None:
        return {str(k): _json_safe_value(v) for k, v in serializable.items()}
    float_value = getattr(value, "__float__", None)
    if callable(float_value):
        try:
            coerced = float(value)
        except Exception:
            pass
        else:
            return coerced if math.isfinite(coerced) else None
    return str(value)


def _to_serializable_dict(value: Any) -> dict[str, Any] | None:
    if value is None:
        return None
    if isinstance(value, dict):
        return value
    if hasattr(value, "items"):
        try:
            return dict(value.items())
        except Exception:
            return None
    data = getattr(value, "__dict__", None)
    if isinstance(data, dict) and data:
        return data
    return None


def _extract_structured_content(result: Any) -> dict[str, Any]:
    if isinstance(result, dict):
        structured = (
            result.get("structuredContent")
            or result.get("structured_content")
            or result.get("output")
            or result.get("result")
        )
        if isinstance(structured, dict):
            return structured
        content = result.get("content")
        if isinstance(content, Sequence):
            for entry in content:
                if isinstance(entry, dict) and isinstance(entry.get("text"), str):
                    try:
                        parsed = json.loads(entry["text"])
                    except json.JSONDecodeError:
                        continue
                    if isinstance(parsed, dict):
                        return parsed
        return result
    structured_content = getattr(result, "structured_content", None)
    if isinstance(structured_content, dict):
        return structured_content
    return {"value": structured_content or result}


def _quiet_backtest_logs_enabled() -> bool:
    return str(os.environ.get("IS_BACKTESTING", "")).strip().lower() == "true" and str(
        os.environ.get("BACKTESTING_QUIET_LOGS", "")
    ).strip().lower() in {"1", "true", "yes", "on"}


@contextlib.contextmanager
def _mcp_errlog_stream():
    if _quiet_backtest_logs_enabled():
        with open(os.devnull, "w", encoding="utf-8") as devnull:
            yield devnull
        return
    yield sys.stderr


def _extract_tool_text(response: Any) -> list[str]:
    if response is None:
        return []
    if isinstance(response, dict):
        content = response.get("content") or response.get("contents")
    else:
        content = getattr(response, "content", None) or getattr(response, "contents", None)
    if not content:
        return []
    chunks: list[str] = []
    for entry in content:
        text_value: str | None = None
        if isinstance(entry, str):
            text_value = entry
        elif isinstance(entry, dict):
            text_value = entry.get("text")
        else:
            text_value = getattr(entry, "text", None)
        if isinstance(text_value, str) and text_value.strip():
            chunks.append(text_value.strip())
    return chunks


def _coerce_usage_metadata(value: Any) -> dict[str, Any] | None:
    if value is None:
        return None
    if isinstance(value, dict):
        return value
    data = getattr(value, "__dict__", None)
    if isinstance(data, dict):
        return {str(k): v for k, v in data.items()}
    return None


def _aggregate_usage_metadata(payloads: list[dict[str, Any]]) -> dict[str, Any] | None:
    if not payloads:
        return None
    if len(payloads) == 1:
        return payloads[0]

    aggregate: dict[str, Any] = dict(payloads[-1])
    additive_keys = {
        "cached_content_token_count",
        "cached_input_tokens",
        "cached_prompt_tokens",
        "cached_tokens",
        "cache_creation_input_tokens",
        "cache_read_input_tokens",
        "candidates_token_count",
        "completion_tokens",
        "prompt_token_count",
        "prompt_cache_hit_tokens",
        "prompt_cache_miss_tokens",
        "prompt_tokens",
        "reasoning_tokens",
        "thoughts_token_count",
        "tool_use_prompt_token_count",
        "total_token_count",
        "input_tokens",
        "output_tokens",
        "total_tokens",
    }
    for key in additive_keys:
        total = 0
        seen = False
        for payload in payloads:
            value = payload.get(key)
            if isinstance(value, bool):
                continue
            if isinstance(value, (int, float)):
                total += int(value)
                seen = True
        if seen:
            aggregate[key] = total
    aggregate["aggregated_usage_event_count"] = len(payloads)
    return aggregate


def _normalize_event(event: Any) -> list[AgentTraceEvent]:
    normalized: list[AgentTraceEvent] = []
    parts = getattr(getattr(event, "content", None), "parts", None) or []
    for part in parts:
        if getattr(part, "thought", None) is True:
            thought_text = getattr(part, "text", None)
            if isinstance(thought_text, str) and thought_text.strip():
                normalized.append(
                    AgentTraceEvent(
                        kind="thinking",
                        text=thought_text.strip(),
                        payload={"source": "model_thought"},
                    )
                )
                continue

        text = getattr(part, "text", None)
        if isinstance(text, str) and text.strip():
            normalized.append(AgentTraceEvent(kind="text", text=text.strip()))

        function_call = getattr(part, "function_call", None)
        if function_call and getattr(function_call, "name", None):
            payload = _to_serializable_dict(getattr(function_call, "args", None)) or _to_serializable_dict(
                getattr(function_call, "arguments", None)
            )
            normalized.append(
                AgentTraceEvent(
                    kind="tool_call",
                    tool_name=str(function_call.name),
                    call_id=(str(function_call.id) if getattr(function_call, "id", None) else None),
                    payload=payload,
                )
            )

        function_response = getattr(part, "function_response", None)
        if function_response and getattr(function_response, "name", None):
            tool_name = str(function_response.name)
            for chunk in _extract_tool_text(function_response.response):
                normalized.append(AgentTraceEvent(kind="text", text=chunk, tool_name=tool_name))
            normalized.append(
                AgentTraceEvent(
                    kind="tool_result",
                    tool_name=tool_name,
                    call_id=(str(function_response.id) if getattr(function_response, "id", None) else None),
                    payload=_extract_structured_content(function_response.response or {}),
                )
            )

    usage_payload = _coerce_usage_metadata(getattr(event, "usage_metadata", None))
    if usage_payload:
        normalized.append(AgentTraceEvent(kind="usage", payload=usage_payload))
    return normalized


@dataclass
class RuntimeRequest:
    agent_name: str
    model: str
    system_prompt: str
    task_prompt: str | None
    context: dict[str, Any] | None
    runtime_context: dict[str, Any] | None
    memory_state: dict[str, Any] | None
    memory_notes: list[dict[str, Any]]
    bound_tools: list[BoundTool]
    include_builtin_skills: bool = True
    builtin_skill_fingerprint: str | None = None
    model_call_id: str | None = None
    provider_prompt_cache_key: str | None = None
    model_request_timeout_seconds: float | None = None
    run_timeout_seconds: float | None = None
    max_output_tokens: int | None = None
    reasoning_effort: str | None = None
    # Optional caller-owned budget (release evals). No provider credentials or
    # account caps are modified. Each continuation gets a separate reservation.
    model_call_budget: Any | None = None
    # Private synchronous append owner supplied by the caller (e.g. MemoryStore).
    # Only bounded intent/status and original-argument hash enter this callback.
    tool_journal_callback: Callable[[dict[str, Any]], None] | None = None


_LITELLM_CONFIGURED = False


def _coerce_positive_timeout_seconds(value: Any) -> float | None:
    if value is None:
        return None
    try:
        timeout_seconds = float(value)
    except Exception:
        return None
    return timeout_seconds if timeout_seconds > 0 else None


def _parse_timeout_seconds(value: Any) -> tuple[bool, float | None]:
    if value is None:
        return False, None
    try:
        timeout_seconds = float(value)
    except Exception:
        return False, None
    return True, timeout_seconds if timeout_seconds > 0 else None


# Error classification for AI agent calls.
#
# The taxonomy has five buckets. Scope: AI agent calls only. The rest of
# LumiBot's error handling (strategy_executor, brokers, data sources) is
# unchanged. See `AgentHandle.run()` and `docsrc/agents.rst` for how these
# buckets map to backtest-vs-live behavior.
#
#   "auth"      : missing/invalid API key, permission denied (401, 403)
#   "config"    : bad model id, malformed prompt, context-window exceeded,
#                 invalid payload (400, 404, 422)
#   "billing"   : out of credits, payment required, quota exhausted (402,
#                 429 + "insufficient_quota", 403 + billing/credits msg)
#   "transient" : 5xx, rate-limit bursts, timeouts, connection errors
#   "unknown"   : anything not matched above; treated as transient (safe default)

_ERROR_CLASS_AUTH = (
    "AuthenticationError",
    "PermissionDeniedError",
    "UnauthenticatedError",
    "NotAuthorized",
)
_ERROR_CLASS_CONFIG = (
    "BadRequestError",
    "NotFoundError",
    "UnprocessableEntityError",
    "ContextWindowExceededError",
    "ContentPolicyViolationError",
    "InvalidRequestError",
    "ImportError",
    "ModuleNotFoundError",
)
_ERROR_CLASS_BILLING = (
    "BillingError",
    "InsufficientQuotaError",
    "PaymentRequiredError",
)
_ERROR_CLASS_TRANSIENT = (
    "APIConnectionError",
    "APIResponseValidationError",
    "APITimeoutError",
    "InternalServerError",
    "ServerError",
    "ServiceUnavailableError",
    "Timeout",
    "TimeoutError",
    "OverloadedError",
    "RateLimitError",
    "ServerDisconnectedError",
    "ReadTimeout",
    "ConnectTimeout",
    "ConnectionError",
)

_BILLING_BODY_KEYWORDS = (
    "insufficient_quota",
    "insufficient funds",
    "no credits",
    "no credit",
    "available credits",
    "out of credits",
    "spending limit",
    "monthly spending limit",
    "billing",
    "payment",
    "purchase those",
    "team doesn't have any credits",
    "team does not have any credits",
    "quota exceeded",
    "exceeded your current quota",
)


def _classify_agent_error(exc: BaseException) -> str:
    """Map an exception raised by the AI agent stack to a bucket.

    See the module-level docstring for the taxonomy. Safe default is
    "unknown" so behavior matches "transient" (retry/skip) when we
    cannot tell — failing closed is the wrong choice for AI errors
    because most truly-unknown failures are transient provider issues.
    """
    exc_name = exc.__class__.__name__
    message = str(exc)
    message_lower = message.lower()
    typed_code = str(getattr(exc, "code", "") or "").strip().lower()

    # Managed-gateway errors retain a machine-readable cause even though the
    # public message is deliberately sanitized. Honor that cause before the
    # gateway's HTTP 502/503 envelope would incorrectly make every failure look
    # transient. Hard quota/billing failures and invalid provider contracts are
    # actionable backtest failures, not valid no-op trading decisions.
    if typed_code == "provider_quota_exhausted":
        return "billing"
    if typed_code in {"subscription_sharing_usage_limit_exceeded", "subscription_sharing_usage_unavailable"}:
        return "billing"
    if typed_code == "eval_call_limit_exceeded":
        return "config"
    if typed_code in {
        "protocol_integrity_error",
        "subscription_stream_incomplete",
        "subscription_history_conflict",
        "subscription_call_id_missing",
    }:
        return "config"
    if typed_code in {"provider_auth_failed", "unauthorized", "renewal_failed"}:
        return "auth"
    if typed_code in {"provider_not_configured", "invalid_request"}:
        return "config"

    # HTTP status code if the provider SDK attached one.
    status_code = None
    for attr in ("status_code", "http_status", "code"):
        value = getattr(exc, attr, None)
        if isinstance(value, int):
            status_code = value
            break

    # Body/keyword check for billing — takes precedence over auth because
    # providers often return 401/403 for "no credits" when the key itself
    # is valid (e.g. xAI's "team doesn't have any credits yet").
    if any(kw in message_lower for kw in _BILLING_BODY_KEYWORDS):
        return "billing"

    # Explicit class-name matches (litellm + google-genai + openai + anthropic).
    if exc_name in _ERROR_CLASS_AUTH:
        return "auth"
    if exc_name in _ERROR_CLASS_CONFIG:
        return "config"
    if exc_name in _ERROR_CLASS_BILLING:
        return "billing"
    if exc_name in _ERROR_CLASS_TRANSIENT:
        return "transient"

    # HTTP status code based classification as a fallback.
    if status_code is not None:
        if status_code == 402:
            return "billing"
        if status_code in (401, 403):
            # Already checked billing keywords above; if we got here it's auth.
            return "auth"
        if status_code == 404:
            return "config"
        if status_code in (400, 422):
            return "config"
        if status_code == 429:
            # Rate limits are transient; insufficient_quota already caught above.
            return "transient"
        if 500 <= status_code < 600:
            return "transient"

    # Streaming Responses failures can carry a sanitized machine reason without
    # an HTTP status. Preserve explicit HTTP/auth/quota/integrity boundaries above.
    if typed_code == "server_error":
        return "transient"

    # Message substring fallback for providers that don't use standard class names.
    lower_exc = exc_name.lower()
    if any(kw in lower_exc for kw in ("auth", "permission", "unauthorized", "apikey")):
        return "auth"
    if "context" in lower_exc and ("length" in lower_exc or "window" in lower_exc):
        return "config"
    if any(kw in message_lower for kw in ("api key", "apikey", "unauthenticated", "permission denied")):
        return "auth"
    if "invalid model" in message_lower or "model not found" in message_lower:
        return "config"
    if "context length" in message_lower or "context_length" in message_lower or "context window" in message_lower:
        return "config"
    if "not json serializable" in message_lower or "not json-serializable" in message_lower:
        return "config"

    return "unknown"


_RATE_LIMIT_CLASS_NAMES = {"RateLimitError", "ResourceExhausted", "TooManyRequests", "ResourceExhaustedError"}
_RETRY_AFTER_MESSAGE_PATTERN = re.compile(
    r"(?:try again|retry)\s+(?:in|after)\s+([0-9]+(?:\.[0-9]+)?)\s*(ms|milliseconds?|s|sec|secs|seconds?)\b",
    re.IGNORECASE,
)
_RETRY_DELAY_FIELD_PATTERN = re.compile(r"retry_?delay[\"']?\s*[:=]\s*[\"']?([0-9]+(?:\.[0-9]+)?)s", re.IGNORECASE)


def _is_rate_limit_error(exc: BaseException) -> bool:
    """True for a provider rate limit (HTTP 429), not a quota/billing exhaustion."""
    if _classify_agent_error(exc) not in ("transient", "unknown"):
        return False
    if exc.__class__.__name__ in _RATE_LIMIT_CLASS_NAMES:
        return True
    # BotSpot's managed AI gateway already retried the provider's 429 and answers
    # 503 with this code once its own bounded retries are used up.
    if str(getattr(exc, "code", "") or "").strip().lower() == "provider_rate_limited":
        return True
    for attr in ("status_code", "http_status", "code", "status"):
        value = getattr(exc, attr, None)
        if value == 429 or str(value).strip() == "429":
            return True
    message = str(exc).lower()
    return "rate limit" in message or "rate_limit" in message or "resource_exhausted" in message or "too many requests" in message


def _retry_after_seconds(exc: BaseException) -> float | None:
    """Read how long the provider asked us to wait (Retry-After header or message)."""
    candidates: list[Any] = [getattr(exc, "retry_after", None)]
    response = getattr(exc, "response", None)
    headers = getattr(response, "headers", None)
    if headers is not None:
        try:
            ms_value = headers.get("retry-after-ms")
            if ms_value is not None:
                return max(float(ms_value) / 1000.0, 0.0)
        except Exception:
            pass
        try:
            candidates.append(headers.get("retry-after"))
        except Exception:
            pass
    for value in candidates:
        if value is None:
            continue
        try:
            seconds = float(value)
        except (TypeError, ValueError):
            # RFC 9110 also allows an HTTP-date ("Wed, 21 Oct 2026 07:28:00 GMT").
            try:
                from email.utils import parsedate_to_datetime

                when = parsedate_to_datetime(str(value))
                if when.tzinfo is None:
                    when = when.replace(tzinfo=timezone.utc)
                return max((when - datetime.now(timezone.utc)).total_seconds(), 0.0)
            except Exception:
                continue
        if seconds >= 0:
            return seconds
    message = str(exc)
    match = _RETRY_AFTER_MESSAGE_PATTERN.search(message)
    if match:
        amount = float(match.group(1))
        unit = match.group(2).lower()
        return amount / 1000.0 if unit.startswith("m") else amount
    match = _RETRY_DELAY_FIELD_PATTERN.search(message)
    if match:
        return float(match.group(1))
    return None


def _configure_litellm_quietly() -> None:
    # LiteLLM's provider-lookup path in get_llm_provider_logic.py prints a
    # red "Provider List: https://docs.litellm.ai/docs/providers" banner to
    # stderr on internal probes (cost/tokenizer lookups for models not in
    # litellm.model_cost). The banner is purely cosmetic: real failures
    # still raise BadRequestError. New model ids (e.g. gpt-5.4-*, grok-4.20)
    # routinely ship before LiteLLM's static registry catches up, so this
    # banner would fire on every agent call for current-generation models.
    # suppress_debug_info mutes the banner without suppressing exceptions.
    global _LITELLM_CONFIGURED
    if _LITELLM_CONFIGURED:
        return
    try:
        import litellm
    except ImportError:
        _LITELLM_CONFIGURED = True
        return
    try:
        litellm.suppress_debug_info = True
    except Exception:
        pass
    # Provider param compatibility: Google ADK's LiteLlm bridge emits
    # OpenAI-shaped params (e.g. max_completion_tokens). Some providers
    # (xAI, Anthropic, a few others) reject unknown params with
    # UnsupportedParamsError. drop_params makes LiteLLM silently drop
    # params the target provider does not accept instead of failing the
    # call. Affects only unknown kwargs; real errors still propagate.
    try:
        litellm.drop_params = True
    except Exception:
        pass
    # Transient-error retry: rate-limit (429), server errors (500/502/503/529),
    # and brief network blips all happen in normal operation. LiteLLM has
    # provider-aware retry logic (exponential backoff, 429 Retry-After
    # awareness). Enable it at the library level so every provider benefits.
    # Does NOT retry 4xx client errors (auth, invalid model, context length).
    try:
        litellm.num_retries = 3
    except Exception:
        pass
    _LITELLM_CONFIGURED = True


def _sync_xai_api_key_alias() -> None:
    """Allow Grok users to provide either the vendor key name or product name.

    LiteLLM's xAI provider reads XAI_API_KEY. LumiBot's older Grok helper also
    accepts GROK_API_KEY, so mirror GROK_API_KEY into XAI_API_KEY for xai/ models
    when the canonical xAI env var is absent.
    """
    if not os.environ.get("XAI_API_KEY") and os.environ.get("GROK_API_KEY"):
        os.environ["XAI_API_KEY"] = os.environ["GROK_API_KEY"]


def _sync_together_api_key_alias() -> None:
    """Allow either Together's SDK key name or LiteLLM's provider key name.

    Together's own examples commonly use TOGETHER_API_KEY, while LiteLLM's
    Together provider reads TOGETHERAI_API_KEY. Mirror in both directions so
    users can set either one.
    """
    if not os.environ.get("TOGETHERAI_API_KEY") and os.environ.get("TOGETHER_API_KEY"):
        os.environ["TOGETHERAI_API_KEY"] = os.environ["TOGETHER_API_KEY"]
    if not os.environ.get("TOGETHER_API_KEY") and os.environ.get("TOGETHERAI_API_KEY"):
        os.environ["TOGETHER_API_KEY"] = os.environ["TOGETHERAI_API_KEY"]


def _provider_prompt_cache_key(request: RuntimeRequest) -> str:
    """Stable provider-routing key for server-side prompt caches.

    This is not LumiBot's replay cache key. It intentionally excludes the
    changing market context so providers can reuse the static prefix
    (system prompt + tool declarations) while still computing each new bar.
    """
    payload = {
        "agent": request.agent_name,
        "model": request.model,
        "system_prompt": request.system_prompt,
        "builtin_skill_fingerprint": request.builtin_skill_fingerprint,
        "tools": [
            {
                "name": tool.name,
                "description": tool.description,
                "source": tool.source,
                "metadata": tool.metadata,
            }
            for tool in request.bound_tools
        ],
    }
    digest = hashlib.sha256(json.dumps(_json_safe_value(payload), sort_keys=True).encode("utf-8")).hexdigest()
    return f"lumibot:{request.agent_name}:{digest[:32]}"


DEFAULT_MODEL_CONTEXT_LIMIT_TOKENS = 1_000_000
DEFAULT_MODEL_CONTEXT_STRING_LIMIT_CHARS = 20_000

MODEL_CONTEXT_LIMIT_PREFIXES: tuple[tuple[str, int, int], ...] = (
    ("anthropic/claude-", 200_000, DEFAULT_MODEL_CONTEXT_STRING_LIMIT_CHARS),
    ("claude-", 200_000, DEFAULT_MODEL_CONTEXT_STRING_LIMIT_CHARS),
    ("deepseek/deepseek-v4-", 1_048_576, DEFAULT_MODEL_CONTEXT_STRING_LIMIT_CHARS),
    ("gemini-3.1", 1_048_576, DEFAULT_MODEL_CONTEXT_STRING_LIMIT_CHARS),
    ("gemini-2.5", 1_048_576, DEFAULT_MODEL_CONTEXT_STRING_LIMIT_CHARS),
    ("gemini-1.5", 1_048_576, DEFAULT_MODEL_CONTEXT_STRING_LIMIT_CHARS),
    ("openai/gpt-6-", 922_000, DEFAULT_MODEL_CONTEXT_STRING_LIMIT_CHARS),
    ("gpt-6-", 922_000, DEFAULT_MODEL_CONTEXT_STRING_LIMIT_CHARS),
    ("openai/gpt-4.1", 1_047_576, DEFAULT_MODEL_CONTEXT_STRING_LIMIT_CHARS),
    ("gpt-4.1", 1_047_576, DEFAULT_MODEL_CONTEXT_STRING_LIMIT_CHARS),
    ("xai/grok-4.20", 2_000_000, DEFAULT_MODEL_CONTEXT_STRING_LIMIT_CHARS),
    ("grok-4.20", 2_000_000, DEFAULT_MODEL_CONTEXT_STRING_LIMIT_CHARS),
)


def _positive_int_env(name: str, default: int) -> int:
    raw = os.environ.get(name)
    if raw is None:
        return default
    try:
        parsed = int(str(raw).strip())
    except (TypeError, ValueError):
        return default
    return parsed if parsed > 0 else default


def _model_context_limit_entry(model: Any) -> tuple[int, int] | None:
    if not isinstance(model, str):
        return None
    lower = model.strip().lower()
    if not lower:
        return None
    for prefix, token_limit, string_limit in MODEL_CONTEXT_LIMIT_PREFIXES:
        if lower.startswith(prefix):
            return token_limit, string_limit
    return (
        _positive_int_env("LUMIBOT_AGENT_DEFAULT_CONTEXT_LIMIT_TOKENS", DEFAULT_MODEL_CONTEXT_LIMIT_TOKENS),
        _positive_int_env("LUMIBOT_AGENT_DEFAULT_CONTEXT_STRING_LIMIT_CHARS", DEFAULT_MODEL_CONTEXT_STRING_LIMIT_CHARS),
    )


# Output-token limits (2026-10-07, customer investigation). Every agent call used to
# send max_output_tokens=65535 whatever the model, which is 4x what openai/gpt-4o
# can produce (16,384). Rob's rule: send no output length by default and let the
# model answer as long as it needs. Only providers that require one (Anthropic's
# max_tokens) get it, set to that model's real limit. An explicit value from the
# strategy is honored, capped at the model's real limit.
# Used only when an Anthropic model is missing from LiteLLM's registry (all
# current Claude models allow at least this many output tokens).
_ANTHROPIC_UNKNOWN_MODEL_OUTPUT_TOKENS = 32_000
_MODEL_OUTPUT_LIMIT_CACHE: dict[str, int | None] = {}


def _model_max_output_tokens(model: Any) -> int | None:
    """Return the model's published output-token limit, or None when unknown."""
    if not isinstance(model, str) or not model.strip():
        return None
    name = model.strip()
    if name in _MODEL_OUTPUT_LIMIT_CACHE:
        return _MODEL_OUTPUT_LIMIT_CACHE[name]
    limit: int | None = None
    # chatgpt/ selects our OAuth transport, not LiteLLM's separate login provider.
    # Metadata resolution must not authenticate or change the inference model.
    metadata_name = "openai/" + name.split("/", 1)[1] if name.startswith("chatgpt/") else name
    bare = metadata_name[len("openai/"):] if metadata_name.startswith("openai/") else metadata_name
    gpt6 = _OPENAI_GPT6_MODEL_INFO.get(bare)
    if gpt6 is not None:
        limit = int(gpt6["max_output_tokens"])
    else:
        candidates = [metadata_name]
        if _is_native_gemini_model(name):
            bare_gemini = name.split("/", 1)[-1] if name.startswith("models/") else name
            candidates = [f"gemini/{bare_gemini}", bare_gemini]
        try:
            import litellm

            for candidate in candidates:
                try:
                    info = litellm.get_model_info(candidate)
                except Exception:
                    continue
                value = info.get("max_output_tokens") or info.get("max_tokens")
                if isinstance(value, (int, float)) and value > 0:
                    limit = int(value)
                    break
        except Exception:
            limit = None
    _MODEL_OUTPUT_LIMIT_CACHE[name] = limit
    return limit


def _model_requires_max_output_tokens(model: Any) -> bool:
    """Providers whose API rejects a request without an output limit (Anthropic)."""
    if not isinstance(model, str):
        return False
    lower = model.strip().lower()
    return lower.startswith("anthropic/") or "claude" in lower


def _effective_max_output_tokens(model: Any, requested: Any) -> int | None:
    """Output-token limit to send, or None to send none (the model decides).

    Explicit values are capped at the model's real limit. With no explicit value
    only providers that require a limit get one: the model's real limit.
    """
    limit = _model_max_output_tokens(model)
    if requested is not None:
        try:
            parsed = int(requested)
        except (TypeError, ValueError):
            parsed = 0
        if parsed > 0:
            return min(parsed, limit) if limit is not None else parsed
    if _model_requires_max_output_tokens(model):
        return limit if limit is not None else _ANTHROPIC_UNKNOWN_MODEL_OUTPUT_TOKENS
    return None


def _model_context_limit_tokens(model: Any) -> int | None:
    entry = _model_context_limit_entry(model)
    if entry is None:
        return None
    return entry[0]


def _model_context_string_limit_chars(model: Any) -> int | None:
    entry = _model_context_limit_entry(model)
    if entry is None:
        return None
    return entry[1]


def _truncate_preserving_edges(text: str, max_chars: int, *, label: str) -> str:
    if len(text) <= max_chars:
        return text
    head_chars = max(max_chars // 2, 0)
    tail_chars = max(max_chars - head_chars, 0)
    omitted = len(text) - head_chars - tail_chars
    notice = (
        f"\n\n[Lumibot input context pruned {omitted} characters from {label} "
        "to stay within the receiving model context window. Beginning and end "
        "are preserved.]\n\n"
    )
    if len(notice) >= max_chars:
        notice = f"\n[Pruned {omitted} chars from {label}.]\n"
    available = max(max_chars - len(notice), 0)
    head_chars = available // 2
    tail_chars = available - head_chars
    return f"{text[:head_chars]}{notice}{text[-tail_chars:] if tail_chars else ''}"


def _prune_large_context_strings(value: Any, *, max_string_chars: int, path: str = "context") -> tuple[Any, int]:
    if isinstance(value, str):
        if len(value) <= max_string_chars:
            return value, 0
        return _truncate_preserving_edges(value, max_string_chars, label=path), 1
    if isinstance(value, dict):
        pruned = 0
        output: dict[str, Any] = {}
        for key, item in value.items():
            child, child_pruned = _prune_large_context_strings(
                item,
                max_string_chars=max_string_chars,
                path=f"{path}.{key}",
            )
            output[str(key)] = child
            pruned += child_pruned
        return output, pruned
    if isinstance(value, list):
        pruned = 0
        output = []
        for idx, item in enumerate(value):
            child, child_pruned = _prune_large_context_strings(
                item,
                max_string_chars=max_string_chars,
                path=f"{path}[{idx}]",
            )
            output.append(child)
            pruned += child_pruned
        return output, pruned
    return value, 0


def _serialized_content_length(value: Any) -> int:
    try:
        if hasattr(value, "model_dump"):
            return len(json.dumps(_json_safe_value(value.model_dump(mode="json")), sort_keys=True, default=str))
        return len(json.dumps(_json_safe_value(value), sort_keys=True, default=str))
    except Exception:
        return len(repr(value))


def _request_contents_length(contents: list[Any]) -> int:
    return sum(_serialized_content_length(content) for content in contents)


def _part_has_function_response(part: Any) -> bool:
    return getattr(part, "function_response", None) is not None


def _function_response_payload_length(part: Any) -> int:
    function_response = getattr(part, "function_response", None)
    if function_response is None:
        return 0
    return _serialized_content_length(getattr(function_response, "response", None))


def _function_response_payload_is_pruned(part: Any) -> bool:
    function_response = getattr(part, "function_response", None)
    if function_response is None:
        return False
    response = getattr(function_response, "response", None)
    if isinstance(response, dict):
        return response.get("lumibot_context_pruned") is True
    return False


def _replace_function_response_payload(part: Any, message: str) -> bool:
    function_response = getattr(part, "function_response", None)
    if function_response is None:
        return False
    original_response = getattr(function_response, "response", None)
    original_chars = _serialized_content_length(original_response)
    replacement = {
        "lumibot_context_pruned": True,
        "message": message,
    }
    if _serialized_content_length(replacement) >= original_chars:
        return False
    try:
        function_response.response = replacement
        return True
    except Exception:
        return False


def _prune_request_contents_for_context_window(
    contents: list[Any],
    *,
    context_limit_tokens: int,
    reserve_ratio: float = 3.0,
    preserve_recent_tool_results: int = 4,
    always_prune_older_tool_results: bool = False,
) -> dict[str, Any] | None:
    """Trim oversized historical tool results before provider context failure.

    This is input-side context pruning. It leaves the Lumibot system prompt,
    task, tool declarations, function-call sequence, and most recent tool
    results intact. Only older tool-result payloads are replaced, and only when
    the serialized request is already larger than a conservative provider-window
    budget.
    """
    if not contents:
        return None

    # The registry stores provider limits in tokens while this guard only has a
    # cheap serialized-character estimate. Use a conservative character budget
    # instead of pruning at a tiny percentage of the true token window.
    max_chars = int(context_limit_tokens * reserve_ratio)
    before_chars = _request_contents_length(contents)

    tool_response_parts: list[Any] = []
    for content in contents:
        for part in getattr(content, "parts", None) or []:
            if _part_has_function_response(part):
                tool_response_parts.append(part)

    should_prune_for_size = before_chars > max_chars
    should_prune_for_history = (
        always_prune_older_tool_results and len(tool_response_parts) > preserve_recent_tool_results
    )
    if not should_prune_for_size and not should_prune_for_history:
        return None

    if len(tool_response_parts) <= preserve_recent_tool_results:
        return None

    pruned = 0
    replacement_message = (
        "Older tool result omitted by Lumibot before this model call because "
        "the provider context window would otherwise be exceeded. Use the most "
        "recent visible tool results or call a targeted tool again if this older "
        "detail is still required."
    )
    candidates = [
        part
        for part in tool_response_parts[:-preserve_recent_tool_results]
        if not _function_response_payload_is_pruned(part)
    ]
    candidates.sort(key=_function_response_payload_length, reverse=True)
    for part in candidates:
        if should_prune_for_size and _request_contents_length(contents) <= max_chars:
            break
        if _replace_function_response_payload(part, replacement_message):
            pruned += 1

    after_chars = _request_contents_length(contents)
    if pruned <= 0:
        return None
    return {
        "type": "provider_context_pruning",
        "pruned_tool_results": pruned,
        "before_chars": before_chars,
        "after_chars": after_chars,
        "max_chars": max_chars,
    }


def _copy_content_without_thought_parts(content: Any) -> tuple[Any, bool]:
    parts = getattr(content, "parts", None)
    if not parts:
        return content, False
    filtered_parts = [part for part in parts if not getattr(part, "thought", False)]
    if len(filtered_parts) == len(parts):
        return content, False
    if hasattr(content, "model_copy"):
        return content.model_copy(update={"parts": filtered_parts}), True
    try:
        return type(content)(role=getattr(content, "role", None), parts=filtered_parts), True
    except Exception:
        content.parts = filtered_parts
        return content, True


def _strip_thought_parts_from_litellm_request(llm_request: Any) -> None:
    contents = getattr(llm_request, "contents", None)
    if not contents:
        return
    updated = []
    changed = False
    for content in contents:
        clean_content, content_changed = _copy_content_without_thought_parts(content)
        updated.append(clean_content)
        changed = changed or content_changed
    if changed:
        llm_request.contents = updated


# OpenAI pricing and limits, checked 2026-09-23:
# https://platform.openai.com/docs/models/gpt-6-luna
# LiteLLM 1.83 has no GPT-6 entry, so without this it rejects reasoning_effort
# and never bridges tool calls with reasoning to the Responses API, which
# OpenAI requires for GPT-6 function calling when reasoning is on.
_OPENAI_GPT6_MODEL_INFO: dict[str, dict[str, Any]] = {
    "gpt-6-luna": {
        "litellm_provider": "openai",
        "mode": "responses",
        "max_input_tokens": 922_000,
        "max_output_tokens": 128_000,
        "max_tokens": 128_000,
        "input_cost_per_token": 0.10e-6,
        "cache_read_input_token_cost": 0.01e-6,
        "cache_creation_input_token_cost": 0.125e-6,
        "output_cost_per_token": 0.50e-6,
        "supports_function_calling": True,
        "supports_parallel_function_calling": True,
        "supports_tool_choice": True,
        "supports_reasoning": True,
        "supports_prompt_caching": True,
        "supports_response_schema": True,
    },
}


def _is_priced_openai_gpt6_model(model: Any) -> bool:
    """True for a GPT-6 model whose pricing and limits are registered above."""
    name = str(model or "").strip()
    if name.startswith("openai/"):
        name = name[len("openai/"):]
    return name in _OPENAI_GPT6_MODEL_INFO


def _register_openai_gpt6_models() -> None:
    import litellm

    entries: dict[str, dict[str, Any]] = {}
    for name, info in _OPENAI_GPT6_MODEL_INFO.items():
        entries[name] = dict(info)
        entries[f"openai/{name}"] = dict(info)
    litellm.register_model(entries)


def _is_openai_gpt6_model(lower_model: str) -> bool:
    return lower_model.removeprefix("openai/").startswith("gpt-6-")


def _is_native_gemini_model(model: Any) -> bool:
    if not isinstance(model, str):
        return False
    lower = model.strip().lower()
    return lower.startswith("gemini-") or lower.startswith("models/gemini")


def _resolve_model_for_adk(
    model: Any,
    *,
    prompt_cache_key: str | None = None,
    model_request_timeout_seconds: float | None = None,
    reasoning_effort: str | None = None,
    disable_provider_retries: bool = False,
) -> Any:
    # Native Gemini IDs take ADK's fast path as plain strings. Any other
    # provider prefix (e.g. "openai/...", "xai/...", "anthropic/...") is
    # routed through google.adk.models.lite_llm.LiteLlm which normalizes
    # tool-call shapes and auth across ~100 providers via LiteLLM.
    if not isinstance(model, str):
        return model
    lower = model.strip().lower()
    if lower.startswith("chatgpt/"):
        from .chatgpt_auth import profile_path
        from .chatgpt_llm import ChatGPTPlanLlm

        slug = model.removeprefix("chatgpt/")
        if not slug or "/" in slug:
            raise ValueError("Use chatgpt/<slug> from the signed-in model catalog")
        _configure_litellm_quietly()
        _register_openai_gpt6_models()
        kwargs = {}
        if reasoning_effort is not None:
            kwargs["reasoning_effort"] = reasoning_effort
            kwargs["allowed_openai_params"] = ["reasoning_effort"]
        timeout = _coerce_positive_timeout_seconds(model_request_timeout_seconds)
        # Preserve disabled timeouts instead of restoring the transport default.
        kwargs["timeout"] = timeout
        return ChatGPTPlanLlm(model="openai/responses/" + slug, profile=profile_path(), **kwargs)
    from lumibot.components.agents.managed_gateway import (
        MANAGED_MODEL_FAMILIES,
        ManagedAiGatewayError,
        managed_gateway_available_for,
        managed_gateway_model,
    )

    if managed_gateway_available_for(model):
        return managed_gateway_model(model, reasoning_effort=reasoning_effort)
    if model in MANAGED_MODEL_FAMILIES:
        raise ManagedAiGatewayError(
            "Model families require BotSpot managed AI without a personal provider key. "
            "For direct provider/BYOK execution, select an exact provider model id.",
            code="model_resolution_required",
        )
    if _is_native_gemini_model(model):
        return model
    if lower.startswith("xai/"):
        _sync_xai_api_key_alias()
    if lower.startswith("together_ai/"):
        _sync_together_api_key_alias()
    _configure_litellm_quietly()
    try:
        from google.adk.models.lite_llm import LiteLlm
    except ImportError as exc:
        raise ImportError(
            f"Agent model '{model}' requires the 'litellm' package. "
            "Install it with: pip install 'google-adk[extensions]' litellm"
        ) from exc

    class CerebrasLiteLlm(LiteLlm):
        async def generate_content_async(self, llm_request: Any, stream: bool = False):
            # ADK 2 preserves provider reasoning as Gemini thought parts and
            # LiteLLM serializes those back to `messages.*.reasoning_content`.
            # Cerebras rejects that nonstandard message field, so strip thought
            # parts before request conversion while preserving normal text and
            # tool-call history.
            _strip_thought_parts_from_litellm_request(llm_request)
            async for response in super().generate_content_async(llm_request, stream=stream):
                yield response

    kwargs: dict[str, Any] = {}
    resolved_timeout_seconds = _coerce_positive_timeout_seconds(model_request_timeout_seconds)
    if resolved_timeout_seconds is not None:
        # google.adk.models.lite_llm.LiteLlm forwards additional args to
        # LiteLLM's acompletion call. LiteLLM accepts timeout in seconds.
        kwargs["timeout"] = resolved_timeout_seconds
    if prompt_cache_key:
        if lower.startswith("openai/"):
            # OpenAI prompt caching is automatic for long shared prefixes. The
            # key improves routing stability and 24h is the documented maximum
            # extended retention value.
            kwargs["prompt_cache_key"] = prompt_cache_key
            kwargs["prompt_cache_retention"] = "24h"
        elif lower.startswith("xai/"):
            # xAI recommends x-grok-conv-id for Chat Completions cache routing.
            kwargs["headers"] = {"x-grok-conv-id": prompt_cache_key}
    if lower.startswith("openai/") and _is_openai_gpt6_model(lower):
        _register_openai_gpt6_models()
    if reasoning_effort is not None:
        kwargs["reasoning_effort"] = reasoning_effort
        if lower.startswith("openai/"):
            kwargs["allowed_openai_params"] = ["reasoning_effort"]
    if disable_provider_retries:
        # Budgeted eval calls: a retry below ADK's callbacks would bypass the
        # per-call spending reservation, so each attempt must go through it.
        kwargs["num_retries"] = 0
        kwargs["max_retries"] = 0
    model_type = CerebrasLiteLlm if lower.startswith("cerebras/") else LiteLlm
    return model_type(model=model, **kwargs)


_BROKER_MUTATING_TOOLS = frozenset(
    {"orders_submit_order", "orders_submit_orders", "orders_submit_multileg", "orders_cancel_order", "orders_modify_order"}
)


def _trading_mutation_tool_names(request: Any) -> set[str]:
    # Audit records retain BoundTool.name even when the model-facing name is
    # normalized or aliased. Keep legacy order names for older request records.
    return set(_BROKER_MUTATING_TOOLS) | {
        tool.name
        for tool in getattr(request, "bound_tools", ())
        if (tool.metadata or {}).get("mutates_trading")
    }


def _attempt_tool_call_log(request: Any) -> list[dict[str, Any]]:
    """Per-attempt tool-call list shared between run() and _run_async()."""
    calls = getattr(request, "_attempt_tool_calls", None)
    if not isinstance(calls, list):
        calls = []
        try:
            request._attempt_tool_calls = calls
        except Exception:
            pass
    return calls


def _attempt_touched_broker(request: Any) -> bool:
    calls = getattr(request, "_attempt_tool_calls", None)
    if not isinstance(calls, list):
        return False
    mutations = _trading_mutation_tool_names(request)
    return any(isinstance(call, dict) and call.get("tool_name") in mutations for call in calls)


class GoogleADKRuntime:
    agent_tool_contract = "private-purpose-audit-v1"

    def __init__(self, mcp_servers: list[MCPServer] | None = None) -> None:
        self.mcp_servers = mcp_servers or []
        self._llm_agent_type: type[Any] | None = None
        self._runner_type: type[Any] | None = None
        self._genai_types: Any = None
        self._function_tool_type: Any = None
        self._google_genai_types: Any = None

    def _ensure_adk(self) -> tuple[type[Any], type[Any], Any, Any]:
        _configure_google_sdk_noise_filters()
        if (
            self._llm_agent_type is not None
            and self._runner_type is not None
            and self._genai_types is not None
            and self._function_tool_type is not None
        ):
            return self._llm_agent_type, self._runner_type, self._genai_types, self._function_tool_type

        llm_agent_module = importlib.import_module("google.adk.agents.llm_agent")
        runners_module = importlib.import_module("google.adk.runners")
        function_tool_module = importlib.import_module("google.adk.tools.function_tool")
        from google.genai import types as google_genai_types

        self._llm_agent_type = llm_agent_module.LlmAgent
        self._runner_type = runners_module.InMemoryRunner
        self._function_tool_type = getattr(function_tool_module, "FunctionTool")
        self._genai_types = google_genai_types
        self._google_genai_types = google_genai_types
        return self._llm_agent_type, self._runner_type, self._genai_types, self._function_tool_type

    @staticmethod
    def _maybe_build_gemini_thinking_planner(model: Any, genai_types: Any) -> Any | None:
        """Gemini 3 thought text only shows up when ADK thinking is enabled via
        BuiltInPlanner, not GenerateContentConfig.

        BotSpot already uses this path successfully. LumiBot originally tried to
        set `ThinkingConfig(include_thoughts=True)` inside
        `GenerateContentConfig`, which still yielded thought token counts but not
        explicit thought parts in normalized events. This helper mirrors the
        BotSpot pattern so real thought parts can flow through `_normalize_event`.
        """
        if not isinstance(model, str):
            return None
        lower_model = model.strip().lower()
        if not lower_model.startswith("gemini-3"):
            return None
        thinking_config_type = getattr(genai_types, "ThinkingConfig", None)
        if thinking_config_type is None:
            return None
        try:
            planners_module = importlib.import_module("google.adk.planners")
        except ImportError:
            return None
        planner_type = getattr(planners_module, "BuiltInPlanner", None)
        if planner_type is None:
            return None
        try:
            thinking_config = thinking_config_type(include_thoughts=True)
            return planner_type(thinking_config=thinking_config)
        except Exception:
            return None

    def _instruction_for(self, request: RuntimeRequest) -> str:
        lines = [request.system_prompt.strip()]
        lines.append("")
        lines.append("General rules:")
        lines.append("- Use tools for structured data and trading actions.")
        lines.append(
            "- When the user explicitly instructs you to execute an authorized action, verify the stated conditions and then invoke the action tool if they are satisfied. "
            "Do not invent new acceptance thresholds or substitute analysis, preparation, calculation, or narration for execution. "
            "A conditional action instruction authorizes the action when its stated conditions hold; it does not require a second unconditional instruction. "
            "Reviewing evidence alongside that instruction does not revoke it. Do not manufacture a separate confirmation, sizing target, or history requirement that the user and active rules did not impose. "
            "If a stated condition or real safety constraint prevents action, report it explicitly."
        )
        lines.append(
            "- Preserve discretion when the user requests analysis or delegates the choice of whether and what to trade; do not treat analysis as an execution instruction."
        )
        lines.append(
            "- Report an action as submitted only after its action tool succeeds and returns the action's identifier. Preparation or an intended order is not a submission."
        )
        lines.append(
            "- Report fills only from observed status or position evidence; never infer a fill from submission or planned quantities or prices."
        )
        if request.bound_tools:
            tool_names = ", ".join(sorted(tool.name for tool in request.bound_tools))
            lines.append(f"- Available tool names for this run: {tool_names}.")
            lines.append("- Only call tool names that appear in the available tool list for this run.")
        lines.append("- Use DuckDB when the decision requires time-series analysis and historical tables are available. A current-evidence execution mandate does not require an additional history-based signal unless the user or active rules require one.")
        lines.append(
            "- Return a short final summary of the requested outcome, observed state and any unresolved task exceptions. "
            "Do not add an unsolicited valuation reconciliation, profit/loss estimate or other optional numeric comparison to a completed action. "
            "If a derived number is required for the task or a material exception, calculate it with a tool and copy the latest returned value exactly, including its sign and decimal magnitude. "
            "The returned result overrides earlier reasoning or a drafted answer; update conflicting draft numbers before finalizing. "
            "Otherwise report the observed quantities, fills, cash and equity separately."
        )
        return "\n".join(lines).strip()

    def _before_model_context_pruning_callback(self, request: RuntimeRequest):
        context_limit = _model_context_limit_tokens(request.model)
        if not context_limit:
            return None

        def _callback(*args: Any, callback_context: Any = None, llm_request: Any = None, **_kwargs: Any) -> None:
            if llm_request is None and len(args) >= 2:
                llm_request = args[1]
            contents = getattr(llm_request, "contents", None)
            if not isinstance(contents, list):
                return None
            pruning = _prune_request_contents_for_context_window(
                contents,
                context_limit_tokens=context_limit,
            )
            if pruning:
                logging.getLogger(__name__).warning(
                    "Pruned %s older tool result payload(s) for model=%s before provider context window overflow "
                    "(request chars %s -> %s, budget %s).",
                    pruning["pruned_tool_results"],
                    request.model,
                    pruning["before_chars"],
                    pruning["after_chars"],
                    pruning["max_chars"],
                )
            return None

        return _callback

    def _model_callbacks(self, request: RuntimeRequest):
        pruning = self._before_model_context_pruning_callback(request)
        budget = request.model_call_budget
        if budget is None:
            return pruning, None
        if not (str(request.model).startswith("chatgpt/") or _is_native_gemini_model(request.model) or _is_priced_openai_gpt6_model(request.model)):
            raise ValueError(
                "Per-call eval budgeting requires a priced model: native Gemini or a registered GPT-6 model."
            )
        from .managed_gateway import managed_gateway_available_for
        if managed_gateway_available_for(request.model):
            raise ValueError("Budgeted native Gemini evals cannot use a managed gateway pricing route.")
        ticket = None

        def before(*args, **kwargs):
            nonlocal ticket
            if pruning is not None:
                pruning(*args, **kwargs)
            before_request = getattr(budget, "before_request", None)
            if callable(before_request):
                llm_request = kwargs.get("llm_request") or (args[1] if len(args) > 1 else None)
                before_request(request.model, llm_request)
            # An earlier request without usage remains reserved in the durable
            # ledger. A retry/continuation cannot spend that reservation again.
            # The eval budget reserves the worst case: the sent limit, else the model's limit.
            ticket = budget.reserve(
                request.model,
                _effective_max_output_tokens(request.model, request.max_output_tokens)
                or _model_max_output_tokens(request.model)
                or 65535,
            )

        def after(*args, llm_response=None, **kwargs):
            nonlocal ticket
            if llm_response is None and len(args) >= 2:
                llm_response = args[1]
            if getattr(llm_response, "partial", False):
                return None
            usage = _coerce_usage_metadata(getattr(llm_response, "usage_metadata", None))
            if ticket is not None and usage:
                budget.settle(ticket, usage)
                ticket = None
            return None

        return before, after

    @staticmethod
    def _unknown_tool_error_callback(*, tool: Any = None, args: Any = None, tool_context: Any = None, error: Any = None):
        """Turn a call to a tool that does not exist into a tool error the model can read.

        ADK raises ValueError for an unknown function name, which ended the whole
        run with no decision (release eval options_iron_condor_atomic_open, where
        the model invented a tool name). Returning a structured error lets the
        model call a real tool. Other errors keep their normal handling.
        """
        message = str(error or "")
        if not isinstance(error, ValueError) or "not found." not in message or not message.startswith("Tool '"):
            return None
        name = str(getattr(tool, "name", "") or "")
        available = ""
        marker = "Available tools:"
        if marker in message:
            available = message.split(marker, 1)[1].split("\n", 1)[0].strip()
        return {
            "ok": False,
            "tool_error": True,
            "unknown_tool": True,
            "tool_name": name,
            "error": {
                "type": "UnknownTool",
                "message": (
                    f"Tool {name!r} does not exist, so nothing ran. Call one of the available tools instead"
                    + (f": {available}." if available else ".")
                ),
            },
        }

    def _build_user_text(self, request: RuntimeRequest) -> str:
        sections: list[str] = []
        tool_names = {tool.name for tool in request.bound_tools}
        if request.runtime_context:
            sections.append(
                f"Runtime Context JSON:\n{json.dumps(_json_safe_value(request.runtime_context), sort_keys=True, default=str)}"
            )
        if request.bound_tools:
            sections.append(f"Available Tools JSON:\n{json.dumps(sorted(tool_names), sort_keys=True, default=str)}")
        if request.memory_state:
            sections.append(
                "Lumibot Memory State JSON:\n"
                f"{json.dumps(_json_safe_value(request.memory_state), sort_keys=True, default=str)}"
            )
        if request.memory_notes:
            memory_notes = _json_safe_value(request.memory_notes[-5:])
            context_string_limit = _model_context_string_limit_chars(request.model)
            if context_string_limit:
                memory_notes, memory_pruned = _prune_large_context_strings(
                    memory_notes,
                    max_string_chars=max(context_string_limit // 2, 1),
                    path="memory_notes",
                )
                if memory_pruned:
                    sections.append(f"Lumibot Context Notice:\nPruned {memory_pruned} oversized memory string(s).")
            sections.append(f"Persistent Memory JSON:\n{json.dumps(memory_notes, sort_keys=True, default=str)}")
        if request.task_prompt:
            sections.append(f"Task:\n{request.task_prompt.strip()}")
        else:
            sections.append(
                "Task:\n"
                "Do your normal job for the current market state. Use only the evidence and tools needed for this "
                "decision. Do not call every available data category by default. Treat a fresh, complete Runtime "
                "Context account snapshot as authoritative until an order mutation occurs. Refresh only stale, "
                "incomplete, omitted, or decision-critical account details. Prefer bounded batch tools when several "
                "related values are needed, and pass compact conclusions rather than raw histories between agents. "
                "In backtests, date-bound every external data request to the current simulated datetime and do not use "
                "future information."
            )
        if request.context:
            context_payload = _json_safe_value(request.context)
            context_string_limit = _model_context_string_limit_chars(request.model)
            if context_string_limit:
                context_payload, context_pruned = _prune_large_context_strings(
                    context_payload,
                    max_string_chars=context_string_limit,
                    path="context",
                )
                if context_pruned:
                    sections.append(f"Lumibot Context Notice:\nPruned {context_pruned} oversized context string(s).")
            sections.append(f"User Context JSON:\n{json.dumps(context_payload, sort_keys=True, default=str)}")
        return "\n\n".join(sections)

    async def _run_async(self, request: RuntimeRequest) -> AgentRunResult:
        started_at = _utc_iso_timestamp()
        started_perf = time.perf_counter()
        first_event_at: str | None = None
        first_event_perf: float | None = None
        LlmAgentType, InMemoryRunnerType, genai_types, function_tool_type = self._ensure_adk()
        run_config_module = importlib.import_module("google.adk.agents.run_config")
        tool_name_map = {_tool_function_name(tool.name): tool.name for tool in request.bound_tools}
        for canonical, original in list(tool_name_map.items()):
            for alias in _tool_name_space_aliases(canonical):
                tool_name_map.setdefault(alias, original)
                tool_name_map.setdefault(_normalize_tool_name_typo(alias), original)
        active_tool_context = {
            "agent_name": request.agent_name,
            "model_call_id": request.model_call_id,
            "tool_journal_callback": request.tool_journal_callback,
            "enforce_order_readiness": True,
            "account_snapshot": (
                request.runtime_context.get("account_snapshot") if isinstance(request.runtime_context, dict) else None
            ),
            # Shared with run() so a failed attempt can tell whether it already
            # touched the broker before deciding to retry.
            "tool_calls": _attempt_tool_call_log(request),
        }
        tools = _function_tools_with_name_aliases(
            function_tool_type,
            request.bound_tools,
            active_tool_context,
        )
        if request.include_builtin_skills:
            from .skills import build_builtin_skill_toolset

            tools.append(_agent_toolset_with_purpose(build_builtin_skill_toolset(), active_tool_context))
        config_kwargs = self._generate_content_config_kwargs_for_request(request, genai_types)
        model_request_timeout_seconds = self._model_request_timeout_seconds_for_request(request)
        run_timeout_seconds = self._run_timeout_seconds_for_request(request)
        model_timeout_label = (
            f"{model_request_timeout_seconds:g}s" if model_request_timeout_seconds is not None else "disabled"
        )
        run_timeout_label = f"{run_timeout_seconds:g}s" if run_timeout_seconds is not None else "disabled"
        try:
            sys.stderr.write(
                f"[lumibot.agents] starting agent '{request.agent_name}' "
                f"(model={request.model!r}, model_request_timeout={model_timeout_label}, "
                f"run_timeout={run_timeout_label}).\n"
            )
            sys.stderr.flush()
        except Exception:
            pass
        planner = self._maybe_build_gemini_thinking_planner(request.model, genai_types)
        before_model, after_model = self._model_callbacks(request)
        agent = LlmAgentType(
            name=request.agent_name,
            model=_resolve_model_for_adk(
                request.model,
                prompt_cache_key=request.provider_prompt_cache_key or _provider_prompt_cache_key(request),
                model_request_timeout_seconds=model_request_timeout_seconds,
                reasoning_effort=request.reasoning_effort,
                disable_provider_retries=request.model_call_budget is not None,
            ),
            instruction=self._instruction_for(request),
            tools=tools,
            generate_content_config=genai_types.GenerateContentConfig(**config_kwargs),
            planner=planner,
            before_model_callback=before_model,
            after_model_callback=after_model,
            on_tool_error_callback=GoogleADKRuntime._unknown_tool_error_callback,
        )
        runner = InMemoryRunnerType(agent=agent, app_name="lumibot-agents")
        session_id = str(uuid4())
        user_id = "lumibot-user"
        await runner.session_service.create_session(
            app_name=runner.app_name,
            user_id=user_id,
            session_id=session_id,
        )
        content = genai_types.Content(
            role="user",
            parts=[genai_types.Part(text=self._build_user_text(request))],
        )
        events: list[AgentTraceEvent] = []
        # Preserve only events actually received if a later provider call fails.
        request._attempt_events = events
        run_config = run_config_module.RunConfig(max_llm_calls=sys.maxsize - 1)
        async for event in runner.run_async(
            user_id=user_id,
            session_id=session_id,
            new_message=content,
            run_config=run_config,
        ):
            normalized_events = _normalize_event(event)
            if normalized_events and first_event_perf is None:
                first_event_perf = time.perf_counter()
                first_event_at = _utc_iso_timestamp()
                try:
                    sys.stderr.write(
                        f"[lumibot.agents] first ADK event for agent '{request.agent_name}' "
                        f"(model={request.model!r}) after "
                        f"{max(int((first_event_perf - started_perf) * 1000), 0)}ms.\n"
                    )
                    sys.stderr.flush()
                except Exception:
                    pass
            timestamp = _utc_iso_timestamp()
            for normalized_event in normalized_events:
                normalized_event.timestamp = timestamp
                if normalized_event.tool_name:
                    normalized_event.tool_name = tool_name_map.get(
                        normalized_event.tool_name,
                        tool_name_map.get(
                            _normalize_tool_name_typo(normalized_event.tool_name), normalized_event.tool_name
                        ),
                    )
            events.extend(normalized_events)
        summary = None
        text_chunks = [event.text for event in events if event.kind == "text" and event.text]
        if text_chunks:
            summary = text_chunks[-1]
        usage = _aggregate_usage_metadata(
            [event.payload for event in events if event.kind == "usage" and isinstance(event.payload, dict)]
        )
        ended_at = _utc_iso_timestamp()
        ended_perf = time.perf_counter()
        return AgentRunResult(
            summary=summary,
            model=request.model,
            events=events,
            payload={"agent_tool_contract": self.agent_tool_contract},
            usage=usage,
            started_at=started_at,
            first_event_at=first_event_at,
            ended_at=ended_at,
            latency_ms=max(int((ended_perf - started_perf) * 1000), 0),
            first_event_latency_ms=(
                max(int((first_event_perf - started_perf) * 1000), 0) if first_event_perf is not None else None
            ),
        )

    # Transient-error retry policy for the full agent call. Covers both the
    # Gemini-native path (google-genai exceptions) and the LiteLlm path
    # (network/timeouts below LiteLLM's own retry layer). LiteLLM already
    # retries individual HTTP calls 3x; this outer retry handles whole-run
    # failures like session setup errors, ADK runner glitches, and anything
    # else that bubbles up.
    #
    # Retry schedule: 10 attempts with per-step backoff capped at 60s so no
    # single wait exceeds one minute. Total budget ~= 5 minutes across all
    # attempts. Prefer more small tries over a few long ones — most cloud
    # provider 5xx storms clear within seconds or low-minutes, and a 5-min
    # budget covers the common case without leaving a live bot frozen for
    # 10 minutes on a single call. If the provider is still down after
    # this budget, the strategy-level safety net (in manager.py's
    # AgentHandle.run) catches the failure and skips this iteration so
    # the strategy stays alive and retries on the next bar.
    _MAX_RUN_ATTEMPTS = 10
    _DEFAULT_RUN_TIMEOUT_SECONDS = 1800.0
    _DEFAULT_MODEL_REQUEST_TIMEOUT_SECONDS = 600.0
    _RETRY_BACKOFF_SECONDS = (2.0, 3.0, 5.0, 10.0, 20.0, 30.0, 45.0, 60.0, 60.0, 60.0)
    # Rate limits (429): bounded retries that honor the provider's Retry-After,
    # each wait capped so a backtest cannot stall for long on one bar.
    _RATE_LIMIT_MAX_ATTEMPTS = 6
    _RATE_LIMIT_MAX_WAIT_SECONDS = 120.0

    @staticmethod
    def _model_request_timeout_seconds_for_request(request: RuntimeRequest) -> float | None:
        if request.model_request_timeout_seconds is not None:
            return _coerce_positive_timeout_seconds(request.model_request_timeout_seconds)
        raw = os.environ.get("LUMIBOT_AGENT_MODEL_REQUEST_TIMEOUT_SECONDS")
        if raw is not None:
            parsed, timeout_seconds = _parse_timeout_seconds(raw)
            if parsed:
                return timeout_seconds
        # This is the provider/model HTTP request timeout, not the full agent
        # run timeout. Multi-tool agents can still run longer via the outer
        # run timeout; one wedged model request should not.
        return GoogleADKRuntime._DEFAULT_MODEL_REQUEST_TIMEOUT_SECONDS

    @staticmethod
    def _generate_content_config_kwargs_for_request(request: RuntimeRequest, genai_types: Any) -> dict[str, Any]:
        config_kwargs: dict[str, Any] = {}
        max_output_tokens = _effective_max_output_tokens(request.model, request.max_output_tokens)
        if max_output_tokens is not None:
            config_kwargs["max_output_tokens"] = max_output_tokens
        request_timeout_seconds = GoogleADKRuntime._model_request_timeout_seconds_for_request(request)
        if _is_native_gemini_model(request.model) and request_timeout_seconds is not None:
            timeout_millis = max(int(request_timeout_seconds * 1000), 1)
            http_options_type = getattr(genai_types, "HttpOptions", None)
            if http_options_type is not None:
                config_kwargs["http_options"] = http_options_type(timeout=timeout_millis)
        if request.model_call_budget is not None:
            if str(request.model).startswith("chatgpt/") or _is_priced_openai_gpt6_model(request.model):
                # LiteLLM retries are disabled on the model itself
                # (disable_provider_retries in _resolve_model_for_adk).
                return config_kwargs
            if not _is_native_gemini_model(request.model):
                raise ValueError("Per-call eval budgeting requires native Gemini or a registered GPT-6 model.")
            options = config_kwargs.get("http_options") or genai_types.HttpOptions()
            # SDK retries happen below ADK callbacks. Disable them for budgeted
            # runs; outer retries pass through the reservation callback again.
            options.retry_options = genai_types.HttpRetryOptions(attempts=1)
            config_kwargs["http_options"] = options
        return config_kwargs

    @staticmethod
    def _max_attempts_for_request(request: RuntimeRequest) -> int:
        raw = os.environ.get("LUMIBOT_AGENT_MAX_RUN_ATTEMPTS")
        if raw:
            try:
                return max(int(raw), 1)
            except Exception:
                pass
        mutations = _trading_mutation_tool_names(request)
        if any(tool.name in mutations for tool in request.bound_tools):
            # Retrying the whole agent run after a broker-side effect can duplicate orders.
            # Research-only agents keep the larger retry budget; trading agents fail fast
            # and let the next scheduled/bar iteration re-evaluate from current broker state.
            return 1
        mode = ""
        if isinstance(request.runtime_context, dict):
            mode = str(request.runtime_context.get("mode") or "").strip().lower()
        # Backtests can multiply spend quickly because one strategy run may call
        # the model hundreds of times. Keep provider retries conservative unless
        # the user explicitly opts into a higher retry budget.
        if mode == "backtesting":
            return 2
        return GoogleADKRuntime._MAX_RUN_ATTEMPTS

    @staticmethod
    def _run_timeout_seconds_for_request(request: RuntimeRequest) -> float | None:
        if request.run_timeout_seconds is not None:
            return _coerce_positive_timeout_seconds(request.run_timeout_seconds)
        raw = os.environ.get("LUMIBOT_AGENT_RUN_TIMEOUT_SECONDS")
        if raw is not None:
            parsed, timeout_seconds = _parse_timeout_seconds(raw)
            if parsed:
                return timeout_seconds
        # Agentic trading/research runs can legitimately spend many minutes
        # across model calls and tool calls. Keep the default high enough for
        # realistic multi-tool agents while still preventing indefinite hangs.
        return GoogleADKRuntime._DEFAULT_RUN_TIMEOUT_SECONDS

    @staticmethod
    def _is_non_retryable(exc: BaseException) -> bool:
        # Use the shared classifier: only transient and unknown errors retry.
        # auth / config / billing surface immediately so we don't waste ~5
        # minutes of retry budget on a wrong API key.
        return _classify_agent_error(exc) not in ("transient", "unknown")

    async def _run_async_with_timeout(self, request: RuntimeRequest, timeout_seconds: float) -> AgentRunResult:
        try:
            return await asyncio.wait_for(self._run_async(request), timeout=timeout_seconds)
        except (TimeoutError, asyncio.TimeoutError) as exc:
            raise TimeoutError(
                f"Agent run exceeded {timeout_seconds:g}s timeout "
                f"(model={request.model!r}, agent={request.agent_name!r})."
            ) from exc

    @staticmethod
    def _rate_limit_max_attempts_for_request(request: RuntimeRequest, default_attempts: int) -> int:
        """Attempts allowed when the provider rate-limits (HTTP 429).

        A rate limit is not billed and normally clears within seconds, so it gets
        a larger bounded budget than other transient errors, even in backtests
        and for trading agents. Before 2026-10-07 a 429 in a backtest got two
        quick tries (one for trading agents) and the bar was silently skipped.
        An explicit LUMIBOT_AGENT_MAX_RUN_ATTEMPTS still wins.
        """
        if os.environ.get("LUMIBOT_AGENT_MAX_RUN_ATTEMPTS"):
            return default_attempts
        return max(default_attempts, GoogleADKRuntime._RATE_LIMIT_MAX_ATTEMPTS)

    def run(self, request: RuntimeRequest) -> AgentRunResult:
        import time as _time

        last_exc: BaseException | None = None
        max_attempts = self._max_attempts_for_request(request)
        timeout_seconds = self._run_timeout_seconds_for_request(request)
        attempt = 0
        while True:
            attempt += 1
            # Fresh per-attempt record of tool calls (see _attempt_tool_call_log).
            request._attempt_tool_calls = []
            request._attempt_events = []
            try:
                if timeout_seconds is None:
                    return asyncio.run(self._run_async(request))
                return asyncio.run(self._run_async_with_timeout(request, timeout_seconds))
            except (KeyboardInterrupt, SystemExit):
                raise
            except BaseException as exc:  # noqa: BLE001 - intentional broad catch for retry
                last_exc = exc
                if self._is_non_retryable(exc):
                    raise
                if _attempt_touched_broker(request):
                    # Retrying a whole run after an order was submitted, changed
                    # or cancelled could duplicate it. The next bar re-evaluates.
                    raise
                rate_limited = _is_rate_limit_error(exc)
                allowed_attempts = (
                    self._rate_limit_max_attempts_for_request(request, max_attempts) if rate_limited else max_attempts
                )
                if attempt >= allowed_attempts:
                    break
                delay = self._RETRY_BACKOFF_SECONDS[min(attempt - 1, len(self._RETRY_BACKOFF_SECONDS) - 1)]
                if rate_limited:
                    retry_after = _retry_after_seconds(exc)
                    if retry_after is not None:
                        delay = max(delay, min(retry_after, self._RATE_LIMIT_MAX_WAIT_SECONDS))
                try:
                    kind = "rate limit" if rate_limited else "transient error"
                    sys.stderr.write(
                        f"[lumibot.agents] {kind} on attempt {attempt}/{allowed_attempts} "
                        f"for model={request.model!r}: {exc.__class__.__name__}: {str(exc)[:240]}. "
                        f"Retrying in {delay:g}s...\n"
                    )
                    sys.stderr.flush()
                except Exception:
                    pass
                _time.sleep(delay)
        assert last_exc is not None
        raise last_exc


class StubAgentRuntime:
    def __init__(self, scripted_events: list[dict[str, Any]] | None = None) -> None:
        self.scripted_events = scripted_events or []

    def run(self, request: RuntimeRequest) -> AgentRunResult:
        if self.scripted_events:
            events = [
                AgentTraceEvent(
                    kind=event["kind"],
                    text=event.get("text"),
                    tool_name=event.get("tool_name"),
                    call_id=event.get("call_id"),
                    payload=event.get("payload"),
                    timestamp=event.get("timestamp") or _utc_iso_timestamp(),
                )
                for event in self.scripted_events
            ]
            summary = next((event.text for event in reversed(events) if event.kind == "text" and event.text), None)
            return AgentRunResult(summary=summary, model=request.model, events=events)

        events: list[AgentTraceEvent] = []
        if request.context is not None:
            events.append(
                AgentTraceEvent(
                    kind="thinking",
                    text="Stub runtime inspected the provided context.",
                    timestamp=_utc_iso_timestamp(),
                )
            )
        if request.bound_tools:
            first_tool = request.bound_tools[0]
            tool_context = {
                "agent_name": request.agent_name,
                "model_call_id": request.model_call_id,
                "enforce_order_readiness": True,
                "account_snapshot": (
                    request.runtime_context.get("account_snapshot")
                    if isinstance(request.runtime_context, dict)
                    else None
                ),
                "tool_calls": [],
            }
            if callable(first_tool.function):
                tool_result = _wrap_tool_callable(first_tool, tool_context)()
            else:
                tool_result = None
            events.append(
                AgentTraceEvent(
                    kind="tool_call",
                    tool_name=first_tool.name,
                    payload={},
                    timestamp=_utc_iso_timestamp(),
                )
            )
            payload = tool_result if isinstance(tool_result, dict) else {"value": tool_result}
            events.append(
                AgentTraceEvent(
                    kind="tool_result",
                    tool_name=first_tool.name,
                    payload=payload,
                    timestamp=_utc_iso_timestamp(),
                )
            )
        summary = "Stub agent completed run."
        events.append(
            AgentTraceEvent(
                kind="text",
                text=summary,
                timestamp=_utc_iso_timestamp(),
            )
        )
        return AgentRunResult(summary=summary, model=request.model, events=events)


def list_mcp_tools(server: MCPServer) -> list[dict[str, Any]]:
    return _run_mcp_sync(_list_mcp_tools_async, server)


def call_mcp_tool(server: MCPServer, name: str, arguments: dict[str, Any]) -> dict[str, Any]:
    return _run_mcp_sync(_call_mcp_tool_async, server, name, arguments)


def _mcp_headers(server: MCPServer) -> dict[str, str]:
    headers = {"Accept": "application/json, text/event-stream"}
    if server.headers:
        headers.update(server.headers)
    if server.auth_token_env:
        import os

        token = os.environ.get(server.auth_token_env)
        if token:
            headers["Authorization"] = f"Bearer {token}"
    return headers


class RemoteMCPToolError(RuntimeError):
    """A failed MCP result with private evidence and a bounded public message."""

    def __init__(
        self,
        tool_name: str,
        result: dict[str, Any],
        *,
        original_result: Any = None,
        secret_values: Sequence[str] = (),
    ):
        self.tool_name = tool_name
        self.result = result
        self.original_result = result if original_result is None else original_result
        self.structured_result = result.get("structuredContent")
        fields = self.structured_result if isinstance(self.structured_result, dict) else {}
        text = None
        if not fields:
            for content in result.get("content") or []:
                if isinstance(content, dict) and isinstance(content.get("text"), str):
                    text = content["text"]
                    try:
                        parsed = json.loads(text)
                    except (TypeError, ValueError):
                        break
                    if isinstance(parsed, dict):
                        fields = parsed
                    break
        nested = fields.get("error")
        nested = nested if isinstance(nested, dict) else {}
        code = fields.get("errorCode") or fields.get("code") or nested.get("code")
        code = str(code or "remote_mcp_tool_error")
        self.code = code if re.fullmatch(r"[A-Za-z0-9_.-]{1,80}", code) else "remote_mcp_tool_error"
        message = fields.get("message") or nested.get("message")
        if not isinstance(message, str):
            message = text if text and not fields else "Remote MCP server returned a failed-tool result."
        for secret in secret_values:
            if secret:
                message = message.replace(secret, "[REDACTED]")
                if secret in self.code:
                    self.code = "remote_mcp_tool_error"
        self.message = " ".join("".join(char if char.isprintable() else " " for char in message).split())[:512]
        super().__init__(f"{_tool_function_name(tool_name)[:80]} failed [{self.code}]: {self.message}")


def _mcp_error_secret_values(server: MCPServer) -> list[str]:
    values = []
    for name, value in _mcp_headers(server).items():
        normalized = name.lower().replace("-", "").replace("_", "")
        if normalized in {"authorization", "proxyauthorization"} or normalized.endswith(("key", "token", "secret")):
            values.append(str(value))
            if normalized in {"authorization", "proxyauthorization"} and " " in value:
                values.append(value.split(" ", 1)[1])
    for name, value in (server.env or {}).items():
        if any(part in name.upper() for part in ("KEY", "TOKEN", "SECRET", "PASSWORD")):
            values.append(str(value))
    return values


def _single_mcp_exception_leaf(exc: BaseException) -> BaseException | None:
    # MCP's AnyIO dependency declares the backport on Python < 3.11. Keep the
    # import local so ordinary agents do not acquire another eager SDK import.
    try:
        from builtins import BaseExceptionGroup
    except ImportError:
        from exceptiongroup import BaseExceptionGroup

    current = exc
    while isinstance(current, BaseExceptionGroup):
        if len(current.exceptions) != 1:
            return None
        current = current.exceptions[0]
    return current


_MCP_HTTP_401_PATTERN = re.compile(
    r"\b401\s+unauthori[sz]ed\b|\bunauthori[sz]ed\s*\(?401\b|\b(?:http|status(?:\s+code)?)[\s:=]+401\b",
    re.IGNORECASE,
)


def _is_mcp_auth_failure(exc: Exception) -> bool:
    # Streamable HTTP task groups can wrap the transport's HTTPStatusError.
    # Inspect the original errors so a short-lived capability can still renew.
    pending: list[BaseException] = [exc]
    visited: set[int] = set()
    while pending:
        current = pending.pop()
        if id(current) in visited:
            continue
        visited.add(id(current))
        response = getattr(current, "response", None)
        status = getattr(response, "status_code", None)
        if status == 401:
            return True
        # Without a response object, only an explicit HTTP 401 phrase counts. A bare
        # "401" inside a URL, id or port must not trigger a token renewal.
        if status is None and _MCP_HTTP_401_PATTERN.search(str(current)):
            return True
        children = getattr(current, "exceptions", ())
        if isinstance(children, (list, tuple)):
            pending.extend(child for child in children if isinstance(child, BaseException))
        pending.extend(
            child for child in (current.__cause__, current.__context__)
            if isinstance(child, BaseException)
        )
    return False


async def _refresh_mcp_auth_token(server: MCPServer, previous_token: str | None) -> bool:
    if not server.auth_token_env or not server.auth_token_refresh_url:
        return False
    import httpx

    current_token = os.environ.get(server.auth_token_env)
    if current_token and previous_token and current_token != previous_token:
        return True
    if not current_token:
        return False
    async with httpx.AsyncClient(timeout=server.timeout_seconds) as client:
        response = await client.post(
            server.auth_token_refresh_url,
            json={},
            headers={"Authorization": f"Bearer {current_token}", "Accept": "application/json"},
        )
        response.raise_for_status()
        payload = response.json()
    replacement = payload.get("accessToken") if isinstance(payload, dict) else None
    if not isinstance(replacement, str) or not replacement.strip():
        raise RuntimeError(f"MCP server {server.name!r} returned an invalid token renewal response.")
    os.environ[server.auth_token_env] = replacement.strip()
    return True


def _jsonable(value: Any) -> Any:
    value = _json_safe_value(value)
    if value is None:
        return None
    if isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, list):
        return [_jsonable(item) for item in value]
    if isinstance(value, dict):
        return {str(k): _jsonable(v) for k, v in value.items()}
    return str(value)


async def _with_mcp_session_once(server: MCPServer, callback):
    _ensure_mcp_client_imports()
    transport = (server.transport or "http").lower().replace("-", "_")
    if transport == "stdio":
        parameters = StdioServerParameters(
            command=str(server.command),
            args=list(server.args or []),
            env=dict(server.env) if server.env else None,
            cwd=server.cwd,
        )
        with _mcp_errlog_stream() as errlog:
            async with stdio_client(parameters, errlog=errlog) as (read_stream, write_stream):
                async with ClientSession(read_stream, write_stream) as session:
                    await session.initialize()
                    return await callback(session)

    headers = _mcp_headers(server)
    timeout = server.timeout_seconds
    sse_timeout = server.sse_read_timeout_seconds
    if streamablehttp_client_uses_http_client:
        import httpx
        from mcp.shared._httpx_utils import create_mcp_http_client

        http_timeout = httpx.Timeout(timeout, read=sse_timeout)
        async with create_mcp_http_client(headers=headers, timeout=http_timeout) as http_client:
            async with streamablehttp_client(
                str(server.url),
                http_client=http_client,
                terminate_on_close=server.terminate_on_close,
            ) as (read_stream, write_stream, _get_session_id):
                async with ClientSession(read_stream, write_stream) as session:
                    await session.initialize()
                    return await callback(session)
    else:
        async with streamablehttp_client(
            str(server.url),
            headers=headers,
            timeout=timeout,
            sse_read_timeout=sse_timeout,
            terminate_on_close=server.terminate_on_close,
        ) as (read_stream, write_stream, _get_session_id):
            async with ClientSession(read_stream, write_stream) as session:
                await session.initialize()
                return await callback(session)


async def _with_mcp_session(server: MCPServer, callback):
    previous_token = os.environ.get(server.auth_token_env) if server.auth_token_env else None
    try:
        return await _with_mcp_session_once(server, callback)
    except Exception as exc:
        leaf = _single_mcp_exception_leaf(exc)
        if isinstance(leaf, RemoteMCPToolError):
            if leaf is exc:
                raise
            raise leaf from None
        # A group containing independent failures is not just an expired token.
        if leaf is None:
            raise
        if not _is_mcp_auth_failure(exc) or not await _refresh_mcp_auth_token(server, previous_token):
            raise
    return await _with_mcp_session_once(server, callback)


def _run_mcp_sync(async_fn, *args):
    import asyncio

    try:
        asyncio.get_running_loop()
    except RuntimeError:
        from anyio import run as anyio_run

        return anyio_run(async_fn, *args)
    from anyio.from_thread import start_blocking_portal

    with start_blocking_portal() as portal:
        return portal.call(async_fn, *args)


async def _list_mcp_tools_async(server: MCPServer) -> list[dict[str, Any]]:
    transport = (server.transport or "http").lower().replace("-", "_")

    async def callback(session: ClientSession) -> list[dict[str, Any]]:
        result = await session.list_tools()
        tools = getattr(result, "tools", None) or []
        normalized: list[dict[str, Any]] = []
        for tool in tools:
            dumped = _jsonable(tool)
            if isinstance(dumped, dict):
                normalized.append(dumped)
        return normalized

    if transport == "http":
        return await _legacy_http_list_tools(server)
    return await _with_mcp_session(server, callback)


async def _call_mcp_tool_async(server: MCPServer, name: str, arguments: dict[str, Any]) -> dict[str, Any]:
    transport = (server.transport or "http").lower().replace("-", "_")

    async def callback(session: ClientSession) -> dict[str, Any]:
        result = await session.call_tool(name, arguments or {})
        dumped = _jsonable(result)
        if not isinstance(dumped, dict):
            raise RuntimeError(f"{name} returned unexpected payload: {dumped!r}")
        if dumped.get("isError") is True:
            raise RemoteMCPToolError(
                name, dumped, original_result=result, secret_values=_mcp_error_secret_values(server)
            )
        return dumped

    if transport == "http":
        return await _legacy_http_call_tool(server, name, arguments)
    return await _with_mcp_session(server, callback)


async def _legacy_http_list_tools(server: MCPServer) -> list[dict[str, Any]]:
    import httpx

    payload = {
        "jsonrpc": "2.0",
        "id": "tools-list",
        "method": "tools/list",
        "params": {},
    }
    async with httpx.AsyncClient(timeout=server.timeout_seconds) as client:
        previous_token = os.environ.get(server.auth_token_env) if server.auth_token_env else None
        response = await client.post(str(server.url), json=payload, headers=_mcp_headers(server))
        if response.status_code == 401 and await _refresh_mcp_auth_token(server, previous_token):
            response = await client.post(str(server.url), json=payload, headers=_mcp_headers(server))
        response.raise_for_status()
        data = response.json()
    result = data.get("result") or {}
    tools = result.get("tools") or []
    return tools if isinstance(tools, list) else []


async def _legacy_http_call_tool(server: MCPServer, name: str, arguments: dict[str, Any]) -> dict[str, Any]:
    import httpx

    payload = {
        "jsonrpc": "2.0",
        "id": f"{name}-call",
        "method": "tools/call",
        "params": {"name": name, "arguments": arguments},
    }
    async with httpx.AsyncClient(timeout=server.timeout_seconds) as client:
        previous_token = os.environ.get(server.auth_token_env) if server.auth_token_env else None
        response = await client.post(str(server.url), json=payload, headers=_mcp_headers(server))
        if response.status_code == 401 and await _refresh_mcp_auth_token(server, previous_token):
            response = await client.post(str(server.url), json=payload, headers=_mcp_headers(server))
        response.raise_for_status()
        data = response.json()
    if "error" in data:
        raise RuntimeError(f"{name} failed: {data['error']}")
    result = data.get("result") or {}
    if not isinstance(result, dict):
        raise RuntimeError(f"{name} returned unexpected payload: {result!r}")
    if result.get("isError") is True:
        raise RemoteMCPToolError(name, result, secret_values=_mcp_error_secret_values(server))
    return result
