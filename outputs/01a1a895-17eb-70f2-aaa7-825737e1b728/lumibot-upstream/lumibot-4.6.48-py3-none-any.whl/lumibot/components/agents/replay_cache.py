from __future__ import annotations

import gzip
import hashlib
import inspect
import json
import os
import sys
from datetime import date, datetime
from decimal import Decimal
from enum import Enum
from functools import lru_cache
from importlib import metadata
from pathlib import Path
from typing import Any
from uuid import UUID

from lumibot.constants import LUMIBOT_CACHE_FOLDER

_BACKTEST_CACHE_GETTER = None


@lru_cache(maxsize=1)
def _installed_distributions() -> tuple[tuple[str, str], ...]:
    """Public package identities only; never environment variables or paths."""
    return tuple(sorted({
        (str(dist.metadata.get("Name") or "").lower(), dist.version)
        for dist in metadata.distributions()
    }))


@lru_cache(maxsize=128)
def _source_digest(path: str, modified: int, size: int) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def runtime_capability_fingerprint(tools: Any, runtime: Any) -> dict[str, Any]:
    """Bind replay to installed dependencies and the actual callable sources.

    Package versions alone miss editable installs. Source hashes cover those
    without putting local paths or configuration secrets in replay payloads.
    """
    implementations = {}
    functions = [tool.function for tool in tools]
    runtime_run = getattr(runtime, "run", None)
    if callable(runtime_run):
        functions.append(runtime_run)
    for function in functions:
        module = inspect.getmodule(inspect.unwrap(function))
        path = getattr(module, "__file__", None)
        if module is None or not path:
            continue
        try:
            stat = Path(path).stat()
            implementations[module.__name__] = _source_digest(path, stat.st_mtime_ns, stat.st_size)
        except OSError:
            implementations[module.__name__] = None
    return {
        "python": list(sys.version_info[:3]),
        "dependencies": _installed_distributions(),
        "implementations": implementations,
    }


def has_failed_tool_result(cached: dict[str, Any]) -> bool:
    """Failed evidence remains saved, but must not prevent fresh recovery."""
    for event in cached.get("events") or []:
        if event.get("kind") != "tool_result":
            continue
        result = event.get("payload")
        if isinstance(result, dict) and (
            result.get("tool_error") is True or result.get("ok") is False or result.get("isError") is True
        ):
            return True
    return False


def get_backtest_cache():
    global _BACKTEST_CACHE_GETTER
    if _BACKTEST_CACHE_GETTER is None:
        from lumibot.tools.backtest_cache import get_backtest_cache as _get_backtest_cache

        _BACKTEST_CACHE_GETTER = _get_backtest_cache
    return _BACKTEST_CACHE_GETTER()


def _normalize_json(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, dict):
        return {str(key): _normalize_json(val) for key, val in sorted(value.items(), key=lambda item: str(item[0]))}
    if isinstance(value, Enum):
        return value.value
    if isinstance(value, set):
        return sorted(_normalize_json(item) for item in value)
    if isinstance(value, (list, tuple)):
        return [_normalize_json(item) for item in value]
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    if isinstance(value, UUID):
        return str(value)
    if isinstance(value, Decimal):
        return float(value)
    data = getattr(value, "__dict__", None)
    if isinstance(data, dict):
        return {str(key): _normalize_json(val) for key, val in sorted(data.items(), key=lambda item: str(item[0]))}
    if hasattr(value, "to_dict"):
        try:
            return _normalize_json(value.to_dict())
        except Exception:
            return str(value)
    if hasattr(value, "to_minimal_dict"):
        try:
            return _normalize_json(value.to_minimal_dict())
        except Exception:
            return str(value)
    return str(value)


def _cache_root() -> Path:
    return Path(os.environ.get("LUMIBOT_CACHE_FOLDER") or LUMIBOT_CACHE_FOLDER)


class AgentReplayCache:
    def __init__(self) -> None:
        self.root = _cache_root() / "agent_runtime" / "replay"
        self.root.mkdir(parents=True, exist_ok=True)
        self.remote_cache = get_backtest_cache()

    def compute_key(self, payload: dict[str, Any]) -> str:
        normalized = _normalize_json(payload)
        encoded = json.dumps(normalized, sort_keys=True, separators=(",", ":"), ensure_ascii=True)
        return hashlib.sha256(encoded.encode("utf-8")).hexdigest()

    def _path_for(self, key: str) -> Path:
        return self.root / key[:2] / f"{key}.json.gz"

    def load(self, key: str) -> dict[str, Any] | None:
        path = self._path_for(key)
        path.parent.mkdir(parents=True, exist_ok=True)
        self.remote_cache.ensure_local_file(path)
        if not path.exists():
            return None
        with gzip.open(path, "rt", encoding="utf-8") as handle:
            return json.load(handle)

    def save(self, key: str, payload: dict[str, Any]) -> Path:
        path = self._path_for(key)
        path.parent.mkdir(parents=True, exist_ok=True)
        with gzip.open(path, "wt", encoding="utf-8") as handle:
            json.dump(_normalize_json(payload), handle, sort_keys=True)
        self.remote_cache.on_local_update(path)
        return path
