from __future__ import annotations

import math
import os
import re
import time
import warnings

from lumibot._lazy_imports import LazyModule, lazy_class, lazy_typing
from lumibot.data_sources.exceptions import UnsupportedAsset

from ._strategy import IS_BACKTESTING, _Strategy

LUMIBOT_DEFAULT_TIMEZONE = "America/New_York"
_INFO_LEVEL = 20
_DEFAULT_QUOTE_ASSET = object()
TYPE_CHECKING = False

if TYPE_CHECKING:
    from ..data_sources import DataSource
    from ..entities import Data, Position, Quote
    from ..traders import Trader

np = LazyModule("numpy")
pd = LazyModule("pandas")
datetime = LazyModule("datetime")
mcal = LazyModule("pandas_market_calendars")
Asset = lazy_class("lumibot.entities", "Asset")
Data = lazy_class("lumibot.entities", "Data")
DataSource = lazy_class("lumibot.data_sources", "DataSource")
Order = lazy_class("lumibot.entities", "Order")
Position = lazy_class("lumibot.entities", "Position")
Quote = lazy_class("lumibot.entities", "Quote")
SmartLimitConfig = lazy_class("lumibot.entities", "SmartLimitConfig")
Trader = lazy_class("lumibot.traders", "Trader")
TradingFee = lazy_class("lumibot.entities", "TradingFee")
TradingSlippage = lazy_class("lumibot.entities", "TradingSlippage")
Decimal = lazy_class("decimal", "Decimal")
Callable = lazy_typing("Callable")
List = lazy_typing("List")
Optional = lazy_typing("Optional")
Type = lazy_typing("Type")
Union = lazy_typing("Union")


def _default_pytz():
    from ..constants import LUMIBOT_DEFAULT_PYTZ

    return LUMIBOT_DEFAULT_PYTZ


def get_risk_free_rate(*args, **kwargs):
    from ..tools import get_risk_free_rate as _get_risk_free_rate

    return _get_risk_free_rate(*args, **kwargs)


def is_color_like(*args, **kwargs):
    from matplotlib.colors import is_color_like as _is_color_like

    return _is_color_like(*args, **kwargs)


def _smart_limit_config():
    from ..entities import SmartLimitConfig

    return SmartLimitConfig


def build_price_ladder(*args, **kwargs):
    from ..tools.smart_limit_utils import build_price_ladder as _impl

    return _impl(*args, **kwargs)


def compute_final_price(*args, **kwargs):
    from ..tools.smart_limit_utils import compute_final_price as _impl

    return _impl(*args, **kwargs)


def compute_final_price_from_mid(*args, **kwargs):
    from ..tools.smart_limit_utils import compute_final_price_from_mid as _impl

    return _impl(*args, **kwargs)


def compute_mid(*args, **kwargs):
    from ..tools.smart_limit_utils import compute_mid as _impl

    return _impl(*args, **kwargs)


def infer_tick_size(*args, **kwargs):
    from ..tools.smart_limit_utils import infer_tick_size as _impl

    return _impl(*args, **kwargs)


def round_to_tick(*args, **kwargs):
    from ..tools.smart_limit_utils import round_to_tick as _impl

    return _impl(*args, **kwargs)


def _logging_warning(*args, **kwargs):
    import logging

    return logging.warning(*args, **kwargs)


def _colored(*args, **kwargs):
    from termcolor import colored

    return colored(*args, **kwargs)


def _termcolor_colors():
    from termcolor import COLORS

    return COLORS


def _inspect_module():
    import inspect

    return inspect


def _uuid4_hex():
    import uuid

    return uuid.uuid4().hex


def _position_class():
    from ..entities import Position

    return Position


def _quote_class():
    from ..entities import Quote

    return Quote


def _trader_class():
    trader_cls = globals().get("Trader")
    if trader_cls is not None:
        return trader_cls

    from ..traders import Trader

    return Trader


_LAZY_ENTITY_EXPORTS = {
    "Position": _position_class,
    "Quote": _quote_class,
    "Trader": _trader_class,
}


def __getattr__(name):
    factory = _LAZY_ENTITY_EXPORTS.get(name)
    if factory is None:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
    value = factory()
    globals()[name] = value
    return value


class Strategy(_Strategy):
    @property
    def name(self):
        """Returns the name of the strategy.

        Returns:
            str: The name of the strategy.

        Example
        -------
        >>> self.log_message(f'Strategy name: {self.name}')
        """
        return self._name

    @property
    def initial_budget(self):
        """Returns the strategy's starting value.

        In backtests this is the configured starting cash. In live trading it is
        the first broker-verified portfolio equity snapshot, including existing
        positions; it is not merely the account's cash balance.

        Returns:
            float: Starting backtest cash or live account equity.

        Example
        -------
        >>> self.log_message(f'Strategy initial budget: {self.initial_budget}')
        """
        return self._initial_budget

    @property
    def quote_asset(self):
        """Returns the quote asset for the strategy. The quote asset is what is considered
        "cash" (as in `self.cash`), and it is the currency that `self.portfolio_value` uses.

        Returns:
            Asset: The quote asset for the strategy

        Example
        -------
        >>> self.log_message(f"The quote asset for this strategy is {self.quote_asset}")
        """
        return self._quote_asset

    @quote_asset.setter
    def quote_asset(self, value):
        self._quote_asset = value
        self.broker.quote_assets.add(value)

    @property
    def last_on_trading_iteration_datetime(self):
        """Returns the datetime of the last iteration.

        Returns:
            datetime: The datetime of the last iteration.

        Example
        -------
        >>> self.log_message(f'The last trading iteration happened at: {self.last_on_trading_iteration_datetime}')
        """
        return self._last_on_trading_iteration_datetime

    @property
    def minutes_before_opening(self):
        # noinspection PyShadowingNames
        """
        Get or set the number of minutes that the strategy will start executing before the market opens.
        The lifecycle method before_market_opens is executed minutes_before_opening minutes before the market opens.
        By default, equals to 60 minutes.

        Returns
        -------
        int
            The number of minutes before the market opens.

        Example
        -------
        >>> # Set the number of minutes before the market opens
        >>> self.minutes_before_opening = 10

        >>> # Set the number of minutes before the market opens to 0 in the initialize method
        >>> def initialize(self):
        >>>     self.minutes_before_opening = 0

        """
        return self._minutes_before_opening

    @minutes_before_opening.setter
    def minutes_before_opening(self, value):
        self._minutes_before_opening = value

    @property
    def minutes_before_closing(self):
        """Get or set the number of minutes that the strategy will stop executing before market closes.

        The lifecycle method on_trading_iteration is executed inside a loop that stops only when there is only minutes_before_closing minutes remaining before market closes. By default equals to 5 minutes.

        Returns
        -------
        minutes_before_closing : int
            The number of minutes before market closes that the strategy will stop executing.

        Example
        -------
        >>> # Set the minutes before closing to 5
        >>> self.minutes_before_closing = 5

        >>> # Get the minutes before closing
        >>> self.log_message(self.minutes_before_closing)

        >>> # Set the minutes before closing to 10 in the initialize method
        >>> def initialize(self):
        >>>     self.minutes_before_closing = 10
        """
        return self._minutes_before_closing

    @minutes_before_closing.setter
    def minutes_before_closing(self, value):
        self._minutes_before_closing = value

    @property
    def minutes_after_closing(self):
        """Get or set the number of minutes that the strategy will continue executing after market closes.

        The lifecycle method after_market_closes is executed minutes_after_closing minutes after the market closes. By default, equals to 0 minutes.

        Returns
        -------
        int
            The number of minutes after the market closes that the strategy will continue executing.

        Example
        -------
        >>> # Set the number of minutes after the market closes
        >>> self.minutes_after_closing = 10

        >>> # Set the number of minutes after the market closes to 0 in the initialize method
        >>> def initialize(self):
        >>>     self.minutes_after_closing = 0

        """
        return self._minutes_after_closing

    @minutes_after_closing.setter
    def minutes_after_closing(self, value):
        self._minutes_after_closing = value

    @property
    def sleeptime(self):
        """Get or set the current sleep time for the strategy.

        Sleep time is the time the program will pause between executions of on_trading_iteration and trace_stats.
        This is used to control the speed of the program.

        By default, equals 1 minute. You can set the sleep time as an integer which will be interpreted as
        minutes. eg: sleeptime = 50 would be 50 minutes. Conversely, you can enter the time as a string with
        the duration numbers first, followed by the time units: 'M' for minutes, 'S' for seconds
        eg: '300S' is 300 seconds, '10M' is 10 minutes.

        Returns
        -------
        sleeptime : int or str
            Sleep time in minutes or a string with the duration numbers first, followed by the time
            units: `S` for seconds, `M` for minutes, `H` for hours' or `D` for days.

        Example
        -------
        >>> # This is usually used in the initialize method

        >>> # Set the sleep time to 5 minutes in the initialize method
        >>> def initialize(self): # Your initialize lifecycle method
        >>>     self.sleeptime = '5M'

        >>> # Set the sleep time to 10 seconds in the initialize method
        >>> def initialize(self): # Your initialize lifecycle method
        >>>     self.sleeptime = '10S'

        >>> # Set the sleeptime to 10 minutes
        >>> self.sleeptime = 10

        >>> # Set the sleeptime to 300 seconds
        >>> self.sleeptime = "300S"

        >>> # Set the sleep time to 5 minutes
        >>> self.sleeptime = 5

        >>> # Set the sleep time to 5 seconds
        >>> self.sleeptime = "5S"

        >>> # Set the sleep time to 2 hours
        >>> self.sleeptime = "2H"

        >>> # Set the sleep time to 2 days
        >>> self.sleeptime = "2D"
        """
        return self._sleeptime

    @sleeptime.setter
    def sleeptime(self, value):
        self._sleeptime = value

    @property
    def backtesting_start(self):
        return self._backtesting_start

    @property
    def backtesting_end(self):
        return self._backtesting_end

    @property
    def unspent_money(self):
        """Deprecated, will be removed in the future. Please use `self.cash` instead."""
        return self.cash

    @property
    def portfolio_value(self):
        """
        Returns the last portfolio value (cash + positions value) reported by the broker. Does
        not query the broker for an updated value. To get the current broker value, use
        `self.get_portfolio_value()`.

        Returns the portfolio value of positions plus cash in US dollars.

        Crypto markets will attempt to resove to US dollars as a quote
        currency.

        Returns
        -------
        portfolio_value : float
            The current portfolio value. Includes the actual values of shares held by the current strategy plus the total cash.

        Example
        -------
        >>> # Get the last seen portfolio value
        >>> self.log_message(self.portfolio_value)

        """
        return self._portfolio_value

    @portfolio_value.setter
    def portfolio_value(self, value):
        self._portfolio_value = value

    @property
    def cash(self):
        """Returns the current cash. This is the money that is not used for positions or
        orders (in other words, the money that is available to buy new assets, or cash).

        This property is updated whenever a transaction was filled by the broker or when dividends
        are paid.

        Crypto currencies are a form of cash. Therefore cash will always be zero.

        Returns
        -------
        cash : float
            The current cash.

        Example
        -------
        >>> # Get the current cash available in the account
        >>> self.log_message(self.cash)
        """

        self.update_broker_balances(force_update=False)

        cash_position = self._get_cash_position()
        quantity = cash_position.quantity if cash_position else None

        # This is not really true:
        # if quantity is None:
        #     self._set_cash_position(0)
        #     quantity = 0

        if isinstance(quantity, Decimal):
            quantity = float(quantity)
        elif quantity is None:
            quantity = 0.0

        return quantity

    @property
    def first_iteration(self):
        """Returns True if this is the first iteration of the strategy (is True if the lifecycle
        method on_trading_iteration is being excuted for the first time).

        Returns
        -------
        first_iteration : bool
            True if this is the first iteration of the strategy.

        Example
        -------
        >>> # Check if this is the first iteration
        >>> if self.first_iteration:
        >>>     self.log_message("This is the first iteration")
        """
        return self._first_iteration

    @property
    def stats_file(self):
        return self._stats_file

    @property
    def stats(self):
        return self._stats

    @property
    def analysis(self):
        return self._analysis

    @property
    def risk_free_rate(self) -> float:
        if self._risk_free_rate is not None:
            return self._risk_free_rate
        else:
            # Use the yahoo data to get the risk free rate, or 0 if None is returned
            now = self.get_datetime()
            return get_risk_free_rate(now) or 0.0

    # ======= Helper Methods =======================

    def log_message(self, message: str, color: str = None, broadcast: bool = False):
        """Logs an info message prefixed with the strategy name.

        Uses python logging to log the message at the `info` level.
        Logging goes to the logging file, not the console.

        Parameters
        ----------
        message : str
            String message for logging.

        color : str
            Color of the message. Eg. `"red"` or `"green"`.

        broadcast : bool
            If True, the message will be broadcasted to any connected message services.

        Returns
        -------
        message : str
            Strategy name plus the original message.

        Example
        --------
        >>> self.log_message('Sending a buy order')
        """

        if broadcast:
            # Send the message to Discord
            self.send_discord_message(message)

        # Performance optimization: skip work if INFO is not enabled.
        # This respects BACKTESTING_QUIET_LOGS via StrategyLoggerAdapter.isEnabledFor().
        if not self.logger.isEnabledFor(_INFO_LEVEL):
            return message

        if color:
            if color in _termcolor_colors():
                colored_message = _colored(message, color)
                self.logger.info(colored_message)
            else:
                self.logger.warning(f"Unsupported log color '{color}' for message: {message}")
                self.logger.info(message)
        else:
            self.logger.info(message)

        return message

    # ====== Order Methods ===============

    def create_order(
        self,
        asset: Union[str, Asset],
        quantity: Union[int, str, Decimal],
        side: str,
        limit_price: float = None,
        stop_price: float = None,
        stop_limit_price: float = None,
        trail_price: float = None,
        trail_percent: float = None,
        secondary_limit_price: float = None,
        secondary_stop_price: float = None,
        secondary_stop_limit_price: float = None,
        secondary_trail_price: float = None,
        secondary_trail_percent: float = None,
        time_in_force: str = "gtc",
        good_till_date: datetime.datetime = None,
        take_profit_price: float = None,  # Deprecated, use 'secondary_limit_price' instead
        stop_loss_price: float = None,  # Deprecated, use 'secondary_stop_price' instead
        stop_loss_limit_price: float = None,  # Deprecated, use 'secondary_stop_limit_price' instead
        position_filled: float = None,
        exchange: str = None,
        quote: Asset = None,
        pair: str = None,
        order_type: Union[Order.OrderType, None] = None,
        order_class: Union[Order.OrderClass, None] = None,
        type: Union[Order.OrderType, None] = None,  # Deprecated, use 'order_type' instead
        smart_limit: SmartLimitConfig = None,
        custom_params: dict = None,
        position_side: str = None,
        position_id: str = None,
        reduce_only: bool = False,
    ):
        # noinspection PyShadowingNames,PyUnresolvedReferences
        """Creates a new order for this specific strategy. Once created, an order must still be submitted.

        Some notes on Crypto markets:

        Crypto markets require both a base currency and a quote currency to create an order. For example, use the quote parameter.:

            >>> from lumibot.entities import Asset
            >>>
            >>> self.create_order(
            >>>     Asset(symbol='BTC', asset_type=Asset.AssetType.CRYPTO),
            >>>     .50,
            >>>     'buy',
            >>>     quote=Asset(symbol='USDT', asset_type='crypto'),
            >>> )

        Orders for crypto markets are restriced to: ``market``, ``limit``, ``stop_limit``.

        Crypto markets' orders are simple. There are no compound orders such
        ``oco`` or ``bracket``. Also, duration of orders are all GTC.

        Parameters
        ----------
        asset : str or Asset
            The asset that will be traded. If this is just a stock, then
            ``str`` is sufficient. However, all assets other than stocks
            must use ``Asset``.
        quantity : int string Decimal (float will deprecate)
            The number of shares or units to trade. One may enter an
            int, a string number eg: "3.213", or a Decimal obect,
            eg: Decimal("3.213"). Internally all will convert to Decimal.
        side : str
            Whether the order is ``buy`` or ``sell``.
        order_type : Order.OrderType
            The type of order. Order types include: ``'market'``, ``'limit'``, ``'stop'``, ``'stop_limit'``,
            ``trailing_stop``, ``smart_limit``
            We will try to determine the order type if you do not specify it.
        smart_limit : SmartLimitConfig
            Configuration for SMART_LIMIT orders. If provided, the order type defaults to ``smart_limit``.
        order_class: Order.OrderClass
            The class of the order. Order classes include: ``'simple'``, ``'bracket'``, ``'oco'``, ``'oto'``,
            ``'multileg'``
        limit_price : float
            A Limit order is an order to buy or sell at a specified
            price or better. The Limit order ensures that if the
            order fills, it will not fill at a price less favorable
            than your limit price, but it does not guarantee a fill.
        stop_price : float
            A Stop order is an instruction to submit a buy or sell
            market order if and when the user-specified stop trigger
            price is attained or penetrated.
        stop_limit_price : float
            Stop loss with limit price used to ensure a specific fill price
            when the stop price is reached. For more information, visit:
            https://www.investopedia.com/terms/s/stop-limitorder.asp
        secondary_limit_price : float
            Limit price used for child orders of Advanced Orders like
            Bracket Orders and One Triggers Other (OTO) orders. One Cancels
            Other (OCO) orders do not use this field as the primary prices
            can specify all info needed to execute the OCO (because there is
            no corresponding Entry Order).
        secondary_stop_price : float
            Stop price used for child orders of Advanced Orders like
            Bracket Orders and One Triggers Other (OTO) orders. One Cancels
            Other (OCO) orders do not use this field as the primary prices
            can specify all info needed to execute the OCO (because there is
            no corresponding Entry Order).
        secondary_stop_limit_price : float
            Stop limit price used for child orders of Advanced Orders like
            Bracket Orders and One Triggers Other (OTO) orders. One Cancels
            Other (OCO) orders do not use this field as the primary prices
            can specify all info needed to execute the OCO (because there is
            no corresponding Entry Order).
        stop_loss_limit_price : float
            Stop loss with limit price used for bracket orders and one
            cancels other orders. (Depricated, use 'stop_limit_price` instead)
        time_in_force : str
            Amount of time the order is in force. Order types include:
                - ``'day'`` Orders valid for the remainder of the day.
                - ``'gtc'`` Good until cancelled.
                - ``'gtd'`` Good until date.
            (Default: 'gtc'). Pass ``time_in_force='day'`` explicitly for an
            intraday order. Constructing ``Order`` directly defaults to 'day';
            this Strategy API defaults to 'gtc'.
        good_till_date : datetime.datetime
            This is the time order is valid for Good Though Date orders.
        take_profit_price : float
            Limit price used for bracket orders and one cancels other
            orders. (Depricated, use 'secondary_limit_price` instead)
        stop_loss_price : float
            Stop price used for bracket orders and one cancels other
            orders. (Depricated, use 'secondary_stop_price` instead)
        trail_price : float
            Trailing stop orders allow you to continuously and
            automatically keep updating the stop price threshold based
            on the stock price movement. `trail_price` sets the
            trailing price in dollars.
        trail_percent : float
            Trailing stop orders allow you to continuously and
            automatically keep updating the stop price threshold based
            on the stock price movement. E.g. 0.05 would be a 5% trailing stop.
            `trail_percent` sets the trailing price in percent.
        secondary_trail_price : float
            Trailing stop price for child orders of Advanced Orders like Bracket or OTO orders.
        secondary_trail_percent : float
            Trailing stop percent for child orders of Advanced Orders like Bracket or OTO orders.
        exchange : str
            The exchange where the order will be placed.
            ``Default = 'SMART'``
        quote : Asset
            This is the currency that the main coin being bought or sold
            will exchange in. For example, if trading ``BTC/ETH`` this
            parameter will be 'ETH' (as an Asset object).
        custom_params : dict
            A dictionary of custom parameters that can be used to pass additional information to the broker. This is useful for passing custom parameters to the broker that are not supported by Lumibot.
            E.g. `custom_params={"leverage": 3}` for Kraken margin trading.
        type : Order.OrderType
            Deprecated, use 'order_type' instead

        Further Reading
        -------
        - Although the term "stop_limit" can be confusing, it is important to remember that this is a StopLoss modifier
            not a true limit price nor bracket-style order. For more information, visit:
            https://www.investopedia.com/terms/s/stop-limitorder.asp

        Returns
        -------
        Order
            Order object ready to be submitted for trading.

        Examples
        -------
        >>> # For a market buy order
        >>> order = self.create_order("SPY", 100, "buy")
        >>> self.submit_order(order)

        >>> # For a limit order where limit price = 100
        >>> limit_order = self.create_order("SPY", 1, "buy", limit_price=100)
        >>> self.submit_order(limit_order)

        >>> # Sell 100 shares of TLT
        >>> order = self.create_order("TLT", 100, "sell")
        >>> self.submit_order(order)

        >>> # For a stop loss order
        >>> order = self.create_order("SPY", 100, "buy", stop_price=100.00)
        >>> self.submit_order(order)

        >>> # For a stop limit order
        >>> order = self.create_order("SPY", 100, "buy", stop_price=100.00, stop_limit_price=99.95)
        >>> self.submit_order(order)

        >>> # For a market sell order
        >>> order = self.create_order("SPY", 100, "sell")
        >>> self.submit_order(order)

        >>> # For a limit sell order
        >>> order = self.create_order("SPY", 100, "sell", limit_price=100.00)
        >>> self.submit_order(order)

        >>> # For an order with a trailing stop
        >>> order = self.create_order("SPY", 100, "buy", trail_price=100.00)
        >>> self.submit_order(order)

        >>> # For an OCO order - No entry order specified, only exit order info.
        >>> order = self.create_order(
        >>>                "SPY",
        >>>                100,
        >>>                "sell",
        >>>                limit_price=limit,  # Exit Profit point
        >>>                stop_price=stop_loss,  # Exit Loss point
        >>>                stop_limit_price=stop_loss_limit,  # Stop loss modifier (optional)
        >>>                order_class=Order.OrderClass.OCO,
        >>>            )

        >>> # For a bracket order - One Entry order with a Profit and Loss exit orders (2 child orders).
        >>> order = self.create_order(
        >>>                "SPY",
        >>>                100,
        >>>                "buy",
        >>>                limit_price=limit,  # When the Entry order will execute
        >>>                secondary_limit_price=sec_limit,  # When the child Profit Exit order will execute
        >>>                secondary_stop_price=stop_loss,  # When the child Loss Exit order will execute
        >>>                secondary_stop_limit_price=stop_loss_limit,  # Child loss modifier (optional)
        >>>                order_class=Order.OrderClass.BRACKET,
        >>>            )

        >>> # For a bracket order with a trailing stop
        >>> order = self.create_order(
        >>>                "SPY",
        >>>                100,
        >>>                "buy",
        >>>                limit_price=limit,  # When to Enter
        >>>                secondary_limit_price=sec_limit,  # When to Exit Profit
        >>>                secondary_stop_price=stop_loss,  # When to Exit Loss
        >>>                secondary_trail_percent=trail_percent,  # Exit stop modifier (optional)
        >>>                order_class=Order.OrderClass.BRACKET,
        >>>            )

        >>> # For an OTO order - One Entry, only a single Exit criteria is allowed (1/2 of a bracket order)
        >>> order = self.create_order(
        >>>                "SPY",
        >>>                100,
        >>>                "buy",
        >>>                limit_price=limit,  # When to Enter
        >>>                secondary_stop_price=stop_loss,  # When to Exit
        >>>                order_class=Order.OrderClass.OTO,
        >>>            )

        >>> # For a futures order
        >>> from lumibot.entities import Asset
        >>>
        >>> asset = Asset("ES", asset_type=Asset.AssetType.FUTURE, expiration="2019-01-01")
        >>> order = self.create_order(asset, 100, "buy", limit_price=100.00)
        >>> self.submit_order(order)

        >>> # For a futures order with a trailing stop
        >>> from lumibot.entities import Asset
        >>>
        >>> asset = Asset("ES", asset_type=Asset.AssetType.FUTURE, expiration="2019-01-01")
        >>> order = self.create_order(
        >>>                asset,
        >>>                100,
        >>>                "buy",
        >>>                limit_price=limit,  # When to Enter
        >>>                secondary_stop_price=stop_loss,  # When to Exit
        >>>                secondary_trail_percent=trail_percent,  # Exit modifier (optional)
        >>>                order_class=Order.OrderClass.OTO,
        >>>            )
        >>> self.submit_order(order)

        >>> # For an option order
        >>> from lumibot.entities import Asset
        >>>
        >>> asset = Asset("SPY", asset_type=Asset.AssetType.OPTION, expiration="2019-01-01", strike=100.00)
        >>> order = self.create_order(asset, 100, "buy", limit_price=100.00)
        >>> self.submit_order(order)

        >>> # For an option order with a trailing stop
        >>> from lumibot.entities import Asset
        >>>
        >>> asset = Asset("SPY", asset_type=Asset.AssetType.OPTION, expiration="2019-01-01", strike=100.00)
        >>> order = self.create_order(
        >>>                asset,
        >>>                100,
        >>>                "buy",
        >>>                limit_price=limit,
        >>>                secondary_stop_price=stop_loss,
        >>>                secondary_trail_percent=trail_percent,
        >>>                order_class=Order.OrderClass.BRACKET,
        >>>            )
        >>> self.submit_order(order)

        >>> # For a FOREX order
        >>> from lumibot.entities import Asset
        >>>
        >>> asset = Asset(
        >>>    symbol="CHF",
        >>>    currency="EUR",
        >>>    asset_type=Asset.AssetType.FOREX,
        >>>  )
        >>> order = self.create_order(asset, 100, "buy", limit_price=100.00)
        >>> self.submit_order(order)

        >>> # For a options order with a limit price
        >>> from lumibot.entities import Asset
        >>>
        >>> asset = Asset("SPY", asset_type=Asset.AssetType.OPTION, expiration="2019-01-01", strike=100.00)
        >>> order = self.create_order(asset, 100, "buy", limit_price=100.00)
        >>> self.submit_order(order)

        >>> # For a options order with a trailing stop
        >>> from lumibot.entities import Asset
        >>>
        >>> asset = Asset("SPY", asset_type=Asset.AssetType.OPTION, expiration="2019-01-01", strike=100.00)
        >>> order = self.create_order(
        >>>                asset,
        >>>                100,
        >>>                "buy",
        >>>                limit_price=limit,  # When to Enter
        >>>                secondary_stop_price=stop_loss,  # When to Exit
        >>>                secondary_trail_percent=trail_percent,  # Exit modifier (optional)
        >>>                order_class=Order.OrderClass.OTO,
        >>>            )
        >>> self.submit_order(order)

        >>> # For a cryptocurrency order with a market price
        >>> from lumibot.entities import Asset
        >>>
        >>> base = Asset("BTC", asset_type=Asset.AssetType.CRYPTO)
        >>> quote = Asset("USD", asset_type=Asset.AssetType.CRYPTO)
        >>> order = self.create_order(base, 0.05, "buy", quote=quote)
        >>> self.submit_order(order)

        >>> # Placing a limit order with a quote asset for cryptocurrencies
        >>> from lumibot.entities import Asset
        >>>
        >>> base = Asset("BTC", asset_type=Aset.AssetType.CRYPTO)
        >>> quote = Asset("USD", asset_type=Asset.AssetType.CRYPTO)
        >>> order = self.create_order(base, 0.05, "buy", limit_price=41000,  quote=quote)
        >>> self.submit_order(order)
        """

        if quote is None:
            quote = self.quote_asset

        asset = self._sanitize_user_asset(asset)
        if smart_limit is not None and order_type is None and type is None:
            order_type = Order.OrderType.SMART_LIMIT

        # PERF: uuid4() generation is a measurable hot path in high-churn backtests (1 order per bar per asset).
        # Backtests only need identifiers to be unique within the run, so use a cheap monotonic counter.
        identifier = None
        if getattr(self.broker, "IS_BACKTESTING_BROKER", False):
            seq = getattr(self.broker, "_backtest_order_seq", 0) + 1
            setattr(self.broker, "_backtest_order_seq", seq)
            identifier = f"bt_{seq}"

        order = Order(
            self.name,
            asset,
            quantity,
            side,
            limit_price=limit_price,
            stop_price=stop_price,
            stop_limit_price=stop_limit_price,
            secondary_limit_price=secondary_limit_price,
            secondary_stop_price=secondary_stop_price,
            secondary_stop_limit_price=secondary_stop_limit_price,
            time_in_force=time_in_force,
            good_till_date=good_till_date,
            take_profit_price=take_profit_price,  # Depricated, use 'secondary_limit_price' instead
            stop_loss_price=stop_loss_price,  # Depricated, use 'secondary_stop_price' instead
            stop_loss_limit_price=stop_loss_limit_price,  # Depricated, use 'secondary_stop_limit_price' instead
            trail_price=trail_price,
            trail_percent=trail_percent,
            secondary_trail_price=secondary_trail_price,
            secondary_trail_percent=secondary_trail_percent,
            exchange=exchange,
            position_filled=position_filled,
            date_created=self.get_datetime(),
            quote=quote,
            pair=pair,
            type=type,
            order_type=order_type,
            order_class=order_class,
            smart_limit=smart_limit,
            custom_params=custom_params,
            position_side=position_side,
            position_id=position_id,
            reduce_only=reduce_only,
            identifier=identifier,
        )

        # Add debug logging for custom_params
        if custom_params:
            self.log_message(f"🔧 ORDER CREATED with custom_params: {custom_params} for {asset} {side} {quantity}")

        return order

    # ======= Broker Methods ============

    def sleep(self, sleeptime: float, process_pending_orders: bool = True):
        """Sleep for sleeptime seconds.

        Use to pause the execution of the program. This should be used instead of `time.sleep` within the strategy. Also processes pending orders in the meantime.

        Parameters
        ----------
        sleeptime : float
            Time in seconds the program will be paused.
        process_pending_orders : bool
            If True, process pending broker fills around the sleep. In backtesting
            this calls ``broker.process_pending_orders`` before and after advancing
            the simulation clock. Required for agent tools such as
            ``orders_wait_for_terminal`` so market orders can fill without waiting
            for the next strategy bar.

        Returns
        -------
        None

        Example
        -------
        >>> # Sleep for 5 seconds
        >>> self.sleep(5)
        """

        # Backtesting must advance the broker clock and process fills. The older
        # path only called broker.sleep (safe_sleep), which advances datetime via
        # _update_datetime but never runs process_pending_orders. Agent waits then
        # raced the clock for hundreds of thousands of 1s steps while market
        # orders stayed `new` until end-of-backtest cancel.
        if self.is_backtesting:
            try:
                seconds = float(sleeptime)
            except Exception:
                seconds = 0.0
            broker = self.broker
            if process_pending_orders and hasattr(broker, "process_pending_orders"):
                try:
                    broker.process_pending_orders(strategy=self)
                except TypeError:
                    broker.process_pending_orders(self)
            if seconds > 0 and hasattr(broker, "_update_datetime"):
                broker._update_datetime(seconds)
            if process_pending_orders and hasattr(broker, "process_pending_orders"):
                try:
                    broker.process_pending_orders(strategy=self)
                except TypeError:
                    broker.process_pending_orders(self)
            self._apply_pending_backtest_trade_events()
            return None

        time.sleep(sleeptime)
        return self.broker.sleep(sleeptime)

    def get_selling_order(self, position: Position):
        """Get the selling order for a position.

        Parameters
        -----------
        position : Position
            The position to get the selling order for.

        Returns
        -------
        Order or None

        Example
        -------
        >>> # Get the selling order for a position
        >>> position = self.get_position("SPY")
        >>> order = self.get_selling_order(position)
        >>> self.submit_order(order)

        >>> # Sell all positions owned by the account
        >>> for position in self.get_positions():
        >>>    order = self.get_selling_order(position)
        >>>    self.submit_order(order)
        """
        if position.asset != self.quote_asset:
            selling_order = self.create_order(position.asset, position.quantity, "sell", quote=self.quote_asset)
            return selling_order
        else:
            return None

    def set_market(self, market: str):
        """Set the market for trading hours.

        Setting the market will determine the trading hours for live
        trading and for Yahoo backtesting. Not applicable to Pandas
        backtesting.

        Crypto markets are always 24/7.
        `NASDAQ` is default.

        Parameters
        ----------
        market : str

            Short form for the markets.
            List of markets available are:

            "MarketCalendar", "ASX", "BMF", "CFE", "NYSE", "stock",
            "NASDAQ", "BATS", "CME_Equity", "CBOT_Equity",
            "CME_Agriculture", "CBOT_Agriculture", "COMEX_Agriculture",
            "NYMEX_Agriculture", "CME_Rate", "CBOT_Rate",
            "CME_InterestRate", "CBOT_InterestRate", "CME_Bond",
            "CBOT_Bond", "EUREX", "HKEX", "ICE", "ICEUS", "NYFE", "JPX",
            "LSE", "OSE", "SIX", "SSE", "TSX", "TSXV", "BSE", "TASE",
            "TradingCalendar", "ASEX", "BVMF", "CMES", "IEPA", "XAMS",
            "XASX", "XBKK", "XBOG", "XBOM", "XBRU", "XBUD", "XBUE",
            "XCBF", "XCSE", "XDUB", "XFRA", "XETR", "XHEL", "XHKG",
            "XICE", "XIDX", "XIST", "XJSE", "XKAR", "XKLS", "XKRX",
            "XLIM", "XLIS", "XLON", "XMAD", "XMEX", "XMIL", "XMOS",
            "XNYS", "XNZE", "XOSL", "XPAR", "XPHS", "XPRA", "XSES",
            "XSGO", "XSHG", "XSTO", "XSWX", "XTAE", "XTAI", "XTKS",
            "XTSE", "XWAR", "XWBO", "us_futures", "24/7", "24/5",

            (default: `NASDAQ`)

            The market to set.

        Returns
        -------
        None


        Example
        -------
        >>> # Set the market to 24/7
        >>> def initialize(self):
        >>>    # Set the market to 24/7
        >>>    self.set_market('24/7')

        >>> # Set the market to NASDAQ
        >>> self.set_market('NASDAQ')

        >>> # Set the market to NYSE
        >>> self.set_market('NYSE')

        >>> # Set the market to 24/5
        >>> self.set_market('24/5')

        >>> # Set the market to us_futures
        >>> self.set_market('us_futures')

        >>> # Set the market to stock
        >>> self.set_market('stock')

        >>> # Set the market to BATS
        >>> self.set_market('BATS')

        >>> # Set the market to CME_Equity
        >>> self.set_market('CME_Equity')
        """
        markets = [
            "MarketCalendar",
            "ASX",
            "BMF",
            "CFE",
            "NYSE",
            "stock",
            "NASDAQ",
            "BATS",
            "CME_Equity",
            "CBOT_Equity",
            "CME_Agriculture",
            "CBOT_Agriculture",
            "COMEX_Agriculture",
            "NYMEX_Agriculture",
            "CME_Rate",
            "CBOT_Rate",
            "CME_InterestRate",
            "CBOT_InterestRate",
            "CME_Bond",
            "CBOT_Bond",
            "EUREX",
            "HKEX",
            "ICE",
            "ICEUS",
            "NYFE",
            "JPX",
            "LSE",
            "OSE",
            "SIX",
            "SSE",
            "TSX",
            "TSXV",
            "BSE",
            "TASE",
            "TradingCalendar",
            "ASEX",
            "BVMF",
            "CMES",
            "IEPA",
            "XAMS",
            "XASX",
            "XBKK",
            "XBOG",
            "XBOM",
            "XBRU",
            "XBUD",
            "XBUE",
            "XCBF",
            "XCSE",
            "XDUB",
            "XFRA",
            "XETR",
            "XHEL",
            "XHKG",
            "XICE",
            "XIDX",
            "XIST",
            "XJSE",
            "XKAR",
            "XKLS",
            "XKRX",
            "XLIM",
            "XLIS",
            "XLON",
            "XMAD",
            "XMEX",
            "XMIL",
            "XMOS",
            "XNYS",
            "XNZE",
            "XOSL",
            "XPAR",
            "XPHS",
            "XPRA",
            "XSES",
            "XSGO",
            "XSHG",
            "XSTO",
            "XSWX",
            "XTAE",
            "XTAI",
            "XTKS",
            "XTSE",
            "XWAR",
            "XWBO",
            "us_futures",
            "24/7",
            "24/5",
        ]

        if market not in markets:
            raise ValueError(f"Valid market entries are: {markets}. You entered {market}. Please adjust.")

        # Check if broker is None before setting market
        if self.broker is None:
            from termcolor import colored
            error_msg = _colored(
                "No broker is set. Cannot set market. Please set a broker using environment variables, "
                "secrets or by passing it as an argument to the strategy constructor.",
                "red"
            )
            self.logger.error(error_msg)
            raise ValueError(
                "No broker is set. Cannot set market. Please ensure your broker credentials are properly "
                "configured in environment variables or passed to the strategy constructor."
            )

        self.broker.market = market

    def await_market_to_open(self, timedelta: int = None):
        """Executes infinite loop until market opens

        If the market is closed, pauses code execution until
        self.minutes_before_opening minutes before market opens again.
        If an input (float) is passed as parameter, pauses code
        execution until input minutes before market opens again.

        Parameters
        ---------
        timedelta : int
            Time in minutes before market will open to pause to.
            Overrides the `self.minutes_before_opening`.

        Returns
        -------
        None

        Example
        -------
        >>> # Await market to open (on_trading_iteration will stop running until the market opens)
        >>> self.await_market_to_open()

        """
        if self.broker.market == "24/7":
            return None
        if timedelta is None:
            timedelta = self.minutes_before_opening
        return self.broker._await_market_to_open(timedelta, strategy=self)

    def await_market_to_close(self, timedelta: int = None):
        """Sleep until market closes.

        If the market is open, pauses code execution until market is
        closed. If an input (float) is passed as parameter, pauses code
        execution starting input minutes before market closes.

        Parameters
        ---------
        timedelta : int
           Time in minutes before market closes to pause.
           Overrides the `self.minutes_before_closing`.

        Returns
        -------
        None

        Example
        -------
        >>> # Sleep until market closes (on_trading_iteration will stop running until the market closes)
        >>> self.await_market_to_close()
        """
        if hasattr(self.broker, "market") and self.broker.market == "24/7":
            return None
        if timedelta is None:
            timedelta = self.minutes_before_closing
        return self.broker._await_market_to_close(timedelta, strategy=self)

    @staticmethod
    def crypto_assets_to_tuple(base, quote: Asset):
        """Check for crypto quote, convert to tuple"""
        if isinstance(base, Asset) and base.asset_type == "crypto" and isinstance(quote, Asset):
            return (base, quote)
        return base

    def get_tracked_position(self, asset: Union[str, Asset]):
        """Deprecated, will be removed in the future. Please use `get_position()` instead."""

        self.log_message("Warning: get_tracked_position() is deprecated, please use get_position() instead.")
        self.get_position(asset)

    def get_position(
        self,
        asset: Union[str, Asset],
        broker_refresh: bool = True,
        broker_refresh_ttl_seconds: float = 0.0,
        position_side: str = None,
        position_id: str = None,
    ):
        """Get a tracked position given an asset for the current
        strategy.

        Seeks out and returns the position object for the given asset
        in the current strategy. For continuous futures (CONT_FUTURE),
        automatically matches against active contract positions.

        Parameters
        ----------
        asset : Asset or str
            Asset object who's traded positions is sought.

        Returns
        -------
        Position or None
            A position object for the assset if there is a tracked
            position or returns None to indicate no tracked position.
            For continuous futures, returns the position for the most
            appropriate active contract (front-month priority).

        Example
        -------
        >>> # Get the position for the TLT asset
        >>> position = self.get_position("TLT")
        >>> # Show the quantity of the TLT position
        >>> self.log_message(position.quantity)

        >>> # Get position for continuous futures (matches active contract)
        >>> future_asset = Asset("MNQ", asset_type=Asset.AssetType.CONT_FUTURE)
        >>> position = self.get_position(future_asset)  # Returns MNQU5 position if held

        """

        # Check if asset is an Asset object or a string
        if not (isinstance(asset, Asset) or isinstance(asset, str)):
            self.logger.error(f"Asset in get_position() must be an Asset object or a string. You entered {asset}.")
            return None

        self._refresh_live_positions(
            broker_refresh=broker_refresh,
            broker_refresh_ttl_seconds=broker_refresh_ttl_seconds,
        )
        asset = self._sanitize_user_asset(asset)
        
        # For non-continuous futures, use existing exact matching
        if asset.asset_type != Asset.AssetType.CONT_FUTURE:
            selectors = {key: value for key, value in (("position_side", position_side), ("position_id", position_id))
                         if value is not None}
            return self.broker.get_tracked_position(self.name, asset, **selectors)
        
        # For continuous futures, implement smart matching
        return self._get_continuous_future_position(asset)

    def _get_continuous_future_position(self, asset):
        """
        Find position for continuous futures by matching against active contracts.
        
        Parameters
        ----------
        asset : Asset
            Continuous futures asset to find position for
            
        Returns
        -------
        Position or None
            Position for the best matching active contract, or None if no matches
        """
        from lumibot.tools.futures_symbols import (
            symbol_matches_root, 
            get_contract_priority_key,
            build_ib_contract_variants
        )
        
        # First try exact match (ProjectX may store as CONT_FUTURE)
        exact_position = self.broker.get_tracked_position(self.name, asset)
        if exact_position is not None:
            return exact_position
        
        # Get all positions for this strategy
        all_positions = self.broker.get_tracked_positions(self.name)
        if not all_positions:
            return None
        
        # Find positions that match this root symbol
        matching_positions = []
        root_symbol = asset.symbol
        
        for position in all_positions:
            pos_asset = position.asset
            
            # Skip non-futures positions
            if pos_asset.asset_type not in {Asset.AssetType.FUTURE, Asset.AssetType.CRYPTO_FUTURE, Asset.AssetType.CONT_FUTURE}:
                continue
            
            # Check for root symbol match
            if symbol_matches_root(pos_asset.symbol, root_symbol):
                matching_positions.append(position)
            elif (pos_asset.symbol == root_symbol and 
                  pos_asset.expiration is not None and 
                  pos_asset.asset_type == Asset.AssetType.FUTURE):
                # IB-style: same root symbol with expiration
                matching_positions.append(position)
        
        if not matching_positions:
            return None
        
        if len(matching_positions) == 1:
            return matching_positions[0]
        
        # Multiple matches - rank by priority and log
        priority_list = asset.get_potential_futures_contracts()
        
        # Score each position by priority
        scored_positions = []
        for position in matching_positions:
            pos_asset = position.asset
            
            # For IB-style positions, generate contract variants
            if (pos_asset.symbol == root_symbol and 
                pos_asset.expiration is not None and
                pos_asset.asset_type == Asset.AssetType.FUTURE):
                variants = build_ib_contract_variants(root_symbol, pos_asset.expiration)
                # Find best priority among variants
                best_priority = min(
                    (get_contract_priority_key(variant, priority_list) for variant in variants),
                    default=999999
                )
            else:
                # Direct symbol priority lookup
                best_priority = get_contract_priority_key(pos_asset.symbol, priority_list)
            
            scored_positions.append((best_priority, position))
        
        # Sort by priority (lower number = higher priority)
        scored_positions.sort(key=lambda x: x[0])
        best_position = scored_positions[0][1]
        
        # Log ambiguity warning
        contract_symbols = [pos.asset.symbol for pos in matching_positions]
        self.log_message(
            f"Multiple futures contracts found for {root_symbol}: {contract_symbols}. "
            f"Selected {best_position.asset.symbol} (front-month priority).",
            color="yellow"
        )
        
        return best_position

    def get_tracked_positions(self):
        """Deprecated, will be removed in the future. Please use `get_positions()` instead."""

        self.log_message("Warning: get_tracked_positions() is deprecated, please use get_positions() instead.")
        return self.get_positions()

    def get_portfolio_value(self):
        """
        Query the broker to get the current portfolio value (cash + net equity). This is a slow,
        expensive call, if you want the fast "last seen" value, use the `self.portfolio_value` property instead.
        In live trading this forces a fresh broker balance refresh. If the broker cannot return a
        fresh value, this returns None and leaves the cached portfolio value unchanged.

        Parameters
        ----------
        None

        Returns
        -------
        float or None
            The current portfolio value, which is the sum of the cash and net equity. This is the total value of your
             account, which is the amount of money you would have if you sold all your assets and closed all your
             positions. For crypto assets, this is the total value of your account in the quote asset (eg. USDT if
            that is your quote asset). Returns None if the live broker refresh fails.
        """
        if not self.update_broker_balances(force_update=True):
            return None
        return self._portfolio_value

    def get_cash(self):
        """Get the current cash value in your account.

        In live trading this forces a fresh broker balance refresh. If the broker cannot return a
        fresh value, this returns None and leaves the cached cash value unchanged.

        Parameters
        ----------
        None

        Returns
        -------
        float or None
            The current cash value. This is the amount of cash you have in your account, which is the amount of money you can use to buy assets. For crypto assets, this is the amount of the quote asset you have in your account (eg. USDT if that is your quote asset). Returns None if the live broker refresh fails.
        """
        if not self.update_broker_balances(force_update=True):
            return None

        cash_position = self.get_position(
            self._quote_asset,
            broker_refresh=False,
        )
        return cash_position.quantity if cash_position else None

    def adjust_cash(self, amount: float, reason: str = "manual_adjustment", allow_negative: bool | None = None) -> float:
        """Adjust cash directly during backtesting.

        Positive values add cash, negative values remove cash. This method is intended for
        framework-supported strategy cashflows (for example synthetic withdrawals/deposits and
        custom financing accruals) without mutating private internals.
        """
        return self._apply_cash_adjustment(
            delta_cash=amount,
            reason=reason,
            kind="adjustment",
            allow_negative=allow_negative,
        )

    def withdraw_cash(self, amount: float, reason: str = "withdrawal", allow_negative: bool | None = None) -> float:
        """Withdraw cash during backtesting and return the updated cash balance."""
        try:
            amount_value = float(amount)
        except (TypeError, ValueError):
            raise ValueError("amount must be a finite positive number")
        if not math.isfinite(amount_value) or amount_value <= 0:
            raise ValueError("amount must be a finite positive number")

        return self._apply_cash_adjustment(
            delta_cash=-amount_value,
            reason=reason,
            kind="withdrawal",
            allow_negative=allow_negative,
        )

    def deposit_cash(self, amount: float, reason: str = "deposit") -> float:
        """Deposit cash during backtesting and return the updated cash balance."""
        try:
            amount_value = float(amount)
        except (TypeError, ValueError):
            raise ValueError("amount must be a finite positive number")
        if not math.isfinite(amount_value) or amount_value <= 0:
            raise ValueError("amount must be a finite positive number")

        return self._apply_cash_adjustment(
            delta_cash=amount_value,
            reason=reason,
            kind="deposit",
            allow_negative=True,
        )

    def configure_cash_financing(
        self,
        *,
        enabled: bool = True,
        account_mode: str = "margin",
        day_count_basis: int = 360,
        missing_rate_policy: str = "carry_forward",
    ) -> None:
        """Configure framework-managed daily cash financing for backtests.

        Parameters
        ----------
        enabled : bool
            Enables/disables financing accrual.
        account_mode : str
            ``"margin"`` allows negative cash balances, ``"cash"`` blocks them.
        day_count_basis : int
            Day-count basis used for daily accrual conversion (broker-like default is 360).
        missing_rate_policy : str
            ``"carry_forward"`` uses last known rates, ``"error"`` raises if a rate is missing.
        """
        self._configure_cash_financing(
            enabled=enabled,
            account_mode=account_mode,
            day_count_basis=day_count_basis,
            missing_rate_policy=missing_rate_policy,
        )

    def set_cash_financing_rates(
        self,
        *,
        credit_rate_annual: float | None = None,
        debit_rate_annual: float | None = None,
    ) -> None:
        """Set annualized cash financing rates used by framework daily accrual."""
        self._set_cash_financing_rates(
            credit_rate_annual=credit_rate_annual,
            debit_rate_annual=debit_rate_annual,
        )

    def get_positions(
        self,
        include_cash_positions: bool = False,
        broker_refresh: bool = True,
        broker_refresh_ttl_seconds: float = 0.0,
    ):
        """Get all positions for the account.

        Parameters
        ----------
        include_cash_positions : bool
            If True, include cash positions in the returned list. If False, exclude cash positions.

        Returns
        -------
        list
            A list of Position objects for the strategy if there are tracked
            positions or returns and empty list to indicate no tracked
            position.

        Example
        -------
        >>> # Get all tracked positions
        >>> positions = self.get_positions()
        >>> for position in positions:
        >>>     # Show the quantity of each position
        >>>     self.log_message(position.quantity)
        >>>     # Show the asset of each position
        >>>     self.log_message(position.asset)

        """
        self._refresh_live_positions(
            broker_refresh=broker_refresh,
            broker_refresh_ttl_seconds=broker_refresh_ttl_seconds,
        )
        include_cash = include_cash_positions or self.include_cash_positions
        filled_positions = getattr(self.broker, "_filled_positions", None)
        filled_positions_revision = getattr(filled_positions, "revision", 0)
        quote_asset = self.quote_asset
        cache_key = (filled_positions_revision, include_cash, quote_asset)
        cached = getattr(self, "_positions_cache", {}).get(cache_key) if hasattr(self, "_positions_cache") else None
        if cached is not None:
            return list(cached)

        tracked_positions = self.broker.get_tracked_positions(self.name)
        if include_cash:
            result = list(tracked_positions)
        else:
            result = [position for position in tracked_positions if position.asset != quote_asset]

        cache = getattr(self, "_positions_cache", None)
        if cache is None:
            cache = {}
            self._positions_cache = cache
        # Single-entry cache: keep only the latest revision/parameter combination to avoid stale results.
        cache.clear()
        cache[cache_key] = tuple(result)
        return list(result)

    def get_historical_bot_stats(self):
        """Get the historical account value.

        Returns
        -------
        pandas.DataFrame
            The historical bot stats.

        Example
        -------
        >>> # Get the historical bot stats
        >>> bot_stats = self.get_historical_bot_stats()
        >>> # Show the historical bot stats
        >>> self.log_message(account_value)
        """
        return self.stats.set_index("datetime")

    @property
    def positions(self):
        return self.get_positions()

    def _get_contract_details(self, asset: Asset):
        """Convert an asset into a IB Contract.

        Used internally to create an IB Contract from an asset. Used
        only with Interactive Brokers.

        Parameters
        ----------
        asset : Asset
            Asset to be converted into and Interactive Brokers contract.

        Returns
        -------
        list of ContractDetails
            ContractDetails is a complete contract definition with
            Interactive Brokers.
        """

        asset = self._sanitize_user_asset(asset)
        return self.broker.get_contract_details(asset)

    def get_tracked_order(self, identifier: str):
        """Deprecated, will be removed in the future. Please use `get_order()` instead."""

        self.log_message("Warning: get_tracked_order() is deprecated, please use get_order() instead.")
        return self.get_order(identifier)

    def _refresh_live_orders(self, broker_refresh: bool = True, broker_refresh_ttl_seconds: float = 0.0):
        if not broker_refresh or self.broker.IS_BACKTESTING_BROKER:
            return
        refresh_orders = getattr(self.broker, "refresh_orders", None)
        if refresh_orders is not None:
            refresh_orders(self, ttl_seconds=broker_refresh_ttl_seconds)

    def _refresh_live_positions(self, broker_refresh: bool = True, broker_refresh_ttl_seconds: float = 0.0):
        if not broker_refresh or self.broker.IS_BACKTESTING_BROKER:
            return
        refresh_positions = getattr(self.broker, "refresh_positions", None)
        if refresh_positions is not None:
            refresh_positions(self, ttl_seconds=broker_refresh_ttl_seconds)
            if hasattr(self, "_positions_cache"):
                self._positions_cache.clear()

    @staticmethod
    def _normalize_order_statuses(statuses):
        if statuses is None:
            return None

        if isinstance(statuses, Order.OrderStatus):
            return {statuses}

        if isinstance(statuses, str):
            raise TypeError("statuses must use Order.OrderStatus enum values, not raw strings")

        try:
            normalized_statuses = set(statuses)
        except TypeError as exc:
            raise TypeError("statuses must be an Order.OrderStatus or an iterable of Order.OrderStatus values") from exc

        for status in normalized_statuses:
            if not isinstance(status, Order.OrderStatus):
                raise TypeError("statuses must use Order.OrderStatus enum values, not raw strings")

        return normalized_statuses

    @staticmethod
    def _order_matches_statuses(order: Order, statuses) -> bool:
        try:
            order_status = Order.OrderStatus(order.status)
        except ValueError:
            return False
        return order_status in statuses

    def get_order(self, identifier: str, broker_refresh: bool = True, broker_refresh_ttl_seconds: float = 0.0):
        """Get a tracked order given an identifier. Check the details of the order including status, etc.

        In live trading this refreshes broker order state before returning by default.
        Refresh normally reads the broker order list; a tracked active order absent from
        that list may also receive a direct lookup. This is not an unconditional
        single-order HTTP request. Set broker_refresh=False to read only tracked state.

        Returns
        -------
        Order or None
            An order objects for the identifier

        Example
        -------
        >>> # Get the order object for the order id
        >>> order = self.get_order(order_id)
        >>> # Show the status of the order
        >>> self.log_message(order.status)
        """
        self._refresh_live_orders(broker_refresh=broker_refresh, broker_refresh_ttl_seconds=broker_refresh_ttl_seconds)
        order = self.broker.get_tracked_order(identifier)
        if order is not None and order.strategy == self.name:
            return order
        return None

    def get_tracked_orders(self):
        """Deprecated, will be removed in the future. Please use `get_orders()` instead."""

        self.log_message("Warning: get_tracked_orders() is deprecated, please use get_orders() instead.")
        return self.get_orders()

    def get_orders(
        self,
        identifiers: list[str] = None,
        statuses=None,
        broker_refresh: bool = True,
        broker_refresh_ttl_seconds: float = 0.0,
    ):
        """Get tracked orders, optionally filtered by identifiers and OrderStatus values.

        In live trading this refreshes broker order state before returning by default. For
        currently active/open orders, use `statuses=Order.ACTIVE_STATUSES`; raw string status
        filters are rejected to avoid typos and broker-specific wording.

        If you need to verify the exact order immediately after `submit_order(order)`, prefer
        `self.get_order(order.identifier)`. Broad broker order-list endpoints used by
        `get_orders(...)` can lag briefly after submit; if broad-list logic must run immediately
        after submit, use a short `self.sleep(..., process_pending_orders=True)` first.

        Parameters
        ----------
        identifiers : list of str
            A list of order identifiers to filter the orders by. If None, returns all tracked orders for the strategy.
        statuses : Order.OrderStatus or iterable of Order.OrderStatus
            Optional enum status filter. Use Order.ACTIVE_STATUSES for currently active/open orders.

        Returns
        -------
        list of Order objects
            Order objects for the strategy if there are tracked

        Example
        -------
        >>> # Get all tracked orders
        >>> orders = self.get_orders()
        >>> for order in orders:
        >>>     # Show the status of each order
        >>>     self.log_message(order.status)

        >>> # Get active/open orders
        >>> orders = self.get_orders(statuses=Order.ACTIVE_STATUSES)
        >>> for order in orders:
        >>>     self.cancel_order(order)

        """
        normalized_statuses = self._normalize_order_statuses(statuses)
        self._refresh_live_orders(broker_refresh=broker_refresh, broker_refresh_ttl_seconds=broker_refresh_ttl_seconds)
        all_orders = self.broker.get_tracked_orders(self.name)
        if identifiers:
            all_orders = [
                order
                for order in all_orders
                if any(self.broker.identifiers_equal(order.identifier, identifier) for identifier in identifiers)
            ]
        if normalized_statuses is not None:
            all_orders = [order for order in all_orders if self._order_matches_statuses(order, normalized_statuses)]
        return all_orders

    def get_tracked_assets(self):
        """Get the list of assets for positions
        and open orders for the current strategy

        Returns
        -------
        list
            A list of assets for the strategy if there are tracked positions or returns and empty list to indicate no tracked.

        Example
        -------
        >>> # Get all tracked assets
        >>> assets = self.get_tracked_assets()
        >>> for asset in assets:
        >>>     # Show the asset name
        >>>     self.log_message(asset.symbol)
        >>>     # Show the quantity of the asset
        >>>     self.log_message(asset.quantity)


        """
        return self.broker.get_tracked_assets(self.name)

    def get_asset_potential_total(self, asset: Asset):
        """Get the potential total for the asset (orders + positions).

        Parameters
        ----------
        asset : Asset
            Asset object who's potential total is sought.

        Returns
        -------
        int, float or Decimal
            The potential total for the asset. Decimals are automatically
            returned as floats if less than 4 decimal points

        Example
        -------
        >>> # Get the potential total for the TLT asset
        >>> total = self.get_asset_potential_total("TLT")
        >>> self.log_message(total)

        >>> # Show the potential total for an asset
        >>> asset = Asset("TLT")
        >>> total = self.get_asset_potential_total(asset)
        >>> self.log_message(total)

        >>> # Show the potential total for an asset
        >>> asset = Asset("ES", asset_type="future", expiration_date="2020-01-01")
        >>> total = self.get_asset_potential_total(asset)
        """
        asset = self._sanitize_user_asset(asset)
        return self.broker.get_asset_potential_total(self.name, asset)

    def _journal_order_action(self, orders, *, operation, reason, evidence=None, changes=None):
        from lumibot.components.agents.tool_context import current_agent_tool_context
        from lumibot.components.memory.store import validate_order_reason

        context = current_agent_tool_context()
        reason = validate_order_reason(reason, required=bool(context.get("agent_name") or context.get("model_call_id")))
        if reason is None:
            return None
        orders = orders if isinstance(orders, list) else [orders]
        snapshots = [
            {"identifier": o.identifier, "symbol": o.symbol, "side": str(o.side),
             "quantity": str(o.quantity), "order_type": str(o.order_type),
             "limit_price": o.limit_price, "stop_price": o.stop_price, "changes": changes or {},
             "previous_reference": getattr(o, "decision_journal", None) if operation != "submit" else None}
            for o in orders
        ]
        reference = self.memory.record_order_action(
            operation=operation, reason=reason, orders=snapshots, evidence=evidence,
            previous=getattr(orders[0], "decision_journal", None) if operation != "submit" and len(orders) == 1 else None,
            agent_name=context.get("agent_name"), model_call_id=context.get("model_call_id"),
        )
        for order, snapshot in zip(orders, snapshots):
            linked = dict(reference)
            previous = snapshot["previous_reference"]
            if previous:
                linked["previous_action_id"] = previous.get("action_id")
                linked["decision_id"] = previous.get("decision_id") or reference["decision_id"]
            self._attach_order_journal(order, linked)
        return reference

    @staticmethod
    def _attach_order_journal(order, reference, *, preserve_existing=False):
        if order is None:
            return
        if isinstance(order, list):
            for item in order:
                Strategy._attach_order_journal(item, reference, preserve_existing=preserve_existing)
            return
        if preserve_existing and getattr(order, "decision_journal", {}).get("action_id") == reference["action_id"]:
            return
        order.decision_journal = dict(reference)
        if reference.get("operation") in {"submit", "modify"}:
            order.trade_decision_journal = dict(reference)
        order.decision_provenance = {key: reference.get(key) for key in ("deployment_id", "run_id", "decision_id", "model_call_id")}
        for child in getattr(order, "child_orders", None) or []:
            Strategy._attach_order_journal(child, reference)

    def _perform_journaled_order_action(self, reference, operation):
        try:
            result = operation()
        except Exception as exc:
            if reference:
                self._record_order_action_outcome(reference, certainty="unknown", error_type=type(exc).__name__)
            raise
        if reference:
            self._attach_order_journal(result, reference, preserve_existing=True) if isinstance(result, (Order, list)) else None
            self._record_order_action_outcome(reference, certainty="returned")
        return result

    def _record_order_action_outcome(self, reference, **kwargs):
        # An acknowledged broker call must never appear to fail and invite a retry
        # because an observability write failed after execution.
        try:
            self.memory.record_order_action_outcome(reference, **kwargs)
        except Exception:
            import logging
            logging.getLogger(__name__).exception("Unable to persist order action outcome for %s", reference["action_id"])

    def submit_order(self, order: Order|list[Order], *, reason: str | None = None, evidence: dict | None = None, **kwargs):
        """Submit with an optional private explanation; agent actions require one.

        ``reason`` is committed before the broker call. ``evidence`` is an
        optional JSON object of sources, timestamps, sizing and risks. Full
        explanations remain in the private memory journal; orders carry compact
        references. An unknown broker outcome must be reconciled before retrying.
        """
        reference = self._journal_order_action(order, operation="submit", reason=reason, evidence=evidence)
        return self._perform_journaled_order_action(reference, lambda: self._submit_order_impl(order, **kwargs))

    def _submit_order_impl(self, order: Order|list[Order], **kwargs):
        """Submit an order or a list of orders for assets

        Submits an order or a list of orders for processing by the active broker.

        Parameters
        ---------
        order : Order or list[Order]
            Order object or a list of order objects containing the asset and instructions for executing the order.
        is_multileg : bool
            Tradier only.
            A boolean value to indicate if the orders are part of one multileg order.
            Currently, this is only available for Tradier.
        order_type : str
            Tradier only.
            The order type for the multileg order. Possible values are:
            ('market', 'debit', 'credit', 'even'). Default is 'market'.
        duration : str
            Tradier only.
            The duration for the multileg order. Possible values are:
            ('day', 'gtc', 'pre', 'post'). Default is 'day'.
        price : float
            Tradier only.
            The limit price for the multileg order. Required for 'debit' and 'credit' order types.
        tag : str
            Tradier only.
            A tag for the multileg order.

        Returns
        -------
        Order object or list of Order objects
            Processed order object(s).

        Examples
        --------
        Submitting a single order:

        >>> # For a market buy order
        >>> order = self.create_order("SPY", 100, "buy")
        >>> self.submit_order(order)

        >>> # For a limit buy order
        >>> order = self.create_order("SPY", 100, "buy", limit_price=100.00)
        >>> self.submit_order(order)

        >>> # For a stop loss order
        >>> order = self.create_order("SPY", 100, "buy", stop_price=100.00)
        >>> self.submit_order(order)

        >>> # For a stop limit order
        >>> order = self.create_order("SPY", 100, "buy", limit_price=100.00, stop_price=100.00)
        >>> self.submit_order(order)

        >>> # For a SMART_LIMIT order
        >>> from lumibot.entities import SmartLimitConfig, SmartLimitPreset
        >>> config = SmartLimitConfig(preset=SmartLimitPreset.NORMAL, slippage=0.05)
        >>> order = self.create_order("SPY", 100, "buy", smart_limit=config)
        >>> self.submit_order(order)

        >>> # For a market sell order
        >>> order = self.create_order("SPY", 100, "sell")
        >>> self.submit_order(order)

        >>> # For buying a crypto with a market price
        >>> from lumibot.entities import Asset
        >>>
        >>> asset_base = Asset(
        >>>    "BTC",
        >>>    asset_type=Asset.AssetType.CRYPTO,
        >>> )
        >>> asset_quote = Asset(
        >>>    "USD",
        >>>    asset_type=Asset.AssetType.CRYPTO,
        >>> )
        >>> order = self.create_order(asset_base, 0.1, "buy", quote=asset_quote)
        >>> self.submit_order(order)
        >>> # or...
        >>> order = self.create_order((asset_base, asset_quote), 0.1, "buy")
        >>> self.submit_order(order)

        Submitting multiple orders:

        >>> # For 2 market buy orders
        >>> order1 = self.create_order("SPY", 100, "buy")
        >>> order2 = self.create_order("TLT", 200, "buy")
        >>> self.submit_order([order1, order2])

        >>> # For 2 limit buy orders
        >>> order1 = self.create_order("SPY", 100, "buy", limit_price=100.00)
        >>> order2 = self.create_order("TLT", 200, "buy", limit_price=100.00)
        >>> self.submit_order([order1, order2])

        >>> # For 2 CRYPTO buy orders
        >>> from lumibot.entities import Asset
        >>>
        >>> asset_BTC = Asset(
        >>>    "BTC",
        >>>    asset_type=Asset.AssetType.CRYPTO,
        >>> )
        >>> asset_ETH = Asset(
        >>>    "ETH",
        >>>    asset_type=Asset.AssetType.CRYPTO,
        >>> )
        >>> asset_quote = Asset(
        >>>    "USD",
        >>>    asset_type=Asset.AssetType.FOREX,
        >>> )
        >>> order1 = self.create_order(asset_BTC, 0.1, "buy", quote=asset_quote)
        >>> order2 = self.create_order(asset_ETH, 10, "buy", quote=asset_quote)
        >>> self.submit_order([order1, order2])
        >>> # or...
        >>> order1 = self.create_order((asset_BTC, asset_quote), 0.1, "buy")
        >>> order2 = self.create_order((asset_ETH, asset_quote), 10, "buy")
        >>> self.submit_order([order1, order2])
        """

        if isinstance(order, list):
            # Submit multiple orders
            # Validate orders
            default_multileg = True

            for o in order:
                if o is None:
                    raise ValueError("Cannot submit a null order")
                if not self._validate_order(o):
                    return

                if o.asset.asset_type != "option":
                    default_multileg = False

            if 'is_multileg' not in kwargs:
                kwargs['is_multileg'] = default_multileg

            is_multileg = bool(kwargs.get("is_multileg"))
            wants_smart_limit = any(
                o.order_type == Order.OrderType.SMART_LIMIT or getattr(o, "smart_limit", None) is not None for o in order
            )
            if wants_smart_limit:
                cfg = next((getattr(o, "smart_limit", None) for o in order if getattr(o, "smart_limit", None) is not None), None)
                if cfg is None:
                    cfg = _smart_limit_config()()

                if any(getattr(o, "smart_limit", None) not in (None, cfg) for o in order):
                    self.log_message(
                        "[SMART_LIMIT] Multi-leg SMART_LIMIT requires a single SmartLimitConfig; using the first config for all legs.",
                        color="yellow",
                    )

                for o in order:
                    o.order_type = Order.OrderType.SMART_LIMIT
                    o.smart_limit = cfg

                if is_multileg:
                    if self.broker.IS_BACKTESTING_BROKER:
                        return self.broker.submit_orders(order, **kwargs)
                    return self._submit_multileg_smart_limit_orders(order, cfg, **kwargs)

                # Multiple independent SMART_LIMIT orders.
                submitted_orders = []
                for o in order:
                    submitted_orders.append(self._submit_order_impl(o))
                return submitted_orders

            # Broker-agnostic multi-leg LIMIT UX:
            # If the caller requests a package LIMIT (`order_type='limit'`) on a broker that uses
            # debit/credit/even semantics (Tradier) or needs net-side hints (Alpaca mleg),
            # infer the net sign from quotes and map internally so strategies remain portable.
            if (
                is_multileg
                and not self.broker.IS_BACKTESTING_BROKER
                and str(kwargs.get("order_type", "")).lower() == str(Order.OrderType.LIMIT)
                and str(getattr(self.broker, "name", "")).lower() in {"tradier", "alpaca"}
            ):
                inferred = self._infer_multileg_type_and_mid(order)
                if inferred is not None:
                    inferred_type, inferred_mid_abs = inferred
                else:
                    inferred_type, inferred_mid_abs = None, None

                raw_price = kwargs.get("price")
                price_abs = None
                if raw_price is not None:
                    try:
                        price_abs = abs(float(raw_price))
                    except Exception:
                        price_abs = None

                if inferred_type is None:
                    # Fall back to interpreting a signed price (negative=credit) if quotes are missing.
                    if raw_price is not None:
                        try:
                            signed = float(raw_price)
                            inferred_type = "even" if abs(signed) < 1e-9 else ("debit" if signed > 0 else "credit")
                            if price_abs is None:
                                price_abs = abs(signed)
                            self.log_message(
                                "[MULTILEG][LIMIT] Missing quotes; inferring debit/credit from price sign. "
                                "For net credits, pass a negative price or explicit order_type='credit'.",
                                color="yellow",
                            )
                        except Exception:
                            inferred_type = None

                if inferred_type is not None:
                    kwargs["order_type"] = inferred_type
                    if price_abs is None and inferred_mid_abs is not None:
                        price_abs = float(inferred_mid_abs)

                    broker_name = str(getattr(self.broker, "name", "")).lower()
                    if inferred_type == "even" and broker_name == "tradier":
                        kwargs["price"] = None
                    else:
                        # Alpaca requires a limit_price for mleg orders; treat even as 0.0 and let the broker decide.
                        kwargs["price"] = 0.0 if price_abs is None else float(price_abs)

            return self.broker.submit_orders(order, **kwargs)

        else:
            # Submit single order
            if not self._validate_order(order):
                return

            if order.order_type == Order.OrderType.SMART_LIMIT:
                if self.broker.IS_BACKTESTING_BROKER:
                    return self.broker.submit_order(order)

                if order.smart_limit is None:
                    order.smart_limit = _smart_limit_config()()

                if order.order_class == Order.OrderClass.MULTILEG and order.child_orders:
                    return self._submit_multileg_smart_limit(order)

                try:
                    quote = self.get_quote(order.asset, quote=order.quote, exchange=order.exchange)
                except Exception as exc:
                    self.log_message(
                        f"[SMART_LIMIT] Quote fetch failed for {order.asset} ({exc}); downgrading to market.",
                        color="yellow",
                    )
                    order.smart_limit = None
                    order.order_type = Order.OrderType.MARKET
                    return self.broker.submit_order(order)
                bid = getattr(quote, "bid", None)
                ask = getattr(quote, "ask", None)
                if bid is None or ask is None or bid < 0 or ask <= 0:
                    self.log_message(
                        f"[SMART_LIMIT] Missing bid/ask for {order.asset}; downgrading to market.",
                        color="yellow",
                    )
                    order.smart_limit = None
                    order.order_type = Order.OrderType.MARKET
                    return self.broker.submit_order(order)

                side = "buy" if order.is_buy_order() else "sell"
                tick = infer_tick_size(bid, ask)
                mid = compute_mid(bid, ask)
                final_price = compute_final_price(bid, ask, side, order.smart_limit.final_price_pct)
                ladder = build_price_ladder(mid, final_price, order.smart_limit.get_step_count())
                initial_price = round_to_tick(ladder[0], tick, side=side)

                order.limit_price = initial_price
                order._smart_limit_state = {
                    "created_at": time.monotonic(),
                    "step_index": 0,
                    "steps": max(1, order.smart_limit.get_step_count()),
                    "step_seconds": max(1, order.smart_limit.get_step_seconds()),
                    "final_hold_seconds": order.smart_limit.get_final_hold_seconds(),
                }

                original_type = order.order_type
                order.order_type = Order.OrderType.LIMIT
                try:
                    submitted = self.broker.submit_order(order)
                finally:
                    order.order_type = original_type
                return submitted

            return self.broker.submit_order(order)

    def _submit_multileg_smart_limit(self, order: Order):
        return self._submit_multileg_smart_limit_orders(order.child_orders, order.smart_limit)

    def _compute_multileg_net_best_fastest(self, child_orders: List[Order]) -> tuple[float, float] | None:
        """Compute signed net best/fastest prices for a multi-leg options package.

        Convention (matches OptionsHelper and SMART_LIMIT logic):
        - For buy legs: best=bid, fastest=ask (positive contribution)
        - For sell legs: best=-ask, fastest=-bid (negative contribution)
        """

        quote_data: list[tuple[Order, float | None, float | None]] = []
        for leg in child_orders:
            try:
                quote = self.get_quote(leg.asset, quote=leg.quote, exchange=leg.exchange)
                bid = getattr(quote, "bid", None)
                ask = getattr(quote, "ask", None)
            except Exception:
                bid = None
                ask = None
            quote_data.append((leg, bid, ask))

        if any(bid is None or ask is None or bid < 0 or ask <= 0 for _, bid, ask in quote_data):
            return None

        net_best = 0.0
        net_fastest = 0.0
        for leg, bid, ask in quote_data:
            if leg.is_buy_order():
                net_best += float(bid)
                net_fastest += float(ask)
            else:
                net_best -= float(ask)
                net_fastest -= float(bid)

        return net_best, net_fastest

    def _infer_multileg_type_and_mid(self, child_orders: List[Order]) -> tuple[str, float] | None:
        """Infer package type (debit/credit/even) and return abs(net_mid)."""

        computed = self._compute_multileg_net_best_fastest(child_orders)
        if computed is None:
            return None

        net_best, net_fastest = computed
        mid_signed = compute_mid(net_best, net_fastest)
        if abs(mid_signed) < 1e-9:
            return "even", 0.0
        if mid_signed > 0:
            return "debit", float(abs(mid_signed))
        return "credit", float(abs(mid_signed))

    def _submit_multileg_smart_limit_orders(self, child_orders: List[Order], smart_limit: SmartLimitConfig, **kwargs):
        if self.broker.IS_BACKTESTING_BROKER:
            kwargs.setdefault("is_multileg", True)
            return self.broker.submit_orders(child_orders, **kwargs)

        if smart_limit is None:
            smart_limit = _smart_limit_config()()

        computed = self._compute_multileg_net_best_fastest(child_orders)
        if computed is None:
            self.log_message(
                "[SMART_LIMIT] Missing bid/ask for multileg order; downgrading to market.",
                color="yellow",
            )
            return self.broker.submit_orders(child_orders, is_multileg=True, order_type=Order.OrderType.MARKET)
        net_best, net_fastest = computed

        tick = infer_tick_size(net_best, net_fastest)
        mid = compute_mid(net_best, net_fastest)
        final_signed = compute_final_price_from_mid(mid, net_fastest, smart_limit.final_price_pct)
        ladder = build_price_ladder(mid, final_signed, smart_limit.get_step_count())
        initial_signed = round_to_tick(ladder[0], tick, side="buy")

        initial_type = "even" if abs(initial_signed) < 1e-9 else ("debit" if initial_signed > 0 else "credit")
        initial_price: float | None = abs(initial_signed) if initial_type != "even" else 0.0
        broker_name = str(getattr(self.broker, "name", "")).lower()
        if initial_type == "even" and broker_name == "tradier":
            initial_price = None

        duration = kwargs.get("duration") or kwargs.get("time_in_force")
        if not duration:
            duration = "day" if all(o.asset.asset_type == "option" for o in child_orders) else (
                getattr(child_orders[0], "time_in_force", None) or "day"
            )

        state = {
            "created_at": time.monotonic(),
            "step_index": 0,
            "steps": max(1, smart_limit.get_step_count()),
            "step_seconds": max(1, smart_limit.get_step_seconds()),
            "final_hold_seconds": smart_limit.get_final_hold_seconds(),
            "multileg_order_type": initial_type,
        }

        submit_price = 0.0 if initial_price is None else float(initial_price)
        submit_price_or_none = None if (initial_type == "even" and broker_name == "tradier") else submit_price

        try:
            submitted = self.broker.submit_orders(
                child_orders,
                is_multileg=True,
                order_type=initial_type,
                duration=duration,
                price=submit_price_or_none,
            )
        except Exception as exc:
            self.log_message(
                f"[SMART_LIMIT] Multi-leg submit failed for type={initial_type} ({exc}); retrying as limit.",
                color="yellow",
            )
            submitted = self.broker.submit_orders(
                child_orders,
                is_multileg=True,
                order_type=Order.OrderType.LIMIT,
                duration=duration,
                price=submit_price,
            )

        parent_order = submitted[0] if isinstance(submitted, list) and submitted else submitted
        if parent_order is not None:
            parent_order.smart_limit = smart_limit
            parent_order.order_type = Order.OrderType.SMART_LIMIT
            parent_order._smart_limit_state = state
            parent_order.limit_price = 0.0 if initial_price is None else float(initial_price)
        return submitted

    def submit_orders(self, orders: List[Order], **kwargs):
        """[Deprecated] Submit a list of orders

        This method is deprecated and will be removed in future versions.
        Please use `submit_order` instead.

        Submits a list of orders for processing by the active broker.

        Parameters
        ----------
        orders : list of orders
            A list of order objects containing the asset and instructions for the orders.
        is_multileg : bool
            Tradier only.
            A boolean value to indicate if the orders are part of one multileg order.
            Currently, this is only available for Tradier.
        order_type : str
            Tradier only.
            The order type for the multileg order. Possible values are:
            ('market', 'debit', 'credit', 'even'). Default is 'market'.
        duration : str
            Tradier only.
            The duration for the multileg order. Possible values are:
            ('day', 'gtc', 'pre', 'post'). Default is 'day'.
        price : float
            Tradier only.
            The limit price for the multileg order. Required for 'debit' and 'credit' order types.
        tag : str
            Tradier only.
            A tag for the multileg order.

        Returns
        -------
        list of Order objects
            List of processed order objects.

        Examples
        --------
        >>> # For 2 market buy orders
        >>> order1 = self.create_order("SPY", 100, "buy")
        >>> order2 = self.create_order("TLT", 200, "buy")
        >>> self.submit_orders([order1, order2])

        >>> # For 2 limit buy orders
        >>> order1 = self.create_order("SPY", 100, "buy", limit_price=100.00)
        >>> order2 = self.create_order("TLT", 200, "buy", limit_price=100.00)
        >>> self.submit_orders([order1, order2])

        >>> # For 2 CRYPTO buy orders
        >>> from lumibot.entities import Asset
        >>>
        >>> asset_BTC = Asset(
        >>>    "BTC",
        >>>    asset_type=Asset.AssetType.CRYPTO,
        >>> )
        >>> asset_ETH = Asset(
        >>>    "ETH",
        >>>    asset_type=Asset.AssetType.CRYPTO,
        >>> )
        >>> asset_quote = Asset(
        >>>    "USD",
        >>>    asset_type=Asset.AssetType.FOREX,
        >>> )
        >>> order1 = self.create_order(asset_BTC, 0.1, "buy", quote=asset_quote)
        >>> order2 = self.create_order(asset_ETH, 10, "buy", quote=asset_quote)
        >>> self.submit_orders([order1, order2])
        >>> # or...
        >>> order1 = self.create_order((asset_BTC, asset_quote), 0.1, "buy")
        >>> order2 = self.create_order((asset_ETH, asset_quote), 10, "buy")
        >>> self.submit_orders([order1, order2])
        """
        #self.log_message("Warning: `submit_orders` is deprecated, please use `submit_order` instead.")
        return self.submit_order(orders, **kwargs)

    def wait_for_order_registration(self, order: Order):
        """Wait for the order to be registered by the broker

        Parameters
        ----------
        order : Order object
            Order object to be registered by the broker.

        Returns
        -------
        Order object

        Example
        -------
        >>> # For a market buy order
        >>> order = self.create_order("SPY", 100, "buy")
        >>> self.submit_order(order)
        >>> self.wait_for_order_registration(order)

        >>> # For a limit buy order
        >>> order = self.create_order("SPY", 100, "buy", limit_price=100.00)
        >>> self.submit_order(order)
        >>> self.wait_for_order_registration(order)


        """
        return self.broker.wait_for_order_registration(order)

    def wait_for_order_execution(self, order: Order):
        """Wait for one specific order to be executed or canceled by the broker

        Parameters
        ----------
        order : Order object
            Order object to be executed by the broker.

        Returns
        -------
        Order object

        Example
        -------
        >>> # For a market buy order
        >>> order = self.create_order("SPY", 100, "buy")
        >>> self.submit_order(order)
        >>> self.wait_for_order_execution(order)


        """
        return self.broker.wait_for_order_execution(order)

    def wait_for_orders_registration(self, orders: List[Order]):
        """Wait for the orders to be registered by the broker

        Parameters
        ----------
        orders : list of orders
            List of order objects to be registered by the broker.

        Returns
        -------
        list of orders

        Example
        -------
        >>> # For 2 market buy orders
        >>> order1 = self.create_order("SPY", 100, "buy")
        >>> order2 = self.create_order("TLT", 200, "buy")
        >>> self.submit_orders([order1, order2])
        >>> self.wait_for_orders_registration([order1, order2])
        """
        return self.broker.wait_for_orders_registration(orders)

    def wait_for_orders_execution(self, orders: List[Order]):
        """Wait for a list of orders to be executed or canceled by the broker

        Parameters
        ----------
        orders : list of orders
            List of order objects to be executed by the broker.

        Returns
        -------
        list of orders

        Example
        -------
        >>> # For 2 market buy orders
        >>> order1 = self.create_order("SPY", 100, "buy")
        >>> order2 = self.create_order("TLT", 200, "buy")
        >>> self.submit_orders([order1, order2])
        >>> self.wait_for_orders_execution([order1, order2])
        """
        return self.broker.wait_for_orders_execution(orders)

    def cancel_order(self, order: Order, *, reason: str | None = None, evidence: dict | None = None):
        """Cancel an order.

        Cancels a single open order provided.

        Parameters
        ---------
        An order object that the user seeks to cancel.

        Returns
        -------
        None

        Example
        -------
        >>> # Create an order then cancel it
        >>> order = self.create_order("SPY", 100, "buy")
        >>> self.submit_order(order)
        >>> self.cancel_order(order)

        """
        reference = self._journal_order_action(order, operation="cancel", reason=reason, evidence=evidence)
        # Set the status to CANCELLING
        order.status = Order.OrderStatus.CANCELLING

        # Cancel the order
        return self._perform_journaled_order_action(reference, lambda: self.broker.cancel_order(order))

    def cancel_orders(self, orders: List[Order], *, reason: str | None = None, evidence: dict | None = None):
        """Cancel orders in all strategies.

        Cancels all open orders provided in any of the running
        strategies.

        Parameters
        ----------
        orders : list of Order objects.

        Returns
        -------
        None

        Example
        -------
        >>> # Create two orders then cancel them
        >>> order1 = self.create_order("IBM", 100, "buy")
        >>> order2 = self.create_order("AAPL", 100, "buy")
        >>> self.submit_orders([order1, order2])
        >>>
        >>> # Cancel all orders
        >>> self.cancel_orders([order1, order2])
        """
        if not orders:
            return []
        reference = self._journal_order_action(orders, operation="cancel", reason=reason, evidence=evidence)
        return self._perform_journaled_order_action(reference, lambda: self.broker.cancel_orders(orders))

    def cancel_open_orders(self, orders: list[Order] | None = None, *, reason: str | None = None, evidence: dict | None = None):
        """Cancel all the strategy open orders.

        Cancels all orders that are open and awaiting execution within
        a given strategy. If running multiple strategies, will only
        cancel the orders in the current strategy.

        Parameters
        ----------
        orders : list[Order] | None
            Optional list of already enumerated orders. Pass in the list
            when you have just fetched/filtered the active orders to avoid
            re-querying the broker; leave as None to let the broker gather
            them itself.

        Returns
        -------
        None

        Example
        -------
        >>> # Cancel all open orders
        >>> self.cancel_open_orders()

        """
        active_orders: list[Order] = []
        try:
            tracked_orders = orders if orders is not None else self.broker.get_tracked_orders(self.name)
            active_orders = [order for order in tracked_orders if order.is_active()]
            if active_orders:
                order_ids = [
                    getattr(order, "identifier", None)
                    or getattr(order, "id", None)
                    or getattr(order, "order_id", None)
                    for order in active_orders
                ]
                self.log_message(
                    f"cancel_open_orders -> active={len(active_orders)} ids={order_ids}",
                    color="yellow",
                )
        except Exception as exc:  # pragma: no cover - defensive logging
            self.logger.exception("Failed to enumerate open orders before cancellation: %s", exc)
            active_orders = []

        if not active_orders:
            return []

        reference = self._journal_order_action(active_orders, operation="cancel", reason=reason, evidence=evidence)
        return self._perform_journaled_order_action(reference, lambda: self.broker.cancel_open_orders(self.name, active_orders))

    def modify_order(self, order: Order, limit_price: Union[float, None] = None, stop_price: Union[float, None] = None, *, quantity=None, reason: str | None = None, evidence: dict | None = None):
        """Modify an order.

        Modifies a single open order provided.

        Parameters
        ----------
        order : Order object
            Order object to be modified.
        limit_price : float
            New limit price for a limit order. Default is None.
        stop_price : float
            New stop price for a stop order. Default is None.
        quantity : number, optional
            New total quantity, including fills already received. Availability
            depends on the broker. Omit to leave quantity unchanged.

        Returns
        -------
        None

        Example
        -------
        >>> # Modify an existing order
        >>> order = self.create_order("SPY", 100, "buy", limit_price=100.00)
        >>> self.submit_order(order)
        >>> self.modify_order(order, limit_price=101.00)
        """
        # Check if the order is already cancelled or filled
        if not order.is_active():
            return

        if not order.identifier:
            raise ValueError("Order identifier is not set, unable to modify order. Did you remember to submit it?")

        changes = {"limit_price": limit_price, "stop_price": stop_price}
        if quantity is not None:
            changes["quantity"] = quantity
        reference = self._journal_order_action(order, operation="modify", reason=reason, evidence=evidence,
                                               changes=changes)
        result = self._perform_journaled_order_action(reference, lambda: self.broker.modify_order(order, **changes))
        if limit_price is not None:
            order.limit_price = limit_price
        if stop_price is not None:
            order.stop_price = stop_price
        if quantity is not None:
            order.quantity = quantity
        return result

    def sell_all(self, cancel_open_orders: bool = True, is_multileg: bool = False):
        """Sell all strategy positions.

        The system will generate closing market orders for each open
        position. If `cancel_open_orders` is `True`, then all open
        orders will also be cancelled.

        Open orders are cancelled before the positions are closed.

        Parameters
        ----------
        cancel_open_orders : boolean
            Cancel all order if True, leave all orders in place if
            False. Default is True.
        is_multileg : boolean
            When True, will use multileg orders to close positions.

        Returns
        -------
        None

        Example
        -------
        >>> # Will close all positions for the strategy
        >>> self.sell_all()
        """
        self.broker.sell_all(self.name, cancel_open_orders=cancel_open_orders, strategy=self, is_multileg=is_multileg)

    def close_position(self, asset, fraction: float = 1.0, position_side=None, position_id=None):
        """
        Close a single position for the specified asset.

        This method attempts to close an open position for the given asset. For most brokers, this is done by submitting a market sell order for the open position. For crypto futures brokers (such as Bitunix), this may use a broker-specific fast-close or "flash close" endpoint to close the position immediately at market price.

        Args:
            asset (str or Asset): The symbol or Asset object identifying the position to close.

        Returns:
            Any: The broker.close_position result, or None if no action was taken.

        Notes:
            - For crypto futures (e.g., Bitunix), this will use the broker's flash close endpoint if available.
            - For spot/stock/futures brokers, this will submit a market sell order for the open position.
            - If no open position exists, this method does nothing.
        """
        asset_obj = self._sanitize_user_asset(asset)

        position = None
        try:
            selectors = {key: value for key, value in (("position_side", position_side), ("position_id", position_id))
                         if value is not None}
            position = self.get_position(asset_obj, **selectors)
            qty = getattr(position, "quantity", 0) if position else 0
            self.log_message(
                f"close_position -> asset={asset_obj.symbol if hasattr(asset_obj, 'symbol') else asset_obj}, "
                f"fraction={fraction}, current_qty={qty}",
                color="yellow",
            )
        except ValueError as exc:
            # An unselected hedge position may have multiple legs; the broker
            # closes all of them below without requiring a single-position view.
            self.logger.debug("Position lookup before close_position: %s", exc)
        except Exception as exc:  # pragma: no cover - defensive logging
            self.logger.exception("Unable to inspect position prior to close_position: %s", exc)

        target_asset = getattr(position, "asset", asset_obj) if position is not None else asset_obj
        if target_asset is not asset_obj:
            try:
                self.log_message(
                    f"close_position -> resolved continuous asset {asset_obj.symbol if hasattr(asset_obj, 'symbol') else asset_obj} "
                    f"to contract {target_asset.symbol if hasattr(target_asset, 'symbol') else target_asset}",
                    color="yellow",
                )
            except Exception:  # pragma: no cover - best effort logging
                pass
        selectors = {key: value for key, value in (("position_side", position_side), ("position_id", position_id))
                     if value is not None}
        result = self.broker.close_position(self.name, target_asset, fraction, **selectors)
        if result is None:
            self.log_message("close_position -> broker returned None (no order submitted)", color="yellow")
        else:
            order_id = getattr(result, "identifier", None) or getattr(result, "id", None) or getattr(result, "order_id", None)
            self.log_message(
                f"close_position -> broker submitted order {order_id} (type={type(result).__name__})",
                color="yellow",
            )
        if result is not None:
            return result

    def close_positions(self, assets):
        """
        Close multiple positions for the specified assets.

        Iterates over the provided list of assets and attempts to close each open position. See `close_position` for details on how each position is closed.

        Args:
            assets (list[str or Asset]): Symbols or Asset objects identifying the positions to close.

        Returns:
            list: Results from each `close_position` call, or None if no action was taken.

        Notes:
            - For crypto futures (e.g., Bitunix), this will use the broker's flash close endpoint if available.
            - For spot/stock/futures brokers, this will submit a market sell order for each open position.
        """
        results = []
        for asset in assets:
            results.append(self.close_position(asset))
        return results

    def get_contract_exposure(self, asset, quantity, price):
        """Return base/quote derivative exposure using the selected broker's native units."""
        return self.broker.get_contract_exposure(asset, quantity, price, quote=self.quote_asset)

    def get_quantity_for_notional(self, asset, notional, price=None):
        """Native derivative quantity for a notional in the instrument's quote currency."""
        return self.broker.get_quantity_for_notional(asset, notional, price=price, quote=self.quote_asset)

    def get_last_price(self, asset: Union[Asset, str], quote=None, exchange=None) -> Union[float, Decimal, None]:
        """Takes an asset and returns the last known price

        Makes an active call to the market to retrieve the last price.
        In backtesting will provide the close of the last complete bar.

        Parameters
        ----------
        asset : Asset object or str
            Asset object for which the last closed price will be
            retrieved.
        quote : Asset object
            Quote asset object for which the last closed price will be
            retrieved. This is required for cryptocurrency pairs.
        exchange : str
            Exchange name for which the last closed price will be
            retrieved. This is required for some cryptocurrency pairs.
        should_use_last_close : bool
            If False, it will make Interactive Brokers only return the
            price of an asset if it has been trading today. Defaults to True.
            TODO: Should this option be depricated? It is now commented out below

        Returns
        -------
        Float or Decimal
            Last closed price as either a float or Decimal object.

        Example
        -------
        >>> # Will return the last price for the asset
        >>> asset = "SPY"
        >>> last_price = self.get_last_price(asset)
        >>> self.log_message(f"Last price for {asset} is {last_price}")

        >>> # Will return the last price for a crypto asset
        >>> base = Asset(symbol="BTC", asset_type="crypto")
        >>> quote = Asset(symbol="USDT", asset_type="crypto")
        >>> last_price = self.get_last_price(base, quote=quote)
        >>> self.log_message(f"Last price for BTC/USDT is {last_price}")

        >>> # Will return the last price for a crypto asset
        >>> base = Asset(symbol="BTC", asset_type="crypto")
        >>> quote = Asset(symbol="USD", asset_type="forex")
        >>> last_price = self.get_last_price(base, quote=quote)
        >>> self.log_message(f"Last price for BTC/USD is {last_price}")

        >>> # Will return the last price for a futures asset
        >>> self.base = Asset(
        >>>     symbol="ES",
        >>>     asset_type="future",
        >>>     expiration=date(2022, 12, 16),
        >>> )
        >>> price = self.get_last_price(asset=self.base, exchange="CME")
        """

        # Check if the asset is valid
        if asset is None or (isinstance(asset, Asset) and not asset.is_valid()):
            self.logger.error(
                f"Asset in get_last_price() must be a valid asset. Got {asset} of type {type(asset)}. You may be missing some of the required parameters for the asset type (eg. strike price for options, expiry for options/futures, etc)."
            )
            return None

        # Check if the Asset object is a string or Asset object
        if not (isinstance(asset, Asset) or isinstance(asset, str) or isinstance(asset, tuple)):
            self.logger.error(
                f"Asset in get_last_price() must be a string or Asset or tuple object. Got {asset} of type {type(asset)}"
            )
            return None

        asset = self._sanitize_user_asset(asset)

        if quote is None:
            quote_asset = self.quote_asset
        else:
            quote_asset = quote

        is_backtesting_run = bool(
            IS_BACKTESTING
            or getattr(self, "is_backtesting", False)
            or getattr(getattr(self, "broker", None), "IS_BACKTESTING_BROKER", False)
        )
        if is_backtesting_run:
            current_datetime = getattr(getattr(self, "broker", None), "datetime", None)
            cache = getattr(self, "_last_price_request_cache", None)
            if cache is None:
                cache = {}
                self._last_price_request_cache = cache
                self._last_price_request_cache_datetime = current_datetime
            elif getattr(self, "_last_price_request_cache_datetime", None) != current_datetime:
                cache.clear()
                self._last_price_request_cache_datetime = current_datetime
            cache_key = (asset, quote_asset, exchange)
            if cache_key in cache:
                return cache[cache_key]

        if is_backtesting_run:
            self._record_backtest_runtime_milestone("first_price_lookup_at")
        try:
            # For daily-cadence backtests, prefer day bars for sources where minute-level
            # fetches are expensive (ThetaData/IBKR/routed backtesting). Keep Yahoo/Polygon
            # on legacy behavior to preserve existing regression anchors.
            #
            # 🚨 CRITICAL — sim-time safety invariant:
            # This shortcut MUST request exactly the bar AT (or the last completed bar before)
            # the simulation time — never a bar after it. In backtests the full history exists
            # ahead of the sim clock, so any call that reaches into the future is look-ahead
            # bias and will silently leak future prices into position sizing / last-price reads.
            #
            # Why `length=1` (no timeshift, no length=2):
            # `Data.get_bars(dt, length, timestep="day", timeshift=0)` returns rows in the closed
            # interval `[iter_count - (length - 1), iter_count]` where `iter_count` is the index
            # of the last bar whose timestamp is ≤ `dt` (see `Data.get_iter_count` —
            # `searchsorted(side="right") - 1`). With `length=1, timeshift=0` the slice is the
            # single bar at `iter_count`, guaranteed to be at or before sim_time.
            #
            # The earlier `length=2, timeshift=-1` call produced `slice(iter_count, iter_count+2)`,
            # i.e. `[bar-at-sim-time, next-bar-after-sim-time]`, and then read `iloc[-1]` —
            # returning the NEXT bar's close. When the underlying frame also contained bars past
            # the backtest window (e.g. a shared S3 cache row stamped at wall-clock "today"),
            # that next-bar was real-now's market close. Observed 2026-04-17 on an Alpha Picks
            # IBKR backtest: `get_last_price(COP, sim_time=2022-07-01)` returned $97.43 (today's
            # close) instead of the 2022-07-01 close of $90.98, polluting position sizing.
            # Regression coverage lives in `tests/test_get_last_price_sim_time_safety.py` and
            # explicitly replays a polluted frame so this exact failure mode cannot re-land.
            should_use_daily = self._should_use_daily_last_price(asset)
            if is_backtesting_run and should_use_daily and self._supports_daily_last_price_optimization():
                try:
                    bars = self.get_historical_prices(
                        asset,
                        length=1,
                        timestep="day",
                        quote=quote_asset,
                        exchange=exchange,
                    )
                    if bars is not None and getattr(bars, "df", None) is not None and not bars.df.empty:
                        result = float(bars.df["close"].iloc[-1])
                        cache[cache_key] = result
                        self._record_usable_backtest_price(result)
                        return result

                    # Forward-fill retry (v4.5.1): when the length=1 slice comes
                    # back empty (observed on 24/7-market midnight iterations —
                    # no day bar exists exactly at sim_time=00:00), request a
                    # small window ending at sim_time and return the close of
                    # the last row with index <= sim_time. Without this, the
                    # shortcut returns None → broker fallback also returns
                    # None → strategy skips every order for the entire run
                    # (observed on Alpha Picks 24/7 local BT: 31 simulated
                    # days at Val: $100,000 with zero trades). Semantic: "if
                    # we have no bar at sim_time, the price hasn't changed
                    # since the last known bar" — matches how mark-to-market
                    # works elsewhere. No guard layered here; this ONLY
                    # triggers on an honestly-empty length=1 result.
                    sim_dt = getattr(getattr(self, "broker", None), "datetime", None)
                    if sim_dt is not None:
                        bars_ff = self.get_historical_prices(
                            asset,
                            length=5,
                            timestep="day",
                            quote=quote_asset,
                            exchange=exchange,
                        )
                        if (
                            bars_ff is not None
                            and getattr(bars_ff, "df", None) is not None
                            and not bars_ff.df.empty
                        ):
                            try:
                                df_ff = bars_ff.df
                                idx = df_ff.index
                                sim_cmp = pd.Timestamp(sim_dt)
                                if getattr(idx, "tz", None) is not None and sim_cmp.tzinfo is None:
                                    sim_cmp = sim_cmp.tz_localize(idx.tz)
                                elif getattr(idx, "tz", None) is None and sim_cmp.tzinfo is not None:
                                    sim_cmp = sim_cmp.tz_localize(None)
                                pre_sim = df_ff[idx <= sim_cmp]
                                if not pre_sim.empty:
                                    result = float(pre_sim["close"].iloc[-1])
                                    cache[cache_key] = result
                                    self._record_usable_backtest_price(result)
                                    return result
                            except Exception:
                                pass
                except Exception:
                    # Fall through to the default path on any failure.
                    pass
            result = self.broker.get_last_price(
                asset,
                quote=quote_asset,
                exchange=exchange,
                # should_use_last_close=should_use_last_close,
            )
            if is_backtesting_run:
                cache[cache_key] = result
                self._record_usable_backtest_price(result)
            return result
        except UnsupportedAsset:
            raise
        except Exception as e:
            self.log_message(f"Could not get last price for {asset}", color="red")
            self.log_message(f"{e}")
            return None

    def _record_backtest_runtime_milestone(self, name):
        try:
            source = self.broker.data_source
            recorder = getattr(source, "record_runtime_milestone", None)
            if callable(recorder):
                recorder(name)
        except Exception:
            pass

    def _record_usable_backtest_price(self, price):
        try:
            import math

            if price is not None and math.isfinite(float(price)):
                self._record_backtest_runtime_milestone("first_usable_price_at")
        except (TypeError, ValueError, OverflowError):
            pass

    def _supports_daily_last_price_optimization(self) -> bool:
        data_source = getattr(getattr(self, "broker", None), "data_source", None)
        if data_source is None:
            return False
        source_name = type(data_source).__name__.lower()
        is_routed_backtesting = (
            "routed" in source_name
            and ("backtesting" in source_name or "backtest" in source_name)
        )
        return (
            "thetadata" in source_name
            or is_routed_backtesting
            or "ibkr" in source_name
        )

    def _should_use_daily_last_price(self, asset: Asset) -> bool:
        if asset is None:
            return False
        asset_type = getattr(asset, "asset_type", "")
        asset_type = getattr(asset_type, "value", asset_type)
        asset_type = str(asset_type).lower()
        if asset_type not in {"stock", "equity", "index"}:
            return False
        if not (
            IS_BACKTESTING
            or getattr(self, "is_backtesting", False)
            or getattr(getattr(self, "broker", None), "IS_BACKTESTING_BROKER", False)
        ):
            return False
        sleep_value = getattr(self, "sleeptime", None)
        if isinstance(sleep_value, str) and sleep_value.strip().lower().endswith("d"):
            return True
        cadence_seconds = self._get_sleeptime_seconds()
        if cadence_seconds is None:
            raw_sleep = getattr(self, "_sleeptime", None)
            return isinstance(raw_sleep, str) and raw_sleep.strip().lower().endswith("d")
        return cadence_seconds >= 20 * 3600

    def _get_sleeptime_seconds(self) -> Optional[float]:
        value = getattr(self, "_sleeptime", None)
        if value is None:
            return None
        cached_input = getattr(self, "_sleeptime_seconds_cache_input", object())
        if value == cached_input:
            return getattr(self, "_sleeptime_seconds_cache_value", None)
        if isinstance(value, (int, float)):
            result = float(value) * 60.0
            self._sleeptime_seconds_cache_input = value
            self._sleeptime_seconds_cache_value = result
            return result
        if isinstance(value, str):
            normalized = value.strip().upper().replace(" ", "")
            if not normalized:
                return None
            match = re.match(r"^(\d+(?:\.\d+)?)([A-Z]*)$", normalized)
            if not match:
                return None
            qty = float(match.group(1))
            suffix = match.group(2) or "M"
            if suffix.startswith("S"):
                multiplier = 1.0
            elif suffix.startswith("H"):
                multiplier = 3600.0
            elif suffix.startswith("D"):
                multiplier = 86400.0
            else:
                multiplier = 60.0
            result = qty * multiplier
            self._sleeptime_seconds_cache_input = value
            self._sleeptime_seconds_cache_value = result
            return result
        return None

    def get_quote(self, asset: Asset, quote: Asset = None, exchange: str = None) -> Quote:
        """Get a quote for the asset.

        Parameters
        ----------
        asset : Asset object
            The asset for which the quote is needed.
        quote : Asset object, optional
            The quote asset for cryptocurrency pairs.
        exchange : str, optional
            The exchange to get the quote from.

        Returns
        -------
        Quote
            A Quote object with the quote information, eg. bid, ask, etc.
        """

        asset = self._sanitize_user_asset(asset)

        try:
            if self.broker.option_source and asset.asset_type == "option":
                return self.broker.option_source.get_quote(asset, quote=quote, exchange=exchange)
            else:
                return self.broker.data_source.get_quote(asset, quote=quote, exchange=exchange)
        except UnsupportedAsset:
            raise
        except Exception as e:
            self.log_message(f"Error getting quote from data source: {e}", color="red")
            return _quote_class()(asset=asset)

    def get_quotes(self, assets: List[Asset], quote: Asset = None, exchange: str = None):
        """Return exact Assets mapped to Quote objects (or None when absent).

        Schwab batches up to 50 symbols per request, including selected option
        contracts. Other providers retain their existing get_quote behavior;
        no batching speed is promised without a native adapter. Option assets
        honor the configured option_source just like get_quote. A native batch
        failure raises instead of silently triggering serial retries. Snapshot
        freshness and trading decisions remain the strategy's responsibility.
        """
        assets = list(dict.fromkeys(self._sanitize_user_asset(asset) for asset in assets))
        groups = {}
        for asset in assets:
            source = self.broker.option_source if self.broker.option_source and asset.asset_type == "option" else self.broker.data_source
            groups.setdefault(id(source), (source, []))[1].append(asset)
        result = {}
        for source, selected in groups.values():
            native = getattr(source, "get_quotes", None)
            if callable(native):
                quotes = native(selected, quote=quote, exchange=exchange)
                if not isinstance(quotes, dict) or any(asset not in quotes for asset in selected):
                    raise ValueError("Bulk quote adapter omitted requested asset results")
                if any(value is not None and getattr(value, "asset", None) != asset for asset, value in quotes.items() if asset in selected):
                    raise ValueError("Bulk quote adapter returned another asset's quote")
                result.update({asset: quotes[asset] for asset in selected})
            else:
                result.update({asset: self.get_quote(asset, quote=quote, exchange=exchange) for asset in selected})
        return {asset: result[asset] for asset in assets}

    def get_tick(self, asset: Union[Asset, str]):
        """Takes an Asset and returns the last known price"""
        # TODO: Should this function be depricated? This appears to be an IBKR-only thing.
        asset = self._sanitize_user_asset(asset)
        return self.broker._get_tick(asset)

    def get_last_prices(self, assets: List[Asset], quote=None, exchange=None):
        """Takes a list of assets and returns the last known prices

        Makes an active call to the market to retrieve the last price. In backtesting will provide the close of the last complete bar.

        Parameters
        ----------
        assets : list of Asset objects
            List of Asset objects for which the last closed price will be retrieved.
        quote : Asset object
            Quote asset object for which the last closed price will be
            retrieved. This is required for cryptocurrency pairs.
        exchange : str
            The exchange to get the prices of.

        Returns
        -------
        list of floats or Decimals
            Last known closing prices as either a list of floats or Decimal objects.

        Example
        -------
        >>> # Will return the last price for the assets
        >>> assets = ["SPY", "TLT"]
        >>> last_prices = self.get_last_prices(assets)
        """
        symbol_asset = isinstance(assets[0], str)
        if symbol_asset:
            assets = [self._sanitize_user_asset(asset) for asset in assets]

        asset_prices = self.broker.get_last_prices(assets, quote=quote, exchange=exchange)

        if symbol_asset:
            return {a.symbol: p for a, p in asset_prices.items()}
        else:
            return asset_prices

    # ======= Broker Methods  ============
    def options_expiry_to_datetime_date(self, expiry) -> datetime.date:
        """Convert an options expiry to datetime.date.

        Parameters
        ----------
        expiry : str | datetime.date | datetime.datetime
            The expiry to convert. Can be:
            - String in 'YYYYMMDD' format (legacy IB format)
            - String in 'YYYY-MM-DD' format (Polygon format)
            - datetime.date object
            - datetime.datetime object

        Returns
        -------
        datetime.date
            The normalised expiry date.
        """
        if isinstance(expiry, datetime.datetime):
            return expiry.date()
        if isinstance(expiry, datetime.date):
            return expiry
        if isinstance(expiry, str):
            # Try different string formats
            expiry_clean = expiry.strip()

            # Try YYYY-MM-DD format (Polygon)
            if len(expiry_clean) == 10 and expiry_clean[4] == '-' and expiry_clean[7] == '-':
                try:
                    return datetime.datetime.strptime(expiry_clean, "%Y-%m-%d").date()
                except ValueError:
                    pass

            # Try YYYYMMDD format (IB legacy)
            expiry_digits = expiry_clean.replace("-", "")
            if len(expiry_digits) == 8 and expiry_digits.isdigit():
                try:
                    return datetime.datetime.strptime(expiry_digits, "%Y%m%d").date()
                except ValueError:
                    pass

            raise ValueError(f"Unable to parse expiry string: {expiry}")

        raise TypeError(
            f"expiry must be a string, datetime.date, or datetime.datetime instance, got {type(expiry)}"
        )

    def get_chains(self, asset: Asset):
        """Returns option chains.

        Obtains option chain information for the asset (stock) from each
        of the exchanges the options trade on and returns a dictionary
        for each exchange.

        Parameters
        ----------
        asset : Asset object
            The stock whose option chain is being fetched. Represented
            as an asset object.

        Returns
        -------
        dictionary of dictionary
            Format:
            - `Multiplier` (str) eg: `100`
            - 'Chains' - paired Expiration/Strike info to guarentee that the strikes are valid for the specific
                         expiration date.
                         Format:
                           chains['Chains']['CALL'][exp_date] = [strike1, strike2, ...]
                         Expiration Date Format: 2023-07-31

        Example
        -------
        >>> # Will return the option chains for SPY
        >>> asset = "SPY"
        >>> chains = self.get_chains(asset)
        """
        asset = self._sanitize_user_asset(asset)
        return self.broker.get_chains(asset)

    def get_next_trading_day(self, date: str, exchange="NYSE"):
        """
        Finds the next trading day for the given date and exchange.

        Parameters
        ----------
        date : str
            The date from which to find the next trading day, in 'YYYY-MM-DD' format.
        exchange : str
            The exchange calendar to use, default is 'NYSE'.

        Returns
        -------
            next_trading_day (datetime.date): The next trading day after the given date.
        """

        # Load the specified market calendar
        calendar = mcal.get_calendar(exchange)

        # Convert the input string date to pandas Timestamp
        date_timestamp = pd.Timestamp(date)

        # Get the next trading day. The schedule is inclusive of the start_date when the market is open on this day.
        # Hence, we add 1 day to the start_date to ensure we start checking from the day after.
        schedule = calendar.schedule(start_date=date_timestamp + pd.Timedelta(days=1),
                                     end_date=date_timestamp + pd.Timedelta(days=10))

        # The next trading day is the first entry in the schedule
        next_trading_day = schedule.index[0].date()

        return next_trading_day

    def get_chain(self, chains: dict, exchange: str = "SMART"):
        """Returns option chain for a particular exchange.

        Takes in a full set of chains for all the exchanges and returns
        on chain for a given exchange. The full chains are returned
        from `get_chains` method.

        Parameters
        ----------
        chains : dictionary of dictionaries
            The chains dictionary created by `get_chains` method.

        exchange : str optional
            The exchange such as `SMART`, `CBOE`. Default is `SMART`

        Returns
        -------
        dictionary of dictionary
            Format:
            - `Multiplier` (str) eg: `100`
            - 'Chains' - paired Expiration/Strke info to guarentee that the stikes are valid for the specific
                         expiration date.
                         Format:
                           chains['Chains']['CALL'][exp_date] = [strike1, strike2, ...]
                         Expiration Date Format: 2023-07-31

        Example
        -------
        >>> # Will return the option chains for SPY
        >>> asset = "SPY"
        >>> chain = self.get_chain(asset)
        """
        return self.broker.get_chain(chains)

    def get_chain_full_info(
            self,
            asset: Asset,
            expiry: Union[str, datetime.datetime, datetime.date],
            chains: dict = None,
            underlying_price: float = None,
            risk_free_rate: float = None,
            strike_min: float = None,
            strike_max: float = None
            ) -> pd.DataFrame:
        """Returns full option chain information for a given asset and expiry. This will include all known broker
        option information for each strike price, including: greeks, bid, ask, volume, open_interest etc. Not all
        Lumibot brokers provide all of this data and tick-style data like bid/ask/open_interest are not available
        during BackTesting.

        This method can be quite slow for brokers that do not provide this data natively, as it will need to make
        multiple API calls (1 per strike) to get all the data.  Min/Max strike values can be provided to reduce the
        number of queries made.

        Using the `chains` dictionary obtained from `get_chains` finds
        all the options information for a given asset and expiry.

        Parameters
        ----------
        asset : Asset object
            The asset for which the option chain is being fetched.
        expiry : str | datetime.datetime | datetime.date
            The expiry date for the option chain in the format of
            `2023-07-31`.
        chains : dictionary of dictionaries, optional
            The chains dictionary created by `get_chains` method. If not
            provided, the method will fetch the chains for the asset (if needed). This is
            needed to discover the list of strikes. Some brokers like Tradier or
            Polygon LiveData do not need the strike list.
        underlying_price : float, optional
            The price of the underlying asset. If not provided, the
            method will fetch the price from the broker. Useful to provide to reduce the
            number of API calls.
        risk_free_rate : float, optional
            The risk-free rate to use in the calculations. If not
            provided, the method will use the default risk-free rate.
        strike_min : float, optional
            The minimum strike price to return. If not provided, the
            method will return all strikes.
        strike_max : float, optional
            The maximum strike price to return. If not provided, the
            method will return all strikes.

        Returns
        -------
        pd.DataFrame
            A DataFrame with the option chain information.

        Example
        -------
        >>> # Will return the option chains for SPY
        >>> asset = "SPY"
        >>> expiry = "2023-07-31"
        >>> df = self.get_chain_full_info(asset, expiry)
        >>> print(f"Strike: {df.iloc[0]['strike']}, Delta: {df.iloc[0]['greeks.delta']}")
        """
        asset = self._sanitize_user_asset(asset)
        # Native chain snapshots already contain provider Greeks. Do not fetch
        # interest rates or underlying prices that those adapters never use.
        needs_pricing = getattr(self.broker.data_source, "CHAIN_FULL_INFO_REQUIRES_PRICING_INPUTS", True)
        if needs_pricing:
            risk_free_rate = risk_free_rate if risk_free_rate is not None else self.risk_free_rate
            if underlying_price is None:
                underlying_asset = Asset(symbol=asset.symbol, asset_type="stock")
                underlying_price = self.get_last_price(underlying_asset)

        return self.broker.get_chain_full_info(asset, expiry, chains=chains, underlying_price=underlying_price,
                                               risk_free_rate=risk_free_rate, strike_min=strike_min,
                                               strike_max=strike_max)

    def get_expiration(self, chains: dict):
        """Returns expiration dates for an option chain for a particular
        exchange.

        Using the `chains` dictionary obtained from `get_chains` finds
        all expiry dates for the option chains on a given
        exchange. The return list is sorted.

        Parameters
        ---------
        chains : dictionary of dictionaries
            The chains dictionary created by `get_chains` method.

        Returns
        -------
        list of datetime.date
            Sorted list of dates in the form of `2022-10-13`.

        Example
        -------
        >>> # Will return the expiry dates for SPY
        >>> asset = "SPY"
        >>> expiry_dates = self.get_expiration(asset)
        """
        return self.broker.get_expiration(chains)

    def get_multiplier(self, chains: dict, exchange: str = "SMART"):
        """Returns option chain for a particular exchange.

        Using the `chains` dictionary obtained from `get_chains` finds
        all the multipliers for the option chains on a given
        exchange.

        Parameters
        ----------
        chains : dictionary of dictionaries
            The chains dictionary created by `get_chains` method.

        exchange : str optional
            The exchange such as `SMART`, `CBOE`. Default is `SMART`

        Returns
        -------
        list of str
            Sorted list of dates in the form of `20221013`.

        Example
        -------
        >>> # Will return the multiplier for SPY
        >>> asset = "SPY"
        >>> multiplier = self.get_multiplier(asset)
        """

        return self.broker.get_multiplier(chains, exchange=exchange)

    def get_strikes(self, asset: Asset, chains: dict = None):
        """Returns a list of strikes for a give underlying asset.

        Using the `chains` dictionary obtained from `get_chains` finds
        all the multiplier for the option chains on a given
        exchange.

        Parameters
        ----------
        asset : Asset
            Asset object as normally used for an option but without
            the strike information. The Asset object must be an option asset type.
        chains : dictionary of dictionaries, optional
            The chains dictionary created by `get_chains` method. If not
            provided, the method will fetch the chains for the asset.

        Returns
        -------
        list of floats
            Sorted list of strikes as floats.

        Example
        -------
        >>> # Will return the strikes for SPY
        >>> asset = "SPY"
        >>> strikes = self.get_strikes(asset)
        """

        asset = self._sanitize_user_asset(asset)
        return self.broker.get_strikes(asset, chains)

    def find_first_friday(self, timestamp: Union[datetime.datetime, pd.Timestamp]):
        """Finds the first Friday of the month for a given timestamp.

        Parameters
        ----------
        timestamp : datetime.datetime | pd.Timestamp
            The timestamp for which the first Friday of the month is
            needed.

        Returns
        -------
        datetime.datetime
            The first Friday of the month.
        """
        # Convert the timestamp to a datetime object if it's not already one
        if isinstance(timestamp, pd.Timestamp):
            timestamp = timestamp.to_pydatetime()

        # Get the day index of the first day of the month (0 is Monday, 1 is Tuesday, etc.)
        day_index = timestamp.weekday()

        # Calculate the number of days to add to reach the first Friday
        days_to_add = (4 - day_index) % 7

        # Create a new datetime object for the first Friday of the month
        first_friday = timestamp + datetime.timedelta(days=days_to_add)

        return first_friday

    def get_option_expiration_after_date(self, dt: datetime.date):
        """Returns the next option expiration date after the given date.

        Parameters
        ----------
        dt : datetime.date
            The date to find the next option expiration date after.

        Returns
        -------
        datetime.date
            The next option expiration date after the given date.

        Example
        -------
        >>> # Will return the next option expiration date after the given date
        >>> dt = datetime.date(2021, 1, 1)
        >>> next_option_expiration = self.get_next_option_expiration(dt)
        """

        tz = self.timezone
        if dt.tzinfo is None:
            dt = pd.Timestamp(dt).tz_localize(tz)
        else:
            dt = pd.Timestamp(dt).tz_convert(tz)

        # Loop over this month and the next month
        for month_increment in [0, 1]:
            # Calculate the first day of the target month
            first_day_of_month = (
                pd.Timestamp(dt.year, dt.month + month_increment, 1)
                if dt.month + month_increment <= 12
                else pd.Timestamp(dt.year + 1, (dt.month + month_increment) % 12, 1)
            )

            # Localize the first day of the month to the timezone
            first_day_of_month = first_day_of_month.tz_localize(tz)

            # Get the first Friday of the month
            first_friday = self.find_first_friday(first_day_of_month)

            # Calculate the third Friday
            third_friday = first_friday + pd.tseries.offsets.Week(2)

            # Check if the third Friday is after the input date
            if third_friday > dt:
                expiration = third_friday
                break

        # Check if the market is open on the expiration date, if not then get the previous open day
        nyse = mcal.get_calendar("NYSE")

        # Get the schedule for all the days that the market is open between the given date and the proposed expiration date
        end_date = expiration + pd.tseries.offsets.BusinessDay(
            2
        )  # Add 2 days to include the expiration date, in case it is a holiday
        schedule = nyse.schedule(start_date=dt, end_date=end_date)

        # Change the schedule index timezone to be the same as the expiration date timezone
        schedule.index = schedule.index.tz_localize(tz)

        # Check if the expiration date is in the schedule, if not then get the previous open day. Make sure they're only comparing dates, not times
        if expiration.date() not in schedule.index.date:
            # Find the date in the schedule that is right before the expiration date
            previous_open_day = schedule.index[schedule.index < expiration][-1]
            return previous_open_day.date()
        else:
            return expiration.date()

    def get_greeks(
        self,
        asset: Asset,
        asset_price: float = None,
        underlying_price: float = None,
        risk_free_rate: float = None,
        query_greeks: bool = False,
    ):
        """Returns the greeks for the option asset at the current
        bar.

        Will return all the greeks available. API Querying for prices
        and rates are expensive, so they should be passed in as arguments
        most of the time.

        Parameters
        ----------
        asset : Asset
            Option asset only for with greeks are desired.
        asset_price : float, optional
            The price of the option asset, by default None
        underlying_price : float, optional
            The price of the underlying asset, by default None
        risk_free_rate : float, optional
            The risk-free rate used in interest calculations, by default None
        query_greeks : bool, optional
            Whether to query the greeks from the broker. By default, the greeks are calculated locally, but if the
            broker supports it, they can be queried instead which could theoretically be more precise.

        Returns
        -------
        dict or None
            Returns a dictionary with greeks as keys and greek values as values.
            **Returns None if the option price or underlying price is unavailable**
            (e.g., no data from ThetaData for that strike/expiry).
            Always check for None before accessing greek values.

        implied_volatility : float
            The implied volatility.
        delta : float
            The option delta value.
        option_price : float
            The option price.
        pv_dividend : float
            The present value of dividends expected on the option's
            underlying.
        gamma : float
            The option gamma value.
        vega : float
            The option vega value.
        theta : float
            The option theta value.
        underlying_price :
            The price of the underlying.

        Example
        -------
        >>> # Will return the greeks for SPY
        >>> opt_asset = Asset("SPY", expiration=date(2021, 1, 1), strike=100, option_type="call"
        >>> greeks = self.get_greeks(opt_asset)
        >>> if greeks is None:
        >>>     print("Greeks unavailable - option price or underlying price missing")
        >>> else:
        >>>     implied_volatility = greeks["implied_volatility"]
        >>>     delta = greeks["delta"]
        >>>     gamma = greeks["gamma"]
        >>>     vega = greeks["vega"]
        >>>     theta = greeks["theta"]
        """
        if asset.asset_type != "option":
            self.log_message(
                "The greeks method was called using an asset other "
                "than an option. Unable to retrieve greeks for non-"
                "option assest."
            )
            return None

        # Do the expensize API calls here if needed
        opt_price = asset_price if asset_price is not None else self.get_last_price(asset)
        if risk_free_rate is not None:
            risk_free_rate = risk_free_rate
        else:
            risk_free_rate = self.risk_free_rate
        if underlying_price is None:
            underlying_asset = Asset(symbol=asset.symbol, asset_type="stock")
            und_price = self.get_last_price(underlying_asset)
        else:
            und_price = underlying_price

        return self.broker.get_greeks(
            asset,
            asset_price=opt_price,
            underlying_price=und_price,
            risk_free_rate=risk_free_rate,
            query_greeks=query_greeks,
        )

    # ======= Data Source Methods =================

    @property
    def timezone(self):
        """Returns the timezone of the data source. By default, America/New_York.

        Returns
        -------
        str
            The timezone of the data source.

        Example
        -------
        >>> # Will return the timezone of the data source
        >>> timezone = self.timezone
        >>> self.log_message(f"Timezone: {timezone}")
        """
        # Be defensive: pytz timezones have `.zone`, zoneinfo has `.key`, and
        # datetime.timezone may only provide `tzname(None)`
        tz = getattr(self.broker.data_source, "tzinfo", None)

        # Hard default when tzinfo is missing
        if tz is None:
            return LUMIBOT_DEFAULT_TIMEZONE

        # Prefer canonical zone identifiers when available
        if hasattr(tz, "zone") and getattr(tz, "zone", None):
            return tz.zone
        if hasattr(tz, "key") and getattr(tz, "key", None):
            return tz.key

        # Fallbacks: tzname or default
        try:
            name = tz.tzname(None)
            if name:
                return name
        except Exception:
            pass

        # Final fallback to configured default to ensure a str is returned
        return LUMIBOT_DEFAULT_TIMEZONE

    @property
    def pytz(self):
        """Returns the pytz object of the data source. By default, America/New_York.

        Returns
        -------
        pytz.timezone
            The pytz object of the data source.

        Example
        -------
        >>> # Will return the pytz object of the data source
        >>> pytz = self.pytz
        >>> self.log_message(f"pytz: {pytz}")
        """
        tz = getattr(self.broker.data_source, "tzinfo", None)
        return tz or _default_pytz()

    def get_datetime(self, adjust_for_delay: bool = False):
        """Returns the current datetime according to the data source. In a backtest this will be the current bar's datetime. In live trading this will be the current datetime on the exchange.

        Parameters
        ----------
        adjust_for_delay : bool
            If True, will adjust the datetime for any delay in the data source.

        Returns
        -------
        datetime.datetime
            The current datetime.

        Example
        -------
        >>> # Will return the current datetime
        >>> datetime = self.get_datetime()
        >>> self.log_message(f"The current datetime is {datetime}")
        """
        return self.broker.data_source.get_datetime(adjust_for_delay=adjust_for_delay)

    def get_timestamp(self):
        """Returns the current timestamp according to the data source. In a backtest this will be the current bar's timestamp. In live trading this will be the current timestamp on the exchange.

        Returns
        -------
        int
            The current timestamp.

        Example
        -------
        >>> # Will return the current timestamp
        >>> timestamp = self.get_timestamp()
        >>> self.log_message(f"The current timestamp is {timestamp}")
        """
        return self.broker.data_source.get_timestamp()

    def register_cron_callback(self, cron_schedule: str, callback_function: Callable) -> str:
        """Register a callback function to be executed according to a cron schedule.

        Parameters
        ----------
        cron_schedule : str
            A cron schedule string (e.g., "0 9 * * 1-5" for 9:00 AM Monday through Friday)
        callback_function : callable
            The function to call on the schedule

        Returns
        -------
        str
            The job ID that can be used to remove the job later

        Example
        -------
        >>> self.register_cron_callback("0 9 * * 1-5", self.morning_update)

        Notes
        -----
        This method does nothing in backtesting mode.
        """
        # Generate a unique job ID
        job_id = f"cron_callback_{_uuid4_hex()}"

        # Do nothing in backtesting mode
        if self.is_backtesting:
            self.log_message(f"Skipping registration of cron callback {callback_function.__name__} in backtesting mode")
            return job_id

        # Create a CronTrigger from the schedule string using the broker's timezone
        from apscheduler.triggers.cron import CronTrigger

        trigger = CronTrigger.from_crontab(cron_schedule, timezone=self.pytz)

        # Add the job to the scheduler
        scheduler = self._executor.ensure_scheduler()
        scheduler.add_job(
            callback_function,
            trigger,
            id=job_id,
            name=f"Cron Callback: {callback_function.__name__}",
            jobstore="default"
        )

        self.log_message(f"Registered cron callback {callback_function.__name__} with schedule: {cron_schedule} in {self.timezone} timezone")
        return job_id

    def get_round_minute(self, timeshift: int = 0):
        """Returns the current minute rounded to the nearest minute. In a backtest this will be the current bar's timestamp. In live trading this will be the current timestamp on the exchange.

        Parameters
        ----------
        timeshift : int
            The number of minutes to shift the time.

        Returns
        -------
        int
            The current minute rounded to the nearest minute.

        Example
        -------
        >>> # Will return the current minute rounded to the nearest minute
        >>> round_minute = self.get_round_minute()
        >>> self.log_message(f"The current minute rounded to the nearest minute is {round_minute}")
        """
        return self.broker.data_source.get_round_minute(timeshift=timeshift)

    def get_last_minute(self):
        """Returns the last minute of the current day. In a backtest this will be the current bar's timestamp. In live trading this will be the current timestamp on the exchange.

        Returns
        -------
        int
            The last minute of the current day.

        Example
        -------
        >>> # Will return the last minute of the current day
        >>> last_minute = self.get_last_minute()
        >>> self.log_message(f"The last minute of the current day is {last_minute}")
        """
        return self.broker.data_source.get_last_minute()

    def get_round_day(self, timeshift: int = 0):
        """Returns the current day rounded to the nearest day. In a backtest this will be the current bar's timestamp. In live trading this will be the current timestamp on the exchange.

        Parameters
        ----------
        timeshift : int
            The number of days to shift the time.

        Returns
        -------
        int
            The current day rounded to the nearest day.

        Example
        -------
        >>> # Will return the current day rounded to the nearest day
        >>> round_day = self.get_round_day()
        >>> self.log_message(f"The current day rounded to the nearest day is {round_day}")
        """
        return self.broker.data_source.get_round_day(timeshift=timeshift)

    def get_last_day(self):
        """Returns the last day of the current month. In a backtest this will be the current bar's timestamp. In live trading this will be the current timestamp on the exchange.

        Returns
        -------
        int
            The last day of the current month.

        Example
        -------
        >>> # Will return the last day of the current month
        >>> last_day = self.get_last_day()
        >>> self.log_message(f"The last day of the current month is {last_day}")
        """
        return self.broker.data_source.get_last_day()

    def get_datetime_range(self, length: int, timestep: str = "minute", timeshift: int = None):
        """Returns a list of datetimes for the given length and timestep.

        Parameters
        ----------
        length : int
            The number of datetimes to return.
        timestep : str
            The timestep of the datetimes.
        timeshift : int
            The number of timesteps to shift the datetimes.

        Returns
        -------
        list
            A list of datetimes.

        Example
        -------
        >>> # Will return a list of datetimes for the current day
        >>> datetimes = self.get_datetime_range(length=1, timestep="day")
        >>> self.log_message(f"Datetimes: {datetimes}")
        """
        return self.broker.data_source.get_datetime_range(length, timestep=timestep, timeshift=timeshift)

    def localize_datetime(self, dt: datetime.datetime):
        """Returns a datetime localized to the data source's timezone.

        Parameters
        ----------
        dt : datetime.datetime
            The datetime to localize.

        Returns
        -------
        datetime.datetime
            The localized datetime.

        Example
        -------
        >>> # Will return a datetime localized to the data source's timezone
        >>> localize_datetime = self.localize_datetime(dt=datetime.datetime(2020, 1, 1))
        >>> self.log_message(f"Localized datetime: {localize_datetime}")
        """
        return self.broker.data_source.localize_datetime(dt)

    def to_default_timezone(self, dt: datetime.datetime):
        """Returns a datetime localized to the data source's default timezone.

        Parameters
        ----------
        dt : datetime.datetime
            The datetime to localize.

        Returns
        -------
        datetime.datetime
            The localized datetime.

        Example
        -------
        >>> # Will return a datetime localized to the data source's default timezone
        >>> to_default_timezone = self.to_default_timezone(dt=datetime.datetime(2020, 1, 1))
        >>> self.log_message(f"Localized datetime: {to_default_timezone}")
        """
        return self.broker.data_source.to_default_timezone(dt)

    def load_pandas(self, asset: Union[Asset, str], df: pd.DataFrame):
        asset = self._sanitize_user_asset(asset)
        self.broker.data_source.load_pandas(asset, df)

    def create_asset(
        self,
        symbol: str,
        asset_type: str = "stock",
        expiration: datetime.datetime = None,
        strike: float = None,
        right: str = None,
        multiplier: float | None = None,
    ):
        """Creates an asset object. This is used to create an asset object.

        Parameters
        ----------
        symbol : str
            The symbol of the asset.

        asset_type : str
            The type of the asset. Can be either "stock", "option", or "future", "crytpo".

        expiration : datetime.datetime
            The expiration date of the asset (optional, only required for options and futures).

        strike : str
            The strike price of the asset (optional, only required for options).

        right : str
            The right of the option (optional, only required for options).

        multiplier : float
            Contract price multiplier. When omitted, defaults to 100 for options
            and 1 for other asset types. Explicit provider contract terms are preserved.

        Returns
        -------
        Asset
            The asset object.

        Example
        -------
        >>> # Will create a stock object
        >>> asset = self.create_asset("AAPL", asset_type="stock")

        >>> # Will create an option object
        >>> asset = self.create_asset("AAPL", asset_type="option", expiration=datetime.datetime(2020, 1, 1), strike=100, right="CALL")

        >>> # Will create a future object
        >>> asset = self.create_asset("AAPL", asset_type="future", multiplier=100)

        >>> # Will create a FOREX asset
        >>> asset = self.create_asset(symbol="EUR", asset_type="forex")

        >>> # Will create a CRYPTO asset
        >>> asset = self.create(symbol="BTC", asset_type="crypto"),
        >>> asset = self.create(symbol="USDT", asset_type="crypto"),
        >>> asset = self.create(symbol="EUR", asset_type="crypto"),
        >>> asset = self.create(symbol="ETH", asset_type="crypto"),
        """

        return Asset(
            symbol=symbol,
            asset_type=asset_type,
            expiration=expiration,
            strike=strike,
            right=right,
            multiplier=multiplier,
        )

    def _normalize_plot_color(self, color: Optional[str], *, default: Optional[str], context: str):
        """Normalize user-supplied chart colors while falling back gracefully."""
        if color is None:
            return default

        normalized = color.strip()
        if not normalized:
            fallback = default if default is not None else "auto-color selection"
            self.logger.warning(f"Unsupported {context} color '{color}', defaulting to {fallback}.")
            return default

        try:
            valid = is_color_like(normalized)
        except Exception:
            valid = False

        if valid:
            if normalized.startswith('#'):
                return normalized.lower()
            return normalized.lower()

        fallback = default if default is not None else "auto-color selection"
        self.logger.warning(f"Unsupported {context} color '{color}', defaulting to {fallback}.")
        return default

    def add_marker(
            self,
            name: str,
            value: float = None,
            color: str = "blue",
            symbol: str = "circle",
            size: int = None,
            detail_text: str = None,
            dt: Union[datetime.datetime, pd.Timestamp] = None,
            plot_name: str = "default_plot",
            asset: Asset = None
            ):
        """Adds a marker to the indicators plot that loads after a backtest. This can be used to mark important events on the graph, such as price crossing a certain value, marking a support level, marking a resistance level, etc.

        Parameters
        ----------
        name : str
            The name of the marker. This is used to display the name on the graph. Eg. "Overbought", "Oversold", "Stop Loss", "Take Profit", ...
        symbol : str
            The symbol of the marker. Possible values are 'circle', 'circle-open', 'circle-dot', 'circle-open-dot', 'square', 'square-open', 'square-dot', 'square-open-dot', 'diamond', 'diamond-open', 'diamond-dot', 'diamond-open-dot', 'cross', 'cross-open', 'cross-dot', 'cross-open-dot', 'x', 'x-open', 'x-dot', 'x-open-dot', 'triangle-up', 'triangle-up-open', 'triangle-up-dot', 'triangle-up-open-dot', 'triangle-down', 'triangle-down-open', 'triangle-down-dot', 'triangle-down-open-dot', 'triangle-left', 'triangle-left-open', 'triangle-left-dot', 'triangle-left-open-dot', 'triangle-right', 'triangle-right-open', 'triangle-right-dot', 'triangle-right-open-dot', 'triangle-ne', 'triangle-ne-open', 'triangle-ne-dot', 'triangle-ne-open-dot', 'triangle-se', 'triangle-se-open', 'triangle-se-dot', 'triangle-se-open-dot', 'triangle-sw', 'triangle-sw-open', 'triangle-sw-dot', 'triangle-sw-open-dot', 'triangle-nw', 'triangle-nw-open', 'triangle-nw-dot', 'triangle-nw-open-dot', 'pentagon', 'pentagon-open', 'pentagon-dot', 'pentagon-open-dot', 'hexagon', 'hexagon-open', 'hexagon-dot', 'hexagon-open-dot', 'hexagon2', 'hexagon2-open', 'hexagon2-dot', 'hexagon2-open-dot', 'octagon', 'octagon-open', 'octagon-dot', 'octagon-open-dot', 'star', 'star-open', 'star-dot', 'star-open-dot', 'hexagram', 'hexagram-open', 'hexagram-dot', 'hexagram-open-dot', 'star-triangle-up', 'star-triangle-up-open', 'star-triangle-up-dot', 'star-triangle-up-open-dot', 'star-triangle-down', 'star-triangle-down-open', 'star-triangle-down-dot', 'star-triangle-down-open-dot', 'star-square', 'star-square-open', 'star-square-dot', 'star-square-open-dot', 'star-diamond', 'star-diamond-open', 'star-diamond-dot', 'star-diamond-open-dot', 'diamond-tall', 'diamond-tall-open', 'diamond-tall-dot', 'diamond-tall-open-dot', 'diamond-wide', 'diamond-wide-open', 'diamond-wide-dot', 'diamond-wide-open-dot', 'hourglass', 'hourglass-open', 'bowtie', 'bowtie-open', 'circle-cross', 'circle-cross-open', 'circle-x', 'circle-x-open', 'square-cross', 'square-cross-open', 'square-x', 'square-x-open', 'diamond-cross', 'diamond-cross-open', 'diamond-x', 'diamond-x-open', 'cross-thin', 'cross-thin-open', 'x-thin', 'x-thin-open', 'asterisk', 'asterisk-open', 'hash', 'hash-open', 'hash-dot', 'hash-open-dot', 'y-up', 'y-up-open', 'y-down', 'y-down-open', 'y-left', 'y-left-open', 'y-right', 'y-right-open', 'line-ew', 'line-ew-open', 'line-ns', 'line-ns-open', 'line-ne', 'line-ne-open', 'line-nw', 'line-nw-open', 'arrow-up', 'arrow-up-open', 'arrow-down', 'arrow-down-open', 'arrow-left', 'arrow-left-open', 'arrow-right', 'arrow-right-open', 'arrow-bar-up', 'arrow-bar-up-open', 'arrow-bar-down', 'arrow-bar-down-open', 'arrow-bar-left', 'arrow-bar-left-open', 'arrow-bar-right', 'arrow-bar-right-open', 'arrow', 'arrow-open', 'arrow-wide', 'arrow-wide-open'
        value : float or int
            The value of the marker. Default is the current portfolio value.
        color : str
            The color of the marker. Use any Matplotlib/Plotly compatible color name (e.g. "red", "magenta", "lightblue") or a hex string like "#ff0000".
        size : int
            The size of the marker.
        detail_text : str
            The text to display when the marker is hovered over.
        dt : datetime.datetime or pandas.Timestamp
            The datetime of the marker. Default is the current datetime.
        plot_name : str
            The name of the subplot to add the marker to. If "default_plot" (the default value) or None, the marker will be added to the main plot.
        asset : Asset, optional
            The Asset object to associate with this marker. Indicators are almost always tied to specific assets,
            so if you have an asset object, you should pass it here. This enables proper multi-symbol charting
            where indicators can be displayed as overlays on their corresponding asset's price chart rather than
            as separate subplots. Must be an Asset object, not a string.

        Note
        ----
        Colors are validated before plotting; use Matplotlib/Plotly color names or hex codes.

        Example
        -------
        >>> # Will add a marker to the chart
        >>> self.add_chart_marker("Overbought", symbol="circle", color="red", size=10)
        >>> # Will add a marker associated with a specific asset
        >>> self.add_marker("buy_signal", value=150.0, color="green", symbol="arrow-up", asset=my_asset)
        """

        # Check that the parameters are valid
        if not isinstance(name, str):
            raise ValueError(
                f"Invalid name parameter in add_marker() method. Name must be a string but instead got {name}, "
                f"which is a type {type(name)}."
            )

        if not isinstance(symbol, str):
            raise ValueError(
                f"Invalid symbol parameter in add_marker() method. Symbol must be a string but instead got {symbol}, "
                f"which is a type {type(symbol)}."
            )

        if value is not None and not isinstance(value, (float, int, np.float64)):
            raise ValueError(
                f"Invalid value parameter in add_marker() method. Value must be a float or int but instead got {value}, "
                f"which is a type {type(value)}."
            )

        if color is not None and not isinstance(color, str):
            raise ValueError(
                f"Invalid color parameter in add_marker() method. Color must be a string but instead got {color}, "
                f"which is a type {type(color)}."
            )

        if size is not None and not isinstance(size, int):
            raise ValueError(
                f"Invalid size parameter in add_marker() method. Size must be an int but instead got {size}, "
                f"which is a type {type(size)}."
            )

        if detail_text is not None and not isinstance(detail_text, str):
            raise ValueError(
                f"Invalid detail_text parameter in add_marker() method. Detail_text must be a string but instead "
                f"got {detail_text}, which is a type {type(detail_text)}."
            )

        if dt is not None and not isinstance(dt, (datetime.datetime, pd.Timestamp)):
            raise ValueError(
                f"Invalid dt parameter in add_marker() method. Dt must be a datetime.datetime but instead got {dt}, "
                f"which is a type {type(dt)}."
            )

        if asset is not None and not isinstance(asset, Asset):
            raise TypeError(
                f"Invalid asset parameter in add_marker() method. Asset must be an Asset object, not a string or other type. "
                f"Got {asset}, which is a type {type(asset)}. Use Asset(symbol='SPY', asset_type='stock') to create an Asset."
            )

        color = self._normalize_plot_color(color, default="blue", context="marker")

        def _coerce_finite(label: str, number):
            if number is None:
                return None
            try:
                num = float(number)
            except (TypeError, ValueError):
                self.logger.warning(f"Skipping {label} marker: value '{number}' is not numeric.")
                return None
            if math.isnan(num) or math.isinf(num):
                self.logger.warning(f"Skipping {label} marker: value '{number}' is not finite.")
                return None
            return num

        if dt is None:
            dt = self.get_datetime()

        if value is None:
            value = self.portfolio_value

        numeric_value = _coerce_finite(name, value)
        if numeric_value is None:
            return None

        if size is not None and size <= 0:
            self.logger.warning("Marker size must be positive; ignoring the size override.")
            size = None

        value = numeric_value

        # Check for duplicate markers
        if len(self._chart_markers_list) > 0:
            timestamp = dt.timestamp()
            for marker in self._chart_markers_list:
                if (
                        marker["timestamp"] == timestamp
                        and marker["name"] == name
                        and marker["symbol"] == symbol
                        and marker['plot_name'] == plot_name
                ):
                    return None

        new_marker = {
            "datetime": dt,
            "timestamp": dt.timestamp(),  # This is to speed up the process of finding duplicate markers
            "name": name,
            "symbol": symbol,
            "color": color,
            "size": size,
            "value": value,
            "detail_text": detail_text,
            "plot_name": plot_name,
            # Asset fields for multi-symbol charting support
            "asset_symbol": asset.symbol if asset else None,
            "asset_type": asset.asset_type if asset else None,
            "asset_expiration": str(asset.expiration) if asset and asset.expiration else None,
            "asset_strike": asset.strike if asset else None,
            "asset_right": asset.right if asset else None,
            "asset_multiplier": asset.multiplier if asset else None,
            "quote_symbol": asset._quote_asset.symbol if asset and hasattr(asset, '_quote_asset') and asset._quote_asset else None,
            "asset_display_name": str(asset) if asset else None,
        }

        self._chart_markers_list.append(new_marker)

        return new_marker

    def get_markers_df(self):
        """Returns the markers on the indicator chart as a pandas DataFrame.

        Returns
        -------
        pandas.DataFrame
            The markers on the indicator chart.
        """

        df = pd.DataFrame(self._chart_markers_list)

        return df

    def add_line(
            self,
            name: str,
            value: float,
            color: str = None,
            style: str = "solid",
            width: int = None,
            detail_text: str = None,
            dt: Union[datetime.datetime, pd.Timestamp] = None,
            plot_name: str = "default_plot",
            asset: Asset = None
            ):
        """Adds a line data point to the indicator chart. This can be used to add lines such as bollinger bands, prices for specific assets, or any other line you want to add to the chart.

        Parameters
        ----------
        name : str
            The name of the line. This is used to display the name on the graph. Eg. "Overbought", "Oversold", "Stop Loss", "Take Profit", ...
        value : float or int
            The value of the line.
        color : str
            The color of the line. Use any Matplotlib/Plotly compatible color name (e.g. "red", "magenta", "lightblue") or a hex string like "#ff0000".
        style : str
            The style of the line. Possible values are "solid", "dotted", and "dashed".
        width : int
            The width of the line.
        detail_text : str
            The text to display when the line is hovered over.
        dt : datetime.datetime or pandas.Timestamp
            The datetime of the line. Default is the current datetime.
        plot_name : str
            The name of the subplot to add the line to. If "default_plot" (the default value) or None, the line will be added to the main plot.
        asset : Asset, optional
            The Asset object to associate with this line. Indicators are almost always tied to specific assets,
            so if you have an asset object, you should pass it here. This enables proper multi-symbol charting
            where indicators can be displayed as overlays on their corresponding asset's price chart rather than
            as separate subplots. Must be an Asset object, not a string.

        Note
        ----
        Colors are validated before plotting; use Matplotlib/Plotly color names or hex codes.

        Example
        -------
        >>> # Will add a line to the chart
        >>> self.add_chart_line("Overbought", value=80, color="red", style="dotted", width=2)
        >>> # Will add a line associated with a specific asset
        >>> self.add_line("SMA_20", sma_value, color="blue", dt=dt, asset=my_asset)
        """

        # Check that the parameters are valid
        if not isinstance(name, str):
            raise ValueError(
                f"Invalid name parameter in add_line() method. Name must be a string but instead got {name}, "
                f"which is a type {type(name)}."
            )

        if not isinstance(value, (float, int, np.float64)):
            raise ValueError(
                f"Invalid value parameter in add_line() method. Value must be a float or int but instead got {value}, "
                f"which is a type {type(value)}."
            )

        if color is not None and not isinstance(color, str):
            raise ValueError(
                f"Invalid color parameter in add_line() method. Color must be a string but instead got {color}, "
                f"which is a type {type(color)}."
            )

        if not isinstance(style, str):
            raise ValueError(
                f"Invalid style parameter in add_line() method. Style must be a string but instead got {style}, "
                f"which is a type {type(style)}."
            )

        if width is not None and not isinstance(width, int):
            raise ValueError(
                f"Invalid width parameter in add_line() method. Width must be an int but instead got {width}, "
                f"which is a type {type(width)}."
            )

        if detail_text is not None and not isinstance(detail_text, str):
            raise ValueError(
                f"Invalid detail_text parameter in add_line() method. Detail_text must be a string but instead got "
                f"{detail_text}, which is a type {type(detail_text)}."
            )

        if dt is not None and not isinstance(dt, (datetime.datetime, pd.Timestamp)):
            raise ValueError(
                f"Invalid dt parameter in add_line() method. Dt must be a datetime.datetime but instead got {dt}, "
                f"which is a type {type(dt)}."
            )

        if asset is not None and not isinstance(asset, Asset):
            raise TypeError(
                f"Invalid asset parameter in add_line() method. Asset must be an Asset object, not a string or other type. "
                f"Got {asset}, which is a type {type(asset)}. Use Asset(symbol='SPY', asset_type='stock') to create an Asset."
            )

        if color is not None:
            color = self._normalize_plot_color(color, default="blue", context="line")

        if style not in {"solid", "dotted", "dashed"}:
            self.logger.warning(f"Unsupported line style '{style}', defaulting to solid.")
            style = "solid"

        value = float(value)
        if math.isnan(value) or math.isinf(value):
            self.logger.warning("Skipping line because value is not finite.")
            return None

        if width is not None and width <= 0:
            self.logger.warning("Line width must be positive; ignoring the width override.")
            width = None

        # If no datetime is specified, use the current datetime
        if dt is None:
            dt = self.get_datetime()

        # Whenever you want to add a new line, use the following code
        new_line = {
            "datetime": dt,
            "name": name,
            "value": value,
            "color": color,
            "style": style,
            "width": width,
            "detail_text": detail_text,
            "plot_name": plot_name,
            # Asset fields for multi-symbol charting support
            "asset_symbol": asset.symbol if asset else None,
            "asset_type": asset.asset_type if asset else None,
            "asset_expiration": str(asset.expiration) if asset and asset.expiration else None,
            "asset_strike": asset.strike if asset else None,
            "asset_right": asset.right if asset else None,
            "asset_multiplier": asset.multiplier if asset else None,
            "quote_symbol": asset._quote_asset.symbol if asset and hasattr(asset, '_quote_asset') and asset._quote_asset else None,
            "asset_display_name": str(asset) if asset else None,
        }

        self._chart_lines_list.append(new_line)
        return new_line

    def add_ohlc(
            self,
            name: str,
            open: float,
            high: float,
            low: float,
            close: float,
            color: str = None,
            detail_text: str = None,
            dt: Union[datetime.datetime, pd.Timestamp] = None,
            plot_name: str = "default_plot",
            asset: Asset = None
    ):
        """Adds an OHLC (candlestick) data point to the indicator chart.

        This can be used to plot price bars, Heikin Ashi candles, or any other
        OHLC series on the indicator chart. OHLC data is exported to indicators.csv
        with type="ohlc" and (when supported by the viewer) can be rendered as
        candlesticks.

        Parameters
        ----------
        name : str
            The name of the OHLC series.
        open : float
            The opening value for the bar.
        high : float
            The high value for the bar.
        low : float
            The low value for the bar.
        close : float
            The closing value for the bar.
        color : str, optional
            The color for this bar. If omitted, defaults to "green" for bullish
            (close >= open) and "red" for bearish (close < open).
        detail_text : str, optional
            Additional hover text.
        dt : datetime.datetime or pandas.Timestamp, optional
            The datetime for this bar. Defaults to current strategy datetime.
        plot_name : str, optional
            Subplot name. Default "default_plot".
        asset : Asset, optional
            Asset metadata for multi-symbol charting.
        """

        if not isinstance(name, str):
            raise ValueError(
                f"Invalid name parameter in add_ohlc() method. Name must be a string but instead got {name}, "
                f"which is a type {type(name)}."
            )

        for label, number in (("open", open), ("high", high), ("low", low), ("close", close)):
            if not isinstance(number, (float, int, np.float64)):
                raise ValueError(
                    f"Invalid {label} parameter in add_ohlc() method. {label} must be a float or int but instead got {number}, "
                    f"which is a type {type(number)}."
                )

        if color is not None and not isinstance(color, str):
            raise ValueError(
                f"Invalid color parameter in add_ohlc() method. Color must be a string but instead got {color}, "
                f"which is a type {type(color)}."
            )

        if detail_text is not None and not isinstance(detail_text, str):
            raise ValueError(
                f"Invalid detail_text parameter in add_ohlc() method. Detail_text must be a string but instead got "
                f"{detail_text}, which is a type {type(detail_text)}."
            )

        if dt is not None and not isinstance(dt, (datetime.datetime, pd.Timestamp)):
            raise ValueError(
                f"Invalid dt parameter in add_ohlc() method. Dt must be a datetime.datetime but instead got {dt}, "
                f"which is a type {type(dt)}."
            )

        if asset is not None and not isinstance(asset, Asset):
            raise TypeError(
                f"Invalid asset parameter in add_ohlc() method. Asset must be an Asset object, not a string or other type. "
                f"Got {asset}, which is a type {type(asset)}. Use Asset(symbol='SPY', asset_type='stock') to create an Asset."
            )

        open = float(open)
        high = float(high)
        low = float(low)
        close = float(close)

        if any(math.isnan(x) or math.isinf(x) for x in (open, high, low, close)):
            self.logger.error("Skipping OHLC bar because one or more values are not finite.")
            return None

        if high < low or high < max(open, close) or low > min(open, close):
            self.logger.error(
                "Skipping OHLC bar because values are invalid: "
                f"open={open}, high={high}, low={low}, close={close}."
            )
            return None

        if dt is None:
            dt = self.get_datetime()

        default_color = "green" if close >= open else "red"
        color = self._normalize_plot_color(color, default=default_color, context="ohlc")

        new_ohlc = {
            "datetime": dt,
            "name": name,
            "open": open,
            "high": high,
            "low": low,
            "close": close,
            "color": color,
            "detail_text": detail_text,
            "plot_name": plot_name,
            # Asset fields for multi-symbol charting support
            "asset_symbol": asset.symbol if asset else None,
            "asset_type": asset.asset_type if asset else None,
            "asset_expiration": str(asset.expiration) if asset and asset.expiration else None,
            "asset_strike": asset.strike if asset else None,
            "asset_right": asset.right if asset else None,
            "asset_multiplier": asset.multiplier if asset else None,
            "quote_symbol": asset._quote_asset.symbol if asset and hasattr(asset, '_quote_asset') and asset._quote_asset else None,
            "asset_display_name": str(asset) if asset else None,
        }

        self._chart_ohlc_list.append(new_ohlc)
        return new_ohlc

    def get_lines_df(self):
        """Returns a dataframe of the lines on the indicator chart.

        Returns
        -------
        pandas.DataFrame
            The lines on the indicator chart.
        """

        df = pd.DataFrame(self._chart_lines_list)

        return df

    def get_ohlc_df(self):
        """Returns the OHLC data on the indicator chart as a pandas DataFrame."""
        df = pd.DataFrame(self._chart_ohlc_list)
        return df

    def write_backtest_settings(self, settings_file: str):
        """Writes the backtest settings to a file.

        Parameters
        ----------
        settings_file : str
            The file path to write the settings to.

        Returns
        -------
        None

        Example
        -------
        >>> # Will write the backtest settings to a file
        >>> self.write_backtest_settings("backtest_settings.json")

        """
        datasource = self.broker.data_source
        auto_adjust = datasource.auto_adjust if hasattr(datasource, "auto_adjust") else False

        lumibot_version = None
        backtesting_data_sources = None
        backtest_time_seconds = None
        try:
            import lumibot as _lumibot

            lumibot_version = getattr(_lumibot, "__version__", None)
        except Exception:
            pass
        try:
            backtesting_data_sources = (
                os.environ.get("BACKTESTING_DATA_SOURCES")
                or os.environ.get("BACKTESTING_DATA_SOURCE")
                or type(datasource).__name__
            )
        except Exception:
            backtesting_data_sources = os.environ.get("BACKTESTING_DATA_SOURCE")
        try:
            backtest_time_seconds = getattr(self, "_backtest_time_seconds", None)
            if backtest_time_seconds is None:
                start_ts = getattr(self, "_backtest_time_start_monotonic", None)
                if start_ts is not None:
                    backtest_time_seconds = time.monotonic() - float(start_ts)
        except Exception:
            pass
        settings = {
            "name": self.name,
            "backtesting_start": str(self.backtesting_start),
            "backtesting_end": str(self.backtesting_end),
            "budget": self.initial_budget,
            "risk_free_rate": float(self.risk_free_rate),
            "minutes_before_closing": self.minutes_before_closing,
            "minutes_before_opening": self.minutes_before_opening,
            "sleeptime": self.sleeptime,
            "auto_adjust": auto_adjust,
            "quote_asset": self.quote_asset,
            "benchmark_asset": self._benchmark_asset,
            "starting_positions": self.starting_positions,
            "parameters": {k: v for k, v in self.parameters.items() if k != 'pandas_data'},
            "lumibot_version": lumibot_version,
            "backtesting_data_sources": backtesting_data_sources,
            "backtest_time_seconds": backtest_time_seconds,
        }
        profiling_enabled = bool(getattr(self, "_backtest_profiling_enabled", False))
        if profiling_enabled:
            settings["profiling_enabled"] = True
            settings["profiling_tool"] = getattr(self, "_backtest_profiling_tool", None)
            settings["profiling_format"] = getattr(self, "_backtest_profiling_format", None)
            settings["profiling_clock"] = getattr(self, "_backtest_profiling_clock", None)
            settings["profiling_artifact"] = getattr(self, "_backtest_profiling_artifact", None)

        # Non-secret telemetry (best-effort; must never crash a backtest).
        #
        # These fields are intentionally safe to share in artifacts:
        # - do NOT include API keys or AWS secret keys
        # - include only config identifiers + counters
        try:
            settings["datadownloader_base_url"] = os.environ.get("DATADOWNLOADER_BASE_URL")
            settings["datadownloader_skip_local_start"] = os.environ.get("DATADOWNLOADER_SKIP_LOCAL_START")
        except Exception:
            pass

        try:
            from lumibot.tools.backtest_cache import get_backtest_cache

            cache = get_backtest_cache()
            settings["remote_cache"] = {
                "backend": os.environ.get("LUMIBOT_CACHE_BACKEND"),
                "mode": os.environ.get("LUMIBOT_CACHE_MODE"),
                "s3_bucket": os.environ.get("LUMIBOT_CACHE_S3_BUCKET"),
                "s3_prefix": os.environ.get("LUMIBOT_CACHE_S3_PREFIX"),
                "s3_region": os.environ.get("LUMIBOT_CACHE_S3_REGION"),
                "s3_version": os.environ.get("LUMIBOT_CACHE_S3_VERSION"),
            }
            settings["remote_cache_stats"] = cache.stats_snapshot()
        except Exception:
            pass

        try:
            from lumibot.tools.data_downloader_queue_client import queue_telemetry_snapshot

            settings["thetadata_queue_telemetry"] = queue_telemetry_snapshot()
        except Exception:
            pass
        try:
            from lumibot.tools.ibkr_history_health import ibkr_history_health_snapshot

            history_health = ibkr_history_health_snapshot()
            sources = (datasource, getattr(self.broker, "option_source", None))
            uses_ibkr = any(
                getattr(source, "SOURCE", None) in ("InteractiveBrokersREST", "InteractiveBrokers")
                for source in sources
            )
            if uses_ibkr or any(history_health.get(key) for key in ("series", "required_failures", "warnings")):
                settings["data_health"] = history_health
        except Exception:
            pass
        try:
            settings["runtime_timings"] = self.broker.data_source.get_runtime_timings()
        except Exception:
            pass
        # AI agent health (2026-10-07): bars where an agent call failed (for example a
        # provider rate limit that outlasted its retries) and the strategy continued
        # without an AI decision. Only written when the strategy actually used agents;
        # the lazy agents component is never loaded just to report on it.
        try:
            agents = self.__dict__.get("agents")
            manager = None
            if agents is not None:
                try:
                    manager = object.__getattribute__(agents, "_instance")
                except AttributeError:
                    manager = agents
            health_snapshot = getattr(manager, "health_snapshot", None) if manager is not None else None
            if callable(health_snapshot):
                settings["agent_health"] = health_snapshot()
        except Exception:
            pass
        os.makedirs(os.path.dirname(settings_file), exist_ok=True)
        with open(settings_file, "w") as outfile:
            import jsonpickle
            from jsonpickle.pickler import Pickler
            from lumibot.brokers.broker import Broker as RuntimeBroker
            from lumibot.data_sources.data_source import DataSource as RuntimeDataSource

            class SettingsPickler(Pickler):
                def _flatten_obj_instance(self, obj):
                    # Report connections without traversing their authenticated
                    # clients. Keep normal parameter types and graph references
                    # through this export's own encoder, never global handlers.
                    if isinstance(obj, RuntimeDataSource):
                        return {"object_type": type(obj).__name__, "data_source": obj.SOURCE}
                    if isinstance(obj, RuntimeBroker):
                        return {"object_type": type(obj).__name__}
                    return super()._flatten_obj_instance(obj)

            json = jsonpickle.encode(settings, context=SettingsPickler())
            outfile.write(json)

    def _parse_timestep(self, timestep: str) -> tuple:
        """Parse various timestep formats into (multiplier, base_unit).

        Examples:
            "5min", "5m", "5 minutes", "5Min", "5T" -> (5, "minute")
            "1h", "1hour" -> (60, "minute")
            "2d", "2 days", "1Day" -> (2, "day") or (1, "day")
            "minute" -> (1, "minute")
            "day" -> (1, "day")
            "30S", "30 seconds" -> (30, "second")

        Returns None if unparseable.
        """
        from lumibot.tools.helpers import parse_canonical_timestep

        parsed = parse_canonical_timestep(timestep)
        if parsed is None:
            return None

        multiplier, unit = parsed
        if unit == "hour":
            # Convert hours to minutes for the Strategy resample path.
            return (multiplier * 60, "minute")
        if unit == "week":
            return (multiplier * 7, "day")
        if unit == "month":
            # Approximate months as 30 days
            return (multiplier * 30, "day")
        return (multiplier, unit)

    def _prefetch_indicator_history(self, *args, **kwargs):
        """Populate optional indicator history through normal asset/timeframe handling.

        The indicator records its actual causal input separately. A cache fill
        ceiling is not a demand for that many decision-input rows.
        """
        return self.get_historical_prices(*args, _history_requirement="prefetch", **kwargs)

    def get_historical_prices(
        self,
        asset: Union[Asset, str],
        length: int,
        timestep: str = "",
        timeshift: Union[int, datetime.timedelta, None] = None,
        quote: Asset = None,
        exchange: str = None,
        include_after_hours: bool = True,
        *args,
        **kwargs
    ):
        """Get historical pricing data for a given symbol or asset.

        Return data bars for a given symbol or asset.  Any number of bars can
        be return limited by the data available. This is set with 'length' in
        number of bars. Bars may be returned as daily or by minute. And the
        starting point can be shifted backwards by time or bars.

        Parameters
        ----------
        asset : str or Asset
            The symbol string representation (e.g. AAPL, GOOG, ...) or asset
            object. Cryptocurrencies must also specify the quote currency.
        length : int
            The number of rows (number of timesteps)
        minimum_bars : int, optional
            Minimum completed bars required by this backtest decision, between
            1 and ``length``. Defaults to ``length`` to preserve strict existing
            requirements. Set this when requesting a generous history window
            but consuming only its most recent smaller lookback. This changes
            validation only; returned prices and the download window are unchanged.
        timestep : str
            Time interval for each bar. Supports multiple formats:

            **Basic formats:**
                - ``"minute"`` or ``"day"`` - Single minute or day bars

            **Multi-timeframe formats (automatically aggregated):**
                - Minutes: ``"5min"``, ``"5m"``, ``"5 minutes"``, ``"15min"``, ``"30m"``, etc.
                - Hours: ``"1h"``, ``"1hour"``, ``"2h"``, ``"4 hours"``, etc. (converted to minutes)
                - Days: ``"2d"``, ``"2 days"``, ``"1 week"``, ``"1w"``, etc.
                - Flexible formatting: Case-insensitive, with/without spaces

            When using multi-timeframe formats, the method asks capable live data
            sources for native bars. Other sources automatically fetch the underlying
            minute or day data and resample it to your desired timeframe.
            Default value depends on the data_source (minute for alpaca, day for yahoo, ...)
        timeshift : int, timedelta, or None
            ``None`` by default. When provided it shifts the data window relative to
            the current backtest time.

            - Passing an ``int`` shifts by bars (positive = past, negative = future).
            - Passing a ``timedelta`` shifts by wall-clock time (e.g. ``timedelta(hours=-1)``).
        quote : Asset
            The quote currency for crypto currencies (e.g. USD, USDT, EUR, ...).
            Default is the quote asset for the strategy.
        exchange : str
            The exchange to pull the historical data from. Default is None (decided based on the broker)
        include_after_hours : bool
            Whether to include after hours data. Default is True. Currently only works with Interactive Brokers.
        return_polars : bool (deprecated)
            Deprecated. Do not use in strategy code. This keyword will be removed in a future release.
            Strategy logic should use pandas operations on ``bars.pandas_df`` and should not depend on
            the underlying DataFrame backend.

        Returns
        -------
        Bars
            The bars object with all the historical pricing data. Please check the ``Entities.Bars``
            object documentation for more details on how to use Bars objects. To get a ``DataFrame``
            from the Bars object, use ``bars.pandas_df``.

        Example
        -------
        Extract 2 rows of SPY data with one day timestep between each row
        with the latest data being 24h ago (timedelta(days=1)) (in a backtest)

        >>> # Get the data for SPY for the last 2 days
        >>> bars =  self.get_historical_prices("SPY", 2, "day")
        >>> # To get the DataFrame of SPY data
        >>> df = bars.pandas_df
        >>>
        >>> # Then, to get the DataFrame of SPY data
        >>> df = bars.pandas_df
        >>> last_ohlc = df.iloc[-1] # Get the last row of the DataFrame (the most recent pricing data we have)
        >>> self.log_message(f"Last price of BTC in USD: {last_ohlc['close']}, and the open price was {last_ohlc['open']}")

        >>> # Get the data for AAPL for the last 30 minutes
        >>> bars =  self.get_historical_prices("AAPL", 30, "minute")
        >>>
        >>> # Then, to get the DataFrame of SPY data
        >>> df = bars.pandas_df
        >>> last_ohlc = df.iloc[-1] # Get the last row of the DataFrame (the most recent pricing data we have)
        >>> self.log_message(f"Last price of AAPL: {last_ohlc['close']}, and the open price was {last_ohlc['open']}")

        >>> # Get 5-minute bars for the last 10 5-minute periods (using new multi-timeframe support)
        >>> bars = self.get_historical_prices("SPY", 10, "5min")
        >>> df = bars.pandas_df  # DataFrame with 10 rows of 5-minute OHLCV data
        >>>
        >>> # Get hourly bars for the last 24 hours
        >>> bars = self.get_historical_prices("AAPL", 24, "1h")
        >>>
        >>> # Get 15-minute bars (multiple format options work)
        >>> bars = self.get_historical_prices("TSLA", 20, "15m")       # Short format
        >>> bars = self.get_historical_prices("TSLA", 20, "15min")     # Alternative
        >>> bars = self.get_historical_prices("TSLA", 20, "15 minutes") # With space

        >>> # Get the historical data for an AAPL option for the last 30 minutes
        >>> asset = self.create_asset("AAPL", asset_type="option", expiration=datetime.datetime(2020, 1, 1), strike=100, right="call")
        >>> bars =  self.get_historical_prices(asset, 30, "minute")
        >>>
        >>> # Then, to get the DataFrame of SPY data
        >>> df = bars.pandas_df
        >>> last_ohlc = df.iloc[-1] # Get the last row of the DataFrame (the most recent pricing data we have)
        >>> self.log_message(f"Last price of BTC in USD: {last_ohlc['close']}, and the open price was {last_ohlc['open']}")


        >>> # Get the data for BTC in USD  for the last 2 days
        >>> asset_base = self.create(symbol="BTC", asset_type="crypto"),
        >>> asset_quote = self.create(symbol="USDT", asset_type="crypto"),
        >>>
        >>> bars =  self.get_historical_prices(asset_base, 2, "day", quote=asset_quote)
        >>>
        >>> # Then, to get the DataFrame of SPY data
        >>> df = bars.pandas_df
        >>> last_ohlc = df.iloc[-1] # Get the last row of the DataFrame (the most recent pricing data we have)
        >>> self.log_message(f"Last price of BTC in USD: {last_ohlc['close']}, and the open price was {last_ohlc['open']}")
        """
        if args:
            if len(args) != 1:
                raise TypeError("get_historical_prices() accepts at most 1 extra positional argument (deprecated `return_polars`)")
            if "return_polars" in kwargs:
                raise TypeError("get_historical_prices() got multiple values for keyword argument 'return_polars'")
            kwargs["return_polars"] = args[0]

        history_requirement = kwargs.pop("_history_requirement", "required")
        minimum_bars = kwargs.pop("minimum_bars", None)
        if history_requirement not in {"required", "prefetch"}:
            raise ValueError("Unknown internal history requirement mode")
        return_polars_provided = "return_polars" in kwargs
        return_polars = kwargs.pop("return_polars", False)
        if return_polars_provided:
            warnings.warn(
                "`return_polars` is deprecated and will be removed. "
                "Do not depend on the DataFrame backend; use `bars.pandas_df` for pandas.",
                category=DeprecationWarning,
                stacklevel=2,
            )
        if kwargs:
            unexpected = ", ".join(sorted(kwargs))
            raise TypeError(f"get_historical_prices() got unexpected keyword argument(s): {unexpected}")

        # Get that length is type int and if not try to cast it
        if not isinstance(length, int):
            try:
                length = int(length)
            except Exception:
                raise ValueError(
                    f"Invalid length parameter in get_historical_prices() method. Length must be an int but instead got {length}, "
                    f"which is a type {type(length)}."
                )

        if minimum_bars is not None and (
            isinstance(minimum_bars, bool) or not isinstance(minimum_bars, int)
            or minimum_bars < 1 or minimum_bars > length
        ):
            raise ValueError("minimum_bars must be an integer between 1 and length")

        if quote is None:
            quote = self.quote_asset

        # Parse timestep to check if we need to aggregate
        original_timestep = timestep
        parsed = self._parse_timestep(timestep) if timestep else None

        # Determine the actual timestep to use for data fetching
        if parsed and parsed[0] > 1:
            # Multi-timeframe request detected.
            #
            # Backtesting data sources already implement aggregation via Data.get_bars()
            # (see `lumibot/entities/data.py`). In backtests, avoid doing an extra layer of
            # resampling here; instead pass the original timestep (e.g., "15min") through to
            # the backtesting data source so it can slice/aggregate efficiently and cache
            # results internally.
            multiplier, base_unit = parsed
            live_data_source = getattr(getattr(self, "broker", None), "data_source", None)
            supports_native_timestep = getattr(live_data_source, "supports_native_timestep", None)
            if getattr(self, "is_backtesting", False) or getattr(getattr(self, "broker", None), "IS_BACKTESTING_BROKER", False):
                actual_timestep = original_timestep
                actual_length = length
                needs_resampling = False
            elif callable(supports_native_timestep) and supports_native_timestep(original_timestep):
                actual_timestep = original_timestep
                actual_length = length
                needs_resampling = False
            else:
                actual_timestep = base_unit
                actual_length = length * multiplier
                needs_resampling = True
        elif parsed:
            # Standard format (1 minute or 1 day)
            multiplier, base_unit = parsed
            actual_timestep = base_unit
            actual_length = length
            needs_resampling = False
        else:
            # Use original timestep if parsing failed or empty
            actual_timestep = timestep if timestep else None
            actual_length = length
            needs_resampling = False

        asset = self._sanitize_user_asset(asset)

        asset = self.crypto_assets_to_tuple(asset, quote)
        if not actual_timestep:
            actual_timestep = self.broker.data_source.get_timestep()

        # Only log once per asset to reduce noise.
        # PERF: avoid per-call f-string construction in hot loops; use a tuple key.
        asset_key = (asset, int(length), original_timestep)
        if asset_key not in self._logged_get_historical_prices_assets:
            if needs_resampling:
                self.logger.info(
                    f"Getting historical prices for {asset}, {length} bars of {original_timestep} "
                    f"(fetching {actual_length} {actual_timestep} bars)"
                )
            else:
                self.logger.info(f"Getting historical prices for {asset}, {length} bars, {original_timestep}")
            self._logged_get_historical_prices_assets.add(asset_key)

        effective_return_polars = return_polars

        # Call through to the appropriate data source. Only pass `return_polars` if supported
        # to maintain compatibility with live data sources that don't yet accept it.
        #
        # PERF: avoid per-call nested function creation/dict allocations; keep this inline and cache
        # `return_polars` support per data source type.
        supports_cache = getattr(self, "_get_hist_supports_return_polars_by_ds_type", None)
        if supports_cache is None:
            supports_cache = {}
            setattr(self, "_get_hist_supports_return_polars_by_ds_type", supports_cache)

        ds = self.broker.data_source
        if self.broker.option_source and getattr(asset, "asset_type", None) == "option":
            ds = self.broker.option_source

        ds_type = type(ds)
        supports_return_polars = supports_cache.get(ds_type)
        if supports_return_polars is None:
            try:
                inspect_module = _inspect_module()
                params = inspect_module.signature(ds_type.get_historical_prices).parameters
                supports_return_polars = (
                    "return_polars" in params
                    or any(p.kind == inspect_module.Parameter.VAR_KEYWORD for p in params.values())
                )
            except Exception:
                # Conservative default: if we can't inspect, assume it does NOT support return_polars
                # so we don't raise TypeError by passing an unknown kwarg.
                supports_return_polars = False
            supports_cache[ds_type] = bool(supports_return_polars)

        fn = ds.get_historical_prices
        if supports_return_polars:
            bars = fn(
                asset,
                actual_length,  # Use the actual length for fetching
                timestep=actual_timestep,
                timeshift=timeshift,
                exchange=exchange,
                include_after_hours=include_after_hours,
                quote=quote,
                return_polars=effective_return_polars,
            )
        else:
            bars = fn(
                asset,
                actual_length,  # Use the actual length for fetching
                timestep=actual_timestep,
                timeshift=timeshift,
                exchange=exchange,
                include_after_hours=include_after_hours,
                quote=quote,
            )

        # If we need to resample the data
        if needs_resampling and bars and len(bars) > 0:
            resampled_with_polars = False
            if return_polars:
                from ..tools.polars_utils import PolarsResampleError, resample_polars_ohlc

                try:
                    polars_frame = bars.polars_df
                    resampled_frame = resample_polars_ohlc(polars_frame, multiplier, base_unit, length)
                    if resampled_frame is not None and not resampled_frame.is_empty():
                        bars.df = resampled_frame
                        resampled_with_polars = True
                except PolarsResampleError as exc:
                    self.logger.debug(
                        "Unsupported polars resample for %s (%s); falling back to pandas.",
                        asset,
                        exc,
                    )
                except Exception as exc:
                    self.logger.warning(
                        "Polars resample failed for %s; falling back to pandas. Error: %s",
                        asset,
                        exc,
                    )
            if not resampled_with_polars:
                try:
                    import pandas as pd

                    df = bars.pandas_df.copy()
                    if not isinstance(df.index, pd.DatetimeIndex):
                        df.index = pd.to_datetime(df.index)

                    if base_unit == "minute":
                        resample_rule = f"{multiplier}min"
                    elif base_unit == "second":
                        resample_rule = f"{multiplier}s"
                    elif base_unit == "day":
                        resample_rule = f"{multiplier}D"
                    else:
                        return bars

                    from lumibot.tools.candles import OHLCV_AGGREGATION, resample_ohlcv

                    # Explicit OHLCV map: a frame without volume still fails here and
                    # the original bars are returned, as before.
                    resampled_df = resample_ohlcv(
                        df, resample_rule, aggregation=dict(OHLCV_AGGREGATION), dropna="any", sort=False
                    )

                    if len(resampled_df) > length:
                        resampled_df = resampled_df.iloc[-length:]

                    bars.df = resampled_df
                except Exception as e:
                    # If resampling fails, log warning and return original data
                    self.logger.warning(f"Failed to resample data from {actual_timestep} to {original_timestep}: {e}")

        if self.is_backtesting and history_requirement == "required":
            from lumibot.backtesting.market_input_evidence import record_market_input

            record_market_input(source=ds, asset=asset, quote=quote,
                timestep=original_timestep or actual_timestep, when=self.get_datetime(),
                frame=bars.pandas_df if bars is not None else None, purpose="history")
            record_requirement = getattr(ds, "record_history_requirement", None)
            if callable(record_requirement):
                record_requirement(asset=asset, timestep=original_timestep or actual_timestep,
                                   requested_bars=length if minimum_bars is None else minimum_bars,
                                   bars=bars, timeshift=timeshift)
        return bars

    def get_symbol_bars(
        self,
        asset: Union[Asset, str],
        length: int,
        timestep: str = "",
        timeshift: datetime.timedelta = None,
        quote: Asset = None,
        exchange: str = None,
    ):
        """
        This method is deprecated and will be removed in a future version.
        Please use self.get_historical_prices() instead.
        """
        self.logger.warning(
            "The get_bars method is deprecated and will be removed in a future version. "
            "Please use self.get_historical_prices() instead."
        )

        return self.get_historical_prices(
            asset,
            length,
            timestep=timestep,
            timeshift=timeshift,
            quote=quote,
            exchange=exchange,
        )

    def get_historical_prices_for_assets(
        self,
        assets: List[Asset | str | tuple],
        length: int,
        timestep: str = "minute",
        timeshift: datetime.timedelta = None,
        chunk_size: int = 100,
        max_workers: int = 200,
        exchange: str = None,
        include_after_hours: bool = True,
        sleep_time: float | None = None,
    ):
        """Get historical pricing data for the list of assets.

        Return data bars for a list of symbols or assets.  Return a dictionary
        of bars for a given list of symbols. Works the same as get_historical_prices
        but take as first parameter a list of assets. Any number of bars can
        be return limited by the data available. This is set with `length` in
        number of bars. Bars may be returned as daily or by minute. And the
        starting point can be shifted backwards by time or bars.

        Parameters
        ----------
        assets : list(str/asset,tuple)
            The symbol string representation (e.g. AAPL, GOOG, ...) or asset
            objects.
            Cryptocurrencies must specify the quote asset. Use tuples with the two asset
            objects, base first, quote second. '(Asset(ETH), Asset(BTC))'
        length : int
            The number of rows (number of timesteps)
        timestep : str
            Either ``"minute"`` for minutes data or ``"day"``
            for days data default value depends on the data_source (minute
            for alpaca, day for yahoo, ...). If you need, you can specify the width of the bars by adding a number
            before the timestep (e.g. "5 minutes", "15 minutes", "1 day", "2 weeks", "1month", ...)
        timeshift : timedelta
            ``None`` by default. If specified indicates the time shift from
            the present. If  backtesting in Pandas, use integer representing
            number of bars.
        include_after_hours : bool
            ``True`` by default. If ``False``, only return bars that are during
            regular trading hours. If ``True``, return all bars. Currently only works for Interactive Brokers.
        sleep_time : float, optional
            Sleep between per-asset fetches to reduce the likelihood of upstream rate limiting.
            When omitted (``None``), LumiBot defaults to:
            - ``0`` for backtesting data sources
            - ``0.1`` seconds for live data sources

        Returns
        -------
        dictionary : Asset : bars
            Return a dictionary bars for a given list of symbols. Works the
            same as get_historical_prices take as first parameter a list of symbols.

        Example
        -------

        >>> # Get the data for SPY and TLT for the last 2 days
        >>> bars =  self.get_historical_prices_for_assets(["SPY", "TLT"], 2, "day")
        >>> for asset_bars in bars_list:
        >>>     self.log_message(asset_bars.df)

        >>> # Get the data for AAPL and GOOG for the last 30 minutes
        >>> bars =  self.get_historical_prices_for_assets(["AAPL", "GOOG"], 30, "minute")
        >>> for asset_bars in bars_list:
        >>>     self.log_message(asset_bars.df)

        >>> # Get the price data for EURUSD for the last 2 days
        >>> from lumibot.entities import Asset
        >>> asset_base = Asset(symbol="EUR", asset_type="forex")
        >>> asset_quote = Asset(symbol="USD", asset_type="forex")
        >>> bars =  self.get_historical_prices_for_assets(asset_base, 2, "day", quote=asset_quote)
        >>> df = bars.df
        """

        # Only log once per asset list to reduce noise
        assets_key = f"{assets}_{length}_{timestep}"
        if assets_key not in self._logged_get_historical_prices_assets:
            self.logger.info(f"Getting historical prices for {assets}, {length} bars, {timestep}")
            self._logged_get_historical_prices_assets.add(assets_key)

        assets = [self._sanitize_user_asset(asset) for asset in assets]

        effective_sleep_time = sleep_time
        if effective_sleep_time is None:
            data_source = getattr(getattr(self, "broker", None), "data_source", None)
            effective_sleep_time = 0.0 if getattr(data_source, "IS_BACKTESTING_DATA_SOURCE", False) else 0.1
        results = self.broker.data_source.get_bars(
            assets,
            length,
            timestep=timestep,
            timeshift=timeshift,
            chunk_size=chunk_size,
            max_workers=max_workers,
            exchange=exchange,
            include_after_hours=include_after_hours,
            sleep_time=effective_sleep_time
        )
        if self.is_backtesting:
            from lumibot.backtesting.market_input_evidence import record_market_input

            for asset in assets:
                bars = results.get(asset) if isinstance(results, dict) else None
                record_market_input(source=self.broker.data_source, asset=asset,
                    quote=self.quote_asset, timestep=timestep, when=self.get_datetime(),
                    frame=bars.pandas_df if bars is not None else None, purpose="history-batch")
        return results

    def get_bars(
        self,
        assets: List[Union[Asset, str]],
        length: int,
        timestep: str = "minute",
        timeshift: datetime.timedelta = None,
        chunk_size: int = 100,
        max_workers: int = 200,
        exchange: str = None,
        sleep_time: float | None = None,
    ):
        """
        This method is deprecated and will be removed in a future version.
        Please use self.get_historical_prices_for_assets() instead."""
        self.logger.warning(
            "The get_bars method is deprecated and will be removed in a future version. "
            "Please use self.get_historical_prices_for_assets() instead."
        )

        return self.get_historical_prices_for_assets(
            assets,
            length,
            timestep=timestep,
            timeshift=timeshift,
            chunk_size=chunk_size,
            max_workers=max_workers,
            exchange=exchange,
            sleep_time=sleep_time
        )

    def start_realtime_bars(self, asset: Asset, keep_bars: int = 30):
        """Starts a real time stream of tickers for Interactive Broker
        only.

        This allows for real time data to stream to the strategy. Bars
        are fixed at every fix seconds.  They will arrive in the strategy
        in the form of a dataframe. The data returned will be:

        - datetime
        - open
        - high
        - low
        - close
        - volume
        - vwap
        - count (trade count)

        Parameters
        ----------
        asset : Asset object
            The asset to stream.

        keep_bars : int
            How many bars/rows to keep of data. If running for an
            extended period of time, it may be desirable to limit the
            size of the data kept.

        Returns
        -------
        None

        """
        self.broker._start_realtime_bars(asset=asset, keep_bars=keep_bars)

    def get_realtime_bars(self, asset: Asset):
        """Retrieve the real time bars as dataframe.

        Returns the current set of real time bars as a dataframe.
        The `datetime` will be in the index. The columns of the
        dataframe are:

        - open
        - high
        - low
        - close
        - volume
        - vwap
        - count (trade count)

        Parameters
        ----------
        asset : Asset object
            The asset that has a stream active.

        Returns
        -------
        dataframe : Pandas Dataframe.
            Dataframe containing the most recent pricing information
            for the asset. The data returned will be the `datetime` in
            the index and the following columns.

            - open
            - high
            - low
            - close
            - volume
            - vwap
            - count (trade count)

            The length of the dataframe will have been set the intial
            start of the real time bars.
        """
        rtb = self.broker._get_realtime_bars(asset)
        if rtb is not None:
            return pd.DataFrame(rtb).set_index("datetime")
        return rtb

    def cancel_realtime_bars(self, asset: Asset):
        """Cancels a stream of real time bars for a given asset.

        Cancels the real time bars for the given asset.

        Parameters
        ----------
        asset : Asset
            Asset object that has streaming data to cancel.

        Returns
        -------
        None

        Example
        -------
        >>> # Cancel the real time bars for SPY
        >>> asset = self.create_asset("SPY")
        >>> self.cancel_realtime_bars(asset)

        """
        self.broker._cancel_realtime_bars(asset)

    def get_yesterday_dividend(self, asset: Asset):
        """Get the dividend for the previous day.

        Parameters
        ----------
        asset : Asset object
            The asset to get the dividend for.

        Returns
        -------
        dividend : float
            The dividend amount.

        Example
        -------
        >>> # Get the dividend for SPY
        >>> asset = self.create_asset("SPY")
        >>> self.get_yesterday_dividend(asset)


        """
        asset = self._sanitize_user_asset(asset)
        return self.broker.data_source.get_yesterday_dividend(asset)

    def get_yesterday_dividends(self, assets: List[Asset]):
        """Get the dividends for the previous day.

        Parameters
        ----------
        assets : list(Asset object)
            The assets to get the dividends for.

        Returns
        -------
        dividends : list(float)
            The dividend amount for each asset.

        Example
        -------
        >>> # Get the dividends for SPY and TLT
        >>> from lumibot.entities import Asset
        >>> assets = [Asset("SPY"), Asset("TLT")]
        >>> self.get_yesterday_dividends(assets)

        """
        assets = [self._sanitize_user_asset(asset) for asset in assets]
        if self.broker and self.broker.data_source:
            return self.broker.data_source.get_yesterday_dividends(assets, quote=self.quote_asset)
        else:
            self.log_message("Broker or data source is not available.")
            return None

    def get_yesterday_stock_split(self, asset: Asset):
        """Get the stock split ratio for the current backtest day."""
        asset = self._sanitize_user_asset(asset)
        if self.broker and self.broker.data_source:
            return self.broker.data_source.get_yesterday_stock_split(asset, quote=self.quote_asset)
        else:
            self.log_message("Broker or data source is not available.")
            return None

    def get_yesterday_stock_splits(self, assets: List[Asset]):
        """Get stock split ratios for the current backtest day.

        A value of 2.0 means a 2-for-1 split, 0.1 means a 1-for-10 reverse split,
        and 0 means no split event for that asset/date.
        """
        assets = [self._sanitize_user_asset(asset) for asset in assets]
        if self.broker and self.broker.data_source:
            return self.broker.data_source.get_yesterday_stock_splits(assets, quote=self.quote_asset)
        else:
            self.log_message("Broker or data source is not available.")
            return None

    def update_parameters(self, parameters: dict):
        """Update the parameters of the strategy.

        Parameters
        ----------
        parameters : dict
            The parameters to update.

        Returns
        -------
        None
        """
        for key, value in parameters.items():
            self.parameters[key] = value

        self.on_parameters_updated(parameters)

    def get_parameters(self):
        """Get the parameters of the strategy.

        Returns
        -------
        parameters : dict
            The parameters of the strategy.
        """
        return self.parameters

    def set_parameters(self, parameters: dict):
        """Set the default parameters of the strategy.

        Parameters
        ----------
        parameters : dict
            The parameters to set. These new parameters will overwrite
            the existing parameters (including the default settings).

        Returns
        -------
        None
        """
        if parameters is None:
            return None

        for key, value in parameters.items():
            self.parameters[key] = value

        self.on_parameters_updated(parameters)

        return self.parameters

    def set_parameter_defaults(self, parameters: dict):
        """Set the default parameters of the strategy.

        Parameters
        ----------
        parameters : dict
            The parameters to set defaults for. This will not overwrite
            existing parameters if they have already been set.

        Returns
        -------
        None
        """
        if parameters is None:
            return None

        for key, value in parameters.items():
            if key not in self.parameters:
                self.parameters[key] = value

        return self.parameters

    # ======= Lifecycle Methods ====================

    def initialize(self, parameters: dict = None):
        """Initialize the strategy. Use this lifecycle method to initialize parameters.

        This method is called once before the first time the strategy is run.

        Returns
        -------
        None

        Example
        -------
        >>> # Initialize the strategy
        >>> def initialize(self):
        >>>   self.sleeptime = 5
        >>>   self.ticker = "AAPL"
        >>>   self.minutes_before_closing = 5
        >>>   self.max_bars = 100

        >>> # Initialize the strategy
        >>> def initialize(self):
        >>>   # Set the strategy to call on_trading_interation every 2 seconds
        >>>   self.sleeptime = "2S"
        >>>   self.count = 0

        >>> # Initialize the strategy
        >>> def initialize(self):
        >>>   # Set the strategy to call on_trading_interation every 10 minutes
        >>>   self.sleeptime = "10M"
        >>>   self.count = 0

        >>> # Initialize the strategy
        >>> def initialize(self):
        >>>   # Set the strategy to call on_trading_interation every 20 hours
        >>>   self.sleeptime = "20H"
        >>>   self.count = 0

        >>> # Initialize the strategy
        >>> def initialize(self):
        >>>   # Set the strategy to call on_trading_interation every 2 days (48 hours)
        >>>   self.sleeptime = "2D"
        >>>   self.count = 0


        """
        pass

    def before_market_opens(self):
        """Use this lifecycle method to execute code
        self.minutes_before_opening minutes before opening.

        Returns
        -------
        None

        Example
        -------
        >>> # Get the data for SPY and TLT for the last 2 days
        >>> def before_market_opens(self):
        >>>     bars_list =  self.get_historical_prices_for_assets(["SPY", "TLT"], 2, "day")
        >>>     for asset_bars in bars_list:
        >>>         self.log_message(asset_bars.df)

        >
        """
        pass

    def before_starting_trading(self):
        """Lifecycle method executed after the market opens
        and before entering the trading loop. Use this method
        for daily resetting variables

        Returns
        -------
        None

        Example
        -------
        >>> # Get pricing data for the last day
        >>> def before_starting_trading(self):
        >>>     self.get_historical_prices("SPY", 1, "day")


        """
        pass

    def on_trading_iteration(self):
        """Use this lifecycle method for your main trading loop. This method is called every self.sleeptime minutes (or seconds/hours/days if self.sleeptime is "30S", "1H", "1D", etc.).

        Example
        -------
        >>> def on_trading_iteration(self):
        >>>     self.log_message("Hello")
        >>>     order = self.create_order("SPY", 10, "buy")
        >>>     self.submit_order(order)
        """
        pass

    def on_closed_market_iteration(self):
        """Prepare data during an explicitly scheduled closed-market run.

        This lifecycle is only called for scheduled one-shot runs whose internal
        target event is ``closed_market_prepare`` and whose broker reports the
        market closed. LumiBot blocks supported broker order submission,
        cancellation, and modification APIs for the duration of this method.
        Use it to fetch data and persist a plan for a later market-open run.
        """
        pass

    def trace_stats(self, context: dict, snapshot_before: dict):
        """Lifecycle method that will be executed after
        on_trading_iteration. context is a dictionary containing
        on_trading_iteration locals() in last call. Use this
        method to dump stats

        Parameters
        ----------
        context : dict
            Dictionary containing locals() from current call to on_trading_iteration method.

        snapshot_before : dict
            Dictionary containing locals() from last call to on_trading_iteration method.

        Returns
        -------
        dict
            Dictionary containing the stats to be logged.

        Example
        -------
        >>> def trace_stats(self, context, snapshot_before):
        >>>     self.log_message("Trace stats")
        >>>     self.log_message(f"Context: {context}")
        >>>     self.log_message(f"Snapshot before: {snapshot_before}")
        >>>     return {
        >>>         "my_stat": context["my_stat"],
        >>>         "my_other_stat": context["my_other_stat"],
        >>>         "portfolio_value": self.portfolio_value,
        >>>         "cash": self.cash,
        >>>     }
        """
        return {}

    def tearsheet_custom_metrics(
        self,
        stats_df: pd.DataFrame | None,
        strategy_returns: pd.Series,
        benchmark_returns: pd.Series | None,
        drawdown: pd.Series,
        drawdown_details: pd.DataFrame,
        risk_free_rate: float,
    ):
        """Lifecycle hook to append strategy-defined metrics to the tearsheet.

        This hook runs during backtest analysis immediately before the tearsheet HTML and
        ``*_tearsheet_metrics.json`` artifacts are generated.

        Parameters
        ----------
        stats_df : pd.DataFrame or None
            Full backtest stats DataFrame (same data used for ``*_stats.csv/parquet``).
        strategy_returns : pd.Series
            Strategy return series used for QuantStats metrics.
        benchmark_returns : pd.Series or None
            Benchmark return series if a benchmark is available.
        drawdown : pd.Series
            Drawdown series computed from ``strategy_returns``.
        drawdown_details : pd.DataFrame
            Drawdown period table (start/end/valley/days/max drawdown when available).
        risk_free_rate : float
            Effective risk-free rate used for tearsheet calculations.

        Returns
        -------
        dict
            Mapping of metric name to value.
            Supported values:
            - ``{"My Metric": 1.23}``
            - ``{"My Metric": {"strategy": 1.23, "benchmark": 0.87}}``
            - ``{"My Metric": {"Strategy": 1.23, "Benchmark (SPY)": 0.87}}``

            Custom metrics are treated as literal scalars. LumiBot and QuantStats do
            not automatically infer percent units for custom rows, so the safest
            pattern is to return unit-clear values such as counts, days, ratios, or
            raw decimals with explicit names.

        Example
        -------
        >>> def tearsheet_custom_metrics(
        >>>     self,
        >>>     stats_df,
        >>>     strategy_returns,
        >>>     benchmark_returns,
        >>>     drawdown,
        >>>     drawdown_details,
        >>>     risk_free_rate,
        >>> ):
        >>>     non_null_returns = strategy_returns.dropna()
        >>>     return {
        >>>         "Custom Return Observation Count": int(non_null_returns.shape[0]),
        >>>         "Custom Mean Absolute Daily Return": (
        >>>             float(non_null_returns.abs().mean()) if not non_null_returns.empty else 0.0
        >>>         ),
        >>>     }
        """
        return {}

    def before_market_closes(self):
        """Use this lifecycle method to execute code before the market closes. You can use self.minutes_before_closing to set the number of minutes before closing

        Parameters
        ----------
        None

        Returns
        -------
        None

        Example
        -------
        >>> # Execute code before market closes
        >>> def before_market_closes(self):
        >>>     self.sell_all()
        """
        pass

    def after_market_closes(self):
        """Use this lifecycle method to execute code
        after market closes. For example dumping stats/reports. This method is called after the last on_trading_iteration.

        Parameters
        ----------
        None

        Returns
        -------
        None

        Example
        -------
        >>> # Dump stats
        >>> def after_market_closes(self):
        >>>     self.log_message("The market is closed")
        >>>     self.log_message(f"The total value of our portfolio is {self.portfolio_value}")
        >>>     self.log_message(f"The amount of cash we have is {self.cash})
        """
        pass

    def on_strategy_end(self):
        """Use this lifecycle method to execute code
        when strategy reached its end. Used to dump
        statistics when backtesting finishes

        Parameters
        ----------
        None

        Returns
        -------
        None

        Example
        -------
        >>> # Log end of strategy
        >>> def on_strategy_end(self):
        >>>     self.log_message("The strategy is complete")
        """
        pass

    # ====== Events Methods ========================

    def on_bot_crash(self, error: Exception):
        """Use this lifecycle event to execute code
        when an exception is raised and the bot crashes

        Parameters
        ----------
        error : Exception
            The exception that was raised.

        Returns
        -------
        None

        Example
        -------
        >>> def on_bot_crash(self, error):
        >>>     self.log_message(error)

        >>> # Sell all assets on crash
        >>> def on_bot_crash(self, error):
        >>>     self.sell_all()

        """
        self.on_abrupt_closing()

    def on_abrupt_closing(self):
        """Use this lifecycle event to execute code
        when the main trader was shut down (Keybord Interuption)

        Parameters
        ----------
        None

        Returns
        -------
        None

        Example
        -------
        >>> def on_abrupt_closing(self):
        >>>     self.log_message("Abrupt closing")
        >>>     self.sell_all()
        """
        pass

    def on_new_order(self, order: Order):
        """Use this lifecycle event to execute code
        when a new order is being processed by the broker

        Parameters
        ----------
        order : Order object
            The order that is being processed.

        Returns
        -------
        None

        Example
        -------
        >>> def on_new_order(self, order):
        >>>     if order.asset == "AAPL":
        >>>         self.log_message("Order for AAPL")
        """
        pass

    def on_canceled_order(self, order: Order):
        """Use this lifecycle event to execute code when an order is canceled.

        Parameters
        ----------
        order : Order object
            The order that is being canceled.

        Returns
        -------
        None

        Example
        -------
        >>> def on_canceled_order(self, order):
        >>>     if order.asset == "AAPL":
        >>>         self.log_message("Order for AAPL canceled")
        """
        pass

    def on_partially_filled_order(
            self,
            position: Position,
            order: Order,
            price: float,
            quantity: Union[float, int],
            multiplier: float
            ):
        """Use this lifecycle event to execute code
        when an order has been partially filled by the broker

        Parameters
        ----------
        position : Position object
            The position that is being filled.

        order : Order object
            The order that is being filled.

        price : float
            The price of the fill.

        quantity : float or int
            The quantity of the fill.

        multiplier : float
            The multiplier of the fill.

        Returns
        -------
        None

        Example
        -------
        >>> def on_partially_filled_order(self, position, order, price, quantity, multiplier):
        >>>     if order.asset == "AAPL":
        >>>         self.log_message(f"{quantity} shares of AAPL partially filled")
        >>>         self.log_message(f"Price: {price}")
        """
        pass

    def on_filled_order(
            self,
            position: Position,
            order: Order,
            price: float,
            quantity: Union[float, int],
            multiplier: float
            ):
        """Use this lifecycle event to execute code when an order has been filled by the broker.

        Parameters
        ----------
        position : Position object
            The position that is being filled.

        order : Order object
            The order that is being filled.

        price : float
            The price of the fill.

        quantity : float or int
            The quantity of the fill.

        multiplier : float
            The multiplier of the fill.

        Returns
        -------
        None

        Example
        -------
        >>> def on_filled_order(self, position, order, price, quantity, multiplier):
        >>>     if order.asset == "AAPL":
        >>>         self.log_message("Order for AAPL filled")
        >>>         self.log_message(f"Price: {price}")

        >>> # Update dictionary with new position
        >>> def on_filled_order(self, position, order, price, quantity, multiplier):
        >>>     if order.asset == "AAPL":
        >>>         self.log_message("Order for AAPL filled")
        >>>         self.log_message(f"Price: {price}")
        >>>         self.positions["AAPL"] = position
        """
        pass

    def on_parameters_updated(self, parameters: dict):
        """Use this lifecycle event to execute code when the parameters are updated.

        Parameters
        ----------
        parameters : dict
            The parameters that are being updated.

        Returns
        -------
        None

        Example
        -------
        >>> def on_parameters_updated(self, parameters):
        >>>     self.log_message(f"Parameters updated: {parameters}")
        """
        pass

    def run_live(self, run_once: bool | None = None):
        """
        Executes the trading strategy in Live mode

        Parameters
        ----------
        run_once : bool, optional
            Run one trading iteration and exit instead of starting the normal always-on scheduler loop.
            If omitted, this is enabled automatically when ``LUMIBOT_SCHEDULED_EXECUTION`` is truthy.

        Returns:
            None
        """
        if run_once is None:
            run_once = str(os.environ.get("LUMIBOT_SCHEDULED_EXECUTION", "")).strip().lower() in {
                "1",
                "true",
                "yes",
                "y",
                "on",
            }

        trader = _trader_class()()

        trader.add_strategy(self)
        trader.run_all(run_once=run_once)

    @classmethod
    def backtest(
        self,
        datasource_class: Type[DataSource] | None = None,
        backtesting_start: datetime.datetime = None,
        backtesting_end: datetime.datetime = None,
        minutes_before_closing: int = 1,
        minutes_before_opening: int = 60,
        sleeptime: int = 1,
        stats_file: str = None,
        risk_free_rate: float = None,
        logfile: str = None,
        config: dict = None,
        auto_adjust: bool = False,
        name: str = None,
        budget: float = None,
        benchmark_asset: Union[str, Asset] = "SPY",
        plot_file_html: str = None,
        trades_file: str = None,
        settings_file: str = None,
        pandas_data: List[Data] = None,
        quote_asset: Asset = _DEFAULT_QUOTE_ASSET,
        starting_positions: dict = None,
        show_plot: bool | None = None,
        tearsheet_file: str = None,
        tearsheet_metrics_file: str = None,
        save_tearsheet: bool = True,
        show_tearsheet: bool | None = None,
        parameters: dict = {},
        buy_trading_fees: List[TradingFee] = [],
        sell_trading_fees: List[TradingFee] = [],
        buy_trading_slippages: List[TradingSlippage] = [],
        sell_trading_slippages: List[TradingSlippage] = [],
        polygon_api_key: str = None,
        indicators_file: str = None,
        show_indicators: bool | None = None,
        save_logfile: bool = False,
        thetadata_username: str = None,
        thetadata_password: str = None,
        use_quote_data: bool = True,  # Changed to True for ThetaData options support
        show_progress_bar: bool = True,
        quiet_logs: bool = True,
        trader_class: Type[Trader] | None = None,
        save_stats_file: bool = True,
        **kwargs,
    ):
        """Backtest a strategy.

        Parameters
        ----------
        datasource_class : class, optional
            The datasource class to use. For example, if you want to use the yahoo finance datasource, then you
            would pass YahooDataBacktesting as the datasource_class. When BACKTESTING_DATA_SOURCE is configured
            in the environment, you may leave this as None and let the runtime resolve the effective datasource.
        backtesting_start : datetime.datetime
            The start date of the backtesting period.
        backtesting_end : datetime.datetime
            The end date of the backtesting period.
        minutes_before_closing : int
            The number of minutes before closing that the minutes_before_closing strategy method will be called.
        minutes_before_opening : int
            The number of minutes before opening that the minutes_before_opening strategy method will be called.
        sleeptime : int
            The number of seconds to sleep between each iteration of the backtest.
        stats_file : str
            The file to write the stats to.
        risk_free_rate : float
            The risk free rate to use.
        logfile : str
            The file to write the log to.
        config : dict
            The config to use to set up the brokers in live trading.
        auto_adjust : bool
            Whether or not to automatically adjust the strategy.
        name : str
            The name of the strategy.
        budget : float
            The initial budget to use for the backtest.
        benchmark_asset : str or Asset
            The benchmark asset to use for the backtest to compare to. If it is a string then it will be converted
            to a stock Asset object.
        plot_file_html : str
            The file to write the plot html to.
        trades_file : str
            The file to write the trades to.
        settings_file : str
            The file to write the settings to.
        pandas_data : list of Data
            A list of Data objects that are used when the datasource_class object is set to PandasDataBacktesting.
            This contains all the data that will be used in backtesting.
        quote_asset : Asset (crypto)
            An Asset object for the crypto currency that will get used
            as a valuation asset for measuring overall porfolio values.
            Usually USDT, USD, USDC.
        starting_positions : dict
            A dictionary of starting positions for each asset. For example,
            if you want to start with $100 of SPY, and $200 of AAPL, then you
            would pass in starting_positions={'SPY': 100, 'AAPL': 200}.
        show_plot : bool
            Whether to show the plot.
        tearsheet_file : str
            The file to write the tearsheet HTML to.
        tearsheet_metrics_file : str
            The file to write machine-readable tearsheet summary metrics JSON to.
        show_tearsheet : bool
            Whether to show the tearsheet.
        save_tearsheet : bool
            Whether to save the tearsheet.
        parameters : dict
            A dictionary of parameters to pass to the strategy. These parameters
            must be set up within the initialize() method.
        buy_trading_fees : list of TradingFee objects
            A list of TradingFee objects to apply to the buy orders during backtests.
        sell_trading_fees : list of TradingFee objects
            A list of TradingFee objects to apply to the sell orders during backtests.
        buy_trading_slippages : list of TradingSlippage objects
            Slippage amounts to apply to buy SMART_LIMIT fills when no per-order slippage is provided.
        sell_trading_slippages : list of TradingSlippage objects
            Slippage amounts to apply to sell SMART_LIMIT fills when no per-order slippage is provided.
        polygon_api_key : str
            The polygon api key to use for polygon data. Only required if you are using PolygonDataBacktesting as
            the datasource_class.
        indicators_file : str
            The file to write the indicators to.
        show_indicators : bool
            Whether to show the indicators plot.
        save_logfile : bool
            Whether to save the logs to a file. If True, the logs will be saved to the logs directory. Defaults to False.
            Turning on this option will slow down the backtest.
        thetadata_username : str
            The username to use for the ThetaDataBacktesting datasource. Only required if you are using ThetaDataBacktesting as the datasource_class.
        thetadata_password : str
            The password to use for the ThetaDataBacktesting datasource. Only required if you are using ThetaDataBacktesting as the datasource_class.
        use_quote_data : bool
            Whether to use quote data for the backtest. Defaults to False. If True, the backtest will use quote data for the backtest. (Currently this is specific to ThetaData)
            When set to true this requests Quote data in addition to OHLC which adds time to backtests.
        show_progress_bar : bool
            Whether to show the progress bar. Defaults to True.
        quiet_logs : bool
            Whether to quiet noisy logs by setting the log level to ERROR. Defaults to True.
        trader_class : Trader class
            The trader class to use. Defaults to Trader.

        Returns
        -------
        result : dict
            A dictionary of the backtest results. Eg.

        Examples
        --------

        >>> from datetime import datetime
        >>> from lumibot.backtesting import YahooDataBacktesting
        >>> from lumibot.strategies import Strategy
        >>>
        >>> # A simple strategy that buys AAPL on the first day
        >>> class MyStrategy(Strategy):
        >>>    def on_trading_iteration(self):
        >>>        if self.first_iteration:
        >>>            order = self.create_order("AAPL", quantity=1, side="buy")
        >>>            self.submit_order(order)
        >>>
        >>> # Create a backtest
        >>> backtesting_start = datetime(2018, 1, 1)
        >>> backtesting_end = datetime(2018, 1, 31)
        >>>
        >>> # The benchmark asset to use for the backtest to compare to
        >>> benchmark_asset = Asset(symbol="QQQ", asset_type="stock")
        >>>
        >>> backtest = MyStrategy.backtest(
        >>>     datasource_class=None,
        >>>     backtesting_start=backtesting_start,
        >>>     backtesting_end=backtesting_end,
        >>>     benchmark_asset=benchmark_asset,
        >>> )
        """
        if quote_asset is _DEFAULT_QUOTE_ASSET:
            quote_asset = Asset(symbol="USD", asset_type="forex")

        # Environment-variable override for start/end dates.
        #
        # Why: strategies frequently hardcode `backtesting_start` / `backtesting_end`
        # in their `if __name__ == "__main__":` block for local dev convenience.
        # When the same code is run in a managed container (bot_manager backtest
        # ECS task, etc.), the orchestrator wants the caller's requested date
        # range to win — otherwise MCP `start_backtest(startDate, endDate)` has
        # no teeth and every run uses whatever the author pinned in the file.
        #
        # Precedence: env var > passed argument. The env vars are set by the
        # infrastructure (bot_manager copies `start_date`/`end_date` from the
        # job payload into `BACKTESTING_START` / `BACKTESTING_END`), so they
        # represent the caller's current intent. Local runs with no env var
        # set continue to use the hardcoded datetime as before.
        #
        # Accepted formats: ISO date (`YYYY-MM-DD`) or full ISO datetime. Any
        # parse failure is logged and the passed-in value is kept — we never
        # silently fall back to "now" or the epoch.
        env_start = os.environ.get("BACKTESTING_START")
        env_end = os.environ.get("BACKTESTING_END")
        if env_start:
            try:
                parsed_start = datetime.datetime.fromisoformat(env_start)
                if parsed_start != backtesting_start:
                    # WARNING (not INFO): silent truncation of a strategy's
                    # hardcoded backtest window from a stale .env value is
                    # easy to miss and produces "mystery" result drift. Flag
                    # it loudly so the override is visible in every run.
                    _logging_warning(
                        f"BACKTESTING_START env var override: {backtesting_start} -> {parsed_start}"
                    )
                backtesting_start = parsed_start
            except (TypeError, ValueError) as exc:
                _logging_warning(
                    f"Ignoring unparseable BACKTESTING_START={env_start!r}: {exc}"
                )
        if env_end:
            try:
                parsed_end = datetime.datetime.fromisoformat(env_end)
                if parsed_end != backtesting_end:
                    _logging_warning(
                        f"BACKTESTING_END env var override: {backtesting_end} -> {parsed_end}"
                    )
                backtesting_end = parsed_end
            except (TypeError, ValueError) as exc:
                _logging_warning(
                    f"Ignoring unparseable BACKTESTING_END={env_end!r}: {exc}"
                )

        results, strategy = self.run_backtest(
            datasource_class=datasource_class,
            backtesting_start=backtesting_start,
            backtesting_end=backtesting_end,
            minutes_before_closing=minutes_before_closing,
            minutes_before_opening=minutes_before_opening,
            sleeptime=sleeptime,
            stats_file=stats_file,
            risk_free_rate=risk_free_rate,
            logfile=logfile,
            config=config,
            auto_adjust=auto_adjust,
            name=name,
            budget=budget,
            benchmark_asset=benchmark_asset,
            plot_file_html=plot_file_html,
            trades_file=trades_file,
            settings_file=settings_file,
            pandas_data=pandas_data,
            quote_asset=quote_asset,
            starting_positions=starting_positions,
            show_plot=show_plot,
            tearsheet_file=tearsheet_file,
            tearsheet_metrics_file=tearsheet_metrics_file,
            save_tearsheet=save_tearsheet,
            show_tearsheet=show_tearsheet,
            parameters=parameters,
            buy_trading_fees=buy_trading_fees,
            sell_trading_fees=sell_trading_fees,
            buy_trading_slippages=buy_trading_slippages,
            sell_trading_slippages=sell_trading_slippages,
            polygon_api_key=polygon_api_key,
            indicators_file=indicators_file,
            show_indicators=show_indicators,
            save_logfile=save_logfile,
            thetadata_username=thetadata_username,
            thetadata_password=thetadata_password,
            use_quote_data=use_quote_data,
            show_progress_bar=show_progress_bar,
            quiet_logs=quiet_logs,
            trader_class=trader_class,
            save_stats_file=save_stats_file,
            **kwargs,
        )
        return results
