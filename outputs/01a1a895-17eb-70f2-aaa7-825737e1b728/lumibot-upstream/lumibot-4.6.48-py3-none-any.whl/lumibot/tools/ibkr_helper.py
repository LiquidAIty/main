from __future__ import annotations

import json
import hashlib
import logging
import math
import re
import os
import time
from dataclasses import dataclass
from datetime import date, datetime, timedelta, timezone
from functools import lru_cache
from pathlib import Path
from typing import Any, Callable, Dict, Optional, Tuple

import numpy as np
import pandas as pd

from lumibot.constants import LUMIBOT_CACHE_FOLDER, LUMIBOT_DEFAULT_PYTZ
from lumibot.entities import Asset
from lumibot.tools.backtest_cache import CacheMode, get_backtest_cache
from lumibot.tools.data_downloader_queue_client import queue_request
from lumibot.tools.ibkr_secdef import (
    IbkrFuturesExchangeAmbiguousError,
    select_futures_exchange_from_secdef_search_payload,
)
from lumibot.tools.ibkr_history_health import (
    HistoryOutcome,
    HistoryPayloadError,
    classify_history_failure,
    coalesce_nearby_session_groups,
    group_contiguous_missing_sessions,
    padded_repair_window,
    record_history_health,
    split_session_groups,
)
from lumibot.tools.parquet_series_cache import ParquetSeriesCache
from lumibot.tools.ibkr_volume import validated_volume_factor

logger = logging.getLogger(__name__)

CACHE_SUBFOLDER = "ibkr"

# IBKR Client Portal Gateway caps historical responses at ~1000 datapoints per call.
IBKR_HISTORY_MAX_POINTS = 1000
IBKR_DEFAULT_CRYPTO_VENUE = "ZEROHASH"
IBKR_DEFAULT_HISTORY_SOURCE = "Trades"
IBKR_DEFAULT_FUTURES_EXCHANGE_FALLBACK = "CME"
# IBKR lists CME FX futures under the currency, not the Globex code strategies use.
# Registry keys keep the strategy's symbol; only the IBKR lookup uses the IBKR root.
IBKR_FUTURES_ROOT_ALIASES: Dict[str, str] = {
    "6A": "AUD",
    "6B": "GBP",
    "6C": "CAD",
    "6E": "EUR",
    "6J": "JPY",
    "6M": "MXN",
    "6N": "NZD",
    "6S": "CHF",
}
IBKR_DEFAULT_INDEX_HISTORY_SOURCE = "Midpoint"
# Per-request period cap for daily stock/index history.
#
# Rationale: IBKR Client Portal Gateway caps daily-history responses at ~1000
# data points per call (``IBKR_HISTORY_MAX_POINTS``). Live testing against the
# production gateway on 2026-04-17 showed that ``period=5y`` already hits that
# ceiling (1000 bars returned, covering ~4 trading years), while ``period=2y``
# returned 323 bars and ``period=180d`` (the prior value) returned only ~125
# bars. Asking for less than the cap is pure inefficiency: multi-year
# backtests would need 40+ round-trips per symbol, and in practice the loop
# was completing after a single iteration (the initial fetch near real-now
# filled the cache, then the coverage check skipped the real historical
# window for every subsequent simulation date, resulting in flat "today"
# prices for an entire multi-year historical range).
#
# With ``5y``:
#   - Each call returns up to 1000 bars (~4 years of daily data).
#   - An 8-year backtest is covered in ~2 paginated chunks per symbol/source.
#   - Requests exceeding one year retain this cap and whole-run prefetch.
#     Shorter, explicitly bounded windows include calendar padding instead of
#     downloading and validating five years for a recent short simulation.
#
# If a future need arises for sub-daily stock/index bars with very long
# windows, extend ``_history_period_for_request`` to pick a smaller period
# tailored to the bar size rather than tightening this cap.
IBKR_STOCK_INDEX_DAILY_MAX_PERIOD = "5y"
IBKR_GAP_RETRY_TTL_SECONDS = 24 * 60 * 60
# Older writers mistook a successful page of only older bars for confirmed
# tail absence. Those persisted records must remain retryable after recovery.
IBKR_LEGACY_INFERRED_TAIL_REASON = "successful_history_response_confirmed_no_newer_bars"
IBKR_DAILY_GAP_REPAIR_TIMEOUT_SECONDS = 45.0
IBKR_DAILY_GAP_REPAIR_MAX_SEGMENTS_PER_SERIES = 4
IBKR_DAILY_GAP_REPAIR_MAX_SESSIONS_PER_SEGMENT = 10
IBKR_HOURLY_GAP_REPAIR_TIMEOUT_SECONDS = 300.0
IBKR_HOURLY_INTERNAL_GAP_THRESHOLD = timedelta(days=7)
IBKR_HOURLY_GAP_REPAIR_MAX_SEGMENTS_PER_SERIES = 4
# Minute cache holes are repaired one missing session per request (one 1000-minute page
# covers a whole extended-hours session). Repair stops for the process after this many
# consecutive failed requests, because the downloader is then down, not the data missing.
IBKR_MINUTE_GAP_REPAIR_MAX_CONSECUTIVE_FAILURES = 3
IBKR_MINUTE_GAP_MARKER_REASON = "minute_session_gap_empty"
# A failed repair request, or a series given up after consecutive failures, is retried after
# this long in the same process (a notebook or multi-backtest service outlives an outage).
IBKR_MINUTE_GAP_RETRY_COOLDOWN_SECONDS = 300.0
# Serving a minute series with known unrepaired sessions logs a WARNING, at most this often
# per series so a sliding-window caller does not log one per bar.
IBKR_MINUTE_GAP_WARNING_INTERVAL_SECONDS = 60.0
# Backward pagination of US stock intraday history steps over closed-market pages
# (weekends, holidays, overnight) instead of treating their empty answer as the start
# of history. A 1000-minute page is 16.7 hours, a weekend is about 56 closed hours.
# The bound only guards against a calendar bug; a real walk skips one or two per gap.
IBKR_MAX_CLOSED_PAGE_SKIPS = 2000
# Consecutive empty futures pages during rule-calendar trading time that are stepped over
# before the walk treats the empty answer as the start of history (holiday closes).
IBKR_FUTURES_MAX_EMPTY_OPEN_PAGES = 3
# Smallest daily page tried after IBKR says "Chart data unavailable" for a page that
# reaches back before the contract's first bar (see _smaller_daily_period_after_chart_unavailable).
IBKR_DAILY_MIN_PAGE_DAYS = 5
# Daily windows up to this many days are requested as one exact "<N>d" page (N <= 1000,
# which IBKR accepts); longer windows page with IBKR_STOCK_INDEX_DAILY_MAX_PERIOD.
IBKR_DAILY_EXACT_PERIOD_MAX_DAYS = 993
# Backward pagination writes collected pages to the cache every N pages, so a run that is
# stopped mid-walk keeps its progress (a cold 8-month minute series takes hours).
IBKR_PAGE_CHECKPOINT_EVERY = 10
# How far behind real time IBKR stock/index intraday history can lag on the shared account
# (observed 13 to 17 minutes). Intraday requests never ask for bars newer than this.
IBKR_INTRADAY_HISTORY_DELAY = timedelta(minutes=20)
IBKR_STOCK_INDEX_HOURLY_REPAIR_PERIOD = "2000h"

IBKR_CONID_NEGATIVE_CACHE_TTL_SECONDS = 24 * 60 * 60  # 24h (persisted via BacktestCacheManager when enabled)


class IbkrFuturesConidLookupError(RuntimeError):
    """Raised when IBKR cannot resolve a futures conid for a root/expiration.

    This is treated as a data-availability issue (not a platform crash) so backtests can
    complete while logging loudly.
    """


_FUTURES_EXCHANGE_CACHE: Dict[str, str] = {}
_FUTURES_EXCHANGE_CACHE_LOADED = False

_NEGATIVE_CONID_CACHE: Dict[str, Dict[str, Any]] = {}
_NEGATIVE_CONID_CACHE_LOADED = False
_IBKR_EQUITY_ACTIONS_CACHE: Dict[str, pd.DataFrame] = {}
_IBKR_EQUITY_BASIS_CACHE: dict = {}
_RUNTIME_CONID_CACHE: Dict[str, int] = {}
_RUNTIME_HISTORY_NO_DATA_WINDOWS: Dict[str, Tuple[datetime, datetime]] = {}
# Downloader segments already requested in this process, keyed by cache file.
#
# WHY: a successful response can leave a window underfilled (the provider has no bars
# inside the gap, or answers with bars from before it). Without this memory the next
# iteration computes the same missing segment and re-submits the identical request.
# A production SPY 5-minute backtest (2026-09-15) sent `startTime=20260908-08:00:00` 77 times
# in one run this way. This is in-process state only: it is never written to the cache,
# so a later process still retries (see the history integrity contract).
_RUNTIME_ATTEMPTED_HISTORY_SEGMENTS: Dict[str, list[Tuple[datetime, datetime]]] = {}
_RUNTIME_DAILY_GAP_CHECKED_WINDOWS: set[tuple[str, str, str]] = set()
_RUNTIME_HOURLY_GAP_CHECKED_SERIES: Dict[
    str,
    tuple[tuple[int, str, str, int], datetime, datetime],
] = {}
# series -> (cache signature, checked window start, end, recheck_at). recheck_at is the earliest
# expiry of an empty-session marker in that window (None when there is none): after it the
# window is scanned again, so a long-lived process asks for the session again.
_RUNTIME_MINUTE_GAP_CHECKED_SERIES: Dict[
    str,
    tuple[tuple[int, str, str, int], datetime, datetime, Optional[datetime]],
] = {}
# Per-process memory for the minute-hole repair, in memory only, with monotonic timestamps so
# it expires after IBKR_MINUTE_GAP_RETRY_COOLDOWN_SECONDS: sessions whose request failed, and
# series whose repair stopped after consecutive failures. Without it a sliding-window caller
# asked the same failing session on every bar; without the expiry a long-lived process kept a
# hole after the downloader recovered.
_RUNTIME_MINUTE_GAP_FAILED_SESSIONS: Dict[str, Dict[pd.Timestamp, float]] = {}
_RUNTIME_MINUTE_GAP_REPAIR_STOPPED: Dict[str, float] = {}
_RUNTIME_MINUTE_GAP_LAST_WARNING: Dict[str, float] = {}
_DISABLE_CONIDS_REMOTE_UPLOAD = False
_LOGGED_CONIDS_REMOTE_UPLOAD_DISABLE = False
_LOGGED_HISTORY_ALIASES: set[str] = set()


def _truthy_env(var_name: str, default: str = "false") -> bool:
    raw = os.environ.get(var_name, default)
    return str(raw).strip().lower() in {"1", "true", "yes", "y", "on"}


def _is_access_denied_error(exc: Exception) -> bool:
    msg = str(exc or "").lower()
    return "access denied" in msg or "accessdenied" in msg


def _normalize_asset_type(value: Any) -> str:
    raw = str(value or "").strip().lower()
    if "." in raw:
        raw = raw.split(".")[-1]
    return raw


def _alias_asset_for_ibkr_history(asset: Asset) -> tuple[Asset, Optional[str]]:
    """Map known strategy-facing index aliases to IBKR history symbols.

    Some strategy code uses weekly option roots (for example `SPXW`) as the
    index symbol for convenience. IBKR history resolves the underlying index as
    `SPX`, not `SPXW`. Keep this mapping local to history requests so option
    chains/orders are unaffected.
    """
    asset_type = _normalize_asset_type(getattr(asset, "asset_type", ""))
    symbol = str(getattr(asset, "symbol", "") or "").strip().upper()
    if asset_type == "index" and symbol == "SPXW":
        return Asset("SPX", asset_type=Asset.AssetType.INDEX), "SPXW->SPX"
    return asset, None


def _enable_futures_bid_ask_derivation() -> bool:
    """Whether to derive bid/ask quotes for futures from Bid_Ask + Midpoint history.

    Default is disabled because:
    - Futures backtests in LumiBot are intended to fill off TRADES/OHLC by default.
    - IBKR Client Portal Bid_Ask/Midpoint history can be flaky and adds 2x request volume.
    """
    return os.environ.get("LUMIBOT_IBKR_ENABLE_FUTURES_BID_ASK", "").strip().lower() in {
        "1",
        "true",
        "yes",
        "y",
        "on",
    }

def _futures_exchange_cache_file() -> Path:
    return Path(LUMIBOT_CACHE_FOLDER) / CACHE_SUBFOLDER / "futures_exchanges.json"


def _load_futures_exchange_cache() -> None:
    global _FUTURES_EXCHANGE_CACHE_LOADED
    if _FUTURES_EXCHANGE_CACHE_LOADED:
        return
    _FUTURES_EXCHANGE_CACHE_LOADED = True
    path = _futures_exchange_cache_file()
    try:
        get_backtest_cache().ensure_local_file(
            path, payload={"provider": "ibkr", "type": "futures_exchanges"}
        )
    except Exception:
        pass
    if not path.exists():
        return
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        payload = {}
    if isinstance(payload, dict):
        for k, v in payload.items():
            if not k or not v:
                continue
            _FUTURES_EXCHANGE_CACHE[str(k).strip().upper()] = str(v).strip().upper()


def _persist_futures_exchange_cache() -> None:
    path = _futures_exchange_cache_file()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(_FUTURES_EXCHANGE_CACHE, indent=2, sort_keys=True), encoding="utf-8")
    except Exception:
        return
    try:
        cache = get_backtest_cache()
        cache.on_local_update(path, payload={"provider": "ibkr", "type": "futures_exchanges"})
    except Exception:
        pass


def _negative_conid_cache_file() -> Path:
    return Path(LUMIBOT_CACHE_FOLDER) / CACHE_SUBFOLDER / "conids_negative.json"


def _load_negative_conid_cache() -> None:
    """Load negative conid cache (best-effort) and prune stale entries."""
    global _NEGATIVE_CONID_CACHE_LOADED
    if _NEGATIVE_CONID_CACHE_LOADED:
        return
    _NEGATIVE_CONID_CACHE_LOADED = True

    path = _negative_conid_cache_file()
    cache_manager = get_backtest_cache()
    try:
        cache_manager.ensure_local_file(path, payload={"provider": "ibkr", "type": "conids_negative"})
    except Exception:
        pass

    if not path.exists():
        return

    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        payload = {}
    if not isinstance(payload, dict):
        return

    now = float(time.time())
    changed = False
    for key, value in payload.items():
        if not isinstance(key, str) or not key:
            continue
        if not isinstance(value, dict):
            continue
        ts = value.get("ts")
        try:
            ts_f = float(ts)
        except Exception:
            ts_f = None
        if ts_f is None or (now - ts_f) > IBKR_CONID_NEGATIVE_CACHE_TTL_SECONDS:
            changed = True
            continue
        _NEGATIVE_CONID_CACHE[key] = value

    if changed:
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(_NEGATIVE_CONID_CACHE, indent=2, sort_keys=True), encoding="utf-8")
            try:
                cache_manager.on_local_update(path, payload={"provider": "ibkr", "type": "conids_negative"})
            except Exception:
                pass
        except Exception:
            pass


def _record_negative_conid(*, key: str, reason: str, message: str) -> None:
    """Persist a negative cache marker so we stop hammering IBKR for invalid roots/expirations."""
    if not key:
        return
    _load_negative_conid_cache()
    now = float(time.time())
    _NEGATIVE_CONID_CACHE[key] = {"ts": now, "reason": str(reason), "message": str(message)}

    path = _negative_conid_cache_file()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(_NEGATIVE_CONID_CACHE, indent=2, sort_keys=True), encoding="utf-8")
    except Exception:
        return
    try:
        cache_manager = get_backtest_cache()
        cache_manager.on_local_update(path, payload={"provider": "ibkr", "type": "conids_negative"})
    except Exception:
        pass


def _clear_negative_conid(*, key: str) -> None:
    """Remove a stale negative conid marker after a later successful resolution."""
    if not key:
        return
    _load_negative_conid_cache()
    if key not in _NEGATIVE_CONID_CACHE:
        return
    _NEGATIVE_CONID_CACHE.pop(key, None)

    path = _negative_conid_cache_file()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(_NEGATIVE_CONID_CACHE, indent=2, sort_keys=True), encoding="utf-8")
    except Exception:
        return
    try:
        cache_manager = get_backtest_cache()
        cache_manager.on_local_update(path, payload={"provider": "ibkr", "type": "conids_negative"})
    except Exception:
        pass


def _date_from_yyyymmdd(value: str) -> Optional[date]:
    raw = str(value or "").strip()
    if not (raw.isdigit() and len(raw) == 8):
        return None
    try:
        return datetime.strptime(raw, "%Y%m%d").date()
    except Exception:
        return None


def _expiration_date_only(value: Any) -> Optional[date]:
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    return None


def _is_future_or_current_expiration(value: Any) -> bool:
    expiration_date = _expiration_date_only(value)
    if expiration_date is None:
        return False
    return expiration_date >= datetime.now(timezone.utc).date()


def _resolve_futures_exchange(symbol: str) -> str:
    symbol_upper = str(symbol or "").strip().upper()
    if not symbol_upper:
        raise RuntimeError("IBKR futures exchange resolution requires a non-empty symbol")

    _load_futures_exchange_cache()
    cached = _FUTURES_EXCHANGE_CACHE.get(symbol_upper)
    if cached:
        return cached

    base_url = _downloader_base_url()
    url = f"{base_url}/ibkr/iserver/secdef/search"
    search_symbol = IBKR_FUTURES_ROOT_ALIASES.get(symbol_upper, symbol_upper)
    payload = queue_request(url=url, querystring={"symbol": search_symbol, "secType": "FUT"}, headers=None, timeout=None)
    if payload is None:
        raise RuntimeError(f"IBKR secdef/search returned no payload for FUT symbol={search_symbol!r}")

    exchange = select_futures_exchange_from_secdef_search_payload(search_symbol, payload)
    _FUTURES_EXCHANGE_CACHE[symbol_upper] = exchange
    _persist_futures_exchange_cache()
    return exchange


def _us_futures_closed_interval(
    start_local: datetime, end_local: datetime, *, bar_step: Optional[timedelta] = None
) -> bool:
    """Return True if US futures are fully closed in [start_local, end_local).

    This is a deliberately simple rule-based calendar used to avoid repeated downloader fetches
    for known closed windows (daily maintenance + weekends). It is not intended to encode every
    CME holiday/early-close rule; those can still produce longer gaps that require vendor data.
    Intraday cache edges may supply a cadence: only aligned bar starts at or after
    the requested boundary can be returned. A Friday boundary inside the final
    bar must not repeatedly fetch that earlier bar across the weekend.
    """
    try:
        start_ts = pd.Timestamp(start_local)
        end_ts = pd.Timestamp(end_local)
        if start_ts.tzinfo is None:
            start_ts = start_ts.tz_localize(LUMIBOT_DEFAULT_PYTZ)
        if end_ts.tzinfo is None:
            end_ts = end_ts.tz_localize(LUMIBOT_DEFAULT_PYTZ)
        start_ts = start_ts.tz_convert("America/New_York")
        end_ts = end_ts.tz_convert("America/New_York")
        if bar_step is not None and timedelta(0) < bar_step < timedelta(days=1):
            start_ts = start_ts.ceil(pd.Timedelta(bar_step))
        if end_ts <= start_ts:
            return True
    except Exception:
        return False

    def _next_open(ts: pd.Timestamp) -> pd.Timestamp:
        ts = ts.tz_convert("America/New_York")
        dow = int(ts.weekday())  # Mon=0 .. Sun=6
        t = ts.time()

        def wall_open(days: int) -> pd.Timestamp:
            # Calendar days and local wall time, not elapsed hours across DST.
            day = ts.date() + timedelta(days=days)
            return pd.Timestamp(datetime.combine(day, datetime.min.replace(hour=18).time()),
                                tz="America/New_York")

        # Friday's maintenance window starts the weekend closure.
        if dow == 4 and t >= datetime.min.replace(hour=17).time():
            return wall_open(2)

        # Saturday: closed all day; next open is Sunday 18:00 ET.
        if dow == 5:
            return wall_open(1)

        # Sunday: closed until 18:00 ET.
        if dow == 6:
            open_ts = wall_open(0)
            return ts if ts >= open_ts else open_ts

        # Weekdays: closed daily 17:00–18:00 ET.
        if t >= datetime.min.replace(hour=17, minute=0, second=0).time() and t < datetime.min.replace(hour=18, minute=0, second=0).time():
            reopen = ts.normalize() + pd.Timedelta(hours=18)
            reopen = reopen.tz_localize("America/New_York") if reopen.tzinfo is None else reopen
            return reopen

        return ts

    try:
        next_open = _next_open(start_ts)
        return bool(next_open >= end_ts)
    except Exception:
        return False


def closed_futures_mark(frame: pd.DataFrame, *, timestep: str, when: datetime) -> Optional[float]:
    """Use a completed trade close only when every later instant was closed.

    This is a valuation fallback, never an executable bar or a gap repair. An
    absent bar after the next opening remains missing, including holiday gaps
    not represented by the conservative maintenance/weekend calendar.
    """
    if frame is None or frame.empty or "close" not in frame:
        return None
    try:
        _, seconds, _ = _timestep_to_ibkr_bar(timestep)
        if seconds >= 86400:
            return None
        now = pd.Timestamp(when)
        completed = frame.loc[frame.index + pd.Timedelta(seconds=seconds) <= now]
        if completed.empty:
            return None
        row = completed.iloc[-1]
        if bool(row.get("missing", False)) or not pd.notna(row["close"]):
            return None
        end = completed.index[-1] + pd.Timedelta(seconds=seconds)
        # Include the valuation instant itself: [last close, reopening) is
        # closed, but at reopening a new executable price may already exist.
        if not _us_futures_closed_interval(end.to_pydatetime(), (now + pd.Timedelta(microseconds=1)).to_pydatetime()):
            return None
        price = float(row["close"])
        return price if math.isfinite(price) else None
    except (TypeError, ValueError, KeyError):
        return None


@lru_cache(maxsize=64)
def _us_equity_session_bounds_for_year(year: int, extended_hours: bool) -> tuple[np.ndarray, np.ndarray]:
    """Return sorted NYSE session (open, close) bounds for one year as UTC nanoseconds.

    Extended hours use the calendar's pre/post times (04:00 to 20:00 ET, 17:00 on early
    close days). Regular hours use the market open and close.
    """
    import pandas_market_calendars as mcal

    open_col, close_col = ("pre", "post") if extended_hours else ("market_open", "market_close")
    schedule = mcal.get_calendar("NYSE").schedule(
        start_date=f"{int(year)}-01-01",
        end_date=f"{int(year)}-12-31",
        start=open_col,
        end=close_col,
    )
    if schedule is None or schedule.empty:
        empty = np.array([], dtype="int64")
        return empty, empty
    # Calendar Series also retain their datetime resolution on pandas 3.
    opens = pd.DatetimeIndex(pd.to_datetime(schedule[open_col], utc=True)).as_unit("ns").asi8
    closes = pd.DatetimeIndex(pd.to_datetime(schedule[close_col], utc=True)).as_unit("ns").asi8
    order = np.argsort(opens)
    return opens[order], closes[order]


def _equity_history_start_for_bars(end_dt: datetime, length: int, timestep: str, *, include_after_hours: bool) -> datetime:
    """Count completed bars backward through cached sessions, including closures.

    This is a request boundary, not permission to fabricate missing provider bars.
    Calendar years are cached by the existing completeness checker.
    """
    end = pd.Timestamp(end_dt)
    if end.tzinfo is None:
        end = end.tz_localize(LUMIBOT_DEFAULT_PYTZ)
    _, seconds, _ = _timestep_to_ibkr_bar(timestep)
    daily = str(timestep) == "day"
    remaining = int(length)
    end_ns = int(end.tz_convert("UTC").value)
    step_ns = int(seconds * 1_000_000_000)
    year = end.year
    while remaining > 0:
        opens, closes = _us_equity_session_bounds_for_year(year, include_after_hours and not daily)
        for opened, closed in zip(opens[::-1], closes[::-1]):
            if daily:
                if closed >= end_ns:
                    continue
                remaining -= 1
                if remaining == 0:
                    return pd.Timestamp(int(opened), unit="ns", tz="UTC").to_pydatetime()
            else:
                available = max(0, (min(int(closed), end_ns) - int(opened)) // step_ns)
                if available >= remaining:
                    start_ns = int(opened) + (available - remaining) * step_ns
                    return pd.Timestamp(start_ns, unit="ns", tz="UTC").to_pydatetime()
                remaining -= available
        year -= 1
        if year < 1900:
            raise ValueError("IBKR lookback exceeds supported exchange calendar")
    return end.to_pydatetime()


def _us_equity_closed_interval(start_local: datetime, end_local: datetime, *, include_after_hours: bool) -> bool:
    """Return True if a US equity cannot trade anywhere in ``[start_local, end_local)``.

    Used to skip downloader requests for window edges that are pure market-closed time
    (weekends, exchange holidays, overnight). IBKR has no bars there, so asking again
    only returns bars from outside the window. Any calendar failure returns False, which
    keeps the old behavior of fetching.
    """
    try:
        start_ts = pd.Timestamp(start_local)
        end_ts = pd.Timestamp(end_local)
        if start_ts.tzinfo is None:
            start_ts = start_ts.tz_localize(LUMIBOT_DEFAULT_PYTZ)
        if end_ts.tzinfo is None:
            end_ts = end_ts.tz_localize(LUMIBOT_DEFAULT_PYTZ)
        if end_ts <= start_ts:
            return True
        start_ns = int(start_ts.tz_convert("UTC").value)
        end_ns = int(end_ts.tz_convert("UTC").value)
        first_year = int(start_ts.tz_convert("America/New_York").year)
        last_year = int(end_ts.tz_convert("America/New_York").year)
        for year in range(first_year, last_year + 1):
            opens, closes = _us_equity_session_bounds_for_year(year, bool(include_after_hours))
            if len(opens) == 0:
                continue
            # First session that has not closed by `start`; it overlaps if it opens before `end`.
            idx = int(np.searchsorted(closes, start_ns, side="right"))
            if idx < len(opens) and int(opens[idx]) < end_ns:
                return False
        return True
    except Exception:
        return False


def _period_to_timedelta(period: str) -> Optional[timedelta]:
    """Parse an IBKR history `period` (``1000min``, ``5000min``, ``1000h``, ``45d``)."""
    text = (period or "").strip().lower()
    for suffix, unit, scale in (
        ("min", "minutes", 1),
        ("sec", "seconds", 1),
        ("h", "hours", 1),
        ("d", "days", 1),
        ("w", "days", 7),
        ("y", "days", 365),
        ("m", "days", 30),
    ):
        if text.endswith(suffix):
            number = text[: -len(suffix)]
            if number.isdigit() and int(number) > 0:
                return timedelta(**{unit: int(number) * scale})
            return None
    return None


def _ibkr_history_now_utc() -> datetime:
    """Wall clock for history requests (a seam so tests can pin "now")."""
    return datetime.now(timezone.utc)


def _ibkr_monotonic() -> float:
    """Monotonic clock for in-process cooldowns (a seam so tests can advance it)."""
    return time.monotonic()


def _is_chart_data_unavailable(exc: BaseException) -> bool:
    return "chart data unavailable" in str(exc).lower()


def _smaller_daily_period_after_chart_unavailable(
    exc: BaseException, *, asset_type: str, bar: str, period: str
) -> Optional[str]:
    """Half-size daily page to retry after IBKR's ``Chart data unavailable``.

    IBKR returns that HTTP 500 when a daily page reaches back before the first bar it
    holds for the contract (recent listings, or the last page of a long backtest).
    Verified 2026-09-24: a 2022 listing failed with ``5y`` and returned 1002 bars with
    ``4y``. Halving keeps the real bars that exist; None once the page is tiny.
    """
    if asset_type not in {"stock", "index"} or not (bar or "").strip().lower().endswith("d"):
        return None
    if not _is_chart_data_unavailable(exc):
        return None
    step = _period_to_timedelta(period)
    if step is None:
        return None
    days = step.days // 2
    if days < IBKR_DAILY_MIN_PAGE_DAYS:
        return None
    return f"{days}d"


def _cursor_before_closed_equity_page(
    *,
    asset_type: str,
    bar: str,
    period: str,
    cursor_end: datetime,
    include_after_hours: bool,
) -> Optional[datetime]:
    """Where backward pagination continues after an empty US stock intraday page.

    IBKR answers an empty list when the whole ``[cursor_end - period, cursor_end]`` page
    is closed-market time. That is not the start of history. Returns the end of the next
    page that can hold bars (stepping over further closed pages without a request), or
    None when the empty page covered trading time and the old stop behavior applies.
    Stocks use the NYSE calendar with the request's extended-hours flag. US indexes (SPX,
    NDX, VIX) only print during the regular session (verified live 2026-09-24: an SPX page
    ending Friday 21:00 UTC held 09:30 to 15:59 ET), so their overnight gap (17.5 hours) is
    longer than a 1000-minute page too; they use the regular-session calendar. Futures
    sessions differ and keep the old behavior.
    """
    if asset_type not in {"stock", "index"} or (bar or "").strip().lower().endswith("d"):
        return None
    step = _period_to_timedelta(period)
    if step is None:
        return None
    calendar_extended_hours = bool(include_after_hours) if asset_type == "stock" else False
    page_end = cursor_end
    for _ in range(64):
        page_start = page_end - step
        if not _us_equity_closed_interval(page_start, page_end, include_after_hours=calendar_extended_hours):
            if page_end != cursor_end:
                return page_end
            # The only open time in this empty page may be the quiet start of the session it ends
            # in: a thin symbol's cache began at Monday 04:19 ET, the page ending there held Sunday
            # plus 04:00 to 04:19 with no trades, and paging stopped (live, 2026-09-24). An empty
            # answer there means "no trades yet", so continue from the previous session's close.
            return _previous_close_if_only_session_start_is_open(
                page_start=page_start, page_end=page_end, extended=calendar_extended_hours
            )
        page_end = page_start
    return page_end


def _cursor_before_closed_futures_page(
    *,
    asset_type: str,
    bar: str,
    period: str,
    cursor_end: datetime,
) -> Optional[datetime]:
    """Where backward pagination continues after an empty US futures intraday page.

    Same idea as `_cursor_before_closed_equity_page`, with the CME rule calendar
    (`_us_futures_closed_interval`: weekends and the daily 17:00-18:00 ET break). Without it
    every futures walk stopped at the first weekend: MES 1-minute for Sep 1 to 18, 2026 started
    at the Sunday Sep 6 18:00 open (data matrix, 2026-09-25). Returns None when the empty page
    covered open time by those rules.
    """
    if asset_type not in {"future", "cont_future"} or (bar or "").strip().lower().endswith("d"):
        return None
    step = _period_to_timedelta(period)
    if step is None:
        return None
    page_end = cursor_end
    for _ in range(64):
        page_start = page_end - step
        if not _us_futures_closed_interval(page_start, page_end):
            return page_end if page_end != cursor_end else None
        page_end = page_start
    return page_end


def _previous_close_if_only_session_start_is_open(
    *, page_start: datetime, page_end: datetime, extended: bool
) -> Optional[datetime]:
    try:
        end_ts = pd.Timestamp(page_end)
        if end_ts.tzinfo is None:
            end_ts = end_ts.tz_localize("UTC")
        end_ns = int(end_ts.tz_convert("UTC").value)
        year = int(end_ts.tz_convert("America/New_York").year)
        bounds = [_us_equity_session_bounds_for_year(y, extended) for y in (year - 1, year)]
        opens = np.concatenate([b[0] for b in bounds])
        closes = np.concatenate([b[1] for b in bounds])
        idx = int(np.searchsorted(opens, end_ns, side="left")) - 1
        if idx < 1 or not (int(opens[idx]) < end_ns <= int(closes[idx])):
            return None
        session_open = pd.Timestamp(int(opens[idx]), unit="ns", tz="UTC").to_pydatetime()
        if not _us_equity_closed_interval(page_start, session_open, include_after_hours=extended):
            return None
        return pd.Timestamp(int(closes[idx - 1]), unit="ns", tz="UTC").to_pydatetime()
    except Exception:
        return None


def _previous_equity_session_close_before(
    *,
    asset_type: str,
    bar: str,
    earliest: datetime,
    include_after_hours: bool,
    page_start: Optional[datetime] = None,
    page_was_capped: bool = False,
) -> Optional[datetime]:
    """Close of the last US equity session before ``earliest`` when only closed time lies between.

    Backward pagination continues from the oldest bar received. When that bar opens a session,
    anchoring the next 1000-minute page there makes it straddle the closed overnight or weekend
    gap, so about half of every page was empty (production: ~1.8 requests per session).
    Anchoring at the previous session's close gives one full page per session.
    """
    if asset_type not in {"stock", "index"} or (bar or "").strip().lower().endswith("d"):
        return None
    try:
        extended = bool(include_after_hours) if asset_type == "stock" else False
        earliest_ts = pd.Timestamp(earliest)
        if earliest_ts.tzinfo is None:
            earliest_ts = earliest_ts.tz_localize(LUMIBOT_DEFAULT_PYTZ)
        earliest_ns = int(earliest_ts.tz_convert("UTC").value)
        year = int(earliest_ts.tz_convert("America/New_York").year)
        closes = np.concatenate(
            [
                _us_equity_session_bounds_for_year(year - 1, extended)[1],
                _us_equity_session_bounds_for_year(year, extended)[1],
            ]
        )
        idx = int(np.searchsorted(closes, earliest_ns, side="left")) - 1
        if idx < 0:
            return None
        previous_close = pd.Timestamp(int(closes[idx]), unit="ns", tz="UTC").to_pydatetime()
        if _us_equity_closed_interval(previous_close, earliest_ts.to_pydatetime(), include_after_hours=extended):
            return previous_close
        # Thin symbols often have no print at the session open (XLK's first pre-market trade is
        # frequently 04:01 or later). If this page's window already reached back to the open of
        # the session holding the oldest bar, and IBKR did not cut the page at its point cap,
        # every bar that exists before the oldest bar in that session is already here.
        if page_start is None or page_was_capped:
            return None
        opens = np.concatenate(
            [
                _us_equity_session_bounds_for_year(year - 1, extended)[0],
                _us_equity_session_bounds_for_year(year, extended)[0],
            ]
        )
        open_idx = int(np.searchsorted(opens, earliest_ns, side="right")) - 1
        if open_idx < 0:
            return None
        session_open_ns = int(opens[open_idx])
        page_start_ts = pd.Timestamp(page_start)
        if page_start_ts.tzinfo is None:
            page_start_ts = page_start_ts.tz_localize("UTC")
        if int(page_start_ts.tz_convert("UTC").value) <= session_open_ns:
            return previous_close
        return None
    except Exception:
        return None


def _history_segment_already_attempted(runtime_key: str, seg_start: datetime, seg_end: datetime) -> bool:
    for attempted_start, attempted_end in _RUNTIME_ATTEMPTED_HISTORY_SEGMENTS.get(runtime_key, ()):
        if attempted_start <= seg_start and seg_end <= attempted_end:
            return True
    return False


def _remember_attempted_history_segment(runtime_key: str, seg_start: datetime, seg_end: datetime) -> None:
    segments = list(_RUNTIME_ATTEMPTED_HISTORY_SEGMENTS.get(runtime_key, ()))
    segments.append((seg_start, seg_end))
    segments.sort(key=lambda item: item[0])
    merged: list[Tuple[datetime, datetime]] = []
    for start, end in segments:
        if merged and start <= merged[-1][1]:
            merged[-1] = (merged[-1][0], max(merged[-1][1], end))
        else:
            merged.append((start, end))
    _RUNTIME_ATTEMPTED_HISTORY_SEGMENTS[runtime_key] = merged


@dataclass(frozen=True)
class IbkrConidKey:
    asset_type: str
    symbol: str
    quote_symbol: str
    exchange: str
    expiration: str

    def to_key(self) -> str:
        return "|".join(
            [
                self.asset_type or "",
                self.symbol or "",
                self.quote_symbol or "",
                self.exchange or "",
                self.expiration or "",
            ]
        )


def get_price_data(
    *,
    asset: Asset,
    quote: Optional[Asset],
    timestep: str,
    start_dt: datetime,
    end_dt: datetime,
    exchange: Optional[str] = None,
    include_after_hours: bool = True,
    source: Optional[str] = None,
    history_as_of: Optional[datetime] = None,
    equity_basis=None,
) -> pd.DataFrame:
    """Fetch IBKR historical bars (via the Data Downloader) and cache to parquet.

    This helper mirrors the ThetaData cache pattern:
    - local parquet under `LUMIBOT_CACHE_FOLDER/ibkr/...`
    - optional S3 mirroring via BacktestCacheManager
    - best-effort negative caching via `missing=True` placeholder rows (only for true NO_DATA)
    """
    # v4.5.1: defensive coercion. Callers occasionally hand us a bare string
    # symbol (observed in Alpha Picks 2026-04-19 local backtest: upstream code
    # path leaked a string through to this helper, producing misleading
    # "IBKR history fetch failed for None/USD ...: 'str' object has no
    # attribute 'symbol'" errors that obscured the real bug). Accepting a
    # string here is a one-line safety net that lets the rest of the pipeline
    # work, and the log message becomes accurate.
    if isinstance(asset, str):
        asset = Asset(symbol=asset)

    start_utc = _to_utc(start_dt)
    end_utc = _to_utc(end_dt)
    if start_utc > end_utc:
        start_utc, end_utc = end_utc, start_utc
    start_local = start_utc.astimezone(LUMIBOT_DEFAULT_PYTZ)
    end_local = end_utc.astimezone(LUMIBOT_DEFAULT_PYTZ)

    asset, history_alias = _alias_asset_for_ibkr_history(asset)
    if history_alias:
        alias_key = f"{history_alias}:{timestep}"
        if alias_key not in _LOGGED_HISTORY_ALIASES:
            logger.info("IBKR history symbol alias applied: %s", history_alias)
            _LOGGED_HISTORY_ALIASES.add(alias_key)

    asset_type = _normalize_asset_type(getattr(asset, "asset_type", ""))
    asset_auto_expiry = getattr(asset, "auto_expiry", None)
    if asset_type == "future" and getattr(asset, "expiration", None) is None and not asset_auto_expiry:
        raise ValueError(
            "IBKR futures require an explicit expiration on Asset(asset_type='future') unless "
            "`auto_expiry` is set. Use asset_type='cont_future' for continuous futures."
        )
    effective_exchange = exchange
    if asset_type in {"future", "cont_future"} and not effective_exchange:
        try:
            effective_exchange = _resolve_futures_exchange(getattr(asset, "symbol", ""))
        except IbkrFuturesExchangeAmbiguousError:
            raise
        except Exception as exc:
            fallback = (os.environ.get("IBKR_FUTURES_EXCHANGE") or IBKR_DEFAULT_FUTURES_EXCHANGE_FALLBACK).strip().upper()
            logger.warning(
                "IBKR futures exchange auto-resolution failed for %s: %s. Falling back to %s",
                getattr(asset, "symbol", None),
                exc,
                fallback,
            )
            effective_exchange = fallback
    if asset_type == "crypto" and not effective_exchange:
        effective_exchange = (os.environ.get("IBKR_CRYPTO_VENUE") or IBKR_DEFAULT_CRYPTO_VENUE).strip().upper()

    # Treat the env var as explicit too.
    #
    # WHY: If the user explicitly chooses a history source via env vars (for example `Trades`),
    # we must not silently derive/augment bid/ask from other sources because that would change
    # execution semantics in backtests.
    env_source_raw = os.environ.get("IBKR_HISTORY_SOURCE")
    env_source_was_explicit = False
    if env_source_raw is not None:
        trimmed = env_source_raw.strip()
        if trimmed and trimmed.lower() != "none":
            env_source_was_explicit = True

    source_was_explicit = source is not None or env_source_was_explicit
    history_source = _normalize_history_source(source)
    # IBKR index history is frequently unavailable with `Trades`. Force midpoint bars for index
    # requests unless a per-call source was explicitly provided.
    if source is None and asset_type == "index":
        history_source = IBKR_DEFAULT_INDEX_HISTORY_SOURCE
    # Listed option trades are sparse. Midpoint bars are the history that can
    # price a contract when the caller did not pick a source.
    if source is None and not env_source_was_explicit and asset_type == "option":
        history_source = "Midpoint"

    # Normalize timestep classification once so callers can pass "day", "1d", "1day", etc.
    try:
        _bar, _bar_seconds, timestep_component = _timestep_to_ibkr_bar(timestep)
    except Exception:
        timestep_component = _timestep_component(timestep)

    # Shared IBKR historical feeds can lag current time, including futures.
    # Asking through "now" makes a valid delayed page fail strict stale-tail
    # validation before older requested history can be fetched. Use the same
    # stable historical boundary for explicit and continuous futures as for
    # stocks/indexes; daily bars and real-time snapshot APIs remain separate.
    if asset_type in {"stock", "index", "future", "cont_future"} and not str(timestep_component).endswith("day"):
        latest_available = _to_utc(history_as_of or _ibkr_history_now_utc()) - IBKR_INTRADAY_HISTORY_DELAY
        if end_utc > latest_available:
            if start_utc >= latest_available:
                # This window is too recent to ask the historical feed. Do
                # not turn unavailable delayed bars into a durable absence.
                record_history_health(
                    symbol=str(getattr(asset, "symbol", "")), asset_type=asset_type,
                    timestep=str(timestep), requested_start=start_utc, requested_end=end_utc,
                    outcome=HistoryOutcome.PARTIAL, reason="delayed_history_window_unavailable",
                    series_id=_history_health_series_id(
                        asset=asset, quote=quote, timestep=timestep, exchange=effective_exchange,
                        source=history_source, include_after_hours=include_after_hours,
                    ),
                )
                return pd.DataFrame()
            end_utc = latest_available
            end_local = end_utc.astimezone(LUMIBOT_DEFAULT_PYTZ)

    # Continuous futures
    #
    # IMPORTANT (expired explicit futures support):
    # IBKR's Client Portal API does not reliably expose conids for *expired* futures contracts.
    # To backtest `cont_future` deterministically (and to support explicit expired contracts),
    # LumiBot uses a local conid registry (`ibkr/conids.json`) populated via a one-time TWS
    # backfill. `cont_future` data is stitched by resolving each contract month using LumiBot's
    # roll schedule (see `_resolve_cont_future_segments`), then fetching bars per-expiration.

    is_roll_wrapper = bool(
        asset_type == "cont_future"
        or (
            asset_type == "future"
            and getattr(asset, "expiration", None) is None
            and asset_auto_expiry
        )
    )

    # Cont-futures + Auto-expiry futures
    #
    # Behavior: for IBKR we treat `Asset(asset_type='cont_future')` and
    # `Asset(asset_type='future', auto_expiry=...)` as synthetic roll wrappers.
    #
    # Rationale: backtests must match live semantics and must not depend on `date.today()` for
    # selecting a contract month.
    if is_roll_wrapper:
        segments = _resolve_cont_future_segments(asset=asset, start_dt=start_utc, end_dt=end_utc,
                                                exchange=effective_exchange, timestep=timestep)
        if not segments:
            logger.error(
                "IBKR futures roll wrapper could not resolve any roll segments for %s (type=%s exchange=%s). Returning empty bars.",
                getattr(asset, "symbol", None),
                asset_type,
                effective_exchange,
            )
            return pd.DataFrame()
        # Ensure the *user-facing* cont_future asset (used in orders/positions) carries the
        # correct contract metadata (multiplier/min_tick). Otherwise PnL and tick rounding will
        # be wrong even if we fetch bars for the right underlying expirations.
        #
        # We copy metadata from the first roll segment, since multiplier/minTick are stable
        # across expirations for a given root (e.g., MES, ES).
        try:
            first_asset, _, _ = segments[0]
            _maybe_apply_future_contract_metadata(asset=first_asset, exchange=effective_exchange)
            first_multiplier = getattr(first_asset, "multiplier", None)
            if first_multiplier not in (None, 0, 1):
                try:
                    asset.multiplier = first_multiplier  # type: ignore[assignment]
                except Exception:
                    pass
            first_min_tick = getattr(first_asset, "min_tick", None)
            if first_min_tick not in (None, 0):
                try:
                    setattr(asset, "min_tick", first_min_tick)
                except Exception:
                    pass
        except Exception:
            pass

        frames: list[pd.DataFrame] = []
        for i, (seg_asset, seg_start, seg_end) in enumerate(segments):
            # Clamp each segment to the requested window.
            seg_start = _to_utc(seg_start)
            seg_end = _to_utc(seg_end)

            # IMPORTANT: `Strategy.get_last_price()` is evaluated at bar boundaries, and our
            # futures backtesting semantics treat "last price at dt" as the last completed bar
            # (i.e., previous bar close).
            #
            # At roll boundaries, the *first* bar of the new contract often occurs exactly one
            # minute before the roll trigger (`roll_dt + 1 minute` in `futures_roll`), so the
            # previous-bar lookup at the roll timestamp needs the new contract's final pre-roll
            # minute available.
            #
            # Fix: for every segment after the first, widen the fetch window by 1 minute on the
            # left so the stitched series contains that preceding bar. We rely on "keep=last"
            # de-duping so the newer contract overrides overlaps deterministically.
            if i > 0:
                seg_start = seg_start - timedelta(minutes=1)

            seg_start = max(seg_start, start_utc)
            seg_end = min(_to_utc(seg_end), end_utc)
            if seg_start >= seg_end:
                continue
            df_seg = get_price_data(
                asset=seg_asset,
                quote=quote,
                timestep=timestep,
                start_dt=seg_start,
                end_dt=seg_end,
                exchange=effective_exchange,
                include_after_hours=include_after_hours,
                source=source,
                history_as_of=history_as_of,
            )
            if df_seg is not None and not df_seg.empty:
                frames.append(df_seg)
        if not frames:
            return pd.DataFrame()
        stitched = pd.concat(frames, axis=0)
        stitched = stitched[~stitched.index.duplicated(keep="last")]
        stitched = stitched.sort_index()
        return stitched.loc[(stitched.index >= start_local) & (stitched.index <= end_local)]

    # IMPORTANT (IBKR crypto daily semantics):
    # IBKR's `bar=1d` history is not a clean midnight-to-midnight 24/7 day series for crypto.
    # Daily-cadence strategies in LumiBot typically advance the simulation clock at midnight in
    # the strategy timezone. If we treat IBKR daily bars as authoritative, the series often
    # "ends" at a non-midnight timestamp and can lag by days, which triggers Data.checker()
    # stale-end errors and repeated refreshes (extremely slow; looks like "missing BTC data").
    #
    # Fix: for crypto only, derive daily bars from intraday history and align them to midnight
    # buckets in `LUMIBOT_DEFAULT_PYTZ`.
    if asset_type == "crypto" and str(timestep_component).endswith("day"):
        return _get_crypto_daily_bars(
            asset=asset,
            quote=quote,
            start_dt=start_utc,
            end_dt=end_utc,
            exchange=effective_exchange,
            include_after_hours=include_after_hours,
            source=history_source,
        )

    if asset_type in {"future", "cont_future"} and str(timestep_component).endswith("day"):
        _maybe_apply_future_contract_metadata(asset=asset, exchange=effective_exchange)
        return _get_futures_daily_bars(
            asset=asset,
            quote=quote,
            start_dt=start_utc,
            end_dt=end_utc,
            exchange=effective_exchange,
            include_after_hours=include_after_hours,
            source=history_source,
        )

    if asset_type in {"future", "cont_future"}:
        _maybe_apply_future_contract_metadata(asset=asset, exchange=effective_exchange)

    if asset_type == "stock" and history_source == "Trades":
        current_basis = _get_current_equity_basis(str(asset.symbol))
        if equity_basis is not None and equity_basis.split_fingerprint != current_basis.split_fingerprint:
            raise RuntimeError("corporate_actions_unavailable: equity split basis changed during this run")
        equity_basis = equity_basis or current_basis

    cache_file = _cache_file_for(
        asset=asset,
        quote=quote,
        timestep=timestep,
        exchange=effective_exchange,
        source=history_source,
        include_after_hours=include_after_hours,
        equity_basis=equity_basis.split_fingerprint if equity_basis else None,
    )
    runtime_no_data_key = str(cache_file)
    cache_manager = get_backtest_cache()

    try:
        cache_manager.ensure_local_file(
            cache_file,
            payload=_remote_payload(
                asset,
                quote,
                timestep,
                effective_exchange,
                history_source,
                include_after_hours=include_after_hours,
            ),
        )
    except Exception:
        pass

    df_cache = _read_cache_frame(cache_file)
    if equity_basis is not None:
        df_cache = _verified_equity_cache(df_cache, equity_basis)
    # If this series came from a cached parquet (e.g., prefilled via TWS), it may not include the
    # synthetic bid/ask fallback columns that we add when decoding Client Portal history. For
    # non-explicit history sources, populate bid/ask from close so quote-based fill logic (and
    # SMART_LIMIT) remains functional without forcing extra history requests.
    if (
        not source_was_explicit
        and not df_cache.empty
        and "close" in df_cache.columns
        and (("bid" not in df_cache.columns) or ("ask" not in df_cache.columns))
    ):
        df_cache = df_cache.copy()
        close = pd.to_numeric(df_cache.get("close"), errors="coerce")

        if "bid" in df_cache.columns:
            bid = pd.to_numeric(df_cache.get("bid"), errors="coerce")
        else:
            bid = pd.Series(index=df_cache.index, dtype="float64")
        df_cache["bid"] = bid.where(~bid.isna(), close)

        if "ask" in df_cache.columns:
            ask = pd.to_numeric(df_cache.get("ask"), errors="coerce")
        else:
            ask = pd.Series(index=df_cache.index, dtype="float64")
        df_cache["ask"] = ask.where(~ask.isna(), close)
    if not df_cache.empty:
        coverage_start = df_cache.index.min()
        coverage_end = df_cache.index.max()
    else:
        coverage_start = None
        coverage_end = None

    # Detect disjoint cached segments.
    #
    # IBKR parquet caches (especially when hydrated from remote S3) can contain disjoint segments
    # where `coverage_start..coverage_end` spans a large range but the requested window is only
    # partially covered (or not covered near one boundary). If we only look at global min/max
    # coverage we can incorrectly treat a request as a cache hit and return empty/underfilled bars.
    window_slice = pd.DataFrame()
    window_cov_start = None
    window_cov_end = None
    try:
        if coverage_start is not None and coverage_end is not None:
            window_slice = df_cache.loc[(df_cache.index >= start_local) & (df_cache.index <= end_local)]
            if not window_slice.empty:
                window_cov_start = window_slice.index.min()
                window_cov_end = window_slice.index.max()
    except Exception:
        window_slice = pd.DataFrame()
        window_cov_start = None
        window_cov_end = None

    # IBKR history can legitimately omit the very last bar(s) of a window (e.g., missing the final
    # 1–2 minutes of the day). When this happens, repeatedly trying to "fill to the end" creates
    # unnecessary downloader traffic and can wedge CI acceptance runs.
    #
    # Treat the cached series as "good enough" if it's within 2 bars of the requested end.
    #
    # Futures also have an expected daily maintenance gap (~1 hour). If a request window begins
    # during a closed period and the cache starts at the next session open, do not try to fetch
    # the closed interval (it will return empty and can trigger retry loops).
    end_tolerance = timedelta(0)
    start_tolerance = timedelta(0)
    bar_step = timedelta(0)
    try:
        ibkr_bar, _, _ = _timestep_to_ibkr_bar(timestep)

        def _bar_delta(bar: str) -> timedelta:
            b = (bar or "").strip().lower()
            if b.endswith("min"):
                return timedelta(minutes=int(b.removesuffix("min") or "1"))
            if b.endswith("h"):
                return timedelta(hours=int(b.removesuffix("h") or "1"))
            if b.endswith("d"):
                return timedelta(days=int(b.removesuffix("d") or "1"))
            return timedelta(0)

        bar_step = _bar_delta(ibkr_bar)
        end_tolerance = bar_step * 3
        start_tolerance = bar_step * 3
        if asset_type in {"future", "cont_future"}:
            start_tolerance = max(start_tolerance, timedelta(hours=1))
    except Exception:
        end_tolerance = timedelta(0)
        start_tolerance = timedelta(0)
        bar_step = timedelta(0)

    window_start_gap_closed = (
        asset_type in {"future", "cont_future"}
        and window_cov_start is not None
        and start_local < window_cov_start
        and _us_futures_closed_interval(start_local, window_cov_start, bar_step=bar_step)
    )
    cache_start_gap_closed = (
        asset_type in {"future", "cont_future"}
        and coverage_start is not None
        and start_local < coverage_start
        and _us_futures_closed_interval(start_local, coverage_start, bar_step=bar_step)
    )
    window_end_gap_closed = (
        asset_type in {"future", "cont_future"}
        and window_cov_end is not None
        and end_local > window_cov_end
        and _us_futures_closed_interval(window_cov_end + bar_step, end_local)
    )
    cache_end_gap_closed = (
        asset_type in {"future", "cont_future"}
        and coverage_end is not None
        and end_local > coverage_end
        and _us_futures_closed_interval(coverage_end + bar_step, end_local)
    )

    # US stock intraday series have the same problem around weekends, exchange holidays and
    # the overnight break. A window that starts on a holiday or ends before the next session
    # opens (for example a backtest end clamped to "now" at 00:42 ET) leaves an uncovered edge
    # that contains no trading time. Fetching it only returns bars from outside the window,
    # so coverage never changes and every later call would ask again. Indexes keep the old
    # behavior because their calculation hours differ from the NYSE equity session.
    if asset_type == "stock" and bar_step > timedelta(0) and not str(timestep_component).endswith("day"):
        if window_cov_start is not None and start_local < window_cov_start:
            window_start_gap_closed = _us_equity_closed_interval(
                start_local, window_cov_start, include_after_hours=include_after_hours
            )
        if coverage_start is not None and start_local < coverage_start:
            cache_start_gap_closed = _us_equity_closed_interval(
                start_local, coverage_start, include_after_hours=include_after_hours
            )
        if window_cov_end is not None and end_local > window_cov_end:
            window_end_gap_closed = _us_equity_closed_interval(
                window_cov_end + bar_step, end_local, include_after_hours=include_after_hours
            )
        if coverage_end is not None and end_local > coverage_end:
            cache_end_gap_closed = _us_equity_closed_interval(
                coverage_end + bar_step, end_local, include_after_hours=include_after_hours
            )

    needs_fetch = (
        coverage_start is None
        or coverage_end is None
        # If the requested window has no rows at all (even though the overall cache has a broad
        # min/max range), treat it as a cache miss and fetch that specific segment.
        or (coverage_start is not None and coverage_end is not None and window_slice.empty)
        # Missing coverage near the requested boundaries (disjoint segments within the window).
        or (
            window_cov_start is not None
            and start_local < window_cov_start
            and not window_start_gap_closed
            and (start_tolerance <= timedelta(0) or (window_cov_start - start_local) > start_tolerance)
        )
        or (
            window_cov_end is not None
            and end_local > window_cov_end
            and not window_end_gap_closed
            and (end_tolerance <= timedelta(0) or (end_local - window_cov_end) > end_tolerance)
        )
        or (
            coverage_start is not None
            and start_local < coverage_start
            and not cache_start_gap_closed
            and (start_tolerance <= timedelta(0) or (coverage_start - start_local) > start_tolerance)
        )
        or (
            end_local > coverage_end
            and not cache_end_gap_closed
            and (end_tolerance <= timedelta(0) or (end_local - coverage_end) > end_tolerance)
        )
    )
    blocked_window = _RUNTIME_HISTORY_NO_DATA_WINDOWS.get(runtime_no_data_key)
    if blocked_window is not None:
        blocked_start, blocked_end = blocked_window
        if start_utc >= blocked_start and end_utc <= blocked_end:
            needs_fetch = False
    # Persisted confirmed-no-data suppression. Legacy, ambiguous, and expired
    # markers remain retryable across processes.
    if needs_fetch and _window_is_placeholder_covered(df_cache, start_local=start_local, end_local=end_local):
        needs_fetch = False

    # Opt-in trace: log why we decided to hit the network, so we can audit measured-pass cache misses.
    if needs_fetch and os.environ.get("LUMIBOT_CACHE_MISS_DEBUG"):
        try:
            logger.warning(
                "[CACHE_MISS] %s %s ts=%s start_local=%s end_local=%s cov_start=%s cov_end=%s "
                "win_cov_start=%s win_cov_end=%s win_empty=%s start_tol=%s end_tol=%s "
                "win_start_gap_closed=%s win_end_gap_closed=%s cache_start_gap_closed=%s cache_end_gap_closed=%s",
                getattr(asset, "symbol", None),
                asset_type,
                timestep,
                start_local,
                end_local,
                coverage_start,
                coverage_end,
                window_cov_start,
                window_cov_end,
                bool(window_slice.empty) if coverage_start is not None else None,
                start_tolerance,
                end_tolerance,
                window_start_gap_closed,
                window_end_gap_closed,
                cache_start_gap_closed,
                cache_end_gap_closed,
            )
        except Exception:
            pass

    if needs_fetch:
        segments: list[tuple[datetime, datetime]] = []
        if coverage_start is None or coverage_end is None or window_slice.empty:
            segments.append((start_utc, end_utc))
        else:
            # Prefer window-local coverage for disjoint-segment detection.
            effective_start = window_cov_start or coverage_start
            effective_end = window_cov_end or coverage_end

            # If the requested window has no overlap with the cached window, do NOT try to "bridge"
            # the gap. Fetch exactly the requested window and merge it into the cache as a disjoint
            # segment. Bridging can turn a 1-hour request into months of downloads.
            if end_local < effective_start or start_local > effective_end:
                segments.append((start_utc, end_utc))
            else:
                if effective_start is not None and start_local < effective_start:
                    segments.append((start_utc, effective_start.astimezone(timezone.utc)))
                if effective_end is not None and end_local > effective_end:
                    segments.append((effective_end.astimezone(timezone.utc), end_utc))

        for seg_start, seg_end in segments:
            if seg_start >= seg_end:
                continue
            if _history_segment_already_attempted(runtime_no_data_key, seg_start, seg_end):
                # Same (or a narrower) segment was already requested in this process and the
                # answer did not fill it. Asking again returns the same answer; serve the real
                # cached bars instead.
                logger.debug(
                    "IBKR history segment already requested this run for %s timestep=%s: %s -> %s",
                    getattr(asset, "symbol", None),
                    timestep,
                    seg_start,
                    seg_end,
                )
                continue
            _remember_attempted_history_segment(runtime_no_data_key, seg_start, seg_end)
            checkpoint_state = {"frame": df_cache}

            def _checkpoint_pages(pages: pd.DataFrame, _state=checkpoint_state) -> None:
                merged_so_far = _merge_frames(_state["frame"], pages)
                published = _write_cache_frame(cache_file, merged_so_far)
                _state["frame"] = merged_so_far if published is None else published

            try:
                fetched = _fetch_history_between_dates(
                    asset=asset,
                    quote=quote,
                    timestep=timestep,
                    start_dt=seg_start,
                    end_dt=seg_end,
                    exchange=effective_exchange,
                    include_after_hours=include_after_hours,
                    source=history_source,
                    source_was_explicit=source_was_explicit,
                    _page_checkpoint=_checkpoint_pages,
                )
            except Exception as exc:
                df_cache = checkpoint_state["frame"]
                # Avoid crashing the entire backtest on entitlement/session issues. Return an empty
                # frame so strategies can continue with a loud error in logs.
                logger.error(
                    "IBKR history fetch failed for %s/%s timestep=%s exchange=%s source=%s: %s",
                    getattr(asset, "symbol", None),
                    getattr(quote, "symbol", None) if quote else None,
                    timestep,
                    effective_exchange,
                    history_source,
                    exc,
                )
                classification = classify_history_failure(exc)
                # Every failed window receives an in-process cooldown. This preserves the
                # zero-repeat-call speed invariant without teaching a later process that a
                # transient or partial response means the data does not exist.
                try:
                    existing_block = _RUNTIME_HISTORY_NO_DATA_WINDOWS.get(runtime_no_data_key)
                    if existing_block is None:
                        _RUNTIME_HISTORY_NO_DATA_WINDOWS[runtime_no_data_key] = (start_utc, end_utc)
                    else:
                        _RUNTIME_HISTORY_NO_DATA_WINDOWS[runtime_no_data_key] = (
                            min(existing_block[0], start_utc),
                            max(existing_block[1], end_utc),
                        )
                    record_history_health(
                        series_id=_history_health_series_id(asset=asset, quote=quote, timestep=timestep,
                            exchange=effective_exchange, source=history_source, include_after_hours=include_after_hours),
                        symbol=str(getattr(asset, "symbol", "") or ""),
                        asset_type=asset_type,
                        timestep=timestep,
                        requested_start=start_utc,
                        requested_end=end_utc,
                        outcome=classification.outcome,
                        transient_failures=(
                            0
                            if classification.outcome is HistoryOutcome.CONFIRMED_NO_DATA
                            else 1
                        ),
                        reason=classification.reason,
                        details=classification.details,
                        event_id=(classification.details or {}).get("request_id"),
                    )
                except Exception:
                    pass

                if classification.persist_negative_cache:
                    try:
                        _record_missing_window(
                            asset=asset,
                            quote=quote,
                            timestep=timestep,
                            exchange=effective_exchange,
                            source=history_source,
                            include_after_hours=include_after_hours,
                            # Mark the whole requested window for this get_price_data call so
                            # subsequent iterations don't re-submit near-identical failing slices.
                            start_dt=_to_utc(start_utc),
                            end_dt=_to_utc(end_utc),
                            reason=classification.reason,
                            outcome=classification.outcome,
                            equity_basis=equity_basis.split_fingerprint if equity_basis else None,
                        )
                        # Reload to include the newly written missing markers.
                        df_cache = _read_cache_frame(cache_file)
                    except Exception:
                        pass
                fetched = pd.DataFrame()
                if classification.persist_negative_cache:
                    # No-data terminal errors are not recoverable by trying more segments in the
                    # same iteration/window.
                    break
                # This fetch already recorded its precise cause. An empty-frame
                # follow-up would overwrite it and count the same failure twice.
                continue
            # A conflict merge can add remote-only rows during checkpoint writes.
            # Carry that durable coverage into the final write, not the stale
            # frame captured before paging started.
            df_cache = checkpoint_state["frame"]
            if fetched is None or fetched.empty:
                # Empty payloads are ambiguous in IBKR. Cool down this process, but do not
                # persist a cross-process negative marker.
                existing_block = _RUNTIME_HISTORY_NO_DATA_WINDOWS.get(runtime_no_data_key)
                if existing_block is None:
                    _RUNTIME_HISTORY_NO_DATA_WINDOWS[runtime_no_data_key] = (start_utc, end_utc)
                else:
                    _RUNTIME_HISTORY_NO_DATA_WINDOWS[runtime_no_data_key] = (
                        min(existing_block[0], start_utc),
                        max(existing_block[1], end_utc),
                    )
                record_history_health(
                    series_id=_history_health_series_id(asset=asset, quote=quote, timestep=timestep,
                        exchange=effective_exchange, source=history_source, include_after_hours=include_after_hours),
                    symbol=str(getattr(asset, "symbol", "") or ""),
                    asset_type=asset_type,
                    timestep=timestep,
                    requested_start=start_utc,
                    requested_end=end_utc,
                    outcome=HistoryOutcome.PARTIAL,
                    transient_failures=1,
                    reason="empty_history_payload",
                )
                continue
            if fetched is not None and not fetched.empty:
                merged = _merge_frames(df_cache, fetched)
                published = _write_cache_frame(cache_file, merged)
                if published is not None:
                    merged = published
                df_cache = merged
                # Older positive bars do not establish that the requested tail
                # has no data. Segment-attempt tracking already bounds repeated
                # calls; only explicit NO_DATA may persist a negative window.

    if (
        not df_cache.empty
        and asset_type in {"stock", "index"}
        and str(timestep_component).endswith("day")
    ):
        df_cache = _repair_us_stock_index_daily_gaps(
            df_cache,
            cache_file=cache_file,
            asset=asset,
            quote=quote,
            timestep=timestep,
            start_dt=start_utc,
            end_dt=end_utc,
            exchange=effective_exchange,
            include_after_hours=include_after_hours,
            source=history_source,
            source_was_explicit=source_was_explicit,
        )
    elif (
        not df_cache.empty
        and asset_type in {"stock", "index"}
        and str(timestep_component).endswith("hour")
    ):
        df_cache = _repair_us_stock_index_hourly_gaps(
            df_cache,
            cache_file=cache_file,
            asset=asset,
            quote=quote,
            timestep=timestep,
            start_dt=start_utc,
            end_dt=end_utc,
            exchange=effective_exchange,
            include_after_hours=include_after_hours,
            source=history_source,
            source_was_explicit=source_was_explicit,
        )

    elif (
        not df_cache.empty
        and asset_type in {"stock", "index"}
        and str(timestep_component).endswith("minute")
    ):
        df_cache = _repair_us_stock_index_minute_gaps(
            df_cache,
            cache_file=cache_file,
            asset=asset,
            quote=quote,
            timestep=timestep,
            start_dt=start_utc,
            end_dt=end_utc,
            exchange=effective_exchange,
            include_after_hours=include_after_hours,
            source=history_source,
            source_was_explicit=source_was_explicit,
        )

    if df_cache.empty:
        return df_cache

    # Best-effort: derive actionable bid/ask quotes for crypto *minute* bars so quote-based fills
    # behave realistically (buy at ask, sell at bid). IBKR history does not return separate
    # bid/ask fields, so we reconstruct them from Bid_Ask + Midpoint when needed.
    #
    # IMPORTANT (performance): do not do this for daily series (and avoid doing it for large
    # multi-month windows unless required) because it multiplies request volume.
    if (not source_was_explicit) and asset_type == "crypto" and str(timestep_component).endswith("minute"):
        df_aug, changed = _maybe_augment_crypto_bid_ask(
            df_cache=df_cache,
            asset=asset,
            quote=quote,
            timestep=timestep,
            start_dt=start_utc,
            end_dt=end_utc,
            exchange=effective_exchange,
            include_after_hours=include_after_hours,
        )
        if changed:
            published = _write_cache_frame(cache_file, df_aug)
            if published is not None:
                df_aug = published
            df_cache = df_aug

    if (
        _enable_futures_bid_ask_derivation()
        and (not source_was_explicit)
        and asset_type in {"future", "cont_future"}
        and str(timestep_component).endswith(("minute", "hour"))
    ):
        df_aug, changed = _maybe_augment_futures_bid_ask(
            df_cache=df_cache,
            asset=asset,
            quote=quote,
            timestep=timestep,
            start_dt=start_utc,
            end_dt=end_utc,
            exchange=effective_exchange,
            include_after_hours=include_after_hours,
        )
        if changed:
            published = _write_cache_frame(cache_file, df_aug)
            if published is not None:
                df_aug = published
            df_cache = df_aug

    if asset_type in {"stock", "index", "option"} and str(timestep_component).endswith("day"):
        # Align cached daily bars to session close BEFORE slicing by [start_local, end_local].
        # This avoids same-day lookahead at market open when IBKR timestamps day bars near
        # session open/midnight boundaries.
        aligned_cache = _align_stock_index_daily_to_session_close(df_cache)
        if not aligned_cache.index.equals(df_cache.index):
            published = _write_cache_frame(cache_file, aligned_cache)
            if published is not None:
                aligned_cache = published
        df_cache = aligned_cache

    actions_changed = False
    # Enrich daily equity cache with corporate actions so dividend accounting and splits are
    # consistent with other providers. Unknown actions must not become zero events.
    if equity_basis is not None and str(timestep_component).endswith("day"):
        enriched_cache, actions_changed = _append_equity_corporate_actions_daily(
            df_cache, asset, actions=equity_basis.actions_frame())
        df_cache = enriched_cache
    if equity_basis is not None:
        from lumibot.tools.ibkr_equity_basis import assert_same_basis, decorate_adjusted_frame
        expected_basis = decorate_adjusted_frame(pd.DataFrame(), equity_basis, provider_prices_verified=True)
        assert_same_basis(df_cache, expected_basis)
        df_cache = decorate_adjusted_frame(df_cache, equity_basis, provider_prices_verified=True)
        if actions_changed:
            published = _write_cache_frame(cache_file, df_cache)
            if published is not None:
                df_cache = published

    # Remove placeholder rows from the returned frame (but keep them in cache).
    frame = df_cache.loc[(df_cache.index >= start_local) & (df_cache.index <= end_local)].copy()
    if "missing" in frame.columns:
        # `astype(bool)`: after merges the flag can be object dtype, where `~` would be an
        # integer bitwise NOT instead of a boolean mask.
        frame = frame[~frame["missing"].fillna(False).astype(bool)]
    frame = _strip_missing_cache_metadata(frame)
    placeholder_covered = _window_is_placeholder_covered(df_cache, start_local=start_local, end_local=end_local)
    if not frame.empty:
        try:
            covers_requested_window = frame_covers_requested_window(
                frame,
                asset=asset,
                timestep=timestep,
                start_dt=start_utc,
                end_dt=end_utc,
            )
        except Exception:
            covers_requested_window = False
        if not covers_requested_window:
            logger.warning(
                "IBKR cached history remained underfilled after refresh for %s/%s timestep=%s exchange=%s source=%s; "
                "returning available real bars instead of synthesizing an empty dataset "
                "(placeholder_covered=%s)",
                getattr(asset, "symbol", None),
                getattr(quote, "symbol", None) if quote else None,
                timestep,
                effective_exchange,
                history_source,
                placeholder_covered,
            )
    elif placeholder_covered:
        return frame
    return frame


def _frame_has_actionable_bid_ask(df: pd.DataFrame) -> bool:
    if df is None or df.empty:
        return False
    if "bid" not in df.columns or "ask" not in df.columns:
        return False
    bid = pd.to_numeric(df["bid"], errors="coerce")
    ask = pd.to_numeric(df["ask"], errors="coerce")
    spread = ask - bid
    return bool((spread > 0).any())


def _align_stock_index_daily_to_session_close(df: pd.DataFrame) -> pd.DataFrame:
    """Normalize IBKR stock/index daily timestamps to the session close.

    Why:
    - REST day bars can carry a pre-market timestamp; TWS date labels are normalized
      separately before reaching this function.
    - Daily backtests that run at market open can then incorrectly treat the current session's
      bar as already available.
    - Re-indexing day bars to 16:00 ET aligns them with end-of-session semantics used by
      other providers (for example ThetaData day bars at 21:00 UTC in winter).
    """
    if df is None or df.empty:
        return df

    frame = df.sort_index().copy()
    idx = pd.DatetimeIndex(frame.index)
    if idx.tz is None:
        idx = idx.tz_localize(LUMIBOT_DEFAULT_PYTZ)
    else:
        idx = idx.tz_convert(LUMIBOT_DEFAULT_PYTZ)

    aligned_idx = idx.normalize() + pd.Timedelta(hours=16)
    frame.index = aligned_idx
    return _merge_frames(pd.DataFrame(), frame)


def _normalize_split_ratio(value: Any) -> Optional[float]:
    try:
        ratio = float(value)
    except (TypeError, ValueError):
        return None
    if not math.isfinite(ratio) or ratio <= 0 or math.isclose(ratio, 1.0):
        return None
    return ratio


def _normalize_equity_daily_prices_for_splits(frame: pd.DataFrame) -> tuple[pd.DataFrame, bool]:
    """Preserve qualified adjusted provider prices; never infer a split from shape."""
    if frame is None or frame.empty:
        return frame, False
    if "_ibkr_split_basis" not in frame or "_split_adjusted" not in frame or not frame["_split_adjusted"].fillna(False).eq(True).all():
        raise ValueError("IBKR equity adjustment basis is unverified; reload qualified provider prices")
    from lumibot.tools.ibkr_equity_basis import assert_same_basis
    assert_same_basis(frame, frame)
    return frame, False


def _resolve_cont_future_segments(*, asset: Asset, start_dt: datetime, end_dt: datetime,
                                  exchange: Optional[str], timestep: str = "day") -> list[tuple[Asset, datetime, datetime]]:
    """Resolve a `cont_future` asset into a list of explicit futures contract segments.

    This follows LumiBot's roll schedule (`lumibot.tools.futures_roll`) so that backtests
    match live broker semantics and remain consistent across backtesting environments.
    """
    try:
        from lumibot.tools import futures_roll
    except Exception:
        return []

    start_utc = _to_utc(start_dt)
    end_utc = _to_utc(end_dt)
    if start_utc > end_utc:
        start_utc, end_utc = end_utc, start_utc

    try:
        schedule = futures_roll.build_roll_schedule(asset, start_utc, end_utc, year_digits=2)
    except Exception:
        schedule = []
    if not schedule:
        return []

    segments: list[tuple[Asset, datetime, datetime]] = []
    for contract_symbol, seg_start, seg_end in schedule:
        year, month = _parse_contract_year_month(contract_symbol)
        expiration = _contract_expiration_date(asset.symbol, year=year, month=month)
        contract_asset = Asset(asset.symbol, asset_type=Asset.AssetType.FUTURE, expiration=expiration)
        # Validate that we can resolve an explicit conid for this contract month.
        try:
            _resolve_conid(asset=contract_asset, quote=None, exchange=exchange)
        except Exception as exc:
            # Do not crash the whole backtest because one contract month cannot resolve.
            #
            # This most commonly happens when:
            # - The root symbol is invalid (no contracts returned), or
            # - IBKR cannot discover a conid for an expired contract month via Client Portal.
            logger.error(
                "IBKR roll segment conid resolution failed for %s %s (%s): %s",
                getattr(asset, "symbol", None),
                expiration,
                contract_symbol,
                exc,
            )
            record_history_health(
                symbol=asset.symbol, asset_type=_normalize_asset_type(asset.asset_type), timestep=timestep,
                requested_start=max(start_utc, _to_utc(seg_start)),
                requested_end=min(end_utc, _to_utc(seg_end)), outcome=HistoryOutcome.PARTIAL,
                reason="unresolved_roll_contract", series_id=f"{exchange or 'AUTO'}:{contract_symbol}",
                transient_failures=1,
            )
            continue
        resolved_expiration = _expiration_date_only(getattr(contract_asset, "_ibkr_resolved_expiration", None))
        if resolved_expiration is not None and resolved_expiration != expiration:
            logger.warning(
                "IBKR roll segment %s computed expiration %s but IBKR lists %s; using listed expiration for history fetches.",
                contract_symbol,
                expiration,
                resolved_expiration,
            )
            contract_asset = Asset(asset.symbol, asset_type=Asset.AssetType.FUTURE, expiration=resolved_expiration)
        segments.append((contract_asset, _to_utc(seg_start), _to_utc(seg_end)))
    return segments


def _parse_contract_year_month(contract_symbol: str) -> tuple[int, int]:
    """Parse a futures contract symbol (e.g., MESZ25) into (year, month)."""
    symbol = (contract_symbol or "").strip().upper()
    if len(symbol) < 3:
        raise ValueError(f"Invalid contract symbol: {contract_symbol!r}")

    month_code = symbol[-3:-2]
    year_text = symbol[-2:]
    try:
        year_two = int(year_text)
    except Exception as exc:
        raise ValueError(f"Invalid futures year in {contract_symbol!r}") from exc

    # Assumption: 20xx is the relevant range for our backtests.
    year = 2000 + year_two

    try:
        from lumibot.tools import futures_roll

        reverse = {v: k for k, v in getattr(futures_roll, "_FUTURES_MONTH_CODES", {}).items()}
    except Exception:
        reverse = {"H": 3, "M": 6, "U": 9, "Z": 12}

    month = reverse.get(month_code)
    if month is None:
        raise ValueError(f"Invalid futures month code {month_code!r} in {contract_symbol!r}")
    return year, int(month)


def _contract_expiration_date(root_symbol: str, *, year: int, month: int):
    """Best-effort expiration date for a futures contract based on the roll rules."""
    try:
        from lumibot.tools import futures_roll

        rule = futures_roll.ROLL_RULES.get(str(root_symbol).upper())
        anchor = getattr(rule, "anchor", None) if rule else None

        if anchor == "third_last_business_day":
            expiry = futures_roll._third_last_business_day(year, month)
        elif anchor == "last_friday":
            expiry = futures_roll._last_friday_trading_day(year, month)
        elif anchor == "cl_last_trade":
            expiry = futures_roll._cl_last_trade_date(year, month)
        elif anchor == "mcl_last_trade":
            expiry = futures_roll._mcl_last_trade_date(year, month)
        elif anchor == "ng_last_trade":
            expiry = futures_roll._ng_last_trade_date(year, month)
        else:
            # Default anchor for CME equity index futures is third Friday.
            expiry = futures_roll._third_friday(year, month)
        return expiry.date()
    except Exception:
        # Safe fallback: third Friday.
        from datetime import date, timedelta

        first = date(year, month, 1)
        days_until_friday = (4 - first.weekday()) % 7
        first_friday = first + timedelta(days=days_until_friday)
        third_friday = first_friday + timedelta(days=14)
        return third_friday


def _strip_missing_cache_metadata(frame: pd.DataFrame) -> pd.DataFrame:
    """Remove cache-only placeholder fields before bars reach strategy code."""

    return frame.drop(
        columns=[
            "missing",
            "missing_retry_after",
            "missing_reason",
            "missing_outcome",
        ],
        errors="ignore",
    )


def _get_cached_bars_for_source(
    *,
    asset: Asset,
    quote: Optional[Asset],
    timestep: str,
    start_dt: datetime,
    end_dt: datetime,
    exchange: Optional[str],
    include_after_hours: bool,
    source: str,
) -> pd.DataFrame:
    start_utc = _to_utc(start_dt)
    end_utc = _to_utc(end_dt)
    if start_utc > end_utc:
        start_utc, end_utc = end_utc, start_utc
    start_local = start_utc.astimezone(LUMIBOT_DEFAULT_PYTZ)
    end_local = end_utc.astimezone(LUMIBOT_DEFAULT_PYTZ)

    history_source = _normalize_history_source(source)
    equity_basis = _get_current_equity_basis(str(asset.symbol)) if _normalize_asset_type(asset.asset_type) == "stock" and history_source == "Trades" else None
    cache_file = _cache_file_for(
        asset=asset,
        quote=quote,
        timestep=timestep,
        exchange=exchange,
        source=history_source,
        include_after_hours=include_after_hours,
        equity_basis=equity_basis.split_fingerprint if equity_basis else None,
    )
    cache_manager = get_backtest_cache()
    try:
        cache_manager.ensure_local_file(
            cache_file,
            payload=_remote_payload(
                asset,
                quote,
                timestep,
                exchange,
                history_source,
                include_after_hours=include_after_hours,
            ),
        )
    except Exception:
        pass

    df_cache = _read_cache_frame(cache_file)
    if equity_basis is not None:
        df_cache = _verified_equity_cache(df_cache, equity_basis)
    if not df_cache.empty:
        coverage_start = df_cache.index.min()
        coverage_end = df_cache.index.max()
    else:
        coverage_start = None
        coverage_end = None

    end_tolerance = timedelta(0)
    try:
        ibkr_bar, _, _ = _timestep_to_ibkr_bar(timestep)

        def _bar_delta(bar: str) -> timedelta:
            b = (bar or "").strip().lower()
            if b.endswith("min"):
                return timedelta(minutes=int(b.removesuffix("min") or "1"))
            if b.endswith("h"):
                return timedelta(hours=int(b.removesuffix("h") or "1"))
            if b.endswith("d"):
                return timedelta(days=int(b.removesuffix("d") or "1"))
            return timedelta(0)

        end_tolerance = _bar_delta(ibkr_bar) * 3
    except Exception:
        end_tolerance = timedelta(0)

    needs_fetch = (
        coverage_start is None
        or coverage_end is None
        or start_local < coverage_start
        or (end_local > coverage_end and (end_tolerance <= timedelta(0) or (end_local - coverage_end) > end_tolerance))
    )

    if needs_fetch:
        segments: list[tuple[datetime, datetime]] = []
        if coverage_start is None or coverage_end is None:
            segments.append((start_utc, end_utc))
        else:
            if end_local < coverage_start or start_local > coverage_end:
                segments.append((start_utc, end_utc))
            else:
                if start_local < coverage_start:
                    segments.append((start_utc, coverage_start.astimezone(timezone.utc)))
                if end_local > coverage_end:
                    segments.append((coverage_end.astimezone(timezone.utc), end_utc))

        for seg_start, seg_end in segments:
            if seg_start >= seg_end:
                continue
            try:
                fetched = _fetch_history_between_dates(
                    asset=asset,
                    quote=quote,
                    timestep=timestep,
                    start_dt=seg_start,
                    end_dt=seg_end,
                    exchange=exchange,
                    include_after_hours=include_after_hours,
                    source=history_source,
                    source_was_explicit=True,
                )
            except Exception as exc:
                logger.error(
                    "IBKR history fetch failed for %s/%s timestep=%s exchange=%s source=%s: %s",
                    getattr(asset, "symbol", None),
                    getattr(quote, "symbol", None) if quote else None,
                    timestep,
                    exchange,
                    history_source,
                    exc,
                )
                fetched = pd.DataFrame()
            if fetched is not None and not fetched.empty:
                merged = _merge_frames(df_cache, fetched)
                published = _write_cache_frame(cache_file, merged)
                if published is not None:
                    merged = published
                df_cache = merged
                # Older bars are available data, not confirmation that the
                # newer requested interval is empty. Keep that tail retryable.

    if df_cache.empty:
        return df_cache

    frame = df_cache.loc[(df_cache.index >= start_local) & (df_cache.index <= end_local)].copy()
    if "missing" in frame.columns:
        frame = frame[~frame["missing"].fillna(False)]
    return _strip_missing_cache_metadata(frame)


def _maybe_augment_crypto_bid_ask(
    *,
    df_cache: pd.DataFrame,
    asset: Asset,
    quote: Optional[Asset],
    timestep: str,
    start_dt: datetime,
    end_dt: datetime,
    exchange: Optional[str],
    include_after_hours: bool,
) -> tuple[pd.DataFrame, bool]:
    if df_cache is None or df_cache.empty:
        return df_cache, False
    if _frame_has_actionable_bid_ask(df_cache):
        return df_cache, False

    try:
        bid_ask = _get_cached_bars_for_source(
            asset=asset,
            quote=quote,
            timestep=timestep,
            start_dt=start_dt,
            end_dt=end_dt,
            exchange=exchange,
            include_after_hours=include_after_hours,
            source="Bid_Ask",
        )
        midpoint = _get_cached_bars_for_source(
            asset=asset,
            quote=quote,
            timestep=timestep,
            start_dt=start_dt,
            end_dt=end_dt,
            exchange=exchange,
            include_after_hours=include_after_hours,
            source="Midpoint",
        )
    except Exception:
        return df_cache, False

    derived = _derive_bid_ask_from_bid_ask_and_midpoint(bid_ask, midpoint)
    if derived is None or derived.empty:
        return df_cache, False

    updated = df_cache.copy()
    updated.loc[derived.index, "bid"] = derived["bid"]
    updated.loc[derived.index, "ask"] = derived["ask"]

    # Any residual NaNs fall back to the trade/mark close.
    if "close" in updated.columns:
        updated["bid"] = pd.to_numeric(updated.get("bid"), errors="coerce").where(
            ~pd.to_numeric(updated.get("bid"), errors="coerce").isna(),
            pd.to_numeric(updated.get("close"), errors="coerce"),
        )
        updated["ask"] = pd.to_numeric(updated.get("ask"), errors="coerce").where(
            ~pd.to_numeric(updated.get("ask"), errors="coerce").isna(),
            pd.to_numeric(updated.get("close"), errors="coerce"),
        )

    if not _frame_has_actionable_bid_ask(updated):
        return df_cache, False

    return updated, True


def _maybe_augment_futures_bid_ask(
    *,
    df_cache: pd.DataFrame,
    asset: Asset,
    quote: Optional[Asset],
    timestep: str,
    start_dt: datetime,
    end_dt: datetime,
    exchange: Optional[str],
    include_after_hours: bool,
) -> tuple[pd.DataFrame, bool]:
    if not _enable_futures_bid_ask_derivation():
        return df_cache, False
    if df_cache is None or df_cache.empty:
        return df_cache, False
    if _frame_has_actionable_bid_ask(df_cache):
        return df_cache, False

    try:
        bid_ask = _get_cached_bars_for_source(
            asset=asset,
            quote=quote,
            timestep=timestep,
            start_dt=start_dt,
            end_dt=end_dt,
            exchange=exchange,
            include_after_hours=include_after_hours,
            source="Bid_Ask",
        )
        midpoint = _get_cached_bars_for_source(
            asset=asset,
            quote=quote,
            timestep=timestep,
            start_dt=start_dt,
            end_dt=end_dt,
            exchange=exchange,
            include_after_hours=include_after_hours,
            source="Midpoint",
        )
    except Exception:
        return df_cache, False

    derived = _derive_bid_ask_from_bid_ask_and_midpoint(bid_ask, midpoint)
    if derived is None or derived.empty:
        return df_cache, False

    updated = df_cache.copy()
    updated.loc[derived.index, "bid"] = derived["bid"]
    updated.loc[derived.index, "ask"] = derived["ask"]

    if "close" in updated.columns:
        updated["bid"] = pd.to_numeric(updated.get("bid"), errors="coerce").where(
            ~pd.to_numeric(updated.get("bid"), errors="coerce").isna(),
            pd.to_numeric(updated.get("close"), errors="coerce"),
        )
        updated["ask"] = pd.to_numeric(updated.get("ask"), errors="coerce").where(
            ~pd.to_numeric(updated.get("ask"), errors="coerce").isna(),
            pd.to_numeric(updated.get("close"), errors="coerce"),
        )

    if not _frame_has_actionable_bid_ask(updated):
        return df_cache, False

    return updated, True


def _fetch_history_between_dates(
    *,
    asset: Asset,
    quote: Optional[Asset],
    timestep: str,
    start_dt: datetime,
    end_dt: datetime,
    exchange: Optional[str],
    include_after_hours: bool,
    source: str,
    source_was_explicit: bool,
    _period_override: Optional[str] = None,
    _record_missing_on_empty: bool = True,
    _queue_timeout: Optional[float] = None,
    _max_timeout_attempts: Optional[int] = None,
    _deadline_monotonic: Optional[float] = None,
    _page_checkpoint: Optional[Callable[[pd.DataFrame], None]] = None,
    _backend: Optional[str] = None,
) -> pd.DataFrame:
    conid = _resolve_conid(asset=asset, quote=quote, exchange=exchange)
    conid_refreshed = False
    bar, bar_seconds, _cache_timestep = _timestep_to_ibkr_bar(timestep)
    asset_type = _normalize_asset_type(getattr(asset, "asset_type", ""))
    equity_basis = _get_current_equity_basis(str(asset.symbol)) if asset_type == "stock" and _normalize_history_source(source) == "Trades" else None
    # IBKR's `continuous=true` is IBKR-specific roll behavior. For LumiBot `cont_future` assets
    # we prefer our own synthetic roll (explicit contract series per expiration) so parity is
    # stable across data providers. Only request IBKR "continuous" when we truly do not have an
    # explicit expiration to anchor the contract.
    continuous = bool(asset_type == "cont_future" and getattr(asset, "expiration", None) is None)
    period = _period_override or _history_period_for_request(
        asset_type=asset_type, bar=bar, source=source, requested_start=start_dt, requested_end=end_dt
    )

    cursor_end = _to_utc(end_dt)
    start_dt = _to_utc(start_dt)
    chunks: list[pd.DataFrame] = []
    closed_pages_skipped = 0
    futures_empty_open_pages = 0
    checkpointed_pages = 0
    paging_stalled = False

    # Opt-in trace: log every real network fetch + caller, to audit cache-miss root causes.
    if os.environ.get("LUMIBOT_CACHE_MISS_DEBUG"):
        try:
            import traceback
            stack = "".join(traceback.format_stack(limit=10)[:-1])
            logger.warning(
                "[FETCH] sym=%s type=%s ts=%s start=%s end=%s source=%s\n%s",
                getattr(asset, "symbol", None),
                asset_type,
                timestep,
                start_dt.isoformat(),
                end_dt.isoformat(),
                source,
                stack,
            )
        except Exception:
            pass

    # Fetch backwards (end -> start) to accommodate IBKR's 1000 datapoint cap.
    while cursor_end > start_dt:
        queue_timeout = _queue_timeout
        if _deadline_monotonic is not None:
            remaining = _deadline_monotonic - time.perf_counter()
            if remaining <= 0:
                if chunks:
                    break
                raise TimeoutError("IBKR history repair budget expired before the first page")
            queue_timeout = remaining if queue_timeout is None else min(queue_timeout, remaining)

        try:
            payload = _ibkr_history_request(
                conid=conid,
                period=period,
                bar=bar,
                start_time=_ibkr_page_request_end(cursor_end, bar_seconds, asset_type),
                exchange=exchange,
                include_after_hours=include_after_hours,
                continuous=continuous,
                source=source,
                queue_timeout=max(0.1, queue_timeout) if queue_timeout is not None else None,
                max_timeout_attempts=_max_timeout_attempts,
                **({"backend": _backend} if _backend else {}),
            )
        except Exception as exc:
            smaller_period = _smaller_daily_period_after_chart_unavailable(
                exc, asset_type=asset_type, bar=bar, period=period
            )
            if smaller_period is not None:
                period = smaller_period
                continue
            if chunks and asset_type in {"stock", "index"} and _is_chart_data_unavailable(exc):
                # The page reaches before the first bar IBKR holds. Keep the real bars
                # already collected instead of discarding the whole series.
                break
            classification = classify_history_failure(exc)
            if (
                not chunks
                and not conid_refreshed
                and classification.identity_related
                and asset_type in {"stock", "index"}
            ):
                try:
                    conid = _resolve_conid(
                        asset=asset,
                        quote=quote,
                        exchange=exchange,
                        force_refresh=True,
                    )
                except Exception as refresh_exc:
                    record_history_health(
                        series_id=_history_health_series_id(asset=asset, quote=quote, timestep=timestep,
                            exchange=exchange, source=source, include_after_hours=include_after_hours),
                        symbol=str(getattr(asset, "symbol", "") or ""),
                        asset_type=asset_type,
                        timestep=timestep,
                        requested_start=start_dt,
                        requested_end=_to_utc(end_dt),
                        outcome=classification.outcome,
                        conid_refreshes=1,
                        reason=classification.reason,
                    )
                    logger.warning(
                        "IBKR forced conid refresh failed for %s: %s",
                        getattr(asset, "symbol", None),
                        refresh_exc,
                    )
                    raise exc from refresh_exc
                conid_refreshed = True
                continue
            if conid_refreshed:
                record_history_health(
                    series_id=_history_health_series_id(asset=asset, quote=quote, timestep=timestep,
                        exchange=exchange, source=source, include_after_hours=include_after_hours),
                    symbol=str(getattr(asset, "symbol", "") or ""),
                    asset_type=asset_type,
                    timestep=timestep,
                    requested_start=start_dt,
                    requested_end=_to_utc(end_dt),
                    outcome=classification.outcome,
                    conid_refreshes=1,
                    reason=classification.reason,
                )
            if chunks:
                # A later (older) page failed. The newer pages are real bars: keep them
                # and stop paging instead of raising, which used to discard every page
                # already collected and leave the strategy with no bars at all. Nothing
                # is negatively cached, so the missing older part stays retryable.
                logger.warning(
                    "IBKR history paging for %s timestep=%s stopped at an older page (%s); keeping %d real bars "
                    "already collected back to %s",
                    getattr(asset, "symbol", None),
                    timestep,
                    classification.reason,
                    sum(len(chunk) for chunk in chunks),
                    min(chunk.index.min() for chunk in chunks),
                )
                break
            raise

        # IBKR typically returns {"data":[...]} (empty list means no data).
        data = payload.get("data") if isinstance(payload, dict) else None
        backend = str(_downloader_history_meta(payload).get("backend") or "").strip().lower()
        df = _history_payload_to_frame(
            data,
            source_was_explicit=source_was_explicit,
            volume_factor=validated_volume_factor(payload, asset_type, source),
            daily_session_dates_from_utc=(backend == "tws" and asset_type in {"stock", "index"} and bar.endswith("d")),
        ) if data else pd.DataFrame()
        if df.empty:
            skipped_to = _cursor_before_closed_equity_page(
                asset_type=asset_type,
                bar=bar,
                period=period,
                cursor_end=cursor_end,
                include_after_hours=include_after_hours,
            )
            if skipped_to is None:
                skipped_to = _cursor_before_closed_futures_page(
                    asset_type=asset_type, bar=bar, period=period, cursor_end=cursor_end
                )
            if skipped_to is not None:
                closed_pages_skipped += 1
                if closed_pages_skipped <= IBKR_MAX_CLOSED_PAGE_SKIPS and skipped_to > start_dt:
                    cursor_end = skipped_to
                    continue
            # Futures holiday closes (Good Friday, Christmas) are not in the simple CME rule
            # calendar, so their empty pages look like trading time. Step back one page, a few
            # times, before treating the empty answer as the start of history.
            if (
                chunks
                and asset_type in {"future", "cont_future"}
                and not (bar or "").strip().lower().endswith("d")
                and futures_empty_open_pages < IBKR_FUTURES_MAX_EMPTY_OPEN_PAGES
            ):
                page_span = _period_to_timedelta(period)
                if page_span is not None and cursor_end - page_span > start_dt:
                    futures_empty_open_pages += 1
                    cursor_end = cursor_end - page_span
                    continue
        if not data:
            # If we already fetched earlier chunks, keep them and stop paging.
            # CME weekend/maintenance gaps (Fri 4pm CT → Sun 5pm CT, nightly 4–5pm CT)
            # make a backward-paging window land in a no-trading range and return empty
            # even when the surrounding bars are valid. Raising here discards every
            # chunk we already collected and poisons the cache with a broad
            # missing-window marker — then every subsequent call for the same asset
            # takes the slow retry path. Break out with what we have.
            if chunks:
                break

            if conid_refreshed:
                record_history_health(
                    series_id=_history_health_series_id(asset=asset, quote=quote, timestep=timestep,
                        exchange=exchange, source=source, include_after_hours=include_after_hours),
                    symbol=str(getattr(asset, "symbol", "") or ""),
                    asset_type=asset_type,
                    timestep=timestep,
                    requested_start=start_dt,
                    requested_end=_to_utc(end_dt),
                    outcome=HistoryOutcome.CONFIRMED_NO_DATA,
                    conid_refreshes=1,
                    reason="confirmed_no_data_after_conid_refresh",
                )
            return pd.DataFrame()

        if df.empty:
            # Same rationale as the empty-data branch above: an intermediate empty
            # page during backward pagination must not discard earlier chunks.
            if chunks:
                break

            if conid_refreshed:
                record_history_health(
                    series_id=_history_health_series_id(asset=asset, quote=quote, timestep=timestep,
                        exchange=exchange, source=source, include_after_hours=include_after_hours),
                    symbol=str(getattr(asset, "symbol", "") or ""),
                    asset_type=asset_type,
                    timestep=timestep,
                    requested_start=start_dt,
                    requested_end=_to_utc(end_dt),
                    outcome=HistoryOutcome.CONFIRMED_NO_DATA,
                    conid_refreshes=1,
                    reason="confirmed_no_data_after_conid_refresh",
                )
            return pd.DataFrame()

        if equity_basis is not None:
            from lumibot.tools.ibkr_equity_basis import decorate_adjusted_frame
            if _get_current_equity_basis(str(asset.symbol)).split_fingerprint != equity_basis.split_fingerprint:
                raise RuntimeError("corporate_actions_unavailable: equity split basis changed during download")
            # Both configured historical equity TRADES routes supply split-adjusted
            # prices; volume normalization is independently validated at decoding.
            df = decorate_adjusted_frame(df, equity_basis, provider_prices_verified=True)
        chunks.append(df)
        futures_empty_open_pages = 0
        if _page_checkpoint is not None and len(chunks) - checkpointed_pages >= IBKR_PAGE_CHECKPOINT_EVERY:
            # Long cold walks take hours on the shared downloader. Hand the new pages to the
            # caller now so a stopped or timed-out run keeps its progress for the next run.
            try:
                _page_checkpoint(pd.concat(chunks[checkpointed_pages:], axis=0).sort_index())
                checkpointed_pages = len(chunks)
            except Exception:
                logger.debug("IBKR page checkpoint failed", exc_info=True)

        earliest = df.index.min()
        if earliest is None:
            break
        if earliest <= start_dt:
            break

        # Move cursor backwards.
        #
        # IBKR history bounds are effectively inclusive, and we de-dupe on merge anyway, so it is
        # safer to continue from `earliest` instead of subtracting a whole bar (which can skip the
        # requested start boundary for coarse bars like 1h/1d).
        next_cursor_end = earliest
        if next_cursor_end >= cursor_end:
            next_cursor_end = earliest - pd.Timedelta(seconds=bar_seconds)
        if next_cursor_end >= cursor_end:
            # IBKR can ignore an older anchor and resend the latest page. A
            # repeated cursor would otherwise request that page indefinitely.
            # Keep real bars, expose incomplete history and leave it retryable.
            paging_stalled = True
            logger.warning(
                "IBKR history paging for %s timestep=%s did not advance before %s; keeping real bars",
                getattr(asset, "symbol", None), timestep, cursor_end,
            )
            break
        page_span = _period_to_timedelta(period)
        session_close = _previous_equity_session_close_before(
            asset_type=asset_type,
            bar=bar,
            earliest=earliest,
            include_after_hours=include_after_hours,
            page_start=(cursor_end - page_span) if page_span is not None else None,
            page_was_capped=len(df) >= IBKR_HISTORY_MAX_POINTS,
        )
        if session_close is not None and session_close < _to_utc(next_cursor_end):
            next_cursor_end = session_close
        cursor_end = next_cursor_end

        # Do not assume `len(df) < 1000` implies we're at the start of history.
        # IBKR can return fewer bars due to gaps/vendor behavior; breaking early can leave large
        # holes (and can trigger stale-end refresh loops in daily backtests).

    if not chunks:
        return pd.DataFrame()

    merged = pd.concat(chunks, axis=0).sort_index()
    merged = merged[~merged.index.duplicated(keep="last")]
    if conid_refreshed or paging_stalled:
        record_history_health(
            series_id=_history_health_series_id(asset=asset, quote=quote, timestep=timestep,
                exchange=exchange, source=source, include_after_hours=include_after_hours),
            symbol=str(getattr(asset, "symbol", "") or ""),
            asset_type=asset_type,
            timestep=timestep,
            requested_start=start_dt,
            requested_end=_to_utc(end_dt),
            outcome=HistoryOutcome.PARTIAL if paging_stalled else HistoryOutcome.COMPLETE,
            conid_refreshes=int(conid_refreshed),
            reason="non_advancing_history_page" if paging_stalled else None,
        )
    # IMPORTANT: Do not clamp to the requested window here.
    #
    # IBKR can return the "latest available" bars even when the requested window is in the
    # future (or otherwise outside the available range). We still want to persist those bars
    # to the cache to warm future requests and avoid repeatedly hammering the downloader.
    #
    # The caller (`get_price_data`) performs the final slice for the requested time range.
    return merged


def _ibkr_page_request_end(cursor_end: datetime, bar_seconds: int, asset_type: str = "") -> datetime:
    """Return the IBKR ``startTime`` for a page that must hold every bar starting before ``cursor_end``.

    An IBKR history page ending at T holds bars up to T minus two bars: the bar that starts
    one bar before T (and ends at T) is left out. Recorded live on 2026-09-25: SPY 1-minute
    ending 20:00 ET stopped at 19:58, SPX 1-minute pages ending at the 16:00 ET close held
    389 bars ending 15:58, and a QQQ 5-minute page ending 13:40 UTC stopped at 13:30. Pages
    anchored at a session close lost every session's final bar, and a page continuing from
    the previous page's earliest bar lost the bar just before it. Asking one bar later keeps
    that bar; if IBKR ever includes the bar at T as well, the merge drops the duplicate.
    Daily bars keep their request end unchanged.

    Stock, index and futures intraday requests never ask past the delayed-feed limit
    (IBKR_INTRADAY_HISTORY_DELAY, see get_price_data): the shift used to put the first hourly
    page about 40 minutes after now, which the downloader can reject as stale_tail. At the
    limit the page keeps the old end; the bar it leaves out is too recent to be served yet.
    Crypto keeps its existing full shift. Older futures pages retain the
    overlap shift, so completed session endings are not lost.
    """
    if not bar_seconds or bar_seconds >= 24 * 60 * 60:
        return cursor_end
    shifted = cursor_end + timedelta(seconds=int(bar_seconds))
    if asset_type in {"stock", "index", "future", "cont_future"}:
        latest_available = _ibkr_history_now_utc() - IBKR_INTRADAY_HISTORY_DELAY
        if shifted > latest_available:
            shifted = max(cursor_end, latest_available)
    return shifted


def _history_health_series_id(*, asset, quote, timestep, exchange, source, include_after_hours) -> str:
    instrument = {name: str(getattr(asset, name, "") or "")
                  for name in ("asset_type", "symbol", "expiration", "strike", "right", "multiplier")}
    identity = {"asset": instrument, "quote": str(getattr(quote, "symbol", "") or "USD"),
                "timestep": timestep, "exchange": exchange or "AUTO", "source": source,
                "include_after_hours": bool(include_after_hours)}
    return hashlib.sha256(json.dumps(identity, sort_keys=True).encode()).hexdigest()


def _history_period_for_request(
    *, asset_type: str, bar: str, source: str,
    requested_start: Optional[datetime] = None, requested_end: Optional[datetime] = None,
) -> str:
    normalized_bar = (bar or "").strip().lower()
    if asset_type in {"stock", "index", "option"} and normalized_bar.endswith("d"):
        if requested_start is not None and requested_end is not None:
            span = (_to_utc(requested_end) - _to_utc(requested_start)).total_seconds()
            if 0 < span <= IBKR_DAILY_EXACT_PERIOD_MAX_DAYS * 86400:
                # The caller's full span includes lookback/prefetch. Never infer
                # it from the simulation's visible dates or shrink it per bar.
                #
                # 2026-09-24: the limit was 365 days, so a one-year backtest plus an
                # indicator lookback (~390 days) asked for a 5y page. The downloader's
                # head probe never matches a 5y daily page and rebuilt every one (~35 s
                # per symbol). IBKR accepts exact day periods up to 1000d.
                days = math.ceil(span / 86400) + 7
                return f"{days}d"
        return IBKR_STOCK_INDEX_DAILY_MAX_PERIOD
    return _max_period_for_bar(bar)


def frame_covers_requested_window(
    df: pd.DataFrame,
    *,
    asset: Asset,
    timestep: str,
    start_dt: datetime,
    end_dt: datetime,
) -> bool:
    if df is None or df.empty:
        return False

    asset_type = _normalize_asset_type(getattr(asset, "asset_type", ""))
    try:
        bar, _, _ = _timestep_to_ibkr_bar(timestep)
    except Exception:
        return False

    tolerance = timedelta(0)
    normalized_bar = (bar or "").strip().lower()
    if normalized_bar.endswith("min"):
        tolerance = timedelta(minutes=int(normalized_bar.removesuffix("min") or "1")) * 3
    elif normalized_bar.endswith("h"):
        tolerance = timedelta(hours=int(normalized_bar.removesuffix("h") or "1")) * 3
    elif normalized_bar.endswith("d"):
        tolerance = timedelta(days=int(normalized_bar.removesuffix("d") or "1")) * 3

    frame = df
    if asset_type in {"stock", "index"} and normalized_bar.endswith("d"):
        try:
            frame = _align_stock_index_daily_to_session_close(df)
        except Exception:
            frame = df

    start_local = pd.Timestamp(start_dt)
    end_local = pd.Timestamp(end_dt)
    coverage_start = frame.index.min()
    coverage_end = frame.index.max()
    if coverage_start is None or coverage_end is None:
        return False

    try:
        if coverage_start.tzinfo is not None and start_local.tzinfo is None:
            start_local = start_local.tz_localize(coverage_start.tzinfo)
        elif coverage_start.tzinfo is None and start_local.tzinfo is not None:
            start_local = start_local.tz_localize(None)
        elif coverage_start.tzinfo is not None and start_local.tzinfo is not None:
            start_local = start_local.tz_convert(coverage_start.tzinfo)
    except Exception:
        pass

    try:
        if coverage_end.tzinfo is not None and end_local.tzinfo is None:
            end_local = end_local.tz_localize(coverage_end.tzinfo)
        elif coverage_end.tzinfo is None and end_local.tzinfo is not None:
            end_local = end_local.tz_localize(None)
        elif coverage_end.tzinfo is not None and end_local.tzinfo is not None:
            end_local = end_local.tz_convert(coverage_end.tzinfo)
    except Exception:
        pass

    start_covered = coverage_start <= (start_local + tolerance)
    end_covered = coverage_end >= (end_local - tolerance)

    if asset_type in {"stock", "index"} and (not start_covered or not end_covered):
        try:
            from lumibot.tools.helpers import get_trading_days

            schedule = get_trading_days(
                market="NYSE",
                start_date=start_local.date(),
                # get_trading_days treats end_date as exclusive.
                end_date=end_local.date() + timedelta(days=1),
                tzinfo=LUMIBOT_DEFAULT_PYTZ,
            )
            if schedule is not None and not schedule.empty:
                opens = pd.DatetimeIndex(pd.to_datetime(schedule["market_open"], utc=True))
                closes = pd.DatetimeIndex(pd.to_datetime(schedule["market_close"], utc=True))
                start_utc = start_local.tz_convert("UTC") if start_local.tzinfo is not None else start_local.tz_localize("UTC")
                end_utc = end_local.tz_convert("UTC") if end_local.tzinfo is not None else end_local.tz_localize("UTC")
                cov_start_utc = coverage_start.tz_convert("UTC") if coverage_start.tzinfo is not None else coverage_start.tz_localize("UTC")
                cov_end_utc = coverage_end.tz_convert("UTC") if coverage_end.tzinfo is not None else coverage_end.tz_localize("UTC")
                # A weekend, holiday or overnight request boundary needs no synthetic
                # bars. The real coverage boundaries are the first session that had not
                # closed by the requested start, and the last session that had opened by
                # the requested end. A boundary inside a session still needs the raw check.
                #
                # 2026-09-23: the end side used the close of the last calendar day in the
                # window. A backtest end clamped to "now" at 00:42 ET sits before that
                # day's session, so a complete cache was reported as underfilled and the
                # routed prefetch retried on every bar (production SPY 5-minute backtest).
                pending = closes > start_utc
                if not bool(pending.any()):
                    start_covered = True
                else:
                    first_open = opens[pending][0]
                    if start_utc < first_open:
                        start_covered = start_covered or cov_start_utc <= (first_open + tolerance)
                begun = opens < end_utc
                if not bool(begun.any()):
                    end_covered = True
                else:
                    last_close = closes[begun][-1]
                    if end_utc > last_close:
                        end_covered = end_covered or cov_end_utc >= (last_close - tolerance)
        except Exception:
            pass

    return bool(start_covered and end_covered)


def _downloader_history_meta(payload: Any) -> Dict[str, Any]:
    if not isinstance(payload, dict):
        return {}
    meta = payload.get("_botspot_meta")
    if not isinstance(meta, dict):
        return {}
    if str(meta.get("provider") or "").strip().lower() != "ibkr":
        return {}
    return meta


def _ensure_cacheable_downloader_history_payload(payload: Any) -> None:
    meta = _downloader_history_meta(payload)
    if not meta:
        return
    classification = str(meta.get("classification") or "").strip().lower()
    cache_policy = str(meta.get("cache_write_policy") or "").strip().lower()
    if classification in {"complete", "explicit_no_data"} and cache_policy in {"allow", "negative_only"}:
        return
    error = str(meta.get("error") or "").strip()
    if error:
        logger.warning("IBKR downloader rejected non-cacheable history payload: %s", error)
    raise HistoryPayloadError(meta)


def _ibkr_history_request(
    *,
    conid: int,
    period: str,
    bar: str,
    start_time: datetime,
    exchange: Optional[str],
    include_after_hours: bool,
    continuous: bool,
    source: str,
    queue_timeout: Optional[float] = None,
    max_timeout_attempts: Optional[int] = None,
    backend: Optional[str] = None,
) -> Dict[str, Any]:
    base_url = _downloader_base_url()
    url = f"{base_url}/ibkr/iserver/marketdata/history"
    # IBKR Client Portal history endpoint interprets `startTime` as UTC.
    #
    # If we format `startTime` in a local timezone (e.g. America/New_York) while IBKR treats it
    # as UTC, paginating in 1000-bar chunks can create DST-sized holes (~4h in summer, ~5h in
    # winter). We have observed these holes as ~4h02/~5h02 gaps at chunk boundaries in cached
    # parquet files, which then cascades into stale-bar execution and parity failures.
    start_time_utc = _to_utc(start_time)
    query = {
        "conid": str(int(conid)),
        "period": period,
        "bar": bar,
        "outsideRth": "true" if include_after_hours else "false",
        "source": source,
        "startTime": start_time_utc.strftime("%Y%m%d-%H:%M:%S"),
    }
    if backend is not None:
        if backend not in {"rest", "tws"}:
            raise ValueError("Unsupported IBKR history backend")
        query["ibkr_backend"] = backend
    if continuous:
        query["continuous"] = "true"
    if exchange:
        query["exchange"] = str(exchange)

    queue_kwargs: Dict[str, Any] = {
        "url": url,
        "querystring": query,
        "headers": None,
        "timeout": queue_timeout,
    }
    if max_timeout_attempts is not None:
        queue_kwargs["max_timeout_attempts"] = max_timeout_attempts
    result = queue_request(**queue_kwargs)
    if result is None:
        return {}
    if isinstance(result, dict) and result.get("error"):
        err = str(result.get("error") or "")
        # IBKR occasionally rejects large day windows (e.g. 1000d) with "Chart data unavailable"
        # for symbols that do return data over shorter periods. Fall back to smaller windows before
        # surfacing a hard failure.
        if "chart data unavailable" in err.lower() and str(bar).lower().endswith("d"):
            for fallback_period in ("1y", "6m", "3m", "1m"):
                fallback_query = dict(query)
                fallback_query["period"] = fallback_period
                fallback_kwargs = dict(queue_kwargs)
                fallback_kwargs["querystring"] = fallback_query
                fallback_result = queue_request(**fallback_kwargs)
                if fallback_result is None:
                    continue
                if isinstance(fallback_result, dict) and fallback_result.get("error"):
                    continue
                return fallback_result
        # Do not treat entitlement errors as NO_DATA; surface them to the caller.
        raise RuntimeError(f"IBKR history error: {result.get('error')}")
    _ensure_cacheable_downloader_history_payload(result)
    return result


def _history_payload_to_frame(
    data: Any, *, source_was_explicit: bool, daily_session_dates_from_utc: bool = False,
    volume_factor: Optional[float] = 1.0,
) -> pd.DataFrame:
    df = pd.DataFrame(data)
    if df.empty:
        return df

    # IBKR payload columns: t(ms), o, h, l, c, v.
    rename = {"t": "timestamp", "o": "open", "h": "high", "l": "low", "c": "close", "v": "volume"}
    df = df.rename(columns=rename)
    if "volume" in df.columns:
        # Provider response metadata defines units. Normalize only fresh raw
        # rows, before merging or persistence; cache reads never scale again.
        # IBKR's unavailable-volume sentinel (-1) and nulls are not trades.
        volume = pd.to_numeric(df["volume"], errors="raise")
        scalable = volume.notna() & (volume >= 0) & (volume < float("inf"))
        if volume_factor is None:
            # Units unknown (no volumeFactor): keep the real prices, mark the
            # volume missing instead of guessing shares versus lots.
            df["volume"] = volume.where(~scalable, float("nan"))
        else:
            df["volume"] = volume.where(~scalable, volume * volume_factor)
    if "timestamp" not in df.columns:
        return pd.DataFrame()

    ts = pd.to_datetime(df["timestamp"], unit="ms", utc=True, errors="coerce")
    df = df.drop(columns=["timestamp"], errors="ignore")
    df.index = ts
    df = df[~df.index.isna()]
    df = df.sort_index()
    if daily_session_dates_from_utc:
        # TWS YYYYMMDD bars are date labels encoded as UTC midnight. Converting
        # that instant to New York first assigns the price to the preceding day.
        # Preserve the provider's calendar date before applying close semantics.
        dates = df.index.tz_convert("UTC").tz_localize(None).normalize()
        df.index = (dates + pd.Timedelta(hours=16)).tz_localize(LUMIBOT_DEFAULT_PYTZ)
    else:
        df.index = df.index.tz_convert(LUMIBOT_DEFAULT_PYTZ)
    df["missing"] = False
    # Default quote fields:
    #
    # When callers did not explicitly request a history `source`, we populate bid/ask with the
    # close as a fallback so quote-based fill logic remains functional even before we derive a
    # real spread (Bid_Ask + Midpoint).
    #
    # When the caller explicitly requests a history `source` (e.g., `source="Trades"` in a
    # deterministic parity suite), we intentionally DO NOT synthesize bid/ask so the engine
    # uses OHLC fills.
    if (not source_was_explicit) and "close" in df.columns:
        df["bid"] = df["close"]
        df["ask"] = df["close"]
    return df


def _derive_bid_ask_from_bid_ask_and_midpoint(
    bid_ask: pd.DataFrame,
    midpoint: pd.DataFrame,
) -> pd.DataFrame:
    """Derive per-bar bid/ask quotes using IBKR Bid_Ask + Midpoint history.

    IBKR's Client Portal history endpoint returns OHLC bars for different "sources":
    - Trades: prints-based bars
    - Midpoint: midpoint bars
    - Bid_Ask: IBKR-style BID_ASK bars (historically: open/low use bid, close/high use ask)

    The payload does NOT include separate bid/ask fields. For backtesting fills, we want a
    stable bid/ask at each bar timestamp. The best-effort reconstruction is:
    - ask_close = Bid_Ask.close
    - mid_close = Midpoint.close
    - bid_close = 2 * mid_close - ask_close

    The result is clamped defensively to avoid negative/inverted spreads.
    """
    if bid_ask is None or bid_ask.empty or midpoint is None or midpoint.empty:
        return pd.DataFrame()
    if "close" not in bid_ask.columns or "close" not in midpoint.columns:
        return pd.DataFrame()

    joined = (
        pd.concat(
            [
                bid_ask[["close"]].rename(columns={"close": "ask_close"}),
                midpoint[["close"]].rename(columns={"close": "mid_close"}),
            ],
            axis=1,
            join="inner",
        )
        .dropna()
        .copy()
    )
    if joined.empty:
        return pd.DataFrame()

    ask = pd.to_numeric(joined["ask_close"], errors="coerce")
    mid = pd.to_numeric(joined["mid_close"], errors="coerce")
    bid = 2 * mid - ask

    out = pd.DataFrame(index=joined.index)
    out["bid"] = bid
    out["ask"] = ask

    invalid = (
        out["bid"].isna()
        | out["ask"].isna()
        | (out["bid"] <= 0)
        | (out["ask"] <= 0)
        | (out["bid"] > out["ask"])
    )
    if invalid.any():
        mid_valid = mid > 0
        use_mid = invalid & mid_valid
        out.loc[use_mid, "bid"] = mid[use_mid]
        out.loc[use_mid, "ask"] = mid[use_mid]

        # If midpoint itself is invalid (<=0), leave as NaN so callers can fall back to
        # the trade/mark close instead of propagating negative prices into fills.
        use_nan = invalid & ~mid_valid
        if use_nan.any():
            out.loc[use_nan, "bid"] = float("nan")
            out.loc[use_nan, "ask"] = float("nan")

    return out


def _merge_frames(existing: pd.DataFrame, incoming: pd.DataFrame) -> pd.DataFrame:
    if existing is None or existing.empty:
        merged = incoming
    elif incoming is None or incoming.empty:
        merged = existing
    else:
        from lumibot.tools.ibkr_equity_basis import assert_same_basis
        # Unknown/unknown non-equity frames retain their existing behavior.
        # A known equity basis may never mix with unknown or another split basis.
        assert_same_basis(existing, incoming)
        merged = pd.concat([existing, incoming], axis=0)
    if merged is None or merged.empty:
        return merged

    merged = merged.sort_index(kind="mergesort")
    if "missing" in merged.columns:
        merged["missing"] = merged["missing"].fillna(False)
        missing_mask = merged["missing"].astype(bool)
        real_indexes = merged.index[~missing_mask]
        if len(real_indexes):
            merged = merged[~(missing_mask & merged.index.isin(real_indexes))]
    merged = merged[~merged.index.duplicated(keep="last")]
    return merged


def _expected_us_daily_sessions(
    *,
    start_dt: datetime,
    end_dt: datetime,
) -> list[pd.Timestamp]:
    """Return NYSE session-close timestamps in the end-exclusive request window."""
    from lumibot.tools.helpers import get_trading_days

    start_local = pd.Timestamp(_to_utc(start_dt)).tz_convert(LUMIBOT_DEFAULT_PYTZ)
    end_local = pd.Timestamp(_to_utc(end_dt)).tz_convert(LUMIBOT_DEFAULT_PYTZ)
    if start_local >= end_local:
        return []
    schedule = get_trading_days(
        market="NYSE",
        start_date=start_local.date(),
        end_date=(end_local + pd.Timedelta(days=1)).date(),
        tzinfo=LUMIBOT_DEFAULT_PYTZ,
    )
    if schedule is None or schedule.empty:
        return []
    closes = pd.DatetimeIndex(schedule["market_close"])
    closes = closes[(closes >= start_local) & (closes < end_local)]
    return list(closes)


def _retryable_us_daily_sessions(
    df_cache: pd.DataFrame,
    *,
    start_dt: datetime,
    end_dt: datetime,
    now: Optional[datetime] = None,
) -> list[pd.Timestamp]:
    """Find completed NYSE sessions without a real daily bar and eligible for retry.

    Only a confirmed no-data outcome may suppress a retry until its timestamp
    expires. Older repair markers recorded a timestamp even for ambiguous empty
    responses; honoring those timestamps hides bars after the provider recovers.
    """
    if df_cache is None or df_cache.empty:
        return []

    now_utc = pd.Timestamp(now or datetime.now(timezone.utc))
    if now_utc.tzinfo is None:
        now_utc = now_utc.tz_localize(timezone.utc)
    else:
        now_utc = now_utc.tz_convert(timezone.utc)

    frame = df_cache.copy()
    idx = pd.DatetimeIndex(frame.index)
    if idx.tz is None:
        idx = idx.tz_localize(LUMIBOT_DEFAULT_PYTZ)
    else:
        idx = idx.tz_convert(LUMIBOT_DEFAULT_PYTZ)
    frame.index = idx

    missing_mask = (
        frame["missing"].fillna(False).astype(bool)
        if "missing" in frame.columns
        else pd.Series(False, index=frame.index)
    )
    real_frame = frame.loc[~missing_mask]

    requested_start = _to_utc(start_dt)
    if not real_frame.empty:
        requested_start = max(
            requested_start,
            real_frame.index.min().to_pydatetime().astimezone(timezone.utc),
        )
    requested_end = min(_to_utc(end_dt), now_utc.to_pydatetime())
    expected = _expected_us_daily_sessions(start_dt=requested_start, end_dt=requested_end)
    if not expected:
        return []

    real_dates = {ts.date() for ts in pd.DatetimeIndex(real_frame.index)}
    marker_retry_after: Dict[date, pd.Timestamp] = {}
    if (
        bool(missing_mask.any())
        and "missing_retry_after" in frame.columns
        and "missing_outcome" in frame.columns
    ):
        confirmed = frame["missing_outcome"].fillna("").astype(str).eq(
            HistoryOutcome.CONFIRMED_NO_DATA.value
        )
        if "missing_reason" in frame.columns:
            confirmed &= ~frame["missing_reason"].fillna("").astype(str).eq(
                IBKR_LEGACY_INFERRED_TAIL_REASON
            )
        marker_rows = frame.loc[missing_mask & confirmed, ["missing_retry_after"]]
        parsed = pd.to_datetime(marker_rows["missing_retry_after"], utc=True, errors="coerce")
        for marker_ts, retry_after in parsed.items():
            if pd.isna(retry_after):
                continue
            session_date = pd.Timestamp(marker_ts).tz_convert(LUMIBOT_DEFAULT_PYTZ).date()
            previous = marker_retry_after.get(session_date)
            if previous is None or retry_after > previous:
                marker_retry_after[session_date] = retry_after

    retryable: list[pd.Timestamp] = []
    for session_close in expected:
        session_date = session_close.date()
        if session_date in real_dates:
            continue
        retry_after = marker_retry_after.get(session_date)
        if retry_after is not None and retry_after > now_utc:
            continue
        retryable.append(session_close)
    return retryable


def _daily_missing_placeholders(
    sessions: list[pd.Timestamp],
    *,
    retry_after: datetime,
) -> pd.DataFrame:
    if not sessions:
        return pd.DataFrame()
    count = len(sessions)
    index = pd.DatetimeIndex(sessions).tz_convert(LUMIBOT_DEFAULT_PYTZ)
    index = index.normalize() + pd.Timedelta(hours=16)
    return pd.DataFrame(
        {
            "open": [pd.NA] * count,
            "high": [pd.NA] * count,
            "low": [pd.NA] * count,
            "close": [pd.NA] * count,
            "volume": [pd.NA] * count,
            "missing": [True] * count,
            "missing_retry_after": [retry_after.isoformat()] * count,
        },
        index=index,
    )


def _repair_us_stock_index_daily_gaps(
    df_cache: pd.DataFrame,
    *,
    cache_file: Path,
    asset: Asset,
    quote: Optional[Asset],
    timestep: str,
    start_dt: datetime,
    end_dt: datetime,
    exchange: Optional[str],
    include_after_hours: bool,
    source: str,
    source_was_explicit: bool,
) -> pd.DataFrame:
    """Best-effort lazy repair for internal US stock/index daily cache gaps.

    The repair budget is per cached series. A slow symbol must never consume the
    repair opportunity for every later symbol in the same backtest process.
    """
    quote_symbol = str(getattr(quote, "symbol", "USD") or "USD").strip().upper()
    normalized_exchange = str(exchange or "").strip().upper()
    if quote_symbol != "USD" or normalized_exchange not in {
        "",
        "SMART",
        "NYSE",
        "NASDAQ",
        "ARCA",
        "AMEX",
        "IEX",
        "CBOE",
    }:
        return df_cache

    check_key = (
        str(cache_file),
        _to_utc(start_dt).date().isoformat(),
        _to_utc(end_dt).date().isoformat(),
    )
    if check_key in _RUNTIME_DAILY_GAP_CHECKED_WINDOWS:
        return df_cache
    _RUNTIME_DAILY_GAP_CHECKED_WINDOWS.add(check_key)

    aligned = _align_stock_index_daily_to_session_close(df_cache)
    gaps = _retryable_us_daily_sessions(
        aligned,
        start_dt=start_dt,
        end_dt=end_dt,
    )
    if not gaps:
        effective_end = min(_to_utc(end_dt), datetime.now(timezone.utc))
        expected = _expected_us_daily_sessions(start_dt=start_dt, end_dt=effective_end)
        missing_mask = (
            aligned["missing"].fillna(False).astype(bool)
            if "missing" in aligned.columns
            else pd.Series(False, index=aligned.index)
        )
        real_dates = {
            ts.date()
            for ts in pd.DatetimeIndex(aligned.index[~missing_mask]).tz_convert(
                LUMIBOT_DEFAULT_PYTZ
            )
        }
        unresolved = [session for session in expected if session.date() not in real_dates]
        record_history_health(
            series_id=_history_health_series_id(asset=asset, quote=quote, timestep=timestep,
                exchange=exchange, source=source, include_after_hours=include_after_hours),
            symbol=str(getattr(asset, "symbol", "") or ""),
            asset_type=_normalize_asset_type(getattr(asset, "asset_type", "")),
            timestep=timestep,
            requested_start=_to_utc(start_dt),
            requested_end=_to_utc(end_dt),
            outcome=HistoryOutcome.COMPLETE if not unresolved else HistoryOutcome.PARTIAL,
            expected_sessions=len(expected),
            returned_sessions=len(expected) - len(unresolved),
            missing_sessions=[session.date().isoformat() for session in unresolved],
            reason=None if not unresolved else "daily_sessions_waiting_for_retry",
        )
        return aligned

    working = aligned
    attempted: list[pd.Timestamp] = []
    effective_end = min(_to_utc(end_dt), datetime.now(timezone.utc))
    expected = _expected_us_daily_sessions(start_dt=start_dt, end_dt=effective_end)
    groups = split_session_groups(
        coalesce_nearby_session_groups(
            group_contiguous_missing_sessions(expected, gaps)
        ),
        max_sessions=IBKR_DAILY_GAP_REPAIR_MAX_SESSIONS_PER_SEGMENT,
    )[:IBKR_DAILY_GAP_REPAIR_MAX_SEGMENTS_PER_SERIES]
    deadline = time.perf_counter() + IBKR_DAILY_GAP_REPAIR_TIMEOUT_SECONDS
    repair_attempts = 0
    for group in groups:
        remaining = deadline - time.perf_counter()
        if remaining <= 0:
            break
        repair_start, repair_end = padded_repair_window(group, padding_days=1)
        period_days = max(5, min(30, (repair_end - repair_start).days + 1))
        try:
            repair_attempts += 1
            fetched = _fetch_history_between_dates(
                asset=asset,
                quote=quote,
                timestep=timestep,
                start_dt=repair_start,
                end_dt=repair_end,
                exchange=exchange,
                include_after_hours=include_after_hours,
                source=source,
                source_was_explicit=source_was_explicit,
                _period_override=f"{period_days}d",
                _record_missing_on_empty=False,
                _queue_timeout=max(0.1, remaining),
                _max_timeout_attempts=1,
                _deadline_monotonic=deadline,
            )
            attempted.extend(group)
            if fetched is not None and not fetched.empty:
                fetched = _align_stock_index_daily_to_session_close(fetched)
                working = _merge_frames(working, fetched)
        except Exception as exc:
            attempted.extend(group)
            logger.warning(
                "IBKR daily gap repair skipped for %s %s through %s: %s",
                getattr(asset, "symbol", None),
                group[0].date(),
                group[-1].date(),
                exc,
            )

    # An authenticated REST route can return an older final day without an
    # error (observed SPX, October 2026). Try the existing TWS route once for
    # the missing sessions, keeping the same instrument/source and deadline.
    real = working.loc[~working.get("missing", pd.Series(False, index=working.index)).fillna(False).astype(bool)]
    remaining_sessions = [session for session in gaps if session.date() not in set(real.index.date)]
    if remaining_sessions and not real.empty and deadline > time.perf_counter():
        try:
            alt_start, alt_end = padded_repair_window(remaining_sessions, padding_days=4)
            alternate = _fetch_history_between_dates(
                asset=asset, quote=quote, timestep=timestep, start_dt=alt_start, end_dt=alt_end,
                exchange=exchange, include_after_hours=include_after_hours, source=source,
                source_was_explicit=source_was_explicit, _record_missing_on_empty=False,
                _queue_timeout=max(0.1, deadline - time.perf_counter()), _max_timeout_attempts=1,
                _deadline_monotonic=deadline, _backend="tws")
            repair_attempts += 1
            alternate = _align_stock_index_daily_to_session_close(alternate)
            overlap = real.index.intersection(alternate.index)
            columns = [name for name in ("open", "high", "low", "close") if name in real and name in alternate]
            # A shared session proves date/adjustment compatibility. Small
            # vendor rounding is allowed: one basis point plus one cent.
            compatible = bool(len(overlap) and len(columns) == 4)
            if compatible:
                left = real.loc[overlap, columns].to_numpy(dtype=float)
                right = alternate.loc[overlap, columns].to_numpy(dtype=float)
                compatible = bool(np.isfinite(left).all() and np.isfinite(right).all()
                                  and np.isclose(left, right, rtol=0.0001, atol=0.01).all())
            if compatible:
                # Never rewrite existing real bars with another backend.
                working = _merge_frames(working, alternate.loc[~alternate.index.isin(real.index)])
            else:
                logger.warning("IBKR alternate daily route lacks compatible overlap for %s", getattr(asset, "symbol", None))
        except Exception as exc:
            logger.warning("IBKR alternate daily route unavailable for %s: %s", getattr(asset, "symbol", None), type(exc).__name__)

    missing_mask = (
        working["missing"].fillna(False).astype(bool)
        if "missing" in working.columns
        else pd.Series(False, index=working.index)
    )
    real_dates = {
        ts.date()
        for ts in pd.DatetimeIndex(working.index[~missing_mask]).tz_convert(
            LUMIBOT_DEFAULT_PYTZ
        )
    }
    unresolved = [session for session in expected if session.date() not in real_dates]
    record_history_health(
        series_id=_history_health_series_id(asset=asset, quote=quote, timestep=timestep,
            exchange=exchange, source=source, include_after_hours=include_after_hours),
        symbol=str(getattr(asset, "symbol", "") or ""),
        asset_type=_normalize_asset_type(getattr(asset, "asset_type", "")),
        timestep=timestep,
        requested_start=_to_utc(start_dt),
        requested_end=_to_utc(end_dt),
        outcome=HistoryOutcome.COMPLETE if not unresolved else HistoryOutcome.PARTIAL,
        expected_sessions=len(expected),
        returned_sessions=len(expected) - len(unresolved),
        missing_sessions=[session.date().isoformat() for session in unresolved],
        repair_attempts=repair_attempts,
        reason=None if not unresolved else "unresolved_daily_sessions_after_bounded_repair",
    )

    if not working.equals(df_cache):
        published = _write_cache_frame(cache_file, working)
        if published is not None:
            working = published
    return working


def _hourly_internal_gaps(
    df_cache: pd.DataFrame,
    *,
    start_dt: datetime,
    end_dt: datetime,
    now: Optional[datetime] = None,
) -> list[tuple[pd.Timestamp, pd.Timestamp]]:
    """Return large internal holes between real hourly bars.

    Seven days is longer than any normal US equity weekend or exchange holiday.
    It avoids trying to manufacture bars during expected closures while still
    detecting the multi-month and multi-year cache holes that invalidate a
    historical indicator series.
    """
    if df_cache is None or df_cache.empty:
        return []

    frame = df_cache.copy()
    idx = pd.DatetimeIndex(frame.index)
    if idx.tz is None:
        idx = idx.tz_localize(LUMIBOT_DEFAULT_PYTZ)
    else:
        idx = idx.tz_convert(LUMIBOT_DEFAULT_PYTZ)
    frame.index = idx

    missing_mask = (
        frame["missing"].fillna(False).astype(bool)
        if "missing" in frame.columns
        else pd.Series(False, index=frame.index)
    )
    real_index = pd.DatetimeIndex(frame.index[~missing_mask]).sort_values().unique()
    if len(real_index) < 2:
        return []

    start_local = pd.Timestamp(_to_utc(start_dt)).tz_convert(LUMIBOT_DEFAULT_PYTZ)
    now_utc = pd.Timestamp(now or datetime.now(timezone.utc))
    if now_utc.tzinfo is None:
        now_utc = now_utc.tz_localize(timezone.utc)
    else:
        now_utc = now_utc.tz_convert(timezone.utc)
    end_local = min(
        pd.Timestamp(_to_utc(end_dt)).tz_convert(LUMIBOT_DEFAULT_PYTZ),
        now_utc.tz_convert(LUMIBOT_DEFAULT_PYTZ),
    )
    real_index = real_index[(real_index >= start_local) & (real_index <= end_local)]
    if len(real_index) < 2:
        return []

    gaps: list[tuple[pd.Timestamp, pd.Timestamp]] = []
    for left, right in zip(real_index[:-1], real_index[1:]):
        if right - left > IBKR_HOURLY_INTERNAL_GAP_THRESHOLD:
            gaps.append((left, right))
    return gaps


def _gap_has_fresh_retry_marker(
    df_cache: pd.DataFrame,
    *,
    gap_start: pd.Timestamp,
    gap_end: pd.Timestamp,
    now: Optional[datetime] = None,
) -> bool:
    if (
        df_cache is None
        or df_cache.empty
        or "missing" not in df_cache.columns
        or "missing_retry_after" not in df_cache.columns
        or "missing_reason" not in df_cache.columns
    ):
        return False

    try:
        normalized_index = pd.DatetimeIndex(df_cache.index)
        if normalized_index.tz is None:
            normalized_index = normalized_index.tz_localize(
                LUMIBOT_DEFAULT_PYTZ
            )
        else:
            normalized_index = normalized_index.tz_convert(
                LUMIBOT_DEFAULT_PYTZ
            )
    except Exception:
        return False
    missing_mask = df_cache["missing"].fillna(False).astype(bool).to_numpy()
    hourly_gap_mask = (
        df_cache["missing_reason"].fillna("").astype(str).to_numpy()
        == "hourly_internal_gap_empty"
    )
    marker_rows = df_cache.loc[
        missing_mask
        & hourly_gap_mask
        & (normalized_index > gap_start)
        & (normalized_index < gap_end),
        ["missing_retry_after"],
    ]
    if len(marker_rows) < 2:
        return False
    retry_after = pd.to_datetime(
        marker_rows["missing_retry_after"],
        utc=True,
        errors="coerce",
    ).dropna()
    if len(retry_after) < 2:
        return False
    now_utc = pd.Timestamp(now or datetime.now(timezone.utc))
    if now_utc.tzinfo is None:
        now_utc = now_utc.tz_localize(timezone.utc)
    else:
        now_utc = now_utc.tz_convert(timezone.utc)
    return bool((retry_after > now_utc).all())


def _missing_window_placeholders(
    gap_start: pd.Timestamp,
    gap_end: pd.Timestamp,
    *,
    retry_after: datetime,
    bar_step: pd.Timedelta,
) -> pd.DataFrame:
    left = gap_start + bar_step
    right = gap_end - bar_step
    if left >= right:
        return pd.DataFrame()
    return pd.DataFrame(
        {
            "open": [pd.NA, pd.NA],
            "high": [pd.NA, pd.NA],
            "low": [pd.NA, pd.NA],
            "close": [pd.NA, pd.NA],
            "volume": [pd.NA, pd.NA],
            "missing": [True, True],
            "missing_retry_after": [retry_after.isoformat(), retry_after.isoformat()],
            "missing_reason": [
                "hourly_internal_gap_empty",
                "hourly_internal_gap_empty",
            ],
        },
        index=pd.DatetimeIndex([left, right]),
    )


def _hourly_cache_signature(
    df_cache: pd.DataFrame,
) -> tuple[int, str, str, int]:
    if df_cache is None or df_cache.empty:
        return (0, "", "", 0)
    try:
        index = pd.DatetimeIndex(pd.to_datetime(df_cache.index, utc=True))
        first = index.min().isoformat()
        last = index.max().isoformat()
    except Exception:
        first = str(df_cache.index.min())
        last = str(df_cache.index.max())
    missing_count = (
        int(df_cache["missing"].fillna(False).astype(bool).sum())
        if "missing" in df_cache.columns
        else 0
    )
    return (len(df_cache), first, last, missing_count)


def _repair_us_stock_index_hourly_gaps(
    df_cache: pd.DataFrame,
    *,
    cache_file: Path,
    asset: Asset,
    quote: Optional[Asset],
    timestep: str,
    start_dt: datetime,
    end_dt: datetime,
    exchange: Optional[str],
    include_after_hours: bool,
    source: str,
    source_was_explicit: bool,
) -> pd.DataFrame:
    """Lazily fill large internal stock/index hourly cache holes once per process."""
    quote_symbol = str(getattr(quote, "symbol", "USD") or "USD").strip().upper()
    normalized_exchange = str(exchange or "").strip().upper()
    if quote_symbol != "USD" or normalized_exchange not in {
        "",
        "SMART",
        "NYSE",
        "NASDAQ",
        "ARCA",
        "AMEX",
        "IEX",
    }:
        return df_cache

    series_key = str(cache_file)
    cache_signature = _hourly_cache_signature(df_cache)
    request_start = _to_utc(start_dt)
    request_end = _to_utc(end_dt)
    previous_check = _RUNTIME_HOURLY_GAP_CHECKED_SERIES.get(series_key)
    if previous_check is not None:
        checked_signature, checked_start, checked_end = previous_check
        if (
            checked_signature == cache_signature
            and checked_start <= request_start
            and checked_end >= request_end
        ):
            return df_cache

    gaps = _hourly_internal_gaps(
        df_cache,
        start_dt=start_dt,
        end_dt=end_dt,
    )
    gaps = [
        gap
        for gap in gaps
        if not _gap_has_fresh_retry_marker(
            df_cache,
            gap_start=gap[0],
            gap_end=gap[1],
        )
    ]
    if not gaps:
        _RUNTIME_HOURLY_GAP_CHECKED_SERIES[series_key] = (
            cache_signature,
            request_start,
            request_end,
        )
        return df_cache

    logger.info(
        "IBKR hourly cache repair found %d large internal gap(s) for %s",
        len(gaps),
        getattr(asset, "symbol", None),
    )
    working = df_cache
    changed = False
    deadline = time.perf_counter() + IBKR_HOURLY_GAP_REPAIR_TIMEOUT_SECONDS
    attempted: list[tuple[pd.Timestamp, pd.Timestamp]] = []
    for gap_start, gap_end in gaps[:IBKR_HOURLY_GAP_REPAIR_MAX_SEGMENTS_PER_SERIES]:
        remaining = deadline - time.perf_counter()
        if remaining <= 0:
            break
        try:
            fetched = _fetch_history_between_dates(
                asset=asset,
                quote=quote,
                timestep=timestep,
                start_dt=gap_start.to_pydatetime(),
                end_dt=gap_end.to_pydatetime(),
                exchange=exchange,
                include_after_hours=include_after_hours,
                source=source,
                source_was_explicit=source_was_explicit,
                # With outside-RTH equity data, 2000 calendar hours stays below
                # IBKR's roughly 1000-bar response cap while halving page count.
                _period_override=IBKR_STOCK_INDEX_HOURLY_REPAIR_PERIOD,
                _record_missing_on_empty=False,
                _queue_timeout=max(0.1, remaining),
                _max_timeout_attempts=1,
                _deadline_monotonic=deadline,
            )
            attempted.append((gap_start, gap_end))
            if fetched is not None and not fetched.empty:
                working = _merge_frames(working, fetched)
                changed = True
        except Exception as exc:
            logger.warning(
                "IBKR hourly gap repair skipped for %s %s through %s: %s",
                getattr(asset, "symbol", None),
                gap_start,
                gap_end,
                exc,
            )

    remaining_gaps = _hourly_internal_gaps(
        working,
        start_dt=start_dt,
        end_dt=end_dt,
    )
    unresolved = [
        gap
        for gap in remaining_gaps
        if any(
            gap[0] < attempted_end and gap[1] > attempted_start
            for attempted_start, attempted_end in attempted
        )
    ]
    # A partial response is useful progress, but it must not create a 24-hour
    # negative-cache marker for the unfilled remainder. The next backtest can
    # continue repairing from the newly advanced cache edge.
    if unresolved and not changed:
        retry_after = datetime.now(timezone.utc) + timedelta(
            seconds=IBKR_GAP_RETRY_TTL_SECONDS
        )
        for gap_start, gap_end in unresolved:
            placeholders = _missing_window_placeholders(
                gap_start,
                gap_end,
                retry_after=retry_after,
                bar_step=pd.Timedelta(hours=1),
            )
            if not placeholders.empty:
                working = _merge_frames(working, placeholders)
                changed = True

    if changed:
        published = _write_cache_frame(cache_file, working)
        if published is not None:
            working = published
    _RUNTIME_HOURLY_GAP_CHECKED_SERIES[series_key] = (
        _hourly_cache_signature(working),
        request_start,
        request_end,
    )
    logger.info(
        "IBKR hourly cache repair completed for %s with %d unresolved large gap(s)",
        getattr(asset, "symbol", None),
        len(unresolved),
    )
    return working


def _us_minute_session_fetch_window(
    session_open: pd.Timestamp,
    session_close: pd.Timestamp,
    *,
    asset_type: str,
    include_after_hours: bool,
) -> tuple[datetime, datetime]:
    """Return the UTC window that holds every minute bar IBKR can have for one session."""
    if asset_type == "stock" and include_after_hours:
        day = pd.Timestamp(session_open).tz_convert(LUMIBOT_DEFAULT_PYTZ).normalize()
        start = day + pd.Timedelta(hours=4)
        end = day + pd.Timedelta(hours=20)
    else:
        start = pd.Timestamp(session_open)
        end = pd.Timestamp(session_close)
    return start.tz_convert(timezone.utc).to_pydatetime(), end.tz_convert(timezone.utc).to_pydatetime()


def _missing_us_minute_sessions(
    df_cache: pd.DataFrame,
    *,
    start_dt: datetime,
    end_dt: datetime,
    now: Optional[datetime] = None,
) -> list[tuple[pd.Timestamp, pd.Timestamp]]:
    """Return NYSE sessions inside the cached part of the window that have no minute bar.

    Only sessions strictly between the first and the last real bar of the requested window
    count: the window edges are handled by the edge checks in `get_price_data`. A session
    with an unexpired `minute_session_gap_empty` marker (IBKR answered and had no bars for
    it) is not returned again until the marker expires.
    """
    if df_cache is None or df_cache.empty:
        return []

    idx = pd.DatetimeIndex(df_cache.index)
    if idx.tz is None:
        idx = idx.tz_localize(LUMIBOT_DEFAULT_PYTZ)
    else:
        idx = idx.tz_convert(LUMIBOT_DEFAULT_PYTZ)

    if "missing" in df_cache.columns:
        missing_mask = df_cache["missing"].fillna(False).astype(bool).to_numpy()
    else:
        missing_mask = np.zeros(len(idx), dtype=bool)

    start_local = pd.Timestamp(_to_utc(start_dt)).tz_convert(LUMIBOT_DEFAULT_PYTZ)
    end_local = pd.Timestamp(_to_utc(end_dt)).tz_convert(LUMIBOT_DEFAULT_PYTZ)
    real = idx[~missing_mask] if bool(missing_mask.any()) else idx
    if not real.is_monotonic_increasing:
        real = real.sort_values()
    # Binary searches instead of per-row date math: this runs once per series and window, and
    # a year of extended-hours minute bars is about 250,000 rows.
    # Parquet/pandas can retain second, millisecond or microsecond resolution;
    # Timestamp.value and the session boundaries below are always nanoseconds.
    real_ns = real.as_unit("ns").asi8
    lo = int(np.searchsorted(real_ns, start_local.value, side="left"))
    hi = int(np.searchsorted(real_ns, end_local.value, side="right"))
    if hi - lo < 2:
        return []
    real_ns = real_ns[lo:hi]

    first_day = pd.Timestamp(int(real_ns[0]), unit="ns", tz="UTC").tz_convert(LUMIBOT_DEFAULT_PYTZ).normalize()
    last_day = pd.Timestamp(int(real_ns[-1]), unit="ns", tz="UTC").tz_convert(LUMIBOT_DEFAULT_PYTZ).normalize()
    if (last_day - first_day) <= pd.Timedelta(days=1):
        return []

    def _has_real_bar_on(day: pd.Timestamp) -> bool:
        day_start = day.value
        day_end = (day + pd.DateOffset(days=1)).value  # next local midnight, DST-safe
        pos = int(np.searchsorted(real_ns, day_start, side="left"))
        return pos < len(real_ns) and int(real_ns[pos]) < day_end

    from lumibot.tools.helpers import get_trading_days

    schedule = get_trading_days(
        market="NYSE",
        start_date=first_day.date(),
        end_date=(last_day + pd.Timedelta(days=1)).date(),
        tzinfo=LUMIBOT_DEFAULT_PYTZ,
    )
    if schedule is None or schedule.empty:
        return []

    fresh_marker_days: set[pd.Timestamp] = set()
    if bool(missing_mask.any()) and {"missing_reason", "missing_retry_after"}.issubset(df_cache.columns):
        reasons = df_cache["missing_reason"].fillna("").astype(str).to_numpy()
        marker_mask = missing_mask & (reasons == IBKR_MINUTE_GAP_MARKER_REASON)
        if bool(marker_mask.any()):
            now_utc = pd.Timestamp(now or _ibkr_history_now_utc())
            now_utc = now_utc.tz_localize(timezone.utc) if now_utc.tzinfo is None else now_utc.tz_convert(timezone.utc)
            retry_after = pd.to_datetime(
                df_cache.loc[marker_mask, "missing_retry_after"], utc=True, errors="coerce"
            ).to_numpy()
            for marker_day, retry in zip(idx[marker_mask].normalize(), retry_after):
                if not pd.isna(retry) and pd.Timestamp(retry) > now_utc:
                    fresh_marker_days.add(marker_day)

    missing: list[tuple[pd.Timestamp, pd.Timestamp]] = []
    opens = pd.DatetimeIndex(schedule["market_open"]).tz_convert(LUMIBOT_DEFAULT_PYTZ)
    closes = pd.DatetimeIndex(schedule["market_close"]).tz_convert(LUMIBOT_DEFAULT_PYTZ)
    for session_open, session_close in zip(opens, closes):
        day = session_open.normalize()
        if day <= first_day or day >= last_day:
            continue
        if day in fresh_marker_days or _has_real_bar_on(day):
            continue
        missing.append((session_open, session_close))
    return missing


def _minute_session_markers(
    sessions: list[tuple[pd.Timestamp, pd.Timestamp]],
    *,
    retry_after: datetime,
) -> pd.DataFrame:
    if not sessions:
        return pd.DataFrame()
    count = len(sessions)
    return pd.DataFrame(
        {
            "open": [pd.NA] * count,
            "high": [pd.NA] * count,
            "low": [pd.NA] * count,
            "close": [pd.NA] * count,
            "volume": [pd.NA] * count,
            "missing": [True] * count,
            "missing_retry_after": [retry_after.isoformat()] * count,
            "missing_reason": [IBKR_MINUTE_GAP_MARKER_REASON] * count,
        },
        index=pd.DatetimeIndex([session_open for session_open, _ in sessions]),
    )


def _repair_us_stock_index_minute_gaps(
    df_cache: pd.DataFrame,
    *,
    cache_file: Path,
    asset: Asset,
    quote: Optional[Asset],
    timestep: str,
    start_dt: datetime,
    end_dt: datetime,
    exchange: Optional[str],
    include_after_hours: bool,
    source: str,
    source_was_explicit: bool,
) -> pd.DataFrame:
    """Fetch whole sessions missing inside a cached US stock/index minute series.

    WHY (2026-09-25): the minute path only compared the edges of the requested window with
    the cache. A cache holding June and September (two earlier backtests) served a June to
    September backtest with July and August silently missing: no request, no error, and the
    strategy saw one stale bar for weeks and made no trades. The same holes come from an
    interrupted download (page checkpoints), from a failed older page (newer pages are
    kept), and from LumiBot 4.6.0, which stopped paging at every weekend and wrote those
    holes into the shared S3 cache.

    Each missing session costs one request, the same as a cold walk. A session IBKR answers
    with no bars (a thin symbol with no prints that day) gets a marker so later backtests do
    not ask again until the marker expires. A failed request writes nothing, so the next
    process retries it.

    Cost bound (CodeRabbit on PR #1180 asked for a timer): at most one request per session in
    the requested window, once per process, which is never more than downloading that window
    cold (live 2026-09-25: a 10-session SPY hole took 10 requests, 52 s; the next call made
    none). A session whose request failed is not asked again in this process until
    IBKR_MINUTE_GAP_RETRY_COOLDOWN_SECONDS pass, repair pauses for the series for the same
    cooldown after IBKR_MINUTE_GAP_REPAIR_MAX_CONSECUTIVE_FAILURES in a row, and every serve
    of a series with known unrepaired sessions logs a WARNING (at most once a minute). There is
    deliberately no wall-clock limit: it would leave July missing on a busy downloader and not
    on a quiet one, which is the silent-hole bug this repair exists to fix.
    """
    quote_symbol = str(getattr(quote, "symbol", "USD") or "USD").strip().upper()
    normalized_exchange = str(exchange or "").strip().upper()
    if quote_symbol != "USD" or normalized_exchange not in {
        "",
        "SMART",
        "NYSE",
        "NASDAQ",
        "ARCA",
        "AMEX",
        "IEX",
        "CBOE",
    }:
        return df_cache

    series_key = str(cache_file)
    request_start = _to_utc(start_dt)
    request_end = _to_utc(end_dt)
    previous_check = _RUNTIME_MINUTE_GAP_CHECKED_SERIES.get(series_key)
    if previous_check is not None:
        checked_signature, checked_start, checked_end, recheck_at = previous_check
        if (
            checked_signature == _hourly_cache_signature(df_cache)
            and checked_start <= request_start
            and checked_end >= request_end
            and (recheck_at is None or _ibkr_history_now_utc() < recheck_at)
        ):
            return df_cache

    all_missing = _missing_us_minute_sessions(df_cache, start_dt=start_dt, end_dt=end_dt)
    if not all_missing:
        _RUNTIME_MINUTE_GAP_CHECKED_SERIES[series_key] = (
            _hourly_cache_signature(df_cache),
            request_start,
            request_end,
            _minute_marker_recheck_at(df_cache, start_dt=start_dt, end_dt=end_dt),
        )
        return df_cache

    now_mono = _ibkr_monotonic()
    cooldown = IBKR_MINUTE_GAP_RETRY_COOLDOWN_SECONDS
    stopped_at = _RUNTIME_MINUTE_GAP_REPAIR_STOPPED.get(series_key)
    if stopped_at is not None and now_mono - stopped_at < cooldown:
        _warn_minute_series_served_with_holes(series_key, asset, timestep, all_missing, now_mono)
        return df_cache
    _RUNTIME_MINUTE_GAP_REPAIR_STOPPED.pop(series_key, None)

    failed_before = _RUNTIME_MINUTE_GAP_FAILED_SESSIONS.setdefault(series_key, {})
    missing = [
        (session_open, session_close)
        for session_open, session_close in all_missing
        if now_mono - failed_before.get(session_open.normalize(), float("-inf")) >= cooldown
    ]
    if not missing:
        _warn_minute_series_served_with_holes(series_key, asset, timestep, all_missing, now_mono)
        return df_cache

    asset_type = _normalize_asset_type(getattr(asset, "asset_type", ""))
    logger.info(
        "IBKR minute cache repair: %d session(s) missing inside the cached window for %s (%s to %s)",
        len(missing),
        getattr(asset, "symbol", None),
        missing[0][0].date(),
        missing[-1][0].date(),
    )

    working = df_cache
    remaining = {session_open.normalize() for session_open, _ in missing}
    empty_sessions: list[tuple[pd.Timestamp, pd.Timestamp]] = []
    requests = 0
    failed_requests = 0
    consecutive_failures = 0
    unsaved_pages = 0
    # Newest first, like a cold walk. A page for multi-minute bars can cover several
    # sessions; sessions it filled are skipped.
    for session_open, session_close in reversed(missing):
        day = session_open.normalize()
        if day not in remaining:
            continue
        fetch_start, fetch_end = _us_minute_session_fetch_window(
            session_open, session_close, asset_type=asset_type, include_after_hours=include_after_hours
        )
        requests += 1
        try:
            fetched = _fetch_history_between_dates(
                asset=asset,
                quote=quote,
                timestep=timestep,
                start_dt=fetch_start,
                end_dt=fetch_end,
                exchange=exchange,
                include_after_hours=include_after_hours,
                source=source,
                source_was_explicit=source_was_explicit,
                _record_missing_on_empty=False,
            )
        except Exception as exc:
            failed_requests += 1
            consecutive_failures += 1
            failed_before[day] = _ibkr_monotonic()
            logger.warning(
                "IBKR minute cache repair could not fetch %s session %s: %s",
                getattr(asset, "symbol", None),
                day.date(),
                exc,
            )
            if consecutive_failures >= IBKR_MINUTE_GAP_REPAIR_MAX_CONSECUTIVE_FAILURES:
                _RUNTIME_MINUTE_GAP_REPAIR_STOPPED[series_key] = _ibkr_monotonic()
                break
            continue
        consecutive_failures = 0
        failed_before.pop(day, None)
        if fetched is not None and not fetched.empty:
            working = _merge_frames(working, fetched)
            unsaved_pages += 1
            fetched_idx = pd.DatetimeIndex(fetched.index)
            fetched_idx = (
                fetched_idx.tz_localize(LUMIBOT_DEFAULT_PYTZ)
                if fetched_idx.tz is None
                else fetched_idx.tz_convert(LUMIBOT_DEFAULT_PYTZ)
            )
            remaining.difference_update(fetched_idx.normalize().unique())
        if day in remaining:
            # IBKR answered for this session and had no bars in it.
            remaining.discard(day)
            empty_sessions.append((session_open, session_close))
        if unsaved_pages >= IBKR_PAGE_CHECKPOINT_EVERY:
            # Keep progress if the process is stopped during a long repair.
            published = _write_cache_frame(cache_file, working)
            if published is not None:
                working = published
            unsaved_pages = 0

    if empty_sessions:
        retry_after = _ibkr_history_now_utc() + timedelta(seconds=IBKR_GAP_RETRY_TTL_SECONDS)
        working = _merge_frames(working, _minute_session_markers(empty_sessions, retry_after=retry_after))

    if not working.equals(df_cache):
        published = _write_cache_frame(cache_file, working)
        if published is not None:
            working = published

    unresolved = _missing_us_minute_sessions(working, start_dt=start_dt, end_dt=end_dt)
    record_history_health(
        series_id=_history_health_series_id(asset=asset, quote=quote, timestep=timestep,
            exchange=exchange, source=source, include_after_hours=include_after_hours),
        symbol=str(getattr(asset, "symbol", "") or ""),
        asset_type=asset_type,
        timestep=timestep,
        requested_start=request_start,
        requested_end=request_end,
        outcome=HistoryOutcome.COMPLETE if not unresolved else HistoryOutcome.PARTIAL,
        expected_sessions=len(missing),
        returned_sessions=len(missing) - len(unresolved),
        missing_sessions=[session_open.date().isoformat() for session_open, _ in unresolved],
        repair_attempts=requests,
        transient_failures=failed_requests,
        reason=None if not unresolved else "minute_sessions_missing_after_repair",
    )
    if unresolved:
        # Not marked checked: a later call re-scans (milliseconds), warns, and retries the
        # failed sessions once their cooldown has passed.
        _warn_minute_series_served_with_holes(series_key, asset, timestep, unresolved, _ibkr_monotonic())
    else:
        _RUNTIME_MINUTE_GAP_CHECKED_SERIES[series_key] = (
            _hourly_cache_signature(working),
            request_start,
            request_end,
            _minute_marker_recheck_at(working, start_dt=start_dt, end_dt=end_dt),
        )
    return working


def _minute_marker_recheck_at(df_cache: pd.DataFrame, *, start_dt: datetime, end_dt: datetime) -> Optional[datetime]:
    """Earliest future expiry of an empty-session marker inside the window, or None."""
    if df_cache is None or df_cache.empty or not {"missing", "missing_reason", "missing_retry_after"}.issubset(df_cache.columns):
        return None
    try:
        idx = pd.DatetimeIndex(df_cache.index)
        idx = idx.tz_localize(LUMIBOT_DEFAULT_PYTZ) if idx.tz is None else idx.tz_convert(LUMIBOT_DEFAULT_PYTZ)
        mask = (
            df_cache["missing"].fillna(False).astype(bool).to_numpy()
            & (df_cache["missing_reason"].fillna("").astype(str).to_numpy() == IBKR_MINUTE_GAP_MARKER_REASON)
            & (idx >= pd.Timestamp(_to_utc(start_dt))) & (idx <= pd.Timestamp(_to_utc(end_dt)))
        )
        if not bool(mask.any()):
            return None
        expiries = pd.to_datetime(df_cache.loc[mask, "missing_retry_after"], utc=True, errors="coerce").dropna()
        now = pd.Timestamp(_ibkr_history_now_utc())
        future = expiries[expiries > now]
        return future.min().to_pydatetime() if len(future) else None
    except Exception:
        return None


def _warn_minute_series_served_with_holes(
    series_key: str,
    asset: Asset,
    timestep: str,
    missing: list[tuple[pd.Timestamp, pd.Timestamp]],
    now_mono: float,
) -> None:
    """Say loudly that bars are being served with sessions missing inside the window.

    At most once a minute per series within one backtest. Each backtest data source sets its
    own downloader queue client id, so a new backtest in the same process always warns.
    """
    try:
        from lumibot.tools import data_downloader_queue_client as _queue

        backtest_id = str(getattr(getattr(_queue, "_queue_client", None), "client_id", "") or "")
    except Exception:
        backtest_id = ""
    warning_key = f"{series_key}|{backtest_id}"
    last = _RUNTIME_MINUTE_GAP_LAST_WARNING.get(warning_key)
    if last is not None and now_mono - last < IBKR_MINUTE_GAP_WARNING_INTERVAL_SECONDS:
        return
    _RUNTIME_MINUTE_GAP_LAST_WARNING[warning_key] = now_mono
    logger.warning(
        "IBKR %s %s history is missing %d session(s) inside the requested window (first %s, last %s); "
        "the downloader could not supply them. They are retried after %.0f s in this process and by the "
        "next backtest.",
        getattr(asset, "symbol", None),
        timestep,
        len(missing),
        missing[0][0].date(),
        missing[-1][0].date(),
        IBKR_MINUTE_GAP_RETRY_COOLDOWN_SECONDS,
    )


def _window_is_placeholder_covered(
    df_cache: pd.DataFrame,
    *,
    start_local: datetime,
    end_local: datetime,
    now: Optional[datetime] = None,
) -> bool:
    """Return True for an unexpired, confirmed no-data placeholder window.

    Legacy or ambiguous markers are intentionally retryable. Only markers written
    with an explicit confirmed outcome and future retry time may suppress a new
    process from asking the provider again.
    """
    required = {"missing", "missing_retry_after", "missing_outcome"}
    if df_cache is None or df_cache.empty or not required.issubset(df_cache.columns):
        return False

    try:
        missing_mask = df_cache["missing"].fillna(False).astype(bool)
    except Exception:
        return False

    if not bool(missing_mask.any()):
        return False

    missing_index = pd.DatetimeIndex(df_cache.index[missing_mask]).sort_values()
    if len(missing_index) < 2:
        return False

    left_candidates = missing_index[missing_index <= start_local]
    right_candidates = missing_index[missing_index >= end_local]
    if len(left_candidates) == 0 or len(right_candidates) == 0:
        return False

    left = left_candidates.max()
    right = right_candidates.min()
    if left > right:
        return False

    between = df_cache.loc[(df_cache.index >= left) & (df_cache.index <= right)]
    if between.empty or "missing" not in between.columns:
        return False

    try:
        if not bool(between["missing"].fillna(False).astype(bool).all()):
            return False
        outcomes = between["missing_outcome"].fillna("").astype(str)
        if not bool((outcomes == HistoryOutcome.CONFIRMED_NO_DATA.value).all()):
            return False
        if "missing_reason" in between.columns and bool(
            between["missing_reason"].fillna("").astype(str).eq(
                IBKR_LEGACY_INFERRED_TAIL_REASON
            ).any()
        ):
            return False
        retry_after = pd.to_datetime(
            between["missing_retry_after"], utc=True, errors="coerce"
        )
        if bool(retry_after.isna().any()):
            return False
        now_utc = pd.Timestamp(now or datetime.now(timezone.utc))
        if now_utc.tzinfo is None:
            now_utc = now_utc.tz_localize(timezone.utc)
        else:
            now_utc = now_utc.tz_convert(timezone.utc)
        return bool((retry_after > now_utc).all())
    except Exception:
        return False


def _record_missing_window(
    *,
    asset: Asset,
    quote: Optional[Asset],
    timestep: str,
    exchange: Optional[str],
    source: str,
    include_after_hours: bool,
    start_dt: datetime,
    end_dt: datetime,
    reason: str,
    outcome: HistoryOutcome,
    equity_basis: str | None = None,
) -> None:
    if outcome is not HistoryOutcome.CONFIRMED_NO_DATA:
        raise ValueError("Only confirmed_no_data may be persisted as a missing window")
    # Add a bracketing placeholder window (two rows) to cache.
    cache_file = _cache_file_for(
        asset=asset,
        quote=quote,
        timestep=timestep,
        exchange=exchange,
        source=source,
        include_after_hours=include_after_hours,
        equity_basis=equity_basis,
    )
    cache_manager = get_backtest_cache()
    try:
        cache_manager.ensure_local_file(
            cache_file,
            payload=_remote_payload(
                asset,
                quote,
                timestep,
                exchange,
                source,
                include_after_hours=include_after_hours,
            ),
        )
    except Exception:
        pass

    df = _read_cache_frame(cache_file)
    retry_after = datetime.now(timezone.utc) + timedelta(
        seconds=IBKR_GAP_RETRY_TTL_SECONDS
    )
    placeholder = pd.DataFrame(
        {
            "open": [pd.NA, pd.NA],
            "high": [pd.NA, pd.NA],
            "low": [pd.NA, pd.NA],
            "close": [pd.NA, pd.NA],
            "volume": [pd.NA, pd.NA],
            "missing": [True, True],
            "missing_retry_after": [retry_after.isoformat(), retry_after.isoformat()],
            "missing_reason": [str(reason)[:500], str(reason)[:500]],
            "missing_outcome": [outcome.value, outcome.value],
        },
        index=pd.DatetimeIndex([_to_utc(start_dt), _to_utc(end_dt)]).tz_convert(LUMIBOT_DEFAULT_PYTZ),
    )
    merged = _merge_frames(df, placeholder)
    _write_cache_frame(cache_file, merged)


def _crypto_day_bounds(start_local: datetime, end_local: datetime) -> tuple[datetime, datetime]:
    """Return inclusive midnight-to-midnight day bucket bounds in `LUMIBOT_DEFAULT_PYTZ`.

    LumiBot treats BACKTESTING_END as exclusive. If the requested end timestamp is exactly
    midnight, exclude that day from the derived daily series.
    """
    start_day = start_local.replace(hour=0, minute=0, second=0, microsecond=0)
    end_day = end_local.replace(hour=0, minute=0, second=0, microsecond=0)
    if end_local == end_day:
        end_day = end_day - pd.Timedelta(days=1)
    if end_day < start_day:
        end_day = start_day
    return start_day, end_day


def _derive_daily_from_intraday(
    intraday: pd.DataFrame,
    *,
    start_day: datetime,
    end_day: datetime,
) -> pd.DataFrame:
    """Derive daily OHLCV bars from an intraday OHLCV dataframe (crypto: 24/7 days)."""
    idx = pd.date_range(start=start_day, end=end_day, freq="D", tz=LUMIBOT_DEFAULT_PYTZ)
    if intraday is None or intraday.empty:
        out = pd.DataFrame(index=idx, columns=["open", "high", "low", "close", "volume", "missing"])
        out["missing"] = True
        return out

    df = intraday.copy()
    df.index = pd.to_datetime(df.index, utc=True, errors="coerce").tz_convert(LUMIBOT_DEFAULT_PYTZ)
    df = df[~df.index.isna()].sort_index()
    if df.empty:
        out = pd.DataFrame(index=idx, columns=["open", "high", "low", "close", "volume", "missing"])
        out["missing"] = True
        return out

    day_key = df.index.normalize()
    grouped = df.groupby(day_key)
    daily = pd.DataFrame(
        {
            "open": grouped["open"].first(),
            "high": grouped["high"].max(),
            "low": grouped["low"].min(),
            "close": grouped["close"].last(),
            "volume": grouped["volume"].sum(min_count=1) if "volume" in df.columns else pd.NA,
        }
    )
    daily_idx = pd.DatetimeIndex(daily.index)
    if daily_idx.tz is None:
        daily.index = daily_idx.tz_localize(LUMIBOT_DEFAULT_PYTZ)
    else:
        daily.index = daily_idx.tz_convert(LUMIBOT_DEFAULT_PYTZ)
    daily = daily.sort_index()
    daily["missing"] = False

    daily = daily.reindex(idx)
    close = pd.to_numeric(daily.get("close"), errors="coerce")
    daily["missing"] = daily["missing"].fillna(True) | close.isna()

    # IBKR crypto history is often effectively 24/5: weekend days may be absent even though
    # strategies are frequently configured as 24/7. To keep daily-cadence backtests stable
    # (no refresh loops / "missing BTC day"), forward-fill short gaps (<= 3 days) using the
    # prior close. This mirrors the existing Data.checker() tolerance window.
    if close is not None and not close.empty:
        filled_close = close.ffill(limit=3)
        filled_mask = close.isna() & filled_close.notna()
        if filled_mask.any():
            daily.loc[filled_mask, "close"] = filled_close[filled_mask]
            for col in ("open", "high", "low"):
                if col in daily.columns:
                    daily.loc[filled_mask, col] = pd.to_numeric(daily.loc[filled_mask, col], errors="coerce").fillna(
                        daily.loc[filled_mask, "close"]
                    )
            if "volume" in daily.columns:
                daily.loc[filled_mask, "volume"] = pd.to_numeric(daily.loc[filled_mask, "volume"], errors="coerce").fillna(0)
            daily.loc[filled_mask, "missing"] = False
    return daily


def _get_crypto_daily_bars(
    *,
    asset: Asset,
    quote: Optional[Asset],
    start_dt: datetime,
    end_dt: datetime,
    exchange: Optional[str],
    include_after_hours: bool,
    source: str,
) -> pd.DataFrame:
    """Return crypto daily bars aligned to midnight days in `LUMIBOT_DEFAULT_PYTZ`."""
    start_local = _to_utc(start_dt).astimezone(LUMIBOT_DEFAULT_PYTZ)
    end_local = _to_utc(end_dt).astimezone(LUMIBOT_DEFAULT_PYTZ)
    start_day, end_day = _crypto_day_bounds(start_local, end_local)

    exch = (exchange or os.environ.get("IBKR_CRYPTO_VENUE") or IBKR_DEFAULT_CRYPTO_VENUE).strip().upper()
    # IMPORTANT: keep derived daily bars in a separate cache namespace so we don't mix them with
    # legacy `bar=1d` results (which have different semantics and timestamps).
    derived_source = f"{source}_DERIVED_DAILY"
    cache_file = _cache_file_for(
        asset=asset,
        quote=quote,
        timestep="day",
        exchange=exch,
        source=derived_source,
        include_after_hours=include_after_hours,
    )
    cache = ParquetSeriesCache(
        cache_file,
        remote_payload=_remote_payload(
            asset,
            quote,
            "day",
            exch,
            derived_source,
            include_after_hours=include_after_hours,
        ),
    )
    cache.hydrate_remote()
    df_cache = cache.read()

    if not df_cache.empty:
        coverage_start = df_cache.index.min()
        coverage_end = df_cache.index.max()
    else:
        coverage_start = None
        coverage_end = None

    needs_fetch = (
        coverage_start is None
        or coverage_end is None
        or start_day < coverage_start
        or end_day > coverage_end
    )

    if needs_fetch:
        fetch_start = start_day if coverage_start is None else min(start_day, coverage_start)
        fetch_end = (end_day + pd.Timedelta(days=1)) if coverage_end is None else max(end_day + pd.Timedelta(days=1), coverage_end)

        hourly = _get_cached_bars_for_source(
            asset=asset,
            quote=quote,
            timestep="hour",
            start_dt=fetch_start,
            end_dt=fetch_end,
            exchange=exch,
            include_after_hours=include_after_hours,
            source=source,
        )
        daily = _derive_daily_from_intraday(hourly, start_day=fetch_start, end_day=(fetch_end - pd.Timedelta(days=1)))

        missing_days = daily.index[daily["missing"].fillna(True)]
        for day in missing_days:
            day_start = day
            day_end = day + pd.Timedelta(days=1) - pd.Timedelta(seconds=1)
            minute = _get_cached_bars_for_source(
                asset=asset,
                quote=quote,
                timestep="minute",
                start_dt=day_start,
                end_dt=day_end,
                exchange=exch,
                include_after_hours=True,
                source=source,
            )
            if minute is None or minute.empty:
                continue
            filled = _derive_daily_from_intraday(minute, start_day=day_start, end_day=day_start)
            if not filled.empty and not bool(filled["missing"].iloc[0]):
                daily.loc[day_start, ["open", "high", "low", "close", "volume"]] = filled.iloc[0][
                    ["open", "high", "low", "close", "volume"]
                ]
                daily.loc[day_start, "missing"] = False

        merged = ParquetSeriesCache.merge(df_cache, daily)
        cache.write(
            merged,
            remote_payload=_remote_payload(
                asset,
                quote,
                "day",
                exch,
                derived_source,
                include_after_hours=include_after_hours,
            ),
        )
        df_cache = merged

    if df_cache.empty:
        return df_cache

    frame = df_cache.loc[(df_cache.index >= start_day) & (df_cache.index <= end_day)].copy()
    if "missing" in frame.columns:
        frame = frame[~frame["missing"].fillna(False)]
    frame = _strip_missing_cache_metadata(frame)
    if "close" in frame.columns:
        frame["bid"] = pd.to_numeric(frame.get("bid", frame["close"]), errors="coerce").fillna(frame["close"])
        frame["ask"] = pd.to_numeric(frame.get("ask", frame["close"]), errors="coerce").fillna(frame["close"])
    return frame


def _get_futures_daily_bars(
    *,
    asset: Asset,
    quote: Optional[Asset],
    start_dt: datetime,
    end_dt: datetime,
    exchange: Optional[str],
    include_after_hours: bool,
    source: str,
) -> pd.DataFrame:
    """Derive `day` bars aligned to the `us_futures` session (not midnight).

    This is intentionally session-based because futures strategies commonly use
    `self.set_market("us_futures")` and LumiBot's backtesting clock advances based on that calendar.
    """

    try:
        import pandas_market_calendars as mcal
    except Exception:
        return pd.DataFrame()

    start_utc = _to_utc(start_dt)
    end_utc = _to_utc(end_dt)
    if start_utc > end_utc:
        start_utc, end_utc = end_utc, start_utc
    start_local = start_utc.astimezone(LUMIBOT_DEFAULT_PYTZ)
    end_local = end_utc.astimezone(LUMIBOT_DEFAULT_PYTZ)

    cal = mcal.get_calendar("us_futures")
    schedule = cal.schedule(
        start_date=pd.Timestamp(start_utc.date()) - pd.Timedelta(days=2),
        end_date=pd.Timestamp(end_utc.date()) + pd.Timedelta(days=2),
    )
    if schedule is None or schedule.empty:
        return pd.DataFrame()

    completed_end = min(end_utc, _ibkr_history_now_utc())
    requested_schedule = schedule.loc[
        (schedule["market_close"] >= start_utc) & (schedule["market_close"] <= completed_end)
    ]
    requested_closes = pd.DatetimeIndex(requested_schedule["market_close"])

    def with_daily_coverage(frame: pd.DataFrame) -> pd.DataFrame:
        present = requested_closes.intersection(frame.index) if not frame.empty else requested_closes[:0]
        missing = requested_closes.difference(present)
        record_history_health(
            series_id=_history_health_series_id(asset=asset, quote=quote, timestep="day",
                exchange=exchange, source=source, include_after_hours=include_after_hours),
            symbol=str(getattr(asset, "symbol", "") or ""),
            asset_type=_normalize_asset_type(getattr(asset, "asset_type", "")),
            timestep="day", requested_start=start_utc, requested_end=end_utc,
            outcome=HistoryOutcome.PARTIAL if len(missing) else HistoryOutcome.COMPLETE,
            expected_sessions=len(requested_closes), returned_sessions=len(present),
            missing_sessions=[str(ts.tz_convert(LUMIBOT_DEFAULT_PYTZ).date()) for ts in missing],
            reason="missing_futures_daily_sessions" if len(missing) else None,
        )
        return frame

    if requested_schedule.empty:
        return with_daily_coverage(pd.DataFrame())

    # Calendar padding finds the session containing a boundary. Fetch only the
    # sessions that can produce requested, completed daily bars. Fetching the
    # padded days would miss an otherwise warm cache and query future history.
    session_start = pd.Timestamp(requested_schedule["market_open"].min()).tz_convert("UTC").to_pydatetime()
    session_end = pd.Timestamp(requested_schedule["market_close"].max()).tz_convert("UTC").to_pydatetime()
    if session_start >= session_end:
        return pd.DataFrame()

    # Prefer hourly bars for speed (deriving daily from minute across long windows is too slow).
    intraday = _get_cached_bars_for_source(
        asset=asset,
        quote=quote,
        timestep="hour",
        start_dt=session_start,
        end_dt=session_end,
        exchange=exchange,
        include_after_hours=include_after_hours,
        source=source,
    )
    intraday_timestep = "hour"
    if intraday is None or intraday.empty:
        intraday = _get_cached_bars_for_source(
            asset=asset,
            quote=quote,
            timestep="minute",
            start_dt=session_start,
            end_dt=session_end,
            exchange=exchange,
            include_after_hours=include_after_hours,
            source=source,
        )
        intraday_timestep = "minute"
        if intraday is None or intraday.empty:
            return with_daily_coverage(pd.DataFrame())

    if _enable_futures_bid_ask_derivation():
        intraday, _ = _maybe_augment_futures_bid_ask(
            df_cache=intraday,
            asset=asset,
            quote=quote,
            timestep=intraday_timestep,
            start_dt=session_start,
            end_dt=session_end,
            exchange=exchange,
            include_after_hours=include_after_hours,
        )

    rows: list[dict[str, float]] = []
    idx: list[pd.Timestamp] = []
    minute_fallback: Optional[pd.DataFrame] = None
    for _, sess in requested_schedule.iterrows():
        open_local = pd.Timestamp(sess["market_open"]).tz_convert("UTC").tz_convert(LUMIBOT_DEFAULT_PYTZ)
        close_local = pd.Timestamp(sess["market_close"]).tz_convert("UTC").tz_convert(LUMIBOT_DEFAULT_PYTZ)
        if close_local < start_local or open_local > end_local:
            continue
        # Intraday timestamps mark bar starts. The close boundary begins the next
        # session and must not leak its first bar into this completed daily candle.
        window = intraday.loc[(intraday.index >= open_local) & (intraday.index < close_local)]
        if window.empty and intraday_timestep != "minute":
            if minute_fallback is None:
                minute_fallback = _get_cached_bars_for_source(
                    asset=asset,
                    quote=quote,
                    timestep="minute",
                    start_dt=session_start,
                    end_dt=session_end,
                    exchange=exchange,
                    include_after_hours=include_after_hours,
                    source=source,
                )
                if _enable_futures_bid_ask_derivation():
                    minute_fallback, _ = _maybe_augment_futures_bid_ask(
                        df_cache=minute_fallback,
                        asset=asset,
                        quote=quote,
                        timestep="minute",
                        start_dt=session_start,
                        end_dt=session_end,
                        exchange=exchange,
                        include_after_hours=include_after_hours,
                    )
            if minute_fallback is not None and not minute_fallback.empty:
                window = minute_fallback.loc[(minute_fallback.index >= open_local) & (minute_fallback.index < close_local)]
        if window.empty:
            continue

        open_px = float(window["open"].iloc[0]) if "open" in window.columns else float(window["close"].iloc[0])
        high_px = float(pd.to_numeric(window.get("high"), errors="coerce").max()) if "high" in window.columns else float(window["close"].max())
        low_px = float(pd.to_numeric(window.get("low"), errors="coerce").min()) if "low" in window.columns else float(window["close"].min())
        close_px = float(pd.to_numeric(window.get("close"), errors="coerce").iloc[-1])
        vol = float(pd.to_numeric(window.get("volume"), errors="coerce").fillna(0).sum()) if "volume" in window.columns else 0.0

        payload: dict[str, float] = {"open": open_px, "high": high_px, "low": low_px, "close": close_px, "volume": vol}
        if "bid" in window.columns:
            payload["bid"] = float(pd.to_numeric(window.get("bid"), errors="coerce").iloc[-1])
        if "ask" in window.columns:
            payload["ask"] = float(pd.to_numeric(window.get("ask"), errors="coerce").iloc[-1])

        rows.append(payload)
        idx.append(close_local)

    if not rows:
        return with_daily_coverage(pd.DataFrame())

    df = pd.DataFrame(rows, index=pd.DatetimeIndex(idx))
    df = df.sort_index()
    df.index = df.index.tz_convert(LUMIBOT_DEFAULT_PYTZ)
    return with_daily_coverage(df.loc[(df.index >= start_local) & (df.index <= end_local)])


def _resolve_conid(
    *,
    asset: Asset,
    quote: Optional[Asset],
    exchange: Optional[str],
    force_refresh: bool = False,
) -> int:
    global _RUNTIME_CONID_CACHE

    cache_file = Path(LUMIBOT_CACHE_FOLDER) / CACHE_SUBFOLDER / "conids.json"
    cache_manager = get_backtest_cache()

    asset_type = _normalize_asset_type(getattr(asset, "asset_type", ""))
    effective_exchange = exchange
    if asset_type in {"future", "cont_future"} and not effective_exchange:
        effective_exchange = _resolve_futures_exchange(getattr(asset, "symbol", ""))

    # Fast path: avoid repeated secdef/conid resolution in tight loops (for example minute-index
    # strategies repeatedly requesting SPX bars). For equivalent key variants, mirror historical
    # cache compatibility behavior.
    primary = _conid_key(asset=asset, quote=quote, exchange=effective_exchange)
    candidates = [primary.to_key()]
    if asset_type in {"future", "cont_future"}:
        if primary.quote_symbol:
            candidates.append(IbkrConidKey(primary.asset_type, primary.symbol, "", primary.exchange, primary.expiration).to_key())
        else:
            candidates.append(IbkrConidKey(primary.asset_type, primary.symbol, "USD", primary.exchange, primary.expiration).to_key())

    if not force_refresh:
        for key in candidates:
            cached_runtime = _RUNTIME_CONID_CACHE.get(key)
            if isinstance(cached_runtime, int) and cached_runtime > 0:
                return int(cached_runtime)

    try:
        cache_manager.ensure_local_file(cache_file, payload={"provider": "ibkr", "type": "conids"})
    except Exception:
        pass

    mapping: Dict[str, int] = {}
    if cache_file.exists():
        try:
            mapping = json.loads(cache_file.read_text(encoding="utf-8")) or {}
        except Exception:
            mapping = {}

    # Seed conids.json across cache namespaces.
    #
    # Production backtests often run with a fresh S3 cache version/prefix to simulate cold-cache
    # behavior. IBKR Client Portal cannot resolve conids for *expired* futures contracts, so
    # historical futures backtests depend on the shared conid registry (`ibkr/conids.json`).
    #
    # If the current cache namespace does not contain `conids.json`, fall back to the default
    # `v1` namespace and materialize it locally (and, when possible, upload it into the current
    # namespace) so we do not thrash the downloader in a hot loop.
    if (not mapping) and (not cache_file.exists()) and getattr(cache_manager, "enabled", False):
        settings = getattr(cache_manager, "_settings", None)
        try:
            backend = getattr(settings, "backend", None)
            bucket = str(getattr(settings, "bucket", "") or "")
            prefix = str(getattr(settings, "prefix", "") or "").strip("/")
            version = str(getattr(settings, "version", "") or "").strip("/")
        except Exception:
            backend = None
            bucket = ""
            prefix = ""
            version = ""

        if backend == "s3" and bucket and version and version != "v1":
            try:
                relative_path = cache_file.resolve().relative_to(Path(LUMIBOT_CACHE_FOLDER).resolve()).as_posix()
            except Exception:
                relative_path = f"{CACHE_SUBFOLDER}/conids.json"

            seed_components = [prefix, "v1", relative_path]
            seed_key = "/".join([c for c in seed_components if c])
            seed_mapping: Dict[str, int] = {}
            try:
                seed_mapping = _download_remote_conids_json(cache_manager, bucket=bucket, key=seed_key)
            except Exception as exc:
                if _is_not_found_error(cache_manager, exc):
                    seed_mapping = {}
                else:
                    seed_mapping = {}

            if seed_mapping:
                mapping = dict(seed_mapping)
                cache_file.parent.mkdir(parents=True, exist_ok=True)
                cache_file.write_text(json.dumps(mapping, indent=2, sort_keys=True), encoding="utf-8")
                try:
                    # Best-effort: upload into the current cache namespace so subsequent runs can
                    # reuse without re-downloading from the seed namespace.
                    _merge_upload_conids_json(cache_manager, cache_file, mapping=mapping, required_keys=set())
                except Exception:
                    pass

    # Conid keying is not fully uniform across historical caches (some runs key futures with
    # quote_symbol="USD", others omit it). For robustness (and to avoid unnecessary remote
    # lookups), try a small set of equivalent keys before falling back to the downloader.

    if not force_refresh:
        for key in candidates:
            cached = mapping.get(key)
            if isinstance(cached, int) and cached > 0:
                _RUNTIME_CONID_CACHE[key] = int(cached)
                return cached

    if asset_type not in {"future", "cont_future"} and not force_refresh:
        _load_negative_conid_cache()
        for key in candidates:
            neg_hit = _NEGATIVE_CONID_CACHE.get(key)
            if isinstance(neg_hit, dict):
                cached_msg = str(neg_hit.get("message") or "").strip() or (
                    f"IBKR conid lookup is negatively cached for {asset.symbol} (type={asset_type})."
                )
                logger.error("IBKR negative conid cache hit: %s", cached_msg)
                raise RuntimeError(cached_msg)

    if not force_refresh and asset_type in {"future", "cont_future"} and primary.expiration:
        same_month_cached = _lookup_same_month_future_conid_from_mapping(mapping=mapping, key=primary)
        if same_month_cached is not None:
            conid, actual_expiration = same_month_cached
            actual_date = _date_from_yyyymmdd(actual_expiration)
            if actual_date is not None:
                setattr(asset, "_ibkr_resolved_expiration", actual_date)
            logger.warning(
                "IBKR conid registry has no exact key for %s expiring %s on %s; using unambiguous same-month contract %s.",
                primary.symbol,
                primary.expiration,
                primary.exchange,
                actual_expiration,
            )
            for key in candidates:
                _RUNTIME_CONID_CACHE[key] = int(conid)
            return int(conid)

    keys_added: set[str] = set()
    if force_refresh:
        for key in candidates:
            _RUNTIME_CONID_CACHE.pop(key, None)
            _clear_negative_conid(key=key)
    conid = _lookup_conid_remote(asset=asset, quote=quote, exchange=effective_exchange, mapping=mapping, keys_added=keys_added)
    # Always persist under the primary key for forward consistency.
    primary_key = primary.to_key()
    conid_int = int(conid)
    prior_primary = mapping.get(primary_key)
    mapping[primary_key] = conid_int
    _RUNTIME_CONID_CACHE[primary_key] = conid_int
    if prior_primary != conid_int:
        keys_added.add(primary_key)
    if asset_type in {"future", "cont_future"}:
        # Mirror the primary conid under both quote_symbol variants for compatibility with
        # historical caches and older in-flight backtests.
        if primary.quote_symbol:
            alt_key = IbkrConidKey(primary.asset_type, primary.symbol, "", primary.exchange, primary.expiration).to_key()
        else:
            alt_key = IbkrConidKey(primary.asset_type, primary.symbol, "USD", primary.exchange, primary.expiration).to_key()
        prior_alt = mapping.get(alt_key)
        mapping[alt_key] = conid_int
        _RUNTIME_CONID_CACHE[alt_key] = conid_int
        if prior_alt != conid_int:
            keys_added.add(alt_key)

    for key in set(candidates + [primary_key]):
        _clear_negative_conid(key=key)

    cache_file.parent.mkdir(parents=True, exist_ok=True)
    cache_file.write_text(json.dumps(mapping, indent=2, sort_keys=True), encoding="utf-8")
    try:
        _merge_upload_conids_json(cache_manager, cache_file, mapping=mapping, required_keys=keys_added)
    except Exception:
        pass
    return int(conid)


def _is_not_found_error(cache_manager, exc: Exception) -> bool:
    try:
        fn = getattr(cache_manager, "_is_not_found_error", None)
        if callable(fn):
            return bool(fn(exc))
    except Exception:
        pass
    msg = str(exc).lower()
    return any(token in msg for token in ("nosuchkey", "not found", "404", "no such key"))


def _is_terminal_no_data_error(exc: Exception) -> bool:
    return classify_history_failure(exc).persist_negative_cache


def _download_remote_conids_json(cache_manager, *, bucket: str, key: str) -> Dict[str, int]:
    client = getattr(cache_manager, "_get_client", None)
    if not callable(client):
        return {}
    s3 = client()
    if not hasattr(s3, "get_object"):
        return {}
    response = s3.get_object(Bucket=bucket, Key=key)
    body = response.get("Body")
    raw = b""
    if body is not None:
        raw = body.read()
        try:
            body.close()
        except Exception:
            pass
    try:
        parsed = json.loads(raw.decode("utf-8"))
    except Exception:
        parsed = {}
    if not isinstance(parsed, dict):
        return {}
    out: Dict[str, int] = {}
    for k, v in parsed.items():
        try:
            iv = int(v)
        except Exception:
            continue
        if iv > 0:
            out[str(k)] = iv
    return out


def _persist_s3_marker(*, local_path: Path, remote_key: str) -> None:
    try:
        marker_path = local_path.with_suffix(local_path.suffix + ".s3key")
        marker_tmp = marker_path.with_suffix(marker_path.suffix + ".tmp")
        marker_path.parent.mkdir(parents=True, exist_ok=True)
        marker_tmp.write_text(remote_key, encoding="utf-8")
        os.replace(marker_tmp, marker_path)
    except Exception:
        pass


def _merge_upload_conids_json(
    cache_manager,
    local_path: Path,
    *,
    mapping: Dict[str, int],
    required_keys: set[str],
    max_attempts: int = 3,
) -> None:
    """Publish authoritative identities without overwriting unrelated stale local keys.

    Only required_keys were resolved by this lookup. An empty set denotes a
    namespace seed, which may fill absent keys but cannot replace existing ones.
    Conditional writes protect the read/merge/write from concurrent publishers.
    """
    global _DISABLE_CONIDS_REMOTE_UPLOAD, _LOGGED_CONIDS_REMOTE_UPLOAD_DISABLE

    if _DISABLE_CONIDS_REMOTE_UPLOAD:
        return

    if not cache_manager.enabled or cache_manager.mode != CacheMode.S3_READWRITE:
        cache_manager.on_local_update(local_path, payload={"provider": "ibkr", "type": "conids"})
        return

    settings = getattr(cache_manager, "_settings", None)
    if settings is None or getattr(settings, "backend", None) != "s3":
        cache_manager.on_local_update(local_path, payload={"provider": "ibkr", "type": "conids"})
        return

    remote_key = cache_manager.remote_key_for(local_path, payload={"provider": "ibkr", "type": "conids"})
    if not remote_key:
        cache_manager.on_local_update(local_path, payload={"provider": "ibkr", "type": "conids"})
        return

    bucket = str(getattr(settings, "bucket", "") or "")
    if not bucket:
        cache_manager.on_local_update(local_path, payload={"provider": "ibkr", "type": "conids"})
        return

    client_fn = getattr(cache_manager, "_get_client", None)
    if not callable(client_fn):
        cache_manager.on_local_update(local_path, payload={"provider": "ibkr", "type": "conids"})
        return
    s3 = client_fn()
    if not hasattr(s3, "put_object") or not hasattr(s3, "get_object"):
        logger.warning("IBKR registry publication requires conditional object writes; keeping local identities.")
        return

    updates = {key: mapping[key] for key in required_keys if key in mapping}
    seed = dict(mapping) if not required_keys else {}

    last_exc: Optional[Exception] = None
    for attempt in range(max_attempts):
        try:
            # Read the contents and ETag together. Never upload an entire stale map.
            conditions = {"IfNoneMatch": "*"}
            try:
                response = s3.get_object(Bucket=bucket, Key=remote_key)
                body = response["Body"]
                try:
                    remote = json.loads(body.read())
                finally:
                    body.close()
                if not isinstance(remote, dict) or not response.get("ETag"):
                    raise ValueError("IBKR registry object must contain a mapping and ETag")
                conditions = {"IfMatch": response["ETag"]}
            except Exception as exc:
                if _is_not_found_error(cache_manager, exc):
                    remote = {}
                else:
                    raise
            merged = dict(remote)
            for key, value in seed.items():
                merged.setdefault(key, value)
            merged.update(updates)
            if merged != remote:
                s3.put_object(Bucket=bucket, Key=remote_key,
                              Body=json.dumps(merged, indent=2, sort_keys=True).encode("utf-8"),
                              ContentType="application/json", **conditions)

            # A matching key with the wrong value is not successful publication.
            verified = _download_remote_conids_json(cache_manager, bucket=bucket, key=remote_key)
            if all(verified.get(key) == value for key, value in updates.items()) and set(seed).issubset(verified):
                mapping.clear()
                mapping.update(verified)
                local_path.parent.mkdir(parents=True, exist_ok=True)
                local_path.write_text(json.dumps(mapping, indent=2, sort_keys=True), encoding="utf-8")
                _persist_s3_marker(local_path=local_path, remote_key=remote_key)
                return

            # Lost update: retry after a short backoff.
            time.sleep(0.15 * (attempt + 1))
        except Exception as exc:
            last_exc = exc
            if _is_access_denied_error(exc):
                _DISABLE_CONIDS_REMOTE_UPLOAD = True
                if not _LOGGED_CONIDS_REMOTE_UPLOAD_DISABLE:
                    logger.warning("Disabling remote conids.json uploads due to AccessDenied: %s", exc)
                    _LOGGED_CONIDS_REMOTE_UPLOAD_DISABLE = True
                return
            time.sleep(0.15 * (attempt + 1))

    if last_exc is not None:
        logger.warning("IBKR conids.json merge-upload failed after retries: %s", last_exc)


_INDEX_OPTION_UNDERLYINGS = {"SPX", "SPXW", "VIX", "RUT", "NDX", "XSP"}


def _as_expiration_date(value):
    """Return a date for an option or future expiration, including ISO strings."""
    if value is None:
        return None
    if isinstance(value, datetime):
        return value.date()
    if hasattr(value, "strftime") and not isinstance(value, str):
        return value
    text = str(value).strip()
    for fmt, size in (("%Y-%m-%d", 10), ("%Y%m%d", 8), ("%m/%d/%Y", 10)):
        try:
            return datetime.strptime(text[:size], fmt).date()
        except ValueError:
            continue
    return None


def _option_strike_text(asset: Asset) -> str:
    strike = getattr(asset, "strike", None)
    try:
        number = float(strike)
    except (TypeError, ValueError):
        return _safe_component(str(strike or ""))
    if not math.isfinite(number):
        return ""
    if number.is_integer():
        return str(int(number))
    return str(number).replace(".", "p")


def _listed_option_strike(strike, listed) -> str:
    """Return the strike text from the chain that matches the requested strike."""
    try:
        target = float(strike)
    except (TypeError, ValueError) as exc:
        raise RuntimeError(f"IBKR option strike is not a number: {strike}") from exc
    if not math.isfinite(target):
        raise RuntimeError(f"IBKR option strike is not a number: {strike}")
    for item in listed or []:
        try:
            value = float(item)
        except (TypeError, ValueError):
            continue
        if abs(value - target) < 1e-4:
            if value.is_integer():
                return str(int(value))
            return str(value)
    raise RuntimeError(f"IBKR option chain has no strike {target}")


def _lookup_conid_option(
    *,
    asset: Asset,
    quote: Optional[Asset],
    exchange: Optional[str],
) -> int:
    """Resolve one listed option conid from strike, right, and expiration.

    Client Portal only returns option contracts after three calls, in order:
    search the underlying, ask for that month's strikes, then ask for the contract.
    A cached stock conid is not a substitute for the search call.
    """
    symbol = str(getattr(asset, "symbol", "") or "").strip().upper()
    expiration = _as_expiration_date(getattr(asset, "expiration", None))
    strike = getattr(asset, "strike", None)
    right_raw = str(getattr(asset, "right", "") or "").strip().upper()
    if expiration is None or strike is None or right_raw not in {"CALL", "PUT", "C", "P"}:
        raise RuntimeError(
            f"IBKR option conid needs expiration, strike, and call or put for {symbol or 'unknown'}"
        )
    right_code = "C" if right_raw.startswith("C") else "P"
    underlying_symbol = "SPX" if symbol == "SPXW" else symbol
    underlying_type = (
        Asset.AssetType.INDEX if symbol in _INDEX_OPTION_UNDERLYINGS else Asset.AssetType.STOCK
    )
    underlying = Asset(underlying_symbol, asset_type=underlying_type)
    underlying_conid = _resolve_conid(asset=underlying, quote=quote, exchange=exchange)
    try:
        maturity = expiration.strftime("%Y%m%d")
        month = expiration.strftime("%b%y").upper()
    except Exception as exc:
        raise RuntimeError(f"IBKR option expiration is not a date for {symbol}: {expiration}") from exc
    venue = (exchange or ("CBOE" if underlying_type == Asset.AssetType.INDEX else "SMART")).strip().upper()
    base_url = _downloader_base_url()
    search_sec_type = "IND" if underlying_type == Asset.AssetType.INDEX else "STK"
    queue_request(
        url=f"{base_url}/ibkr/iserver/secdef/search",
        querystring={"symbol": underlying_symbol, "secType": search_sec_type},
        headers=None,
        timeout=None,
    )
    strikes_payload = queue_request(
        url=f"{base_url}/ibkr/iserver/secdef/strikes",
        querystring={
            "conid": str(underlying_conid),
            "sectype": "OPT",
            "month": month,
            "exchange": venue,
        },
        headers=None,
        timeout=None,
    )
    side_key = "call" if right_code == "C" else "put"
    listed = strikes_payload.get(side_key) if isinstance(strikes_payload, dict) else None
    strike_text = _listed_option_strike(strike, listed if isinstance(listed, list) else [])
    payload = queue_request(
        url=f"{base_url}/ibkr/iserver/secdef/info",
        querystring={
            "conid": str(underlying_conid),
            "sectype": "OPT",
            "month": month,
            "strike": strike_text,
            "right": right_code,
            "exchange": venue,
        },
        headers=None,
        timeout=None,
    )
    contracts = payload if isinstance(payload, list) else []
    if isinstance(payload, dict):
        nested = payload.get("contracts") or payload.get("data") or []
        contracts = nested if isinstance(nested, list) else []
    matching = []
    for contract in contracts:
        if not isinstance(contract, dict):
            continue
        maturity_value = str(contract.get("maturityDate") or contract.get("expiry") or "")
        if maturity_value.startswith(maturity) and contract.get("conid") is not None:
            matching.append(contract)
    # On monthly expirations IBKR lists AM-settled SPX and PM-settled SPXW contracts with
    # the same maturity. Prefer the requested trading class; otherwise keep the first match.
    for contract in matching:
        if str(contract.get("tradingClass") or "").strip().upper() == symbol:
            return int(contract["conid"])
    if matching:
        return int(matching[0]["conid"])
    message = (
        f"Unable to resolve IBKR option conid for {symbol} {right_code} {_option_strike_text(asset)} {maturity}"
    )
    _record_negative_conid(
        key=_conid_key(asset=asset, quote=quote, exchange=exchange).to_key(),
        reason="no_option_conid",
        message=message,
    )
    raise RuntimeError(message)


def _lookup_conid_remote(
    *,
    asset: Asset,
    quote: Optional[Asset],
    exchange: Optional[str],
    mapping: Optional[Dict[str, int]] = None,
    keys_added: Optional[set[str]] = None,
) -> int:
    asset_type = _normalize_asset_type(getattr(asset, "asset_type", ""))
    if asset_type in {"future", "cont_future"}:
        if getattr(asset, "expiration", None) is None and asset_type != "cont_future" and not getattr(asset, "auto_expiry", None):
            raise ValueError(
                "IBKR futures require an explicit expiration on Asset(asset_type='future'). "
                "Use asset_type='cont_future' for continuous futures."
            )
        return _lookup_conid_future(asset=asset, exchange=exchange, mapping=mapping, keys_added=keys_added)
    if asset_type in {"crypto"}:
        return _lookup_conid_crypto(asset=asset, quote=quote)
    if asset_type == "option":
        return _lookup_conid_option(asset=asset, quote=quote, exchange=exchange)

    preferred_sec_types: tuple[str, ...] = ()
    if asset_type == "stock":
        preferred_sec_types = ("STK",)
    elif asset_type == "index":
        preferred_sec_types = ("IND",)

    requested_currency = str(getattr(quote, "symbol", "") or "").strip().upper() if asset_type == "stock" else ""
    contract_currencies: Dict[int, str] = {}

    def _payload_item_matches_sec_type(item: dict, allowed: tuple[str, ...]) -> bool:
        if not allowed:
            return True
        direct = str(item.get("secType") or "").upper()
        if direct in allowed:
            return True
        sections = item.get("sections")
        if isinstance(sections, list):
            for section in sections:
                if isinstance(section, dict) and str(section.get("secType") or "").upper() in allowed:
                    return True
        return False

    def _extract_conid(payload: Any, allowed: tuple[str, ...]) -> Optional[int]:
        if not isinstance(payload, list):
            return None
        for item in payload:
            if not isinstance(item, dict):
                continue
            if not _payload_item_matches_sec_type(item, allowed):
                continue
            conid = item.get("conid")
            if conid is not None:
                conid = int(conid)
                if requested_currency:
                    # A stock symbol can identify listings priced in different currencies.
                    # Search results omit currency; inspect each distinct contract once.
                    if conid not in contract_currencies:
                        info = _fetch_contract_info(conid)
                        contract_currencies[conid] = str(info.get("currency") or "").strip().upper()
                    if contract_currencies[conid] != requested_currency:
                        continue
                return conid
        return None

    base_url = _downloader_base_url()
    url = f"{base_url}/ibkr/iserver/secdef/search"

    if preferred_sec_types:
        for sec_type in preferred_sec_types:
            payload = queue_request(
                url=url,
                querystring={"symbol": asset.symbol, "secType": sec_type},
                headers=None,
                timeout=None,
            )
            conid = _extract_conid(payload, (sec_type,))
            if conid is not None:
                return int(conid)

    # Default: fall back to secdef search, but still filter ambiguous symbols by asset type.
    payload = queue_request(url=url, querystring={"symbol": asset.symbol}, headers=None, timeout=None)
    conid = _extract_conid(payload, preferred_sec_types)
    if conid is not None:
        return int(conid)

    currency_detail = f", currency={requested_currency}" if requested_currency else ""
    message = f"Unable to resolve IBKR conid for {asset.symbol} (type={asset_type}{currency_detail})"
    _record_negative_conid(key=_conid_key(asset=asset, quote=quote, exchange=exchange).to_key(), reason="no_conid", message=message)
    raise RuntimeError(message)


def _lookup_conid_crypto(*, asset: Asset, quote: Optional[Asset]) -> int:
    # Best-effort: IBKR crypto availability depends on region; conid mappings differ by venue.
    base_url = _downloader_base_url()
    url = f"{base_url}/ibkr/iserver/secdef/search"
    venue = (os.environ.get("IBKR_CRYPTO_VENUE") or IBKR_DEFAULT_CRYPTO_VENUE).strip().upper()
    desired_quote = str(getattr(quote, "symbol", "") or "").strip().upper() if quote is not None else ""
    payload = queue_request(
        url=url,
        querystring={"symbol": asset.symbol, "secType": "CRYPTO"},
        headers=None,
        timeout=None,
    )
    if not isinstance(payload, list):
        raise RuntimeError(f"Unexpected IBKR secdef/search response for crypto: {payload}")
    fallback_any: Optional[int] = None
    fallback_quote: Optional[int] = None
    for entry in payload:
        entry_currency = str(entry.get("currency") or "").strip().upper()
        conid = entry.get("conid")
        if conid is not None and fallback_any is None:
            try:
                fallback_any = int(conid)
            except Exception:
                fallback_any = None
        sections = entry.get("sections") or []
        for section in sections:
            if str(section.get("secType") or "").upper() == "CRYPTO":
                if venue:
                    exch = str(section.get("exchange") or "").upper()
                    if venue not in exch:
                        # Keep a best-effort fallback if the quote matches but the venue doesn't.
                        if fallback_quote is None:
                            try:
                                fallback_quote = int(conid) if conid is not None else None
                            except Exception:
                                fallback_quote = None
                        continue
                section_currency = str(section.get("currency") or "").strip().upper()
                resolved_currency = section_currency or entry_currency
                if desired_quote and resolved_currency and desired_quote != resolved_currency:
                    continue
                if conid is not None:
                    return int(conid)
    # Fallback: prefer any quote-matching crypto conid even if the venue metadata doesn't match.
    if fallback_quote is not None:
        return int(fallback_quote)
    # Final fallback: accept the first conid only when the caller didn't request a specific quote.
    if fallback_any is not None and not desired_quote:
        return int(fallback_any)
    raise RuntimeError(
        f"Unable to resolve IBKR crypto conid for {asset.symbol}/{getattr(quote,'symbol',None)} "
        f"(venue={venue or 'AUTO'})."
    )


def _future_contract_date_strings(contract: Dict[str, Any]) -> list[str]:
    """Return IBKR date fields for a listed futures contract in priority order."""
    dates: list[str] = []
    for field in ("expirationDate", "ltd", "lastTradeDate", "lastTradeDay", "lastTrade"):
        raw = contract.get(field)
        if raw is None:
            continue
        value = str(raw).strip()
        if value.isdigit() and len(value) == 8 and value not in dates:
            dates.append(value)
    return dates


def _future_contract_conid(contract: Dict[str, Any]) -> Optional[int]:
    try:
        conid = int(contract.get("conid"))
    except Exception:
        return None
    return conid if conid > 0 else None


def _remember_future_conid_mapping(
    *,
    mapping: Optional[Dict[str, int]],
    keys_added: Optional[set[str]],
    symbol: str,
    exchange: str,
    expiration: str,
    conid: int,
) -> None:
    if mapping is None:
        return
    if not (expiration.isdigit() and len(expiration) == 8 and conid > 0):
        return
    key_blank = IbkrConidKey("future", symbol, "", exchange, expiration).to_key()
    key_usd = IbkrConidKey("future", symbol, "USD", exchange, expiration).to_key()
    for key in (key_blank, key_usd):
        prior = mapping.get(key)
        if prior != conid:
            mapping[key] = conid
            if keys_added is not None:
                keys_added.add(key)


def _select_future_contract_for_target(
    *,
    contracts: list[Dict[str, Any]],
    target: str,
) -> tuple[Optional[Dict[str, Any]], str, bool, list[str]]:
    """Select a contract by exact date, then by unambiguous same contract month.

    IBKR's listed `expirationDate`/`ltd` can differ from LumiBot's synthetic expiration
    anchor by a day when a third Friday is a holiday. Same-month fallback is still strict:
    it only succeeds when IBKR returns exactly one conid for the target YYYYMM.
    """
    same_month: Dict[int, tuple[Dict[str, Any], str]] = {}
    same_month_dates: set[str] = set()
    target_month = target[:6]

    for contract in contracts:
        if not isinstance(contract, dict):
            continue
        conid = _future_contract_conid(contract)
        if conid is None:
            continue
        dates = _future_contract_date_strings(contract)
        if not dates:
            continue
        canonical_date = dates[0]
        if target in dates:
            return contract, canonical_date, False, []
        for candidate in dates:
            if target_month and candidate[:6] == target_month:
                same_month_dates.add(candidate)
                same_month.setdefault(conid, (contract, canonical_date))

    if len(same_month) == 1:
        contract, canonical_date = next(iter(same_month.values()))
        return contract, canonical_date, True, sorted(same_month_dates)

    return None, "", False, sorted(same_month_dates)


def _lookup_same_month_future_conid_from_mapping(
    *,
    mapping: Dict[str, int],
    key: IbkrConidKey,
) -> Optional[tuple[int, str]]:
    target = str(key.expiration or "")
    if not (target.isdigit() and len(target) == 8):
        return None
    target_month = target[:6]
    prefixes = (
        IbkrConidKey(key.asset_type, key.symbol, "", key.exchange, "").to_key(),
        IbkrConidKey(key.asset_type, key.symbol, "USD", key.exchange, "").to_key(),
    )
    matches: Dict[int, str] = {}
    for raw_key, raw_conid in mapping.items():
        raw_key_text = str(raw_key)
        if not any(raw_key_text.startswith(prefix) for prefix in prefixes):
            continue
        expiration = raw_key_text.rsplit("|", 1)[-1]
        if expiration == target:
            continue
        if not (expiration.isdigit() and len(expiration) == 8 and expiration[:6] == target_month):
            continue
        try:
            conid = int(raw_conid)
        except Exception:
            continue
        if conid > 0:
            matches.setdefault(conid, expiration)

    if len(matches) == 1:
        conid, expiration = next(iter(matches.items()))
        return conid, expiration
    return None


def _lookup_conid_future_tws(*, asset: Asset, exchange: str,
                             mapping: Optional[Dict[str, int]], keys_added: Optional[set[str]]) -> Optional[int]:
    """Discover one expired month through the shared downloader's existing TWS session."""
    symbol = str(asset.symbol).upper()
    root = IBKR_FUTURES_ROOT_ALIASES.get(symbol, symbol)
    target = asset.expiration.strftime("%Y%m%d")
    # For these roots the last trade date is in the month BEFORE delivery.
    # TWS interprets YYYYMM as delivery month, so truncating an expiry selects
    # the previous contract. YYYYMMDD explicitly means last trade date.
    lookup_expiry = target if symbol in {"NG", "CL", "MCL"} else target[:6]
    payload = queue_request(url=f"{_downloader_base_url()}/ibkr/tws/secdef/contracts",
                            querystring={"symbol": root, "exchange": exchange, "currency": "USD",
                                         "expiry": lookup_expiry}, timeout=45.0, max_timeout_attempts=1)
    if not isinstance(payload, dict) or not isinstance(payload.get("contracts"), list):
        raise RuntimeError("partial_history: malformed TWS futures identity payload")
    contracts = payload["contracts"]
    identities = {}
    for contract in contracts:
        if not isinstance(contract, dict):
            raise RuntimeError("partial_history: malformed TWS futures identity")
        expiry = str(contract.get("expiry") or "")
        conid = _future_contract_conid(contract)
        if (contract.get("symbol") != root or contract.get("exchange") != exchange
                or contract.get("secType") != "FUT" or contract.get("currency") != "USD"
                or len(expiry) != 8 or not expiry.isdigit() or not expiry.startswith(lookup_expiry)
                or _date_from_yyyymmdd(expiry) is None or conid is None):
            raise RuntimeError("partial_history: mismatched TWS futures contract identity")
        identities[(conid, expiry)] = contract
    if not identities:
        message = "partial_history: contract_identity_not_found; retry after 15 minutes or registry recovery"
        key = IbkrConidKey("future", root.upper(), "", exchange, target).to_key()
        _record_negative_conid(key=key, reason="tws_identity_retry_15m", message=message)
        raise RuntimeError(message)
    if len(identities) != 1:
        raise RuntimeError("partial_history: ambiguous TWS futures contract identity")
    conid, expiry = next(iter(identities))
    setattr(asset, "_ibkr_resolved_expiration", _date_from_yyyymmdd(expiry))
    _remember_future_conid_mapping(mapping=mapping, keys_added=keys_added, symbol=symbol,
                                   exchange=exchange, expiration=expiry, conid=conid)
    return conid


def _lookup_conid_future(
    *,
    asset: Asset,
    exchange: Optional[str],
    mapping: Optional[Dict[str, int]] = None,
    keys_added: Optional[set[str]] = None,
) -> int:
    base_url = _downloader_base_url()
    url = f"{base_url}/ibkr/trsrv/futures"
    desired_exchange = (exchange or "").strip().upper()
    if not desired_exchange:
        try:
            desired_exchange = _resolve_futures_exchange(getattr(asset, "symbol", ""))
        except IbkrFuturesExchangeAmbiguousError:
            raise
        except Exception:
            desired_exchange = (os.environ.get("IBKR_FUTURES_EXCHANGE") or IBKR_DEFAULT_FUTURES_EXCHANGE_FALLBACK).strip().upper()

    symbol_upper = str(getattr(asset, "symbol", "") or "").strip().upper()
    ibkr_root = IBKR_FUTURES_ROOT_ALIASES.get(symbol_upper, str(asset.symbol))
    expiration = getattr(asset, "expiration", None)
    target = expiration.strftime("%Y%m%d") if expiration is not None else ""
    expired = expiration is not None and not _is_future_or_current_expiration(expiration)

    # Negative cache: stop hammering IBKR for invalid roots/expirations. Aliased roots use
    # the IBKR root in their negative keys, so misses recorded under the Globex code (before
    # the alias existed) do not block the corrected lookup.
    _load_negative_conid_cache()
    neg_symbol = ibkr_root.upper() if symbol_upper in IBKR_FUTURES_ROOT_ALIASES else symbol_upper
    neg_root_key = IbkrConidKey("future", neg_symbol, "", desired_exchange, "").to_key()
    neg_target_key = IbkrConidKey("future", neg_symbol, "", desired_exchange, target).to_key() if target else ""
    neg_root_hit = _NEGATIVE_CONID_CACHE.get(neg_root_key)
    if isinstance(neg_root_hit, dict) and not expired:
        cached_msg = str(neg_root_hit.get("message") or "").strip() or (
            f"IBKR futures conid lookup is negatively cached for {symbol_upper} on {desired_exchange} (target={target or 'front_month'})."
        )
        logger.error("IBKR negative conid cache hit: %s", cached_msg)
        raise IbkrFuturesConidLookupError(cached_msg)
    neg_target_hit = _NEGATIVE_CONID_CACHE.get(neg_target_key) if neg_target_key else None
    if isinstance(neg_target_hit, dict):
        if neg_target_hit.get("reason") == "tws_identity_retry_15m":
            # Only a completed, empty TWS identity response creates this marker.
            # Re-evaluate its short deadline even in a long-lived process. The
            # shared positive registry is checked before reaching this method.
            retry_at = float(neg_target_hit.get("ts") or 0) + 900
            if time.time() < retry_at:
                raise RuntimeError("partial_history: contract_identity_retry_cooldown; retry after identity deadline")
        cached_msg = str(neg_target_hit.get("message") or "").strip() or (
            f"IBKR futures conid lookup is negatively cached for {symbol_upper} on {desired_exchange} (target={target})."
        )
        if _is_future_or_current_expiration(expiration) or expired:
            logger.warning("Ignoring future-dated IBKR negative conid cache entry and retrying: %s", cached_msg)
        else:
            logger.error("IBKR negative conid cache hit: %s", cached_msg)
            raise IbkrFuturesConidLookupError(cached_msg)

    query = {"symbols": ibkr_root, "exchange": desired_exchange, "secType": "FUT"}
    payload = queue_request(url=url, querystring=query, headers=None, timeout=None)
    # Response shape: { "<symbol>": [ {conid, expirationDate, ...}, ... ] }
    if not isinstance(payload, dict):
        # Some gateways require secType=CONTFUT to list contracts.
        payload = queue_request(
            url=url,
            querystring={"symbols": ibkr_root, "exchange": desired_exchange, "secType": "CONTFUT"},
            headers=None,
            timeout=None,
        )
    if not isinstance(payload, dict):
        raise RuntimeError(f"Unexpected IBKR trsrv/futures response: {payload}")
    contracts = payload.get(ibkr_root) or payload.get(ibkr_root.upper()) or []
    if not isinstance(contracts, list) or not contracts:
        if expired:
            discovered = _lookup_conid_future_tws(asset=asset, exchange=desired_exchange,
                                                  mapping=mapping, keys_added=keys_added)
            if discovered is not None:
                _clear_negative_conid(key=neg_target_key)
                _clear_negative_conid(key=neg_root_key)
                return discovered
        msg = f"No futures contracts returned for {symbol_upper} on {desired_exchange}"
        _record_negative_conid(key=neg_root_key, reason="no_contracts", message=msg)
        raise IbkrFuturesConidLookupError(msg)

    # Bulk-refresh: update conids.json with *all* returned contract months for this root+exchange.
    # This keeps the registry current via REST so we rarely/never need a new TWS backfill.
    if mapping is not None:
        for contract in contracts:
            if not isinstance(contract, dict):
                continue
            conid_int = _future_contract_conid(contract)
            if conid_int is None:
                continue

            for exp_str in _future_contract_date_strings(contract):
                _remember_future_conid_mapping(
                    mapping=mapping,
                    keys_added=keys_added,
                    symbol=symbol_upper,
                    exchange=desired_exchange,
                    expiration=exp_str,
                    conid=conid_int,
                )

    if expiration is not None:
        selected, actual_expiration, used_same_month, same_month_dates = _select_future_contract_for_target(
            contracts=contracts,
            target=target,
        )
        if selected is not None:
            conid_int = _future_contract_conid(selected)
            if conid_int is not None:
                if actual_expiration:
                    actual_date = _date_from_yyyymmdd(actual_expiration)
                    if actual_date is not None:
                        setattr(asset, "_ibkr_resolved_expiration", actual_date)
                    _remember_future_conid_mapping(
                        mapping=mapping,
                        keys_added=keys_added,
                        symbol=symbol_upper,
                        exchange=desired_exchange,
                        expiration=actual_expiration,
                        conid=conid_int,
                    )
                if used_same_month and actual_expiration:
                    _remember_future_conid_mapping(
                        mapping=mapping,
                        keys_added=keys_added,
                        symbol=symbol_upper,
                        exchange=desired_exchange,
                        expiration=target,
                        conid=conid_int,
                    )
                    logger.warning(
                        "IBKR did not list %s %s on %s exactly; using unambiguous same-month contract %s (conid=%s).",
                        symbol_upper,
                        target,
                        desired_exchange,
                        actual_expiration,
                        conid_int,
                    )
                elif actual_expiration and actual_expiration != target:
                    logger.warning(
                        "IBKR matched %s %s on %s by alternate date field; canonical listed date is %s (conid=%s).",
                        symbol_upper,
                        target,
                        desired_exchange,
                        actual_expiration,
                        conid_int,
                    )
                if neg_target_key:
                    _clear_negative_conid(key=neg_target_key)
                return int(conid_int)
        if expired:
            discovered = _lookup_conid_future_tws(asset=asset, exchange=desired_exchange,
                                                  mapping=mapping, keys_added=keys_added)
            if discovered is not None:
                _clear_negative_conid(key=neg_target_key)
                _clear_negative_conid(key=neg_root_key)
                return discovered
        msg = (
            f"IBKR did not return a conid for {symbol_upper} expiring {target} on {desired_exchange}. "
            "If this is an expired contract, IBKR Client Portal cannot reliably discover it. "
            "Ensure the IBKR conid registry (`<cache>/ibkr/conids.json`, S3-mirrored) contains the "
            "missing expiration. New contracts are expected to auto-populate via REST; only older "
            "historical discovery also uses the shared TWS gateway when available."
        )
        if same_month_dates:
            msg += (
                " IBKR returned same-month contract dates "
                f"{', '.join(same_month_dates)}, but they were not an unambiguous single contract."
            )
        if neg_target_key:
            _record_negative_conid(key=neg_target_key, reason="no_conid", message=msg)
        raise IbkrFuturesConidLookupError(msg)

    # Default: earliest expiration (front month) – used for smoke tests like MES.
    def _exp_key(item: Dict[str, Any]) -> int:
        try:
            return int(item.get("expirationDate") or 0)
        except Exception:
            return 0

    chosen = min(contracts, key=_exp_key)
    return int(chosen["conid"])


def _cache_file_for(
    *,
    asset: Asset,
    quote: Optional[Asset],
    timestep: str,
    exchange: Optional[str],
    source: str,
    include_after_hours: bool,
    equity_basis: str | None = None,
) -> Path:
    provider_root = Path(LUMIBOT_CACHE_FOLDER) / CACHE_SUBFOLDER
    asset_folder = _asset_folder(asset)
    _bar, _bar_seconds, timestep_component = _timestep_to_ibkr_bar(timestep)
    exch = (exchange or "").strip().upper() or "AUTO"
    symbol = _safe_component(getattr(asset, "symbol", "") or "symbol")
    quote_symbol = _safe_component(getattr(quote, "symbol", "") or "USD") if quote else "USD"
    expiration = _as_expiration_date(getattr(asset, "expiration", None))
    exp_component = expiration.strftime("%Y%m%d") if expiration else ""
    source_component = _safe_component(source)
    session_component = "AHR" if bool(include_after_hours) else "RTH"
    suffix = f"_{exp_component}" if exp_component else ""
    if _normalize_asset_type(getattr(asset, "asset_type", "")) == "option":
        suffix = f"{suffix}_{_option_strike_text(asset)}_{_safe_component(str(getattr(asset, 'right', '') or ''))}"
    # Legacy stock/index daily files can mix TWS prices shifted to the previous
    # date with correctly dated REST rows. Their provenance is insufficient to
    # repair those prices by shifting the whole frame. Rebuild only daily files
    # from provider data under a new key; leave the old files and intraday caches
    # intact for older readers and rollback.
    if asset_folder in {"stock", "index"} and _bar.endswith("d"):
        suffix += "_SESSION_DATE_V2"
    # Older traded bars may mix REST lots and TWS units without provenance.
    # Keep those files intact, but never hydrate them as normalized volume.
    # Quote-only and index caches carry no traded volume and remain reusable.
    if asset_folder != "index" and source_component in {"TRADES", "TRADES_DERIVED_DAILY"}:
        suffix += "_VOL_V1"
    if asset_folder == "stock" and equity_basis:
        if not re.fullmatch(r"SPLIT_V1_[a-f0-9]{64}", equity_basis):
            raise ValueError("Invalid equity split basis identity")
        suffix += "_" + equity_basis
    filename = (
        f"{asset_folder}_{symbol}_{quote_symbol}_{timestep_component}_{exch}_{source_component}_{session_component}"
        f"{suffix}.parquet"
    )
    return provider_root / asset_folder / timestep_component / "bars" / filename


def _asset_folder(asset: Asset) -> str:
    asset_type = _normalize_asset_type(getattr(asset, "asset_type", ""))
    if asset_type in {"crypto"}:
        return "crypto"
    if asset_type in {"future", "cont_future"}:
        return "future"
    return asset_type or "asset"


def _timestep_component(timestep: str) -> str:
    cleaned = str(timestep or "minute").strip().lower()
    return cleaned.replace(" ", "")


def _safe_component(value: str) -> str:
    return "".join(ch if ch.isalnum() or ch in {"_", "-"} else "_" for ch in value.upper())


def _timestep_to_ibkr_bar(timestep: str) -> Tuple[str, int, str]:
    raw = (timestep or "minute").strip().lower()
    raw = raw.replace(" ", "")
    raw = raw.replace("seconds", "second").replace("minutes", "minute").replace("hours", "hour").replace("days", "day")

    if raw in {"second", "1second", "s", "1s", "sec", "1sec"}:
        return "1sec", 1, "second"
    if raw.endswith("second"):
        qty = raw.removesuffix("second") or "1"
        seconds = int(qty)
        return f"{seconds}sec", seconds, f"{seconds}second"
    if raw.endswith("sec"):
        seconds = int(raw.removesuffix("sec") or "1")
        return f"{seconds}sec", seconds, f"{seconds}second"
    if raw.endswith("s") and raw[:-1].isdigit():
        seconds = int(raw[:-1] or "1")
        return f"{seconds}sec", seconds, f"{seconds}second"

    if raw in {"minute", "1minute", "m", "1m"}:
        return "1min", 60, "minute"
    if raw.endswith("minute"):
        qty = raw.removesuffix("minute") or "1"
        minutes = int(qty)
        return f"{minutes}min", minutes * 60, f"{minutes}minute"

    if raw in {"hour", "1hour", "h", "1h"}:
        return "1h", 60 * 60, "hour"
    if raw.endswith("hour"):
        qty = raw.removesuffix("hour") or "1"
        hours = int(qty)
        return f"{hours}h", hours * 60 * 60, f"{hours}hour"

    if raw in {"day", "1day", "d", "1d"}:
        return "1d", 24 * 60 * 60, "day"
    if raw.endswith("day"):
        qty = raw.removesuffix("day") or "1"
        days = int(qty)
        return f"{days}d", days * 24 * 60 * 60, f"{days}day"

    if raw.endswith("min"):
        minutes = int(raw.removesuffix("min") or "1")
        return f"{minutes}min", minutes * 60, f"{minutes}minute"

    raise ValueError(f"Unsupported IBKR timestep: {timestep}")


def _normalize_history_source(source: Optional[str]) -> str:
    raw = (source or os.environ.get("IBKR_HISTORY_SOURCE") or IBKR_DEFAULT_HISTORY_SOURCE).strip()
    if not raw:
        return IBKR_DEFAULT_HISTORY_SOURCE
    normalized = raw.strip().lower().replace("-", "_")
    if normalized in {"trades", "trade"}:
        return "Trades"
    if normalized in {"midpoint", "mid"}:
        return "Midpoint"
    if normalized in {"bid_ask", "bidask"}:
        return "Bid_Ask"
    raise ValueError(f"Unsupported IBKR history source '{source}'. Expected Trades, Midpoint, or Bid_Ask.")


def _get_cached_equity_actions(symbol: str, last_needed_datetime: Optional[datetime] = None) -> pd.DataFrame:
    """Return verified actions; provider failures are retryable, never cached as absence."""
    key = str(symbol or "").strip().upper()
    if not key:
        return pd.DataFrame(columns=["Dividends", "Stock Splits"])
    cache_key = key
    if isinstance(last_needed_datetime, datetime):
        try:
            # Bucket by date to maximize in-process reuse while keeping "needed coverage" stable.
            cache_key = f"{key}:{last_needed_datetime.date().isoformat()}"
        except Exception:
            cache_key = key

    cached = _IBKR_EQUITY_ACTIONS_CACHE.get(cache_key)
    if cached is not None:
        return cached

    actions = pd.DataFrame(columns=["Dividends", "Stock Splits"])
    try:
        from lumibot.tools.yahoo_helper import YahooHelper

        history = YahooHelper.get_symbol_data(
            key,
            interval="1d",
            caching=True,
            auto_adjust=False,
            last_needed_datetime=last_needed_datetime,
        )
        if not isinstance(history, pd.DataFrame) or history.empty:
            raise ValueError("empty corporate-action history")
        raw = history[["Dividends", "Stock Splits"]].apply(pd.to_numeric, errors="raise")
        if raw.isna().any().any() or not np.isfinite(raw.to_numpy()).all():
            raise ValueError("invalid corporate-action values")
        if (raw["Stock Splits"] < 0).any():
            raise ValueError("invalid split ratio")
        raw.index = pd.to_datetime(raw.index, errors="raise")
        if raw.index.isna().any() or raw.index.has_duplicates:
            raise ValueError("invalid corporate-action dates")
        if isinstance(last_needed_datetime, datetime):
            required_end = min(_to_utc(last_needed_datetime), datetime.now(timezone.utc))
            expected = _expected_us_daily_sessions(
                start_dt=required_end - timedelta(days=14), end_dt=required_end + timedelta(microseconds=1))
            if expected and raw.index.max().date() < expected[-1].date():
                raise ValueError("corporate-action history is stale")
        actions = raw.loc[(raw != 0).any(axis=1)].copy()
        if actions.index.tz is None:
            actions.index = actions.index.tz_localize(LUMIBOT_DEFAULT_PYTZ)
        else:
            actions.index = actions.index.tz_convert(LUMIBOT_DEFAULT_PYTZ)
        actions = actions.sort_index()
        actions.attrs["coverage_through"] = raw.index.max().date().isoformat()
    except Exception as exc:
        # Do not log provider payloads or memoize an empty table. A later call can
        # recover using the provider's normal persistent cache/retry path.
        raise RuntimeError(f"corporate_actions_unavailable: {key}") from exc

    _IBKR_EQUITY_ACTIONS_CACHE[cache_key] = actions
    return actions


def _verified_equity_cache(frame, snapshot):
    """An unversioned or interrupted mixed cache must be refetched, never guessed."""
    if frame is None or frame.empty:
        return frame
    from lumibot.tools.ibkr_equity_basis import EquityBasisError, assert_same_basis, decorate_adjusted_frame
    expected = decorate_adjusted_frame(pd.DataFrame(), snapshot, provider_prices_verified=True)
    try:
        assert_same_basis(frame, expected)
    except EquityBasisError:
        logger.warning("IBKR equity cache has unverified adjustment provenance; refetching")
        return pd.DataFrame()
    return frame


def _get_current_equity_basis(symbol: str):
    from lumibot.tools.ibkr_equity_basis import EquityBasisSnapshot
    now = _ibkr_history_now_utc()
    symbol = str(symbol).strip().upper()
    bucket = now.strftime("%Y-%m-%dT%H")
    cached = _IBKR_EQUITY_BASIS_CACHE.get(symbol)
    if cached is not None:
        # Keep a native-price snapshot stable for this process/session. Recovering
        # optional metadata must not relabel prices already returned to a run.
        native_same_day = (not cached[1].actions_verified and
                           pd.Timestamp(cached[1].as_of).tz_convert(LUMIBOT_DEFAULT_PYTZ).date() ==
                           now.astimezone(LUMIBOT_DEFAULT_PYTZ).date())
        if cached[0] == bucket or native_same_day:
            return cached[1]
    try:
        snapshot = _verified_current_equity_basis(symbol, now)
    except Exception:
        # IBKR already supplies split-adjusted TRADES prices. Failure of the
        # auxiliary action ledger is a warning, never proof of missing prices.
        # Do not expose provider payloads or certify a false empty action ledger.
        from lumibot.tools.ibkr_history_health import record_optional_corporate_action_issue
        record_optional_corporate_action_issue(symbol=symbol, when=now)
        logger.warning("IBKR %s corporate-action metadata unavailable; using native split-adjusted "
                       "prices. Cash dividends are unverified for this run.", symbol)
        snapshot = EquityBasisSnapshot.from_provider_adjusted_prices(as_of=now)
    _IBKR_EQUITY_BASIS_CACHE[symbol] = (bucket, snapshot)
    return snapshot


def _verified_current_equity_basis(symbol, now):
    """Optional enrichment; this function may fail without blocking IBKR prices."""
    from lumibot.tools.ibkr_equity_basis import EquityBasisSnapshot
    from lumibot.tools.helpers import get_trading_days
    local = now.astimezone(LUMIBOT_DEFAULT_PYTZ)
    sessions = get_trading_days(market="NYSE", start_date=(local - timedelta(days=14)).date(),
                               end_date=(local + timedelta(days=1)).date(), tzinfo=LUMIBOT_DEFAULT_PYTZ)
    if sessions is None or sessions.empty:
        raise RuntimeError(f"corporate_actions_unavailable: {symbol} session calendar unavailable")
    # Include today's effective actions even before its close; on weekends require
    # Friday, not an impossible Saturday daily row that causes full-history fetches.
    closes = pd.DatetimeIndex(sessions["market_close"]).tz_convert(LUMIBOT_DEFAULT_PYTZ)
    closes = closes[closes.date <= local.date()]
    latest_session = closes[-1]
    needed = latest_session.normalize().to_pydatetime()
    # A historical replay must still learn splits effective since its end date.
    # Reuse the provider's existing persistent cache, but demand current coverage.
    key = f"{symbol}:{needed.date().isoformat()}"
    _IBKR_EQUITY_ACTIONS_CACHE.pop(key, None)
    actions = _get_cached_equity_actions(symbol, last_needed_datetime=needed)
    coverage = actions.attrs.get("coverage_through")
    if not coverage:
        raise RuntimeError(f"corporate_actions_unavailable: {symbol} source coverage is unknown")
    if str(coverage) < needed.date().isoformat():
        raise RuntimeError(f"corporate_actions_unavailable: {symbol} current effective session is unverified")
    coverage = min(str(coverage), local.date().isoformat())
    snapshot = EquityBasisSnapshot.from_verified_actions(actions, as_of=now, coverage_through=coverage)
    return snapshot


def _append_equity_corporate_actions_daily(frame: pd.DataFrame, asset: Asset, *, actions=None) -> tuple[pd.DataFrame, bool]:
    """Append `dividend` + `stock_splits` columns to daily equity bars.

    WHY:
    - IBKR day bars do not include corporate actions in the history payload.
    - LumiBot dividend accounting reads these columns when present.
    - We enrich only stock/day bars, using Yahoo actions as a free, cached corporate-action
      source until a first-party IBKR corporate-actions endpoint is added to the downloader.
    """
    if frame is None or frame.empty:
        return frame, False
    if not _truthy_env("LUMIBOT_IBKR_ENRICH_EQUITY_CORPORATE_ACTIONS", "true"):
        return frame, False

    symbol = str(getattr(asset, "symbol", "") or "").strip().upper()
    if not symbol:
        return frame, False

    out = frame
    changed = False
    if "dividend" not in out.columns or "stock_splits" not in out.columns:
        out = out.copy()
        if "dividend" not in out.columns:
            out["dividend"] = 0.0
        if "stock_splits" not in out.columns:
            out["stock_splits"] = 0.0
        changed = True

    last_needed_datetime: Optional[datetime] = None
    try:
        if len(out.index):
            last_idx = pd.to_datetime(out.index, errors="coerce")
            if isinstance(last_idx, pd.DatetimeIndex) and len(last_idx) > 0 and not pd.isna(last_idx.max()):
                last_needed_datetime = last_idx.max().to_pydatetime()
    except Exception:
        last_needed_datetime = None

    if actions is None:
        try:
            actions = _get_cached_equity_actions(symbol, last_needed_datetime=last_needed_datetime)
        except Exception:
            from lumibot.tools.ibkr_history_health import record_optional_corporate_action_issue
            record_optional_corporate_action_issue(symbol=symbol, when=_ibkr_history_now_utc())
            actions = pd.DataFrame(columns=["Dividends", "Stock Splits"])
            actions.attrs["actions_verified"] = False
    if actions.attrs.get("actions_verified") is False:
        if (out.attrs.get("actions_verified") is False and
                out["dividend"].isna().all() and out["stock_splits"].isna().all()):
            return out, changed
        out = out.copy()
        # NaN represents unknown metadata. Accounting cannot credit a dividend
        # without evidence; the warning survives in settings/data-health output.
        out["dividend"] = np.nan
        out["stock_splits"] = np.nan
        out.attrs["actions_verified"] = False
        return out, True
    if out.attrs.get("actions_verified") is False:
        out = out.copy()
        out.attrs["actions_verified"] = True
        out["dividend"] = 0.0
        out["stock_splits"] = 0.0
        changed = True
    if actions.empty:
        # A verified correction can remove an event. Reusing prior columns would
        # retain a dividend or split the source no longer reports.
        if bool((out[["dividend", "stock_splits"]].fillna(0) != 0).any().any()):
            out = out.copy()
            out["dividend"] = 0.0
            out["stock_splits"] = 0.0
            changed = True
        return out, changed

    idx = pd.DatetimeIndex(out.index)
    if idx.tz is None:
        idx = idx.tz_localize(LUMIBOT_DEFAULT_PYTZ)
    else:
        idx = idx.tz_convert(LUMIBOT_DEFAULT_PYTZ)
    idx_dates = idx.date

    div_map: Dict[Any, float] = {}
    split_map: Dict[Any, float] = {}
    if "Dividends" in actions.columns:
        div_series = pd.to_numeric(actions["Dividends"], errors="coerce").fillna(0.0)
        div_map = div_series.groupby(actions.index.date).sum().to_dict()
    if "Stock Splits" in actions.columns:
        split_series = pd.to_numeric(actions["Stock Splits"], errors="coerce").fillna(0.0)
        split_map = split_series.groupby(actions.index.date).sum().to_dict()

    if div_map or split_map:
        dividends = pd.Series([float(div_map.get(day, 0.0)) for day in idx_dates], index=out.index)
        splits = pd.Series([float(split_map.get(day, 0.0)) for day in idx_dates], index=out.index)
        if not (out["dividend"].eq(dividends).all() and out["stock_splits"].eq(splits).all()):
            out = out.copy()
            out["dividend"] = dividends
            out["stock_splits"] = splits
            changed = True

    return out, changed


def _max_period_for_bar(bar: str) -> str:
    """Return an IBKR `period` that requests at most ~1000 datapoints for the bar size."""
    normalized = (bar or "").strip().lower()
    if normalized.endswith("sec"):
        multiplier = int(normalized.removesuffix("sec") or "1")
        return f"{IBKR_HISTORY_MAX_POINTS * multiplier}sec"
    if normalized.endswith("min"):
        multiplier = int(normalized.removesuffix("min") or "1")
        return f"{IBKR_HISTORY_MAX_POINTS * multiplier}min"
    if normalized.endswith("h"):
        multiplier = int(normalized.removesuffix("h") or "1")
        return f"{IBKR_HISTORY_MAX_POINTS * multiplier}h"
    if normalized.endswith("d"):
        multiplier = int(normalized.removesuffix("d") or "1")
        return f"{IBKR_HISTORY_MAX_POINTS * multiplier}d"
    return f"{IBKR_HISTORY_MAX_POINTS}min"


def _read_cache_frame(path: Path) -> pd.DataFrame:
    if not path.exists():
        return pd.DataFrame()
    try:
        df = pd.read_parquet(path)
    except Exception:
        return pd.DataFrame()
    if df is None or df.empty:
        return pd.DataFrame()
    if not isinstance(df.index, pd.DatetimeIndex):
        # Defensive: older caches might have a column index.
        if "datetime" in df.columns:
            df = df.set_index(pd.to_datetime(df["datetime"], utc=True, errors="coerce"))
            df = df.drop(columns=["datetime"], errors="ignore")
    df.index = pd.to_datetime(df.index, utc=True, errors="coerce")
    df = df[~df.index.isna()]
    df = df.sort_index()
    df.index = df.index.tz_convert(LUMIBOT_DEFAULT_PYTZ)
    if "missing" in df.columns:
        df["missing"] = df["missing"].fillna(False)
    else:
        df["missing"] = False
    return df


def _write_cache_frame(path: Path, df: pd.DataFrame) -> pd.DataFrame:
    path.parent.mkdir(parents=True, exist_ok=True)
    df_to_save = df.copy()
    if not isinstance(df_to_save.index, pd.DatetimeIndex):
        raise ValueError("IBKR cache frames must be indexed by datetime")
    df_to_save.to_parquet(path)

    def identity():
        stat = path.stat()
        return (stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns)

    written = identity()
    try:
        get_backtest_cache().on_local_update(path, payload=_remote_payload_from_path(path))
    except Exception:
        pass
    # Conditional publication can merge rows written concurrently into this file.
    # Return those rows to the owner so its next checkpoint cannot erase them.
    # Ordinary uploads leave the file untouched: no extra parse or remote read.
    if identity() != written:
        durable = _read_cache_frame(path)
        from lumibot.tools.ibkr_equity_basis import assert_same_basis
        assert_same_basis(df, durable)
        durable.attrs.update(df.attrs)
        return durable
    return df


def _contract_info_cache_file(conid: int) -> Path:
    provider_root = Path(LUMIBOT_CACHE_FOLDER) / CACHE_SUBFOLDER
    return provider_root / "future" / "contracts" / f"CONID_{int(conid)}.json"


def _read_json(path: Path) -> Dict[str, Any]:
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _write_json(path: Path, payload: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, sort_keys=True, default=str, indent=2), encoding="utf-8")
    try:
        get_backtest_cache().on_local_update(path, payload=_remote_payload_from_path(path))
    except Exception:
        pass


def _fetch_contract_info(conid: int) -> Dict[str, Any]:
    base_url = _downloader_base_url()
    url = f"{base_url}/ibkr/iserver/contract/{int(conid)}/info"
    payload = queue_request(url=url, querystring=None, headers=None, timeout=None)
    if payload is None:
        return {}
    if isinstance(payload, dict) and payload.get("error"):
        raise RuntimeError(f"IBKR contract info error: {payload.get('error')}")
    if not isinstance(payload, dict):
        return {}
    return payload


def _maybe_apply_future_contract_metadata(*, asset: Asset, exchange: Optional[str]) -> None:
    """Best-effort: populate futures multiplier + min_tick for accurate PnL and tick rounding."""
    asset_type = _normalize_asset_type(getattr(asset, "asset_type", ""))
    if asset_type not in {"future", "cont_future"}:
        return

    try:
        conid = _resolve_conid(asset=asset, quote=None, exchange=exchange)
    except Exception:
        return

    cache_file = _contract_info_cache_file(int(conid))
    cache = get_backtest_cache()
    try:
        cache.ensure_local_file(cache_file, payload={"provider": "ibkr", "type": "contract_info", "conid": int(conid)})
    except Exception:
        pass

    info = _read_json(cache_file)
    if not info:
        try:
            info = _fetch_contract_info(int(conid))
        except Exception:
            info = {}
        if info:
            _write_json(cache_file, info)

    if not info:
        return

    raw_mult = info.get("multiplier")
    try:
        mult_val = float(raw_mult) if raw_mult is not None else None
    except Exception:
        mult_val = None
    if mult_val and mult_val > 0:
        try:
            asset.multiplier = int(mult_val) if float(mult_val).is_integer() else mult_val  # type: ignore[assignment]
        except Exception:
            pass

    raw_tick = info.get("minTick") if "minTick" in info else info.get("min_tick")
    try:
        tick_val = float(raw_tick) if raw_tick is not None else None
    except Exception:
        tick_val = None
    if tick_val and tick_val > 0:
        try:
            setattr(asset, "min_tick", tick_val)
        except Exception:
            pass


def _remote_payload(
    asset: Asset,
    quote: Optional[Asset],
    timestep: str,
    exchange: Optional[str],
    source: str,
    include_after_hours: bool,
) -> Dict[str, object]:
    return {
        "provider": "ibkr",
        "symbol": getattr(asset, "symbol", None),
        "asset_type": str(getattr(asset, "asset_type", "") or ""),
        "quote": getattr(quote, "symbol", None) if quote else None,
        "timestep": timestep,
        "exchange": exchange,
        "source": source,
        "include_after_hours": bool(include_after_hours),
        "expiration": getattr(asset, "expiration", None).isoformat() if getattr(asset, "expiration", None) else None,
    }


def _remote_payload_from_path(path: Path) -> Dict[str, object]:
    return {"provider": "ibkr", "path": path.as_posix()}


def _conid_key(asset: Asset, quote: Optional[Asset], exchange: Optional[str]) -> IbkrConidKey:
    asset_type = _normalize_asset_type(getattr(asset, "asset_type", ""))
    symbol = str(getattr(asset, "symbol", "") or "")
    quote_symbol = str(getattr(quote, "symbol", "") or "") if quote else ""
    exch = (exchange or "").strip().upper()
    if asset_type == "crypto" and not exch:
        exch = (os.environ.get("IBKR_CRYPTO_VENUE") or IBKR_DEFAULT_CRYPTO_VENUE).strip().upper()
    expiration = ""
    if getattr(asset, "expiration", None) is not None:
        try:
            expiration = asset.expiration.strftime("%Y%m%d")  # type: ignore[union-attr]
        except Exception:
            expiration = str(asset.expiration)
    if asset_type == "option":
        expiration = f"{expiration}|{_option_strike_text(asset)}|{str(getattr(asset, 'right', '') or '').upper()}"
    return IbkrConidKey(
        asset_type=asset_type,
        symbol=symbol,
        quote_symbol=quote_symbol,
        exchange=exch,
        expiration=expiration,
    )


def _downloader_base_url() -> str:
    return os.environ.get("DATADOWNLOADER_BASE_URL", "http://127.0.0.1:8080").rstrip("/")


def _to_utc(dt_value: datetime) -> datetime:
    """Convert a datetime to UTC, treating naive datetimes as LumiBot local time.

    IMPORTANT: LumiBot uses `pytz` timezones. For pytz, you must NOT attach tzinfo via
    `datetime.replace(tzinfo=...)` because it can yield historical "LMT" offsets (e.g. -04:56
    for America/New_York) and create multi-hour gaps/misalignment in paginated history fetches.
    Use `tz.localize()` so DST rules apply correctly.
    """
    if isinstance(dt_value, pd.Timestamp):
        dt_value = dt_value.to_pydatetime()
    if dt_value.tzinfo is None:
        try:
            dt_value = LUMIBOT_DEFAULT_PYTZ.localize(dt_value)  # type: ignore[attr-defined]
        except Exception:
            # Fallback for non-pytz tzinfo implementations.
            dt_value = dt_value.replace(tzinfo=LUMIBOT_DEFAULT_PYTZ)
    return dt_value.astimezone(timezone.utc)
