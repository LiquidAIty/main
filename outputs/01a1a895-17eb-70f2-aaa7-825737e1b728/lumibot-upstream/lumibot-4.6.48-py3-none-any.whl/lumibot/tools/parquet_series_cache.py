from __future__ import annotations

import logging
import os
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Dict, Optional

import pandas as pd

from lumibot.constants import LUMIBOT_DEFAULT_PYTZ
from lumibot.tools.backtest_cache import get_backtest_cache

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class ParquetSeriesCache:
    """Provider-agnostic helper for parquet series caching.

    This standardizes the pattern we implement across data providers:
    - hydrate a local parquet path from remote cache (optional)
    - read and normalize into a tz-aware DatetimeIndex
    - merge updates and persist
    - allow placeholder rows to live in cache (e.g. `missing=True`)
    """

    path: Path
    remote_payload: Optional[Dict[str, object]] = None
    index_coercer: Optional[Callable[[pd.DataFrame], pd.DataFrame]] = None
    tz: Any = LUMIBOT_DEFAULT_PYTZ

    def hydrate_remote(self) -> None:
        cache_manager = get_backtest_cache()
        if cache_manager is None:
            return
        try:
            cache_manager.ensure_local_file(self.path, payload=self.remote_payload)
        except Exception:
            return

    def read(self) -> pd.DataFrame:
        if not self.path.exists():
            return pd.DataFrame()
        try:
            df = pd.read_parquet(self.path)
        except Exception:
            return pd.DataFrame()
        if df is None or df.empty:
            return pd.DataFrame()

        if self.index_coercer is not None:
            try:
                df = self.index_coercer(df)
            except Exception:
                return pd.DataFrame()

        if not isinstance(df.index, pd.DatetimeIndex):
            if "datetime" in df.columns:
                df = df.set_index(pd.to_datetime(df["datetime"], utc=True, errors="coerce"))
                df = df.drop(columns=["datetime"], errors="ignore")
            else:
                return pd.DataFrame()

        df.index = pd.to_datetime(df.index, utc=True, errors="coerce")
        df = df[~df.index.isna()]
        df = df.sort_index()
        try:
            df.index = df.index.tz_convert(self.tz)
        except Exception:
            try:
                df.index = df.index.tz_localize(self.tz)
            except Exception:
                pass

        if "missing" in df.columns:
            df["missing"] = df["missing"].fillna(False)
        return df

    def write(self, df: pd.DataFrame, *, remote_payload: Optional[Dict[str, object]] = None) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        df_to_save = df.copy()
        if not isinstance(df_to_save.index, pd.DatetimeIndex):
            raise ValueError("ParquetSeriesCache frames must be indexed by datetime")
        # Publish complete bytes atomically. Interrupted and concurrent writers
        # must never expose a truncated partition to another reader.
        fd, name = tempfile.mkstemp(prefix=self.path.name + ".", suffix=".tmp", dir=self.path.parent)
        os.close(fd)
        temporary = Path(name)
        try:
            df_to_save.to_parquet(temporary)
            temporary.replace(self.path)
        finally:
            temporary.unlink(missing_ok=True)
        cache_manager = get_backtest_cache()
        if cache_manager is None:
            return
        try:
            cache_manager.on_local_update(self.path, payload=remote_payload or self.remote_payload)
        except Exception:
            logger.debug("Remote cache upload failed for %s", self.path.as_posix(), exc_info=True)

    @staticmethod
    def merge(existing: pd.DataFrame, incoming: pd.DataFrame) -> pd.DataFrame:
        if existing is None or existing.empty:
            return incoming
        if incoming is None or incoming.empty:
            return existing
        merged = pd.concat([existing, incoming], axis=0).sort_index()
        merged = merged[~merged.index.duplicated(keep="last")]
        if "missing" in merged.columns:
            merged["missing"] = merged["missing"].fillna(False)
        return merged
