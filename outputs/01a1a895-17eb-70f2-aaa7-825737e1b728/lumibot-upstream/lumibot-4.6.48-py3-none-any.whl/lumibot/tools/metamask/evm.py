"""Native same-chain EVM balances, MetaMask quotes and managed transactions."""

from __future__ import annotations

import re
import time
from decimal import ROUND_CEILING, Context, Decimal, localcontext
from urllib.parse import urlsplit
from uuid import uuid4

import requests
from eth_utils import keccak

from .fees import estimate_fees, integer, receipt_fees
from .models import Binding, SwapIntent, decimal
from .provider import MetaMaskError, address, json_object

PROXY = "https://agentic-proxy.workers.cx.metamask.io/proxy/prd"
ZERO = "0x" + "0" * 40
_NATIVE = {ZERO, "0x" + "e" * 40, "native"}
_TRANSFER = "0x" + keccak(text="Transfer(address,address,uint256)").hex()
_HEX = re.compile(r"0x(?:[0-9a-fA-F]{2})*\Z")


class EvmWallet:
    def __init__(self, journal, provider, config, *, session=None):
        self.journal, self.provider = journal, provider
        self.agent_id, self.network = config["AGENT_ID"], config["NETWORK"]
        self.rpc_urls = dict(config.get("CHAIN_RPC_URLS", {}))
        self.gas_limits = dict(config.get("GAS_LIMITS", {}))
        self.session = session or requests.Session()
        self.session.trust_env = False
        self._owns_session = session is None
        self.epoch = str(uuid4())
        self._execution = journal.execution_lock(str(journal.binding(self.agent_id)["wallet"]))

    def _binding(self, *, execution=False, expected=None):
        record = self.journal.binding(self.agent_id)
        binding = Binding.parse(record)
        if (
            binding.network != self.network
            or record.get("projectId", self.provider.credentials().project_id) != self.provider.credentials().project_id
        ):
            raise MetaMaskError("IDENTITY_MISMATCH", "Wallet binding differs from the configured network or project")
        if execution and (not binding.enabled or binding.expires_at <= int(time.time() * 1000)):
            raise MetaMaskError("REVOKED", "Wallet binding expired or was revoked")
        if expected is not None and record != expected:
            raise MetaMaskError("POLICY_CHANGED", "Wallet authority changed after the quote was prepared")
        self.provider.verify_wallet(binding.wallet)
        if execution and self.provider.policy(binding.wallet).digest != binding.policy_digest:
            raise MetaMaskError("POLICY_CHANGED", "Provider policy differs from the reviewed binding")
        return binding, record

    def _rpc(self, chain, method, params):
        url = self.rpc_urls.get(str(chain), self.rpc_urls.get(chain))
        if not isinstance(url, str):
            raise MetaMaskError("RPC_REQUIRED", "Configure CHAIN_RPC_URLS for every approved EVM chain")
        parsed = urlsplit(url)
        if (
            (
                parsed.scheme != "https"
                and not (parsed.scheme == "http" and parsed.hostname in {"localhost", "127.0.0.1"})
            )
            or parsed.username
            or parsed.password
            or parsed.fragment
        ):
            raise MetaMaskError("INVALID_RPC", "Use an HTTPS chain RPC or explicit local test endpoint")

        def request(name, arguments):
            try:
                response = self.session.request(
                    "POST",
                    url,
                    json={"jsonrpc": "2.0", "id": 1, "method": name, "params": arguments},
                    timeout=(5, 30),
                    allow_redirects=False,
                )
                if response.status_code != 200:
                    raise ValueError("RPC HTTP failure")
                body = json_object(response.json(), "RPC response")
            except (requests.RequestException, ValueError):
                raise MetaMaskError("RPC_UNAVAILABLE", "Configured chain RPC did not return a valid response") from None
            if body.get("id") != 1 or body.get("jsonrpc") != "2.0" or "error" in body or "result" not in body:
                raise MetaMaskError("RPC_ERROR", "Configured chain RPC returned an error")
            return body["result"]

        if integer(request("eth_chainId", [])) != chain:
            raise MetaMaskError("CHAIN_MISMATCH", "RPC network differs from the approved chain")
        return request(method, params)

    def _proxy(self, route, params):
        try:
            response = self.session.request(
                "GET",
                PROXY + route,
                params=params,
                headers={
                    "Authorization": "Bearer " + self.provider.credentials().access_token,
                    "Client-Version": "lumibot-python/1",
                },
                timeout=(5, 45),
                allow_redirects=False,
            )
        except requests.RequestException:
            raise MetaMaskError("QUOTE_UNAVAILABLE", "MetaMask quote or price service is unavailable") from None
        if not 200 <= response.status_code < 300:
            raise MetaMaskError(
                "QUOTE_UNAVAILABLE", f"MetaMask quote or price service returned HTTP {response.status_code}"
            )
        try:
            return response.json()
        except ValueError:
            raise MetaMaskError("INVALID_RESPONSE", "MetaMask returned malformed quote or price data") from None

    @staticmethod
    def _scope(binding, asset):
        if asset.chain_id not in binding.chains or asset.identity not in {item.identity for item in binding.assets}:
            raise MetaMaskError("ASSET_DENIED", "Asset identity is absent from the reviewed wallet registry")

    def price(self, asset, quote=None):
        binding, _ = self._binding()
        self._scope(binding, asset)
        if quote is not None:
            self._scope(binding, quote)
        assets = [asset] + ([quote] if quote is not None else [])
        result = json_object(
            self._proxy(
                "/price/v3/spot-prices",
                {
                    "assetIds": ",".join(item.caip for item in assets),
                    "vsCurrency": "usd",
                    "includeMarketData": "false",
                    "cacheOnly": "false",
                    "useExternalProviders": "false",
                },
            )
        )
        prices = [
            decimal(json_object(result.get(item.caip), "token price").get("usd"), positive=True) for item in assets
        ]
        with localcontext(Context(prec=160)):
            return prices[0] / prices[1] if quote is not None else prices[0]

    def _balance(self, wallet, asset, block="latest"):
        if asset.address == "native":
            if asset.decimals != 18:
                raise MetaMaskError("NATIVE_DECIMALS_UNSUPPORTED", "Native EVM gas accounting requires 18 decimals")
            atomic = integer(self._rpc(asset.chain_id, "eth_getBalance", [wallet, block]))
        else:
            places = integer(
                self._rpc(asset.chain_id, "eth_call", [{"to": asset.address, "data": "0x313ce567"}, block])
            )
            if places != asset.decimals:
                raise MetaMaskError("TOKEN_DECIMALS_MISMATCH", "Onchain decimals differ from the reviewed registry")
            atomic = integer(
                self._rpc(
                    asset.chain_id,
                    "eth_call",
                    [{"to": asset.address, "data": "0x70a08231" + wallet[2:].rjust(64, "0")}, block],
                )
            )
        return asset.from_atomic(atomic)

    def account(self):
        binding, _ = self._binding()
        positions, equity = [], Decimal(0)
        with localcontext(Context(prec=160)):
            for asset in binding.assets:
                quantity = self._balance(binding.wallet, asset)
                if quantity == 0:
                    continue
                value = quantity * self.price(asset)
                equity += value
                positions.append(
                    {
                        "symbol": asset.symbol,
                        "asset": asset.record(),
                        "quantity": format(quantity, "f"),
                        "marketValue": format(value, "f"),
                    }
                )
        # USD is the valuation unit, not an invented spendable cash balance.
        return {
            "cash": "0",
            "positionsValue": format(equity, "f"),
            "equity": format(equity, "f"),
            "currency": "USD",
            "positions": positions,
        }

    @staticmethod
    def _quote_asset(raw, expected):
        item = json_object(raw, "quote asset")
        chain = item.get("chainId")
        if chain is not None and (type(chain) is not int or chain != expected.chain_id):
            raise MetaMaskError("QUOTE_MISMATCH", "Quote token belongs to another chain")
        contract = str(item.get("address", "")).lower()
        contract = "native" if contract in _NATIVE else address(contract)
        if contract != expected.address or item.get("decimals") != expected.decimals:
            raise MetaMaskError("QUOTE_MISMATCH", "Quote token differs from the approved contract or decimals")

    def _transaction(self, raw, binding, chain):
        item = json_object(raw, "quote transaction")
        if item.get("chainId") != chain or address(item.get("from")) != binding.wallet:
            raise MetaMaskError("QUOTE_MISMATCH", "Transaction chain or sender differs from the bound wallet")
        target, data = address(item.get("to")), item.get("data")
        if not isinstance(data, str) or not _HEX.fullmatch(data):
            raise MetaMaskError("INVALID_RESPONSE", "Quote calldata is malformed")
        value = integer(item.get("value", "0x0"))
        tx = {"from": binding.wallet, "to": target, "chainId": chain, "data": data, "value": hex(value)}
        quoted = item.get("gasLimit")
        configured = self.gas_limits.get(str(chain), self.gas_limits.get(chain))
        ceiling = configured if configured is not None else quoted
        if ceiling is None or integer(ceiling) <= 0:
            raise MetaMaskError("GAS_LIMIT_REQUIRED", "Quote or explicit GAS_LIMITS must bound each transaction")
        gas = integer(ceiling)
        if quoted is not None and integer(quoted) > gas:
            raise MetaMaskError("GAS_BUDGET_EXCEEDED", "Provider gas estimate exceeds the explicit owner ceiling")
        latest = json_object(self._rpc(chain, "eth_getBlockByNumber", ["latest", False]), "latest chain block")
        base = integer(latest.get("baseFeePerGas"))
        tip = integer(self._rpc(chain, "eth_maxPriorityFeePerGas", []))
        tx.update(gasLimit=hex(gas), maxFeePerGas=hex(2 * base + tip), maxPriorityFeePerGas=hex(tip))
        return tx

    def _quote(self, binding, intent):
        atomic = intent.source.to_atomic(intent.amount)
        result = self._proxy(
            "/bridge/getQuote",
            {
                "walletAddress": binding.wallet,
                "destWalletAddress": binding.wallet,
                "srcChainId": intent.source.chain_id,
                "destChainId": intent.destination.chain_id,
                "srcTokenAddress": ZERO if intent.source.address == "native" else intent.source.address,
                "destTokenAddress": ZERO if intent.destination.address == "native" else intent.destination.address,
                "srcTokenAmount": str(atomic),
                "slippage": intent.slippage_bps / 100,
                "resetApproval": "false",
                "insufficientBal": "false",
                "gasIncluded": "false",
                "gasIncluded7702": "false",
            },
        )
        if not isinstance(result, list) or not result:
            raise MetaMaskError("NO_ROUTE", "MetaMask returned no same-chain swap route")
        errors = []
        for raw in result:
            try:
                row = json_object(raw, "quote response")
                quote = json_object(row.get("quote"), "quote")
                if (
                    quote.get("srcChainId") != intent.source.chain_id
                    or quote.get("destChainId") != intent.destination.chain_id
                ):
                    raise MetaMaskError("QUOTE_MISMATCH", "Quote crossed the approved chain boundary")
                for key in ("walletAddress", "destWalletAddress"):
                    if quote.get(key) is not None and address(quote[key]) != binding.wallet:
                        raise MetaMaskError("QUOTE_MISMATCH", "Quote redirects the approved wallet")
                if (
                    quote.get("gasIncluded")
                    or quote.get("gasIncluded7702")
                    or quote.get("intent")
                    or quote.get("refuel")
                ):
                    raise MetaMaskError(
                        "ROUTE_UNSUPPORTED", "Gasless, delegated and cross-chain routes require separate qualification"
                    )
                self._quote_asset(quote.get("srcAsset"), intent.source)
                self._quote_asset(quote.get("destAsset"), intent.destination)
                sent = integer(quote.get("srcTokenAmount"))
                fees = json_object(quote.get("feeData"), "quote fees")
                if set(fees) - {"metabridge", "txFee"}:
                    raise MetaMaskError("FEE_UNSUPPORTED", "Quote fee decomposition contains unsupported charges")
                for fee in fees.values():
                    fee = json_object(fee)
                    amount = integer(fee.get("amount"))
                    if amount:
                        try:
                            self._quote_asset(fee.get("asset"), intent.source)
                        except MetaMaskError:
                            self._quote_asset(fee.get("asset"), intent.destination)
                        else:
                            sent += amount
                if sent != atomic:
                    raise MetaMaskError(
                        "QUOTE_MISMATCH", "Quote source amount plus source fees differs from exact input"
                    )
                minimum, output = integer(quote.get("minDestTokenAmount")), integer(quote.get("destTokenAmount"))
                if not 0 < minimum <= output or minimum < output * (10000 - intent.slippage_bps) // 10000:
                    raise MetaMaskError("SLIPPAGE_LIMIT", "Quote minimum output exceeds the allowed slippage")
                quote_id = row.get("quoteId")
                if not isinstance(quote_id, str) or not quote_id:
                    raise MetaMaskError("QUOTE_ID_REQUIRED", "Managed execution requires the provider quote ID")
                tx = self._transaction(row.get("trade"), binding, intent.source.chain_id)
                if integer(tx["value"]) != (atomic if intent.source.address == "native" else 0):
                    raise MetaMaskError("QUOTE_MISMATCH", "Quote transaction attaches unexpected native value")
                approvals = []
                if row.get("approval") is not None:
                    approval = json_object(row["approval"])
                    data = str(approval.get("data", ""))
                    if (
                        intent.source.address == "native"
                        or address(approval.get("to")) != intent.source.address
                        or integer(approval.get("value", "0x0")) != 0
                    ):
                        raise MetaMaskError("APPROVAL_MISMATCH", "Approval targets an unexpected token or native value")
                    if not re.fullmatch(r"0x095ea7b3[0-9a-fA-F]{128}", data):
                        raise MetaMaskError("APPROVAL_MISMATCH", "Only a bounded ERC20 approval is supported")
                    spender = address("0x" + data[34:74])
                    if data[10:34] != "0" * 24 or int(data[74:], 16) < atomic:
                        raise MetaMaskError("APPROVAL_MISMATCH", "Approval encoding or quoted allowance is invalid")
                    allowance = integer(
                        self._rpc(
                            intent.source.chain_id,
                            "eth_call",
                            [
                                {
                                    "to": intent.source.address,
                                    "data": "0xdd62ed3e"
                                    + binding.wallet[2:].rjust(64, "0")
                                    + spender[2:].rjust(64, "0"),
                                },
                                "latest",
                            ],
                        )
                    )
                    if allowance < atomic:
                        base_approval = {**approval, "data": "0x095ea7b3" + spender[2:].rjust(64, "0")}
                        if allowance:
                            approvals.append(
                                self._transaction(
                                    {**base_approval, "data": base_approval["data"] + "0" * 64},
                                    binding,
                                    intent.source.chain_id,
                                )
                            )
                        approvals.append(
                            self._transaction(
                                {**base_approval, "data": base_approval["data"] + format(atomic, "064x")},
                                binding,
                                intent.source.chain_id,
                            )
                        )
                return {
                    "quoteId": quote_id,
                    "trade": tx,
                    "approvals": approvals,
                    "minimumOutput": str(minimum),
                    "quotedAt": int(time.time() * 1000),
                    "expiresAt": int(time.time() * 1000) + 60_000,
                }
            except (MetaMaskError, ValueError) as error:
                errors.append(type(error).__name__)
        raise MetaMaskError(
            "NO_VERIFIABLE_ROUTE", "No quote matched the exact wallet, assets, amount, fees and transaction constraints"
        )

    def _save(self, operation, **changes):
        updated = {**operation, **changes, "updatedAt": int(time.time() * 1000)}
        self.journal.save(updated)
        return updated

    def submit(self, request):
        intent = SwapIntent.parse(request)
        with self._execution:
            prior = self.journal.get(self.agent_id, intent.identifier)
            if prior is not None:
                if prior["request"] != intent.record():
                    raise MetaMaskError("ID_CONFLICT", "Swap ID already belongs to different intent")
                return self._advance(prior)
            binding, record = self._binding(execution=True)
            self._scope(binding, intent.source)
            self._scope(binding, intent.destination)
            if self.network != "mainnet":
                raise MetaMaskError(
                    "SWAP_NETWORK_UNSUPPORTED", "MetaMask does not provide supported testnet swap routes"
                )
            if intent.slippage_bps > binding.max_slippage_bps:
                raise MetaMaskError("SLIPPAGE_LIMIT", "Swap exceeds the reviewed slippage limit")
            if intent.destination.address == "native":
                raise MetaMaskError(
                    "NATIVE_OUTPUT_UNSUPPORTED",
                    "Use the wrapped token; native output requires qualified trace verification",
                )
            quote = self._quote(binding, intent)
            native = next(
                (a for a in binding.assets if a.chain_id == intent.source.chain_id and a.address == "native"), None
            )
            if native is None:
                raise MetaMaskError("ASSET_DENIED", "Register the chain's native gas token before swap execution")
            quote["feeEstimates"] = [estimate_fees(self._rpc, tx) for tx in [*quote["approvals"], quote["trade"]]]
            gas = sum(integer(fee["totalEstimate"]) for fee in quote["feeEstimates"])
            with localcontext(Context(prec=160, rounding=ROUND_CEILING)):
                native_price = self.price(native)
                source_price = native_price if intent.source.identity == native.identity else self.price(intent.source)
                reservation = intent.amount * source_price + native.from_atomic(gas) * native_price
                native_required = native.from_atomic(gas) + (intent.amount if intent.source.address == "native" else 0)
            quote["nativeUsdPrice"] = format(native_price, "f")
            if (
                self._balance(binding.wallet, intent.source) < intent.amount
                or self._balance(binding.wallet, native) < native_required
            ):
                raise MetaMaskError("INSUFFICIENT_BALANCE", "Wallet cannot cover exact input and estimated total fees")
            operation, _ = self.journal.reserve(
                self.agent_id, intent.record(), format(reservation, "f"), expected_binding=record
            )
            self.journal.save_effect(
                operation,
                "swap-plan",
                {
                    **quote,
                    "binding": record,
                    "wallet": binding.wallet,
                    "projectId": self.provider.credentials().project_id,
                    "network": binding.network,
                    "ownerEpoch": self.epoch,
                },
            )
            return self._advance(operation)

    def _receipt(self, tx_hash, expected):
        chain = expected["chainId"]
        receipt = self._rpc(chain, "eth_getTransactionReceipt", [tx_hash])
        if receipt is None:
            return None
        receipt = json_object(receipt, "transaction receipt")
        transaction = json_object(self._rpc(chain, "eth_getTransactionByHash", [tx_hash]), "mined transaction")
        block_hash = receipt.get("blockHash")
        if not isinstance(block_hash, str) or not re.fullmatch(r"0x[0-9a-fA-F]{64}", block_hash):
            raise MetaMaskError("TRANSACTION_MISMATCH", "Mined receipt is missing a complete block identity")
        try:
            sender, recipient = address(transaction.get("from")), address(transaction.get("to"))
        except ValueError:
            raise MetaMaskError("TRANSACTION_MISMATCH", "Mined transaction addresses are malformed") from None
        if (
            str(transaction.get("hash", "")).lower() != tx_hash.lower()
            or sender != expected["from"]
            or recipient != expected["to"]
            or str(transaction.get("input", "")).lower() != expected["data"].lower()
            or integer(transaction.get("value")) != integer(expected["value"])
            or integer(transaction.get("chainId")) != chain
            or integer(transaction.get("nonce")) != expected["nonce"]
            or str(receipt.get("transactionHash", "")).lower() != tx_hash.lower()
            or receipt.get("blockHash") != transaction.get("blockHash")
        ):
            raise MetaMaskError("TRANSACTION_MISMATCH", "Mined transaction differs from the persisted managed intent")
        if integer(transaction.get("gas")) > integer(expected["gasLimit"]) or integer(
            transaction.get("maxFeePerGas")
        ) > integer(expected["maxFeePerGas"]):
            raise MetaMaskError("GAS_BUDGET_EXCEEDED", "Mined transaction exceeded its frozen gas budget")
        number = integer(receipt.get("blockNumber"))
        if integer(transaction.get("blockNumber")) != number:
            raise MetaMaskError("TRANSACTION_MISMATCH", "Transaction and receipt block heights differ")
        finalized = self._rpc(chain, "eth_getBlockByNumber", ["finalized", False])
        if finalized is None:
            return None
        finalized = json_object(finalized, "finalized block")
        if not isinstance(finalized.get("hash"), str) or not re.fullmatch(r"0x[0-9a-fA-F]{64}", finalized["hash"]):
            raise MetaMaskError("FINALITY_UNAVAILABLE", "Configured RPC did not provide a verifiable finalized block")
        if integer(finalized.get("number")) < number:
            return None
        block = json_object(self._rpc(chain, "eth_getBlockByNumber", [hex(number), False]), "receipt block")
        if (
            block.get("hash") != block_hash
            or integer(block.get("number")) != number
            or (integer(finalized["number"]) == number and finalized["hash"] != receipt.get("blockHash"))
        ):
            raise MetaMaskError("REORG_PENDING", "Receipt is not on the current canonical chain")
        return receipt

    def _advance(self, operation):
        try:
            return self._advance_inner(operation)
        except MetaMaskError as error:
            current = self.journal.get(self.agent_id, str(operation["id"]))
            if current is None:
                raise
            return self._save(current, state="unknown", lastErrorCode=error.code, message=str(error))

    def _advance_inner(self, operation):
        if operation.get("settlementRecheckRequired") or (
            operation["state"] == "filled" and operation.get("settlementFinality") != "rpc_finalized"
        ):
            # Persist the read-only lane before validation, including when old evidence is malformed.
            operation = self._save(operation, state="unknown", settlementRecheckRequired=True)
            return self._reconcile_completed(operation)
        if operation["state"] in {"filled", "rejected", "canceled"}:
            return operation
        intent = SwapIntent.parse(json_object(operation["request"]))
        original_plan = self.journal.effect(self.agent_id, str(operation["id"]), "swap-plan")
        if original_plan is None:
            return self._save(
                operation,
                state="unknown",
                message="Legacy swap needs explicit transaction-hash reconciliation; no replay",
            )
        execution_plan = self.journal.effect(self.agent_id, str(operation["id"]), "swap-execution-plan")
        plan = execution_plan or original_plan
        transactions = [*plan["approvals"], plan["trade"]]
        receipts = []
        actual_fees = []
        fee_estimates = plan.get("feeEstimates")
        fee_budget = (
            sum(integer(fee["totalEstimate"]) for fee in fee_estimates)
            if fee_estimates is not None
            else sum(
                integer(tx["gasLimit"]) * integer(tx["maxFeePerGas"])
                for tx in [*original_plan["approvals"], original_plan["trade"]]
            )
        )
        for index, tx in enumerate(transactions):
            step = "swap-" + str(index)
            effect = self.journal.effect(self.agent_id, intent.identifier, step)
            if effect is None:
                if plan["ownerEpoch"] != self.epoch:
                    return self._save(
                        operation,
                        state="rejected",
                        message="Interrupted swap was not submitted; existing approvals may remain",
                    )
                try:
                    binding, _ = self._binding(execution=True, expected=plan["binding"])
                    if index == len(transactions) - 1 and plan["approvals"] and execution_plan is None:
                        # Finalized allowances can outlive the original trade quote.
                        refreshed = self._quote(binding, intent)
                        if refreshed["approvals"] or integer(refreshed["minimumOutput"]) < integer(
                            original_plan["minimumOutput"]
                        ):
                            raise MetaMaskError(
                                "REQUOTE_REQUIRED",
                                "Fresh trade needs new allowances or weakens the original minimum output",
                            )
                        plan = {**plan, **refreshed, "approvals": plan["approvals"]}
                        self.journal.save_effect(operation, "swap-execution-plan", plan)
                        tx = plan["trade"]
                    if int(time.time() * 1000) >= integer(plan["expiresAt"]):
                        raise MetaMaskError("QUOTE_EXPIRED", "Swap quote expired before managed submission")
                except MetaMaskError as error:
                    return self._save(operation, state="rejected", lastErrorCode=error.code, message=str(error))
                # Simulate after prior allowances mine, within the frozen gas budget.
                estimate = integer(
                    self._rpc(
                        tx["chainId"],
                        "eth_estimateGas",
                        [
                            {
                                **{k: v for k, v in tx.items() if k not in {"gasLimit", "chainId"}},
                                "gas": tx["gasLimit"],
                                "chainId": hex(tx["chainId"]),
                            }
                        ],
                    )
                )
                if estimate > integer(tx["gasLimit"]):
                    return self._save(
                        operation,
                        state="rejected",
                        message="Simulation exceeds frozen gas ceiling; allowances may remain",
                    )
                tx = {
                    **tx,
                    "nonce": integer(self._rpc(tx["chainId"], "eth_getTransactionCount", [plan["wallet"], "pending"])),
                }
                fresh_fees = estimate_fees(self._rpc, tx)
                remaining_fees = (
                    sum(integer(fee["totalEstimate"]) for fee in fee_estimates[index + 1 :])
                    if fee_estimates is not None
                    else 0
                )
                if (
                    sum(integer(fee["totalFee"]) for fee in actual_fees)
                    + integer(fresh_fees["totalEstimate"])
                    + remaining_fees
                    > fee_budget
                ):
                    return self._save(
                        operation,
                        state="rejected",
                        lastErrorCode="REQUOTE_REQUIRED",
                        message="Current fee estimate exceeds the reservation; prior allowances may remain",
                    )
                effect = {
                    "requestId": str(uuid4()),
                    "transaction": tx,
                    "wallet": plan["wallet"],
                    "network": self.network,
                    "projectId": plan["projectId"],
                    "quoteId": plan["quoteId"],
                    "feeEstimate": fresh_fees,
                    "state": "requested",
                    "ownerEpoch": self.epoch,
                }
                try:
                    self._binding(execution=True, expected=plan["binding"])
                    with self.journal.submission(self.agent_id, plan["binding"]):
                        if int(time.time() * 1000) >= integer(plan["expiresAt"]):
                            raise MetaMaskError("QUOTE_EXPIRED", "Swap quote expired before managed submission")
                        self.journal.save_effect(operation, step, effect)
                        operation = self._save(
                            operation,
                            state="unknown",
                            message="Managed transaction prepared; reconcile original request ID",
                        )
                        job = self.provider.submit_transaction(
                            effect["requestId"],
                            tx,
                            quote_id=plan["quoteId"] if index == len(transactions) - 1 else None,
                            intent="Same-chain exact-input swap"
                            if index == len(transactions) - 1
                            else "Bounded token allowance",
                        )
                except MetaMaskError as error:
                    if self.journal.effect(self.agent_id, intent.identifier, step) is None:
                        return self._save(operation, state="rejected", lastErrorCode=error.code, message=str(error))
                    return operation
            else:
                tx = effect["transaction"]
                try:
                    job = self.provider.transaction(effect["requestId"], tx)
                except MetaMaskError:
                    if not effect.get("txHash"):
                        return operation
                    job = {"status": effect["state"]}
            if job.get("txHash"):
                effect = {**effect, "txHash": job["txHash"], "state": job["status"]}
                self.journal.save_effect(operation, step, effect)
                operation = self._save(operation, hashes=list(dict.fromkeys([*operation["hashes"], job["txHash"]])))
            if not effect.get("txHash"):
                if job["status"] in {"DENIED", "EXPIRED"}:
                    return self._save(
                        operation,
                        state="rejected",
                        message="Managed transaction denied or expired; earlier allowances may remain",
                    )
                return self._save(
                    operation,
                    state="awaiting_approval" if job["status"] == "AWAITING_MFA" else "unknown",
                    approvalId=effect["requestId"],
                    message="Managed transaction pending; MetaMask may broadcast after approval",
                )
            try:
                receipt = self._receipt(effect["txHash"], tx)
            except MetaMaskError as error:
                return self._save(operation, state="unknown", lastErrorCode=error.code, message=str(error))
            if receipt is None:
                return self._save(operation, state="submitted")
            receipts.append(receipt)
            fees = receipt_fees(
                self._rpc,
                tx["chainId"],
                receipt,
                fee_estimates[index]["model"] if fee_estimates is not None else None,
            )
            actual_fees.append(fees)
            self.journal.save_effect(operation, step, {**effect, "actualFees": fees})
            spent = sum(integer(fee["totalFee"]) for fee in actual_fees)
            review = {}
            if spent > fee_budget:
                review = {
                    "budgetReviewRequired": True,
                    "feeBudgetOverrun": {
                        "chainId": tx["chainId"],
                        "reservedAtomic": str(fee_budget),
                        "actualAtomic": str(spent),
                    },
                }
                if plan.get("nativeUsdPrice") is not None:
                    with localcontext(Context(prec=160, rounding=ROUND_CEILING)):
                        # Native EVM accounting already requires 18 decimals at balance validation.
                        extra_usd = Decimal(spent - fee_budget).scaleb(-18) * decimal(
                            plan["nativeUsdPrice"], positive=True
                        )
                        adjusted = decimal(operation["reservedUsd"], positive=True) + extra_usd
                    review["feeAdjustedReservationUsd"] = format(adjusted, "f")
            operation = self._save(
                operation,
                fees=[
                    {
                        "asset": "native",
                        "chainId": intent.source.chain_id,
                        "atomicAmount": str(spent),
                    }
                ],
                **review,
            )
            if integer(receipt.get("status")) != 1:
                return self._save(
                    operation,
                    state="rejected",
                    message="Transaction reverted; earlier allowances and gas costs may remain",
                )
        # Receipt logs establish net ERC20 output, not the quoted estimate.
        if intent.destination.address == "native":
            return self._save(
                operation,
                state="unknown",
                message="Native-output receipt needs supported trace verification; no replacement swap",
            )
        output_atomic = self._received_output(receipts[-1], intent.destination, plan["wallet"])
        if output_atomic < integer(plan["minimumOutput"]):
            return self._save(
                operation, state="unknown", message="Mined output does not satisfy the frozen quote minimum"
            )
        output = intent.destination.from_atomic(output_atomic)
        return self._save(
            operation,
            state="filled",
            filledQuantity=format(output, "f"),
            inputAmount=format(intent.amount, "f"),
            outputAmount=format(output, "f"),
            settlementFinality="rpc_finalized",
            lastErrorCode=None,
            message="Managed swap transaction and net output reconciled",
        )

    @staticmethod
    def _received_output(receipt, destination, wallet):
        output_atomic = 0
        logs = receipt.get("logs")
        if not isinstance(logs, list):
            raise MetaMaskError("INVALID_RESPONSE", "Mined receipt is missing its output transfer logs")
        for raw in logs:
            log = json_object(raw, "receipt log")
            topics = log.get("topics")
            if (
                str(log.get("address", "")).lower() == destination.address
                and isinstance(topics, list)
                and len(topics) == 3
                and str(topics[0]).lower() == _TRANSFER
            ):
                wallet_topic = "0x" + wallet[2:].rjust(64, "0")
                units = integer(log.get("data"))
                if str(topics[2]).lower() == wallet_topic:
                    output_atomic += units
                if str(topics[1]).lower() == wallet_topic:
                    output_atomic -= units
        return output_atomic

    def _reconcile_completed(self, operation):
        """Upgrade old inclusion-only settlement evidence without any mutation request."""
        try:
            intent = SwapIntent.parse(json_object(operation.get("request"), "completed swap intent"))
            binding = Binding.parse(self.journal.binding(self.agent_id))
        except (ValueError, TypeError):
            raise MetaMaskError("SETTLEMENT_UNRESOLVED", "Completed swap intent or binding is malformed") from None
        hashes = operation.get("hashes")
        if (
            not isinstance(hashes, list)
            or not hashes
            or any(not isinstance(value, str) or not re.fullmatch(r"0x[0-9a-fA-F]{64}", value) for value in hashes)
        ):
            raise MetaMaskError("SETTLEMENT_UNRESOLVED", "Completed transaction hash history is malformed")
        plan = json_object(
            self.journal.effect(self.agent_id, intent.identifier, "swap-execution-plan")
            or self.journal.effect(self.agent_id, intent.identifier, "swap-plan"),
            "completed swap plan",
        )
        approvals = plan.get("approvals")
        if (
            not isinstance(approvals, list)
            or plan.get("wallet") != binding.wallet
            or plan.get("network") != binding.network
            or binding.network != self.network
            or intent.destination.address == "native"
        ):
            raise MetaMaskError("SETTLEMENT_UNRESOLVED", "Completed swap identity needs explicit reconciliation")
        transactions = [*approvals, json_object(plan.get("trade"), "completed swap trade")]
        total_fee, receipt = 0, None
        estimates = plan.get("feeEstimates")
        if estimates is not None and (not isinstance(estimates, list) or len(estimates) != len(transactions)):
            raise MetaMaskError("SETTLEMENT_UNRESOLVED", "Completed fee estimates are incomplete")
        for index, planned in enumerate(transactions):
            effect = json_object(self.journal.effect(self.agent_id, intent.identifier, f"swap-{index}"), "swap effect")
            tx = json_object(effect.get("transaction"), "completed transaction")
            tx_hash = effect.get("txHash")
            if (
                not isinstance(tx_hash, str)
                or not re.fullmatch(r"0x[0-9a-fA-F]{64}", tx_hash)
                or tx_hash not in hashes
                or not {"from", "to", "chainId", "data", "value", "nonce", "gasLimit", "maxFeePerGas"} <= tx.keys()
                or tx.get("from") != binding.wallet
                or tx.get("chainId") != intent.source.chain_id
                or not isinstance(tx.get("data"), str)
                or not _HEX.fullmatch(tx["data"])
                or any(tx.get(key) != value for key, value in json_object(planned).items())
            ):
                raise MetaMaskError("SETTLEMENT_UNRESOLVED", "Completed transaction differs from retained intent")
            receipt = self._receipt(tx_hash, tx)
            if receipt is None:
                raise MetaMaskError("FINALITY_PENDING", "Completed swap is awaiting RPC-finalized receipt evidence")
            model = json_object(estimates[index], "fee estimate").get("model") if estimates else None
            fees = receipt_fees(self._rpc, tx["chainId"], receipt, model)
            if integer(receipt.get("status")) != 1 or effect.get("actualFees") != fees:
                raise MetaMaskError("SETTLEMENT_UNRESOLVED", "Finalized receipt conflicts with recorded status or fees")
            total_fee += integer(fees["totalFee"])
        output = intent.destination.from_atomic(self._received_output(receipt, intent.destination, plan["wallet"]))
        expected_fees = [{"asset": "native", "chainId": intent.source.chain_id, "atomicAmount": str(total_fee)}]
        if (
            output != decimal(operation.get("filledQuantity"))
            or output != decimal(operation.get("outputAmount"))
            or intent.amount != decimal(operation.get("inputAmount"))
            or intent.destination.to_atomic(output) < integer(plan.get("minimumOutput"))
            or operation.get("fees") != expected_fees
        ):
            raise MetaMaskError("SETTLEMENT_UNRESOLVED", "Finalized output or fees conflict with recorded execution")
        return self._save(
            operation,
            state="filled",
            settlementFinality="rpc_finalized",
            settlementRecheckRequired=False,
            lastErrorCode=None,
            message="Historical swap receipts and recorded execution verified against RPC finality",
        )

    def order(self, operation_id):
        with self._execution:
            operation = self.journal.get(self.agent_id, operation_id)
            if operation is None:
                raise MetaMaskError("NOT_FOUND", "Swap operation not found")
            return self._advance(operation)

    def close(self):
        if self._owns_session:
            self.session.close()
