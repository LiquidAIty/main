"""Typed IBKR history outcomes, repair planning, and safe backtest telemetry.

This module intentionally contains no broker calls.  It keeps the policy that
decides what may become durable negative-cache state separate from the large
IBKR orchestration helper so the policy can be unit tested without a gateway.
"""

from __future__ import annotations

from dataclasses import dataclass
from contextlib import contextmanager
from contextvars import ContextVar
from datetime import datetime, timedelta, timezone
from enum import Enum
import json
import sys
from threading import Lock
from typing import Any, Iterable, Optional, Sequence

import pandas as pd

IBKR_HISTORY_HEALTH_MISSING_SESSION_LIMIT = 100


class HistoryOutcome(str, Enum):
    COMPLETE = "complete"
    PARTIAL = "partial"
    CONFIRMED_NO_DATA = "confirmed_no_data"
    TRANSIENT_FAILURE = "transient_failure"


@dataclass(frozen=True)
class HistoryFailureClassification:
    outcome: HistoryOutcome
    reason: str
    persist_negative_cache: bool = False
    identity_related: bool = False
    details: Optional[dict[str, Any]] = None


class HistoryPayloadError(RuntimeError):
    """Non-cacheable history with safe structured cause, separate from its message."""

    def __init__(self, metadata: dict[str, Any]):
        self.details = {
            key: value[:500] if isinstance(value, str) else value
            for key, value in metadata.items()
            if key in {"provider", "backend", "classification", "cache_write_policy", "error",
                       "request_id", "status_code", "retry_at"}
            and (isinstance(value, (str, int, float, bool)) or value is None)
        }
        super().__init__("partial_history:non_cacheable_downloader_payload "
                         f"classification={metadata.get('classification') or 'unknown'} "
                         f"cache_write_policy={metadata.get('cache_write_policy') or 'unknown'}")


def classify_history_failure(exc: BaseException) -> HistoryFailureClassification:
    """Classify a provider/downloader failure without treating ambiguity as fact."""

    details = exc.details if isinstance(exc, HistoryPayloadError) else None
    provider_details = getattr(exc, "provider_details", None)
    if details is None and isinstance(provider_details, dict):
        details = HistoryPayloadError(provider_details).details
    if details and (details.get("classification") == "rate_limited" or details.get("status_code") == 429):
        return HistoryFailureClassification(outcome=HistoryOutcome.TRANSIENT_FAILURE,
                                            reason="rate_limited", details=dict(details))
    message = str((details or {}).get("error") or exc or "").strip()
    normalized = message.lower()

    identity_tokens = (
        "chart data unavailable",
        "invalid conid",
        "unknown conid",
        "contract not found",
        # IBKR's answer for a conid it retired (company reorganized, ETF reverse split).
        # Oct 7 2026: XOM 13977 -> 895178251, SOXS 854072548 -> 892340391.
        "contract details are not available",
    )
    if any(token in normalized for token in identity_tokens):
        return HistoryFailureClassification(
            outcome=HistoryOutcome.TRANSIENT_FAILURE,
            reason="identity_related_history_failure",
            identity_related=True,
            details=details,
        )

    confirmed_tokens = (
        "asset does not exist",
        "unable to resolve ibkr conid",
        "ibkr conid lookup is negatively cached",
        "secdef/search returned no",
        "contract is not available for trading",
    )
    if any(token in normalized for token in confirmed_tokens):
        return HistoryFailureClassification(
            outcome=HistoryOutcome.CONFIRMED_NO_DATA,
            reason="confirmed_no_data",
            persist_negative_cache=True,
            details=details,
        )

    partial_tokens = (
        "malformed_history_payload",
        "overlap_bar_mismatch",
        "partial_history",
        "pagination returned empty data before covering",
        "pagination returned an empty frame before covering",
        "remained invalid after rebuild",
    )
    if any(token in normalized for token in partial_tokens):
        return HistoryFailureClassification(
            outcome=HistoryOutcome.PARTIAL,
            reason="partial_history",
            details=details,
        )

    return HistoryFailureClassification(
        outcome=HistoryOutcome.TRANSIENT_FAILURE,
        reason="transient_history_failure",
        details=details,
    )


def group_contiguous_missing_sessions(
    expected_sessions: Sequence[pd.Timestamp],
    missing_sessions: Iterable[pd.Timestamp],
) -> list[list[pd.Timestamp]]:
    """Group missing sessions that are adjacent in the exchange calendar."""

    expected = [pd.Timestamp(value) for value in expected_sessions]
    positions = {value.date(): index for index, value in enumerate(expected)}
    missing = sorted(
        {pd.Timestamp(value) for value in missing_sessions},
        key=lambda value: positions.get(value.date(), len(expected)),
    )
    groups: list[list[pd.Timestamp]] = []
    for session in missing:
        position = positions.get(session.date())
        if position is None:
            continue
        if not groups:
            groups.append([session])
            continue
        previous_position = positions.get(groups[-1][-1].date())
        if previous_position is not None and position == previous_position + 1:
            groups[-1].append(session)
        else:
            groups.append([session])
    return groups


def coalesce_nearby_session_groups(
    groups: Sequence[Sequence[pd.Timestamp]],
    *,
    max_calendar_span_days: int = 10,
) -> list[list[pd.Timestamp]]:
    """Coalesce nearby gaps when one small request is cheaper than two."""

    combined: list[list[pd.Timestamp]] = []
    for raw_group in groups:
        group = [pd.Timestamp(value) for value in raw_group]
        if not group:
            continue
        if not combined:
            combined.append(group)
            continue
        proposed_span = (group[-1].normalize() - combined[-1][0].normalize()).days
        if proposed_span <= max_calendar_span_days:
            combined[-1].extend(group)
        else:
            combined.append(group)
    return combined


def split_session_groups(
    groups: Sequence[Sequence[pd.Timestamp]],
    *,
    max_sessions: int = 10,
) -> list[list[pd.Timestamp]]:
    """Split large gaps so one repair request never spans an unbounded range."""

    if max_sessions <= 0:
        raise ValueError("max_sessions must be positive")
    result: list[list[pd.Timestamp]] = []
    for group in groups:
        values = [pd.Timestamp(value) for value in group]
        for offset in range(0, len(values), max_sessions):
            result.append(values[offset : offset + max_sessions])
    return result


def padded_repair_window(
    sessions: Sequence[pd.Timestamp],
    *,
    padding_days: int = 1,
) -> tuple[datetime, datetime]:
    """Return a small end-exclusive calendar window around missing sessions."""

    if not sessions:
        raise ValueError("sessions must not be empty")
    first = pd.Timestamp(min(sessions)).normalize() - pd.Timedelta(days=padding_days)
    last = pd.Timestamp(max(sessions)).normalize() + pd.Timedelta(days=padding_days + 1)
    return first.to_pydatetime(), last.to_pydatetime()


_HEALTH_LOCK = Lock()
_HEALTH_BY_SERIES: dict[str, dict[str, Any]] = {}
_HEALTH_EVENT_IDS: set[tuple[str, str]] = set()
_REQUIRED_FAILURES: dict[tuple, dict[str, Any]] = {}
_OPTIONAL_ISSUES: dict[tuple, dict[str, Any]] = {}
_RECOVERABLE_HISTORY_REQUEST: ContextVar[bool] = ContextVar(
    "lumibot_recoverable_history_request", default=False,
)


class IncompleteResearchHistoryError(ValueError):
    """A research tool cannot use these inputs, but can choose another request."""


@contextmanager
def recoverable_history_request():
    """Reject incomplete research inputs without invalidating unrelated decisions.

    This is request-local, including nested calls. Direct strategy reads and
    portfolio valuation keep their existing required-data semantics.
    """
    token = _RECOVERABLE_HISTORY_REQUEST.set(True)
    try:
        yield
    finally:
        _RECOVERABLE_HISTORY_REQUEST.reset(token)


def record_optional_corporate_action_issue(*, symbol, when):
    """Record unavailable enrichment separately from required price-data failures."""
    key = (str(symbol).strip().upper(), "corporate_actions_unavailable")
    with _HEALTH_LOCK:
        if key in _OPTIONAL_ISSUES:
            _OPTIONAL_ISSUES[key]["occurrences"] += 1
        elif len(_OPTIONAL_ISSUES) < 500:
            _OPTIONAL_ISSUES[key] = {
                "symbol": key[0], "reason": key[1], "required": False,
                "price_provider": "ibkr", "corporate_actions_status": "unavailable",
                "cash_dividends_verified": False, "observed_at": when.isoformat(), "occurrences": 1,
            }


def record_backtest_availability_requirement(*, asset, timestep, when, history_as_of):
    """Keep a frozen delayed-feed cutoff visible when a decision needs newer bars."""
    if history_as_of is None:
        return
    from lumibot.tools import ibkr_helper as helper

    base = asset[0] if isinstance(asset, tuple) else asset
    kind = helper._normalize_asset_type(getattr(base, "asset_type", ""))
    if kind not in {"stock", "index", "future", "cont_future"}:
        return
    _, seconds, component = helper._timestep_to_ibkr_bar(str(timestep))
    if component.endswith("day"):
        return
    cutoff = helper._to_utc(history_as_of) - helper.IBKR_INTRADAY_HISTORY_DELAY
    required = helper._to_utc(when) - timedelta(seconds=seconds)
    if required <= cutoff:
        return
    closed = (helper._us_equity_closed_interval(cutoff, required, include_after_hours=True)
              if kind in {"stock", "index"} else helper._us_futures_closed_interval(cutoff, required))
    if not closed:
        record_required_history(asset=asset, timestep=timestep, requested_bars=1, frame=None,
                                when=when, requirement="availability")



def record_required_data_issue(*, asset, timestep, when, reason, recovery_cause="unknown", retryable=False):
    """Persist a bounded typed failure without leaking provider payloads."""
    allowed = {"temporary_download_failure", "history_unavailable", "corporate_actions_unverified",
               "data_not_yet_available", "unknown"}
    if recovery_cause not in allowed:
        raise ValueError("unknown recovery cause")
    symbol = str(getattr(asset, "symbol", asset)).upper()
    kind = getattr(asset, "asset_type", "")
    kind = str(getattr(kind, "value", kind))
    key = (symbol, kind, str(getattr(asset, "expiration", "")), str(timestep), reason)
    with _HEALTH_LOCK:
        previous = _REQUIRED_FAILURES.get(key)
        if previous:
            previous["occurrences"] += 1
            previous["last_observed_at"] = when.isoformat()
            previous["retryable"] = previous.get("retryable", False) and retryable is True
        elif len(_REQUIRED_FAILURES) < 500:
            _REQUIRED_FAILURES[key] = {"symbol": symbol, "asset_type": kind, "timestep": str(timestep),
                "reason": str(reason)[:200], "recovery_cause": recovery_cause, "retryable": retryable is True,
                "first_observed_at": when.isoformat(), "last_observed_at": when.isoformat(), "occurrences": 1}

def record_required_history(*, asset, timestep, requested_bars, frame, when, requirement="history") -> None:
    """Record history actually consumed by a strategy, separately from prefetch.

    An incomplete decision remains incomplete even if a later decision has enough
    bars. Bound evidence by series rather than storing every iteration.
    """
    base = asset[0] if isinstance(asset, tuple) else asset
    symbol = str(getattr(base, "symbol", base)).upper()
    asset_type = getattr(base, "asset_type", "")
    asset_type = str(getattr(asset_type, "value", asset_type))
    requested = int(requested_bars)
    if requested <= 0:
        return
    usable = frame if isinstance(frame, pd.DataFrame) else pd.DataFrame()
    if "missing" in usable:
        usable = usable.loc[~usable["missing"].fillna(False).astype(bool)]
    usable = usable.dropna(subset=[name for name in ("open", "high", "low", "close") if name in usable])
    returned = len(usable) if "close" in usable else 0
    missing = []
    unresolved_contract = False
    with _HEALTH_LOCK:
        if returned and isinstance(usable.index, pd.DatetimeIndex):
            first, last = usable.index.min().date().isoformat(), usable.index.max().date().isoformat()
            from lumibot.tools.helpers import parse_canonical_timestep

            # Prefetch telemetry may describe a route that failed before another
            # route/cache repair supplied the missing daily row. Validate the
            # prices this decision actually received, without erasing the failed
            # route's evidence. One intraday row does not prove a whole session.
            daily_dates = ({stamp.date().isoformat() for stamp in usable.index}
                           if parse_canonical_timestep(timestep) == (1, "day") else None)
            for health in _HEALTH_BY_SERIES.values():
                if (health["symbol"] == symbol and health["asset_type"] == asset_type
                        and health["timestep"] == str(timestep) and health["outcome"] != "complete"):
                    missing.extend(day for day in health["missing_sessions"]
                                   if first <= day <= last and (daily_dates is None or day not in daily_dates))
                    if health["reason"] == "unresolved_roll_contract":
                        # This interval is an explicitly absent contract segment,
                        # not the broader optional prefetch window. Older bars can
                        # satisfy the row count while hiding this interior hole.
                        gap_start = pd.Timestamp(health["requested_start"]).date().isoformat()
                        gap_end = pd.Timestamp(health["requested_end"]).date().isoformat()
                        unresolved_contract |= gap_start <= last and gap_end >= first
        reason = "insufficient_required_history" if returned < requested else (
            "missing_required_sessions" if missing else (
                "unresolved_required_contract" if unresolved_contract else None))
        if reason and requirement == "valuation":
            reason = "missing_valuation_price"
        if reason and requirement == "availability":
            reason = "required_history_after_feed_cutoff"
        if reason is None:
            return
        correlated = [h for h in _HEALTH_BY_SERIES.values()
                      if h["symbol"] == symbol and h["asset_type"] == asset_type
                      and h["timestep"] == str(timestep) and h["outcome"] != "complete"
                      and pd.Timestamp(h["requested_start"]) <= pd.Timestamp(when)
                      and pd.Timestamp(h["requested_end"]) >= pd.Timestamp(when)]
        transient = bool(correlated) and all(
            h["outcome"] == HistoryOutcome.TRANSIENT_FAILURE.value
            and h["reason"] in {"rate_limited", "transient_history_failure"}
            for h in correlated)
        recovery_cause = ("data_not_yet_available" if requirement == "availability" else
                          "temporary_download_failure" if transient else "unknown")
        key = (symbol, asset_type, str(getattr(base, "expiration", "")), str(timestep), reason)
        if _RECOVERABLE_HISTORY_REQUEST.get() and requirement != "valuation":
            # Do not return an indicator computed from known missing inputs.
            # Keep the failed request as evidence, not a sticky claim that the
            # strategy necessarily consumed it after the tool reported failure.
            previous = _OPTIONAL_ISSUES.get(key)
            if previous:
                previous["occurrences"] += 1
                previous["last_observed_at"] = when.isoformat()
            elif len(_OPTIONAL_ISSUES) < 500:
                _OPTIONAL_ISSUES[key] = {
                    "symbol": symbol, "asset_type": asset_type, "timestep": str(timestep),
                    "reason": reason, "required": False, "operation": "research_history",
                    "requested_bars": requested, "returned_bars": returned,
                    "missing_sessions": sorted(set(missing))[:100],
                    "recovery_cause": recovery_cause, "retryable": transient,
                    "first_observed_at": when.isoformat(), "last_observed_at": when.isoformat(),
                    "occurrences": 1,
                }
            raise IncompleteResearchHistoryError(
                f"{symbol} {timestep}: {reason}; requested {requested} bars, returned {returned}. "
                "No result was calculated from this incomplete request. Retry with available "
                "history, another source or another asset; disclose the limitation."
            )
        previous = _REQUIRED_FAILURES.get(key)
        if previous:
            previous["occurrences"] += 1
            previous["last_observed_at"] = when.isoformat()
            previous["retryable"] = previous.get("retryable", False) and transient
            if previous.get("recovery_cause") != recovery_cause:
                previous["recovery_cause"] = "unknown"
        elif len(_REQUIRED_FAILURES) < 500:
            _REQUIRED_FAILURES[key] = {
                "symbol": symbol, "asset_type": asset_type, "timestep": str(timestep),
                "reason": reason, "recovery_cause": recovery_cause, "retryable": transient,
                "requested_bars": requested, "returned_bars": returned,
                "first_observed_at": when.isoformat(), "last_observed_at": when.isoformat(),
                "missing_sessions": sorted(set(missing))[:100], "occurrences": 1,
            }


def record_history_health(
    *,
    symbol: str,
    asset_type: str,
    timestep: str,
    requested_start: datetime,
    requested_end: datetime,
    outcome: HistoryOutcome,
    expected_sessions: Optional[int] = None,
    returned_sessions: Optional[int] = None,
    missing_sessions: Optional[Iterable[Any]] = None,
    repair_attempts: int = 0,
    transient_failures: int = 0,
    conid_refreshes: int = 0,
    reason: Optional[str] = None,
    series_id: Optional[str] = None,
    details: Optional[dict[str, Any]] = None,
    event_id: Optional[str] = None,
) -> None:
    """Record bounded, credential-free health state for settings.json."""

    start = requested_start.astimezone(timezone.utc).isoformat()
    end = requested_end.astimezone(timezone.utc).isoformat()
    # A successful unrelated interval/source must not erase an unresolved window.
    key = json.dumps((str(asset_type), str(symbol).upper(), str(timestep), series_id, start, end))
    missing = sorted({str(value)[:10] for value in (missing_sessions or [])})
    payload = {
        "symbol": str(symbol).upper(),
        "asset_type": str(asset_type),
        "timestep": str(timestep),
        "requested_start": start,
        "requested_end": end,
        "series_id": series_id,
        "outcome": outcome.value,
        "expected_sessions": expected_sessions,
        "returned_sessions": returned_sessions,
        "missing_sessions": missing[:IBKR_HISTORY_HEALTH_MISSING_SESSION_LIMIT],
        "missing_session_count": len(missing),
        "repair_attempts": int(repair_attempts),
        "transient_failures": int(transient_failures),
        "conid_refreshes": int(conid_refreshes),
        "reason": str(reason)[:500] if reason else None,
        "details": HistoryPayloadError(details).details if details else None,
    }
    with _HEALTH_LOCK:
        if event_id:
            event_key = (key, event_id)
            if event_key in _HEALTH_EVENT_IDS:
                return
            _HEALTH_EVENT_IDS.add(event_key)
        previous = _HEALTH_BY_SERIES.get(key)
        if previous:
            payload["repair_attempts"] += int(previous.get("repair_attempts") or 0)
            payload["transient_failures"] += int(previous.get("transient_failures") or 0)
            payload["conid_refreshes"] += int(previous.get("conid_refreshes") or 0)
        _HEALTH_BY_SERIES[key] = payload


def ibkr_history_health_snapshot() -> dict[str, Any]:
    with _HEALTH_LOCK:
        series = [dict(value) for _, value in sorted(_HEALTH_BY_SERIES.items())]
        required_failures = [dict(value) for value in _REQUIRED_FAILURES.values()]
        warnings = [dict(value) for value in _OPTIONAL_ISSUES.values()]
    incomplete = sum(1 for value in series if value.get("outcome") != HistoryOutcome.COMPLETE.value)
    return {
        "provider": "ibkr",
        "series_count": len(series),
        "incomplete_series_count": incomplete,
        "complete": incomplete == 0,
        "series": series,
        "required_complete": not required_failures,
        "required_failures": required_failures,
        "warnings": warnings,
    }


def reset_ibkr_history_health() -> None:
    with _HEALTH_LOCK:
        _HEALTH_BY_SERIES.clear()
        _HEALTH_EVENT_IDS.clear()
        _REQUIRED_FAILURES.clear()
        _OPTIONAL_ISSUES.clear()
    # A Strategy backtest startup already resets this provider's run telemetry.
    # Reset the price-basis memo at the same boundary, without importing a data
    # adapter into runs that never use IBKR. Within one run it remains frozen.
    helper = sys.modules.get("lumibot.tools.ibkr_helper")
    basis_cache = getattr(helper, "_IBKR_EQUITY_BASIS_CACHE", None)
    if basis_cache is not None:
        basis_cache.clear()


def reset_ibkr_history_health_for_testing() -> None:
    reset_ibkr_history_health()


def retry_after_datetime(*, ttl_seconds: int, now: Optional[datetime] = None) -> datetime:
    base = now or datetime.now(timezone.utc)
    if base.tzinfo is None:
        base = base.replace(tzinfo=timezone.utc)
    return base.astimezone(timezone.utc) + timedelta(seconds=int(ttl_seconds))


def audit_ibkr_cache_frame(frame: pd.DataFrame) -> dict[str, Any]:
    """Return structural health for one cached parquet frame."""

    if frame is None:
        frame = pd.DataFrame()
    index = pd.DatetimeIndex(frame.index) if len(frame.index) else pd.DatetimeIndex([])
    missing_mask = (
        frame["missing"].fillna(False).astype(bool)
        if "missing" in frame.columns
        else pd.Series(False, index=frame.index)
    )
    real = frame.loc[~missing_mask]
    ohlc = [column for column in ("open", "high", "low", "close") if column in real.columns]
    real_ohlc_null_rows = int(real[ohlc].isna().any(axis=1).sum()) if ohlc else 0
    return {
        "rows": int(len(frame)),
        "real_rows": int((~missing_mask).sum()),
        "placeholder_rows": int(missing_mask.sum()),
        "all_placeholder": bool(len(frame) > 0 and bool(missing_mask.all())),
        "duplicate_timestamps": int(index.duplicated().sum()),
        "monotonic": bool(index.is_monotonic_increasing),
        "real_ohlc_null_rows": real_ohlc_null_rows,
        "first_timestamp": index.min().isoformat() if len(index) else None,
        "last_timestamp": index.max().isoformat() if len(index) else None,
    }
