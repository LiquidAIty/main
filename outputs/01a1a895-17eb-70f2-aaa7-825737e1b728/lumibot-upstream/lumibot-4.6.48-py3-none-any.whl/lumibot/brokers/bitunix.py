from __future__ import annotations

import os
import time

from lumibot._lazy_imports import LazyLogger, LazyModule, lazy_class

from .broker import Broker, LumibotBrokerAPIError

logger = LazyLogger(__name__)
TYPE_CHECKING = False
pd = LazyModule("pandas")
Asset = lazy_class("lumibot.entities", "Asset")
Order = lazy_class("lumibot.entities", "Order")
Decimal = lazy_class("decimal", "Decimal")
BitUnixClient = None
BitunixData = None

if TYPE_CHECKING:
    from typing import Any

    from lumibot.entities import Position


def _position_class():
    from lumibot.entities import Position

    return Position


def _format_exc():
    import traceback

    return traceback.format_exc()


def _get_bitunix_client_class():
    global BitUnixClient
    if BitUnixClient is None:
        from lumibot.tools.bitunix_helpers import BitUnixClient
    return BitUnixClient


def _get_bitunix_data_class():
    global BitunixData
    if BitunixData is None:
        from lumibot.data_sources.bitunix_data import BitunixData
    return BitunixData

class Bitunix(Broker):
    """
    A broker class that connects to the Bitunix exchange for crypto futures trading.

    This broker uses Bitunix's perpetual futures REST API to submit, track,
    and close crypto futures positions (e.g., BTCUSDT perpetual).

    Key Features:
    - Only supports crypto futures (TRADING_MODE must be "FUTURES").
    - Closes futures positions with reduce-only market orders.
    - All positions and orders are managed using Bitunix's API conventions.
    - Not suitable for spot trading or non-futures assets.

    Notes:
    - The `close_position` method submits a reduce-only HEDGE close for the matching position.
    - All asset symbols should be the full Bitunix symbol (e.g., "BTCUSDT").
    - Leverage and margin settings are managed per-symbol as needed.
    """

    ASSET_TYPE_MAP = dict(
        stock=[],
        option=[],
        future=["future"],
        crypto_future=["future"],    # new crypto‐futures
        forex=[],
        crypto=["crypto"],
    )

    # Default quote asset for crypto transactions
    LUMIBOT_DEFAULT_QUOTE_ASSET = None

    @classmethod
    def _default_quote_asset(cls):
        if cls.LUMIBOT_DEFAULT_QUOTE_ASSET is None:
            cls.LUMIBOT_DEFAULT_QUOTE_ASSET = Asset("USDT", Asset.AssetType.CRYPTO)
        return cls.LUMIBOT_DEFAULT_QUOTE_ASSET

    POLL_EVENT = "poll"
    DEFAULT_POLL_INTERVAL = 5  # seconds between polling cycles

    def __init__(
        self,
        config,
        max_workers: int = 1,
        chunk_size: int = 100,
        connect_stream: bool = True,
        poll_interval: float | None = None,
        data_source=None,
    ):
        # --- Bitunix trading mode check ---
        trading_mode = None
        if isinstance(config, dict):
            trading_mode = config.get("TRADING_MODE", "FUTURES")
        else:
            trading_mode = getattr(config, "TRADING_MODE", "FUTURES")
        if str(trading_mode).upper() != "FUTURES":
            print(
                f"Bitunix TRADING_MODE '{trading_mode}' is not supported yet. "
                "Please use another broker for spot trading."
            )

        # Ensure _stream_loop exists before calling super, so _launch_stream doesn't error
        self._stream_loop = None
        if isinstance(config, dict):
            api_key = config.get("API_KEY")
            api_secret = config.get("API_SECRET")
        else:
            api_key = getattr(config, "API_KEY", None)
            api_secret = getattr(config, "API_SECRET", None)

        # Track current leverage per symbol to avoid redundant API calls
        self.current_leverage: dict[str, int] = {}
        self._trading_pair_rules: dict[str, tuple[Decimal, Decimal, Decimal]] = {}
        # Override default market setting for to be 24/7, but still respect config/env if set
        self.market = (config.get("MARKET") if config else None) or os.environ.get("MARKET") or "24/7"

        if not api_key or not api_secret:
            raise ValueError("API_KEY and API_SECRET must be provided in config")

        # Initialize API client and WS attributes BEFORE calling super().__init__
        self.api = _get_bitunix_client_class()(api_key=api_key, secret_key=api_secret)
        self.api_secret = api_secret  # needed for signing
        # Private-channel URL per BitUnix docs (used for authenticated account streams)
        self.ws_url = "wss://fapi.bitunix.com/private/"
        """Private websocket endpoint for authenticated Bitunix futures streams."""
        self._position_mode = None

        if not data_source:
            data_source = _get_bitunix_data_class()(config, max_workers=max_workers, chunk_size=chunk_size)
            # Share the client instance with the data source if it was just created
            data_source.client = self.api
            # Share the client_symbols set with the broker for WebSocket subscriptions
            self.client_symbols = data_source.client_symbols

        self.poll_interval = poll_interval or self.DEFAULT_POLL_INTERVAL
        super().__init__(
            name="bitunix",
            connect_stream=connect_stream, # Use connect_stream to enable _run_stream thread
            data_source=data_source,
            config=config,
            max_workers=max_workers,
        )

    def _safe_stream_dispatch(self, event, **kwargs):
        stream = getattr(self, "stream", None)
        if stream is not None and hasattr(stream, "dispatch"):
            stream.dispatch(event, **kwargs)

    def get_quote_asset(self):
        # Only clear and set quote_assets if USDT is not the only asset
        default_quote_asset = self._default_quote_asset()
        if not (len(self.quote_assets) == 1 and default_quote_asset in self.quote_assets):
            self.quote_assets.clear()
            self.quote_assets.add(default_quote_asset)

        return default_quote_asset

    def get_timestamp(self):
        return time.time()

    def is_market_open(self):
        return True

    def get_time_to_open(self):
        return 0

    def get_time_to_close(self):
        return float("inf")

    def _get_balances_at_broker(self, quote_asset: Asset, strategy) -> tuple[float, float, float] | None:
        """
        Returns (cash, positions_value, total_liquidation_value)
        """
        # ---------- FUTURES wallet only ----------
        # Force margin_coin to USDT
        fut_resp = self.api.get_account(margin_coin="USDT")
        try:
            data = fut_resp.get("data", {})

            # cash components
            available = Decimal(data.get("available", "0") or "0")
            frozen = Decimal(data.get("frozen", "0") or "0")
            margin = Decimal(data.get("margin", "0") or "0")
            cross_pnl = Decimal(data.get("crossUnrealizedPNL", "0") or "0")
            iso_pnl = Decimal(data.get("isolationUnrealizedPNL", "0") or "0")

            # equity / net liquidation
            fut_equity = available + frozen + margin + cross_pnl + iso_pnl
            net_liquidation = float(fut_equity)

        except Exception:
            logger.warning("Unexpected futures account response: %s", fut_resp)
            available = frozen = margin = cross_pnl = iso_pnl = Decimal("0")
            net_liquidation = 0.0

        cash = float(available)

        # Compute total notional of open futures positions
        positions_value = 0.0
        for pos in self._pull_positions(strategy):
            if pos.avg_fill_price:
                # Convert both quantity and avg_fill_price to float before multiplication
                positions_value += float(abs(pos.quantity)) * float(pos.avg_fill_price)

        return cash, positions_value, net_liquidation

    def _pull_positions(self, strategy) -> list[Position]:
        """Return a complete futures snapshot or raise without publishing partial state.

        A successful empty list means the account is flat. An unreadable response
        must raise instead, because shared position sync prunes absent assets.
        """
        positions = []
        seen_legs = {}
        Position = _position_class()
        strategy_name = self._strategy_name_from_input(strategy) or ""

        try:
            resp = self.api.get_positions()
            if not isinstance(resp, dict) or resp.get("code") != 0:
                raise LumibotBrokerAPIError("Bitunix position snapshot request failed")
            rows = resp.get("data")
            if not isinstance(rows, list):
                raise LumibotBrokerAPIError("Bitunix position snapshot must contain a list")
            for p in rows:
                if not isinstance(p, dict):
                    raise LumibotBrokerAPIError("Invalid Bitunix position row")
                sym = p.get("symbol")
                side = p.get("side")
                if not isinstance(sym, str) or not sym.strip() or not isinstance(side, str):
                    raise LumibotBrokerAPIError("Invalid Bitunix position identity")
                side = side.upper()
                if side not in ("LONG", "SHORT", "BUY", "SELL"):
                    raise LumibotBrokerAPIError("Invalid Bitunix position side")
                qty = Decimal(str(p["qty"]))
                entry = Decimal(str(p.get("avgOpenPrice", p.get("entryValue", "0"))))
                if not qty.is_finite() or not entry.is_finite():
                    raise LumibotBrokerAPIError("Non-finite Bitunix position quantity or entry price")
                qty = -abs(qty) if side in ("SELL", "SHORT") else abs(qty)
                if qty != 0:
                    asset = Asset(sym, Asset.AssetType.CRYPTO_FUTURE)
                    # HEDGE mode can hold a long and a short leg on one symbol.
                    # Each leg keeps its own side and exchange positionId so the
                    # shared tracker never merges or overwrites them. A repeated
                    # leg with no distinct positionId is still ambiguous.
                    position_side = None if p.get("positionMode") == "ONE_WAY" else (
                        "short" if side in ("SELL", "SHORT") else "long")
                    raw_id = p.get("positionId")
                    position_id = str(raw_id) if raw_id not in (None, "") else None
                    ids = seen_legs.setdefault((asset, position_side), set())
                    if ids and (position_id is None or position_id in ids or None in ids):
                        raise LumibotBrokerAPIError(
                            "Multiple active Bitunix positions for one symbol and side cannot be represented safely"
                        )
                    ids.add(position_id)
                    pos = Position(
                        strategy_name, asset, qty, position_side=position_side, position_id=position_id
                    )
                    pos.avg_fill_price = entry
                    pos._raw = p
                    positions.append(pos)
        except LumibotBrokerAPIError:
            raise
        except Exception as exc:
            raise LumibotBrokerAPIError("Unable to read complete Bitunix position snapshot") from exc
        return positions

    def _map_side_to_bitunix(self, side: Order.OrderSide) -> str:
        """Map Lumibot order side to BitUnix side."""
        return "BUY" if side == Order.OrderSide.BUY else "SELL"

    def _map_type_to_bitunix(self, order_type: Order.OrderType) -> str:
        """Map Lumibot order type to BitUnix order type."""
        if order_type == Order.OrderType.LIMIT:
            return "LIMIT"
        elif order_type == Order.OrderType.MARKET:
            return "MARKET"
        elif order_type == Order.OrderType.STOP:
            return "STOP"
        elif order_type == Order.OrderType.STOP_LIMIT:
            return "STOP_LIMIT"
        else:
            return "MARKET"  # Default to MARKET for unknown types

    def _read_position_mode(self):
        """Account mode belongs to the caller; order submission only reads it."""
        try:
            response = self.api.get_position_mode()
            mode = (response.get("data") or {}).get("positionMode")
            if response.get("code") != 0 or mode not in ("HEDGE", "ONE_WAY"):
                raise ValueError("missing or invalid position mode")
        except Exception as exc:
            raise LumibotBrokerAPIError("Cannot read Bitunix account position mode") from exc
        self._position_mode = mode
        return mode

    def set_position_mode(self, hedged, asset=None, params=None):
        """Explicitly change the account-wide mode; never called implicitly."""
        mode = "HEDGE" if hedged else "ONE_WAY"
        response = self.api.change_position_mode(mode)
        if not response or response.get("code") != 0:
            raise LumibotBrokerAPIError("Bitunix rejected the requested position mode")
        self._position_mode = None
        return response

    def get_contract_spec(self, asset, quote=None):
        """Bitunix quantities remain base coin; currency names come from metadata."""
        from lumibot.entities import ContractSpec

        symbol = getattr(asset, "symbol", asset)
        response = self.api.get_trading_pairs(symbols=symbol)
        if not response or response.get("code") != 0:
            raise LumibotBrokerAPIError("Cannot read Bitunix contract metadata")
        try:
            pair = next(item for item in response["data"] if item["symbol"] == symbol)
            return ContractSpec(pair["base"], pair["quote"], pair.get("marginCoin") or pair["quote"],
                                quantity_unit="base")
        except (KeyError, TypeError, StopIteration, ValueError):
            raise LumibotBrokerAPIError("Cannot read Bitunix contract metadata") from None

    def _get_trading_pair_rules(self, symbol: str) -> tuple[Decimal, Decimal, Decimal]:
        """Cache validated quantity/price steps and minimum size for this broker session."""
        if symbol not in self._trading_pair_rules:
            try:
                response = self.api.get_trading_pairs(symbols=symbol)
                if not response or response.get("code") != 0:
                    raise ValueError("metadata request failed")
                pair = next(pair for pair in response["data"] if pair["symbol"] == symbol)
                base_precision = pair["basePrecision"]
                quote_precision = pair["quotePrecision"]
                if any(type(value) is not int or value < 0 for value in (base_precision, quote_precision)):
                    raise ValueError("precision must be a non-negative integer")
                minimum = Decimal(str(pair["minTradeVolume"]))
                if not minimum.is_finite() or minimum <= 0:
                    raise ValueError("minTradeVolume must be positive")
                rules = (Decimal(1).scaleb(-base_precision), Decimal(1).scaleb(-quote_precision), minimum)
            except Exception as exc:
                # Never guess precision or cache a failed lookup; a subsequent order can retry.
                raise LumibotBrokerAPIError(f"Cannot load valid Bitunix trading pair rules for {symbol}") from exc
            self._trading_pair_rules[symbol] = rules
        return self._trading_pair_rules[symbol]

    def _get_close_position(self, symbol: str, position_side: str, position_id: str | None = None) -> dict:
        response = self.api.get_positions()
        if not response or response.get("code") != 0:
            raise LumibotBrokerAPIError(f"Cannot read Bitunix position for closing {symbol}")
        matches = [
            position for position in response.get("data", [])
            if position.get("symbol") == symbol
            and position.get("side") in (position_side, "BUY" if position_side == "LONG" else "SELL")
            and Decimal(str(position.get("qty", "0"))) > 0
            and (position_id is None or str(position.get("positionId")) == str(position_id))
        ]
        if len(matches) != 1 or not matches[0].get("positionId"):
            raise LumibotBrokerAPIError(f"Cannot identify a unique Bitunix {position_side} position for {symbol}")
        return matches[0]

    def _get_close_position_id(self, symbol: str, position_side: str) -> str:
        return str(self._get_close_position(symbol, position_side)["positionId"])

    # --- Multi-leg, OCO, OTO, Bracket, Trailing Stop ---
    def _submit_orders(self, orders, is_multileg=False, order_type=None, duration="day", price=None):
        """
        Submit multiple orders. Bitunix does not support multi-leg, OCO, OTO, Bracket, or trailing stop natively.
        """
        if is_multileg or (orders and getattr(orders[0], "order_class", None) in [
            Order.OrderClass.MULTILEG, Order.OrderClass.OCO, Order.OrderClass.OTO, Order.OrderClass.BRACKET
        ]):
            raise NotImplementedError("Bitunix does not support multi-leg, OCO, OTO, or Bracket orders natively.")
        return [self._submit_order(order) for order in orders]

    def _submit_order(self, order: Order) -> Order:
        """
        Submits an order to BitUnix exchange.
        Handles FUTURES orders.
        """
        # Flag set by close_position() – when True we send a reduce‑only order
        reduce_only = getattr(order, "reduce_only", False)


        # Determine symbol format based on asset type
        if order.asset.asset_type == Asset.AssetType.CRYPTO_FUTURE:
            symbol = order.asset.symbol
        else:
            error_msg = "Invalid asset type: asset can only be CRYPTO_FUTURE"
            order.set_error(LumibotBrokerAPIError(error_msg))
            order.status = Order.OrderStatus.ERROR  # ensure status is enum
            return order

        # Generate a client order ID for tracking
        client_order_id = f"lmbot_{int(time.time() * 1000)}_{hash(str(order)) % 10000}"

        try:
            from decimal import ROUND_DOWN

            quantity_step, price_step, minimum = self._get_trading_pair_rules(symbol)
            quantity = abs(Decimal(str(order.quantity))).quantize(quantity_step, rounding=ROUND_DOWN)
            if not quantity.is_finite() or quantity <= 0 or quantity < minimum:
                raise LumibotBrokerAPIError(
                    f"Bitunix {symbol} quantity {quantity} is below minTradeVolume {minimum} after precision rounding"
                )
            price = None
            if order.limit_price is not None:
                price = Decimal(str(order.limit_price)).quantize(price_step, rounding=ROUND_DOWN)
                if not price.is_finite() or price <= 0:
                    raise LumibotBrokerAPIError(
                        f"Bitunix {symbol} limit price must be positive after precision rounding"
                    )

            close_position = None
            opening_leg = "long" if self._map_side_to_bitunix(order.side) == "BUY" else "short"
            if not reduce_only and order.position_side is not None and order.position_side != opening_leg:
                # An order naming the other leg trades against it: a hedge-mode close.
                reduce_only = True
                order.reduce_only = True
            try:
                mode = self._read_position_mode()
            except LumibotBrokerAPIError:
                if not reduce_only:
                    raise
                # A position snapshot can still authoritatively select the
                # close protocol when the separate account-mode read failed.
                position_side = "LONG" if self._map_side_to_bitunix(order.side) == "SELL" else "SHORT"
                close_position = self._get_close_position(symbol, position_side, order.position_id)
                mode = close_position.get("positionMode")
                if mode not in ("HEDGE", "ONE_WAY"):
                    raise LumibotBrokerAPIError("Cannot confirm Bitunix position mode for closing")
            if reduce_only:
                position_side = "LONG" if self._map_side_to_bitunix(order.side) == "SELL" else "SHORT"
                if close_position is None:
                    close_position = self._get_close_position(symbol, position_side, order.position_id)
                order.position_side = position_side.lower() if mode == "HEDGE" else None
                order.position_id = str(close_position["positionId"])
            else:
                # Name the leg an opening order trades so its fill lands on that leg.
                order.position_side = opening_leg if mode == "HEDGE" else None
            # Only opening orders set leverage. Reconstructed close assets may
            # default to 1x, which must not change an existing position's margin.
            leverage = order.asset.leverage
            try:
                if not reduce_only and self.current_leverage.get(symbol) != leverage:
                    lev_resp = self.api.change_leverage(
                        symbol=symbol, leverage=leverage, margin_coin=self.get_quote_asset().symbol
                    )  # Use quote_asset.symbol
                    if not lev_resp or lev_resp.get("code") != 0:
                        logger.warning(f"Failed to set leverage for {symbol} to {leverage}x: {lev_resp}")
                    else:
                        logger.info(f"Set leverage for {symbol} to {leverage}x")
                        self.current_leverage[symbol] = leverage
            except Exception as e:
                logger.warning(f"Error setting leverage for {symbol} to {leverage}: {e}")
            # FUTURES order
            params = {
                "symbol": symbol,
                "side": self._map_side_to_bitunix(order.side),
                "orderType": self._map_type_to_bitunix(order.order_type),
                "qty": format(quantity, "f"),
                "tradeSide": "CLOSE" if reduce_only else "OPEN",
                "clientId": client_order_id,
                "position_mode": mode,
                **({"reduceOnly": True} if reduce_only else {}),
            }
            if reduce_only and mode == "HEDGE":
                # Bitunix HEDGE uses the position's side, while LumiBot keeps the execution side.
                params["positionId"] = str(close_position["positionId"])
                params["side"] = "BUY" if position_side == "LONG" else "SELL"
            if price is not None:
                params["price"] = format(price, "f")

            # TP/SL
            tp = getattr(order, "secondary_limit_price", None) or getattr(order, "take_profit_price", None)
            sl = getattr(order, "secondary_stop_price", None) or getattr(order, "stop_loss_price", None)

            for field, value in (("take_profit_price", tp), ("stop_loss_price", sl)):
                if value is not None:
                    trigger = Decimal(str(value)).quantize(price_step, rounding=ROUND_DOWN)
                    if not trigger.is_finite() or trigger <= 0:
                        raise LumibotBrokerAPIError(
                            f"Bitunix {symbol} {field} must be positive after precision rounding"
                        )
                    params[field] = format(trigger, "f")

            # Fill tracking must use the executable size, not the unrounded strategy request.
            order.quantity = quantity
            if price is not None:
                order.limit_price = price

            # Submit order
            response = self.api.place_order(**params)
            self.logger.info(response)
            # Immediately handle any non-zero API codes as errors
            code = response.get("code") if isinstance(response, dict) else None
            if code is None or code != 0:
                err_msg = (
                    f"Error placing order: code={code}, "
                    f"msg={response.get('msg') if isinstance(response, dict) else response}, "
                    f"data={response.get('data') if isinstance(response, dict) else None}"
                )
                order.set_error(LumibotBrokerAPIError(err_msg))
                order.status = Order.OrderStatus.ERROR  # ensure status is enum
                # Attach full response for debugging
                order.update_raw(response)
                self._safe_stream_dispatch(self.ERROR_ORDER, order=order, error_msg=err_msg)
                return order
            # Success handling only
            data = response.get("data", {})
            order_id = data.get("orderId")
            if order_id:
                order.identifier = order_id
                order.status = Order.OrderStatus.SUBMITTED  # ensure status is enum
                order.update_raw(response)
                self._unprocessed_orders.append(order)
                self._process_trade_event(order, self.NEW_ORDER)
            else:
                error_msg = f"No order ID in response: {response}"
                order.set_error(LumibotBrokerAPIError(error_msg))
                order.status = Order.OrderStatus.ERROR  # ensure status is enum
                self._safe_stream_dispatch(self.ERROR_ORDER, order=order, error_msg=error_msg)
        except Exception as e:
            error_msg = f"Exception placing order: {str(e)}"
            order.set_error(LumibotBrokerAPIError(error_msg))
            order.status = Order.OrderStatus.ERROR  # ensure status is enum
            self._safe_stream_dispatch(self.ERROR_ORDER, order=order, error_msg=error_msg)
        return order

    # ------------------------------------------------------------------
    # Position‑closing helper using Bitunix reduce‑only orders
    # ------------------------------------------------------------------
    def close_position(self, strategy_name: str, asset: Asset, fraction: float = 1.0,
                       position_side=None, position_id=None):
        """
        Close all or part of an existing position using a reduce‑only
        market order (tradeSide="CLOSE").

        Parameters
        ----------
        strategy_name : str
            Name of the strategy that owns the position.
        asset : Asset
            The asset whose position should be closed.
        fraction : float, optional
            Fraction of the position to close (0 < fraction ≤ 1). Defaults to 1 (full close).

        Returns
        -------
        Optional[Order]
            The submitted order, or ``None`` if no position exists.
        """
        selectors = {key: value for key, value in (("position_side", position_side), ("position_id", position_id))
                     if value is not None}
        if not selectors:
            legs = [leg for leg in self.get_tracked_positions(strategy_name) if leg.asset == asset and leg.quantity != 0]
            if len(legs) > 1:
                # Both hedge legs: close each one by its own exchange position.
                return [self.close_position(strategy_name, asset, fraction, position_side=leg.position_side,
                                            position_id=leg.position_id) for leg in legs]
        # Retrieve the current tracked position
        position = self.get_tracked_position(strategy_name, asset, **selectors)
        if not position or position.quantity == 0:
            return None

        fraction = Decimal(str(fraction))
        if not fraction.is_finite() or not 0 < fraction <= 1:
            raise ValueError("fraction must be greater than 0 and at most 1")
        quantity = abs(Decimal(str(position.quantity)))

        # Create the order object
        order = Order(strategy_name, asset, quantity * fraction)

        # Reverse the side for closing
        if position.quantity > 0:
            order.side = Order.OrderSide.SELL
        elif position.quantity < 0:
            order.side = Order.OrderSide.BUY

        # Mark as reduce‑only so `_submit_order` will send tradeSide="CLOSE"
        order.reduce_only = True
        order.position_side = getattr(position, "position_side", None)
        order.position_id = getattr(position, "position_id", None)

        return self.submit_order(order)

    def cancel_order(self, order: Order):
        """
        Cancels a FUTURES order.
        """
        if not order.identifier:
            self.logger.warning("Specified order doesn't exist")
            return

        try:
            # Retry up to 5 times on network error
            symbol = getattr(order, "symbol", None)
            if not symbol and getattr(order, "asset", None) is not None:
                symbol = getattr(order.asset, "symbol", None)
            response = self.api.cancel_order(order_id=order.identifier, symbol=symbol)

            # Check response
            if response and response.get("code") == 0:
                # Use self._process_trade_event for consistency
                self._process_trade_event(order, self.CANCELED_ORDER)
            else:
                # Log error but don't raise, let polling handle final state
                logger.error(f"Failed to cancel order {order.identifier}: {response}")
                # Dispatch an error event if immediate feedback is needed
                self._process_trade_event(
                    order, self.ERROR_ORDER, error=LumibotBrokerAPIError(f"Failed to cancel order: {response}")
                )
        except Exception as e:
            # Log error but don't raise, let polling handle final state
            logger.error(f"Error canceling order {order.identifier}: {str(e)}")
            # Dispatch an error event
            self._process_trade_event(
                order, self.ERROR_ORDER, error=LumibotBrokerAPIError(f"Error canceling order: {str(e)}")
            )
            pass

    def _pull_broker_order(self, identifier: str, asset_type="crypto") -> dict | None:
        """
        Fetches a single order by ID from BitUnix.
        """
        try:
            response = self.api.get_order_detail(order_id=identifier)
            if response and response.get("code") == 0:
                return response.get("data")
            return None
        except Exception:
            logger.error(f"Error getting order details for {identifier}")
            return None

    def _pull_broker_all_orders(self, symbol: str | None = None, status: str | None = None) -> list[dict]:
        all_orders = []
        # Fetch FUTURES open orders
        try:
            fut_open_resp = self.api.get_pending_orders(symbol=symbol)
            if fut_open_resp and fut_open_resp.get("code") == 0:

                data = fut_open_resp.get("data") or {}
                fut_orders = data.get("orderList", [])
                if len(fut_orders) > 0:
                    all_orders.extend(fut_orders)
        except Exception:
            logger.warning("Error fetching futures open orders")
        return all_orders

    def _map_status_from_bitunix(self, broker_status) -> Order.OrderStatus:
        """Maps BitUnix order status string to Lumibot OrderStatus enum."""
        # Ensure broker_status is a string before uppercasing and strip trailing underscores and whitespace
        status_str = str(broker_status).upper().rstrip('_').strip()

        status_map = {
            "NEW":               Order.OrderStatus.SUBMITTED,
            "PARTIALLY_FILLED":  Order.OrderStatus.PARTIALLY_FILLED,
            "FILLED":            Order.OrderStatus.FILLED,
            "CANCELED":          Order.OrderStatus.CANCELED,
            "REJECTED":          Order.OrderStatus.ERROR,
            "EXPIRED":           Order.OrderStatus.EXPIRED,
            "PENDING_CANCEL":    Order.OrderStatus.CANCELLING,
        }
        mapped_status = status_map.get(status_str)

        if mapped_status is None:
            logger.warning(
                f"Unmapped Bitunix order status received: '{broker_status}' "
                f"(processed as '{status_str}'). Preserving UNKNOWN."
            )
            return Order.OrderStatus.UNKNOWN
        return mapped_status

    def _parse_broker_order(
        self, response: dict, strategy_name: str, strategy_object: Any = None
    ) -> Order | None:
        """Converts BitUnix order response to Lumibot Order object."""
        if not response:
            return None

        try:
            # Extract order details
            order_id = response.get("orderId")
            symbol = response.get("symbol", "")
            status = response.get("status", "")
            side_raw = response.get("side", "")
            order_type = response.get("orderType", "")

            # Extract quantities and prices
            # fields use 'qty'/'tradeQty' for BitUnix
            qty_original = Decimal(str(response.get("qty",     "0")))
            qty_executed = Decimal(str(response.get("tradeQty","0")))
            # parse limit price only if numeric
            price_limit = None
            ps = response.get("price")
            if ps and isinstance(ps, str) and order_type != "MARKET":
                price_limit = Decimal(ps)
            # parse average price
            price_avg = None
            ap = response.get("avgPrice")
            if ap:
                price_avg = Decimal(str(ap))

            leverage=int(str(response.get("leverage", "1")))

            asset = Asset(symbol, Asset.AssetType.CRYPTO_FUTURE, leverage=leverage)
            quote = None

            # Map order side
            side = Order.OrderSide.BUY if side_raw.upper() == "BUY" else Order.OrderSide.SELL
            is_close = response.get("tradeSide") == "CLOSE" or bool(response.get("reduceOnly"))
            # HEDGE responses name the position side for a CLOSE and the opening
            # direction for an OPEN, so the wire side identifies the leg either way.
            mode = response.get("positionMode") or getattr(self, "_position_mode", None)
            hedged = mode == "HEDGE" or (mode is None and response.get("tradeSide") in ("OPEN", "CLOSE"))
            position_side = ("long" if side == Order.OrderSide.BUY else "short") if hedged else None
            if is_close and hedged:
                side = Order.OrderSide.SELL if side == Order.OrderSide.BUY else Order.OrderSide.BUY
            raw_position_id = response.get("positionId")

            # Map order type
            if order_type.upper() == "LIMIT":
                order_type_enum = Order.OrderType.LIMIT
            elif order_type.upper() == "MARKET":
                order_type_enum = Order.OrderType.MARKET
            elif order_type.upper() == "STOP":
                order_type_enum = Order.OrderType.STOP
            elif order_type.upper() == "STOP_LIMIT":
                order_type_enum = Order.OrderType.STOP_LIMIT
            else:
                order_type_enum = Order.OrderType.MARKET  # Default

            # Map order status
            order_status = self._map_status_from_bitunix(status)

            # Create Lumibot Order object (use keywords to avoid duplicate positional limit_price)
            order = Order(
                strategy=strategy_name,
                asset=asset,
                quantity=qty_original,
                side=side,
                order_type=order_type_enum,
                limit_price=price_limit,
                status=order_status,
                identifier=order_id,
                quote=quote,
                position_side=position_side,
                position_id=str(raw_position_id) if raw_position_id not in (None, "") else None,
            )

            # Set filled info
            order.reduce_only = is_close or bool(response.get("reduceOnly", False))
            order.broker_status = status
            order.filled_quantity = qty_executed
            order.avg_fill_price = price_avg

            # Set creation time if available
            create_time = response.get("time") or response.get("createTime")
            if create_time:
                order.broker_create_date = pd.to_datetime(create_time, unit='ms', utc=True)

            # Store raw response for reference
            order.update_raw(response)
            return order

        except Exception as e:
            logger.error(f"Error parsing order: {str(e)}")
            logger.error(_format_exc())
            return None

    # --- Polling-based stream implementation ---

    def do_polling(self):
        """
        Polls Bitunix for order status updates and dispatches events.
        """
        # Pull current positions and sync with Lumibot's positions
        self.sync_positions(None)

        # Get all open orders from Bitunix and dispatch them to the stream for processing
        raw_orders = self._pull_broker_all_orders()
        stored_orders = {x.identifier: x for x in self.get_all_orders()}
        for order_row in raw_orders:
            order = self._parse_broker_order(order_row, strategy_name=self._strategy_name)
            if not order:
                continue
            # Cumulative executions can advance without a status change.
            # Reduce them synchronously through the same owner as Alpaca polling;
            # subscriber callbacks run after the broker tracker lock is released.
            if order.status in (Order.OrderStatus.PARTIALLY_FILLED, Order.OrderStatus.FILLED):
                terminal = order.status == Order.OrderStatus.FILLED
                tracked = stored_orders.get(order.identifier)
                if tracked is None:
                    tracked = self._process_new_order(order)
                self._reconcile_cumulative_execution(
                    tracked, order.filled_quantity, order.avg_fill_price, terminal=terminal, raw=order_row,
                )
                continue
            # Preserve fills when cancellation wins after partial execution.
            if order.status in (Order.OrderStatus.CANCELED, Order.OrderStatus.ERROR, Order.OrderStatus.EXPIRED):
                tracked = stored_orders.get(order.identifier)
                if tracked is not None and order.filled_quantity:
                    self._reconcile_cumulative_execution(tracked, order.filled_quantity, order.avg_fill_price, raw=order_row)
            tracked = stored_orders.get(order.identifier)
            if tracked is None:
                self._process_broker_synced_order(order)
            else:
                tracked.quantity = order.quantity
                tracked.broker_create_date = order.broker_create_date
                tracked.broker_update_date = order.broker_update_date
                tracked.broker_status = order.broker_status
                if order.avg_fill_price is not None:
                    tracked.avg_fill_price = order.avg_fill_price
                if not order.equivalent_status(tracked):
                    if order.status == Order.OrderStatus.SUBMITTED:
                        self._safe_stream_dispatch(self.NEW_ORDER, order=tracked)
                    elif order.status == Order.OrderStatus.CANCELED:
                        self._safe_stream_dispatch(self.CANCELED_ORDER, order=tracked)
                    elif order.status == Order.OrderStatus.ERROR:
                        self._safe_stream_dispatch(self.ERROR_ORDER, order=tracked,
                            error_msg=order_row.get("msg", f"{self.name} rejected order {order.identifier}"))
                    else:
                        # Retain pending cancellation, expiration and unfamiliar
                        # native states instead of converting them to a cancel.
                        tracked.status = order.status

        # A broad-list miss is not cancellation evidence. Use the existing
        # direct-lookup owner and retain working state on missing/failed reads.
        broker_ids = {str(row.get("orderId")) for row in raw_orders if row.get("orderId") is not None}
        for order in self.get_tracked_orders():
            if str(order.identifier) not in broker_ids and order.is_active():
                self._refresh_missing_active_order_from_broker(
                    order, self._strategy_name, broker_order_count=len(raw_orders),
                )

    def _apply_direct_order_observation(self, order_lumi, matched_order):
        changed = False
        if getattr(matched_order, "filled_quantity", 0):
            changed = self._reconcile_cumulative_execution(
                order_lumi, matched_order.filled_quantity, matched_order.avg_fill_price,
                terminal=matched_order.status == Order.OrderStatus.FILLED, raw=matched_order._raw,
            )
        return super()._apply_direct_order_observation(order_lumi, matched_order) or changed

    def _get_stream_object(self):
        """Returns the polling stream object."""
        from lumibot.trading_builtins import PollingStream

        return PollingStream(self.poll_interval)

    def _register_stream_events(self):
        """Register polling event for Bitunix."""
        broker = self

        @broker.stream.add_action(broker.POLL_EVENT)
        def on_trade_event_poll():
            self.do_polling()

        @broker.stream.add_action(broker.NEW_ORDER)
        def on_trade_event_new(order):
            logger.info(f"Processing action for new order {order}")
            try:
                broker._process_trade_event(order, broker.NEW_ORDER)
                return True
            except Exception:
                logger.error(_format_exc())

        @broker.stream.add_action(broker.FILLED_ORDER)
        def on_trade_event_fill(order, price, filled_quantity):
            logger.info(f"Processing action for filled order {order} | {price} | {filled_quantity}")
            try:
                broker._process_trade_event(order, broker.FILLED_ORDER, price=price, filled_quantity=filled_quantity)
                return True
            except Exception:
                logger.error(_format_exc())

        @broker.stream.add_action(broker.CANCELED_ORDER)
        def on_trade_event_cancel(order):
            logger.info(f"Processing action for cancelled order {order}")
            try:
                broker._process_trade_event(order, broker.CANCELED_ORDER)
            except Exception:
                logger.error(_format_exc())

        @broker.stream.add_action(broker.ERROR_ORDER)
        def on_trade_event_error(order, error_msg):
            logger.error(f"Processing action for error order {order} | {error_msg}")
            try:
                if order.is_active():
                    broker._process_trade_event(order, broker.ERROR_ORDER)
                logger.error(error_msg)
                order.set_error(error_msg)
            except Exception:
                logger.error(_format_exc())

    def _run_stream(self):
        self._stream_established()
        try:
            self.stream._run()
        except Exception as e:
            logger.error(f"Error running Bitunix polling stream: {e}")

    # ...existing code...

    def _modify_order(self, order: Order, price: float = None, quantity: float = None):
        """
        Modifies an existing order (if supported by BitUnix).
        """
        if not order.identifier:
            raise LumibotBrokerAPIError("Cannot modify order without order ID")

        try:
            # Determine symbol format based on asset type
            if order.asset.asset_type == Asset.AssetType.CRYPTO_FUTURE:
                symbol = order.asset.symbol
            else:
                logger.error(f"Cannot modify order for asset type {order.asset.asset_type}")
                return order

            # Prepare modification parameters
            params = {
                "orderId": order.identifier,
                "symbol": symbol
            }

            # Add optional modifications
            if price is not None:
                params["price"] = str(price)
            if quantity is not None:
                params["quantity"] = str(quantity)

            # Send modification request
            response = self.api.modify_order(**params)

            # Process response
            if response and response.get("code") == 0:
                # Update the order object with new values
                if price is not None:
                    order.limit_price = Decimal(str(price))
                if quantity is not None:
                    order.quantity = Decimal(str(quantity))

                # Update raw data
                order.update_raw(response)
                return order
            else:
                raise LumibotBrokerAPIError(f"Failed to modify order: {response}")
        except Exception as e:
            raise LumibotBrokerAPIError(f"Error modifying order: {str(e)}") from e

    def _pull_position(self, strategy, asset: Asset, position_side=None, position_id=None) -> Position | None:
        """
        Fetch a single position by asset, selecting a hedge leg when both exist.
        """
        # Reuse the multi-position pull and filter by asset
        matches = [
            pos for pos in self._pull_positions(strategy)
            if pos.asset == asset
            and (position_side is None or pos.position_side == str(position_side).lower())
            and (position_id is None or pos.position_id == str(position_id))
        ]
        if len(matches) > 1:
            raise ValueError(f"Multiple positions for {asset.symbol}; specify position_side or position_id")
        return matches[0] if matches else None

    def get_historical_account_value(self, start_date=None, end_date=None, frequency=None) -> dict:
        """
        Not implemented: Bitunix does not support historical account value retrieval.
        """
        self.logger.error("get_historical_account_value is not implemented for Bitunix broker.")
        return {}

    def sell_all(self, strategy_name, cancel_open_orders: bool = True, strategy=None, is_multileg: bool = False):
        """Override sell_all to use flash_close_position for futures."""
        # Optional: cancel any open orders first
        if cancel_open_orders:
            super().sell_all(strategy_name, cancel_open_orders=True, strategy=strategy, is_multileg=is_multileg)
        # Fetch current positions
        positions = self._pull_positions(strategy)
        # Flash-close all futures positions
        for pos in positions:
            if pos.asset.asset_type in (Asset.AssetType.CRYPTO_FUTURE) and pos.quantity != 0:
                raw = getattr(pos, "_raw", {})
                position_id = raw.get("positionId")
                if not position_id:
                    logger.warning("No positionId for %s, skipping flash close", pos.asset.symbol)
                    continue
                side = "SELL" if pos.quantity > 0 else "BUY"
                resp = self.api.flash_close_position(position_id=position_id, side=side)
                if not resp or resp.get("code") != 0:
                    logger.warning("Failed to flash close position %s: %s", position_id, resp)
                else:
                    logger.info("Flash-closed position %s (%s)", position_id, pos.asset.symbol)

    def _parse_source_timestep(self, timestep: str) -> str:
        """
        Convert Lumibot timestep to BitUnix interval format.
        Delegates to the data source's implementation.
        """
        if hasattr(self.data_source, '_parse_source_timestep'):
            try:
                parsed = self.data_source._parse_source_timestep(timestep)
            except ValueError:
                # The data source refuses unknown timesteps for history; the
                # broker keeps its long-standing interval mapping below.
                parsed = None
            if isinstance(parsed, str):
                return parsed

        # Fall back when the data source does not implement the parser or
        # returns an invalid value.
        normalized = timestep.lower().strip()

        timestep_map = {
            "1m": "1m", "minute": "1m",
            "3m": "3m",
            "5m": "5m",
            "15m": "15m",
            "30m": "30m",
            "1h": "1h", "hour": "1h",
            "2h": "2h",
            "4h": "4h",
            "1d": "1d", "day": "1d", "d": "1d"
        }

        return timestep_map.get(normalized, "1m")  # Default to 1m if unknown
