"""Native Python MetaMask managed-wallet broker."""

from decimal import Context, Decimal
from threading import Event, RLock, current_thread
from uuid import uuid4

import requests

from lumibot.brokers.broker import Broker
from lumibot.data_sources.metamask_data import MetaMaskData
from lumibot.entities import Asset, Order, Position
from lumibot.tools.metamask_client import MetaMaskAPIError, MetaMaskClient, decimal_value, token_payload
from lumibot.trading_builtins.custom_stream import PollingStream


class MetaMask(Broker):
    """One broker instance binds to one dedicated agent wallet and one market type.

    ``MODE='perp'`` routes Hyperliquid orders. ``MODE='spot'`` exposes exact-input
    swaps via :meth:`swap`; token buys cannot promise an exact output quantity.
    MetaMask retains wallet keys. Local limits are cooperative process controls;
    provider Guard Mode enforces the remote wallet policy.
    """

    IS_BACKTESTING_BROKER = False

    def __init__(self, config=None, data_source=None, connect_stream=True, **kwargs):
        config = dict(config or {})
        self.mode = config.get("MODE", "perp")
        if self.mode not in ("perp", "spot"):
            raise ValueError("MetaMask MODE must be 'perp' or 'spot'")
        self.client = MetaMaskClient(config)
        self._observations = {}
        self._event_lock = RLock()
        self._close_lock = RLock()
        self._closed = False
        self._stream_thread = None
        self._stream_ready = Event()
        if not connect_stream:
            self._stream_ready.set()
        self._poll_interval = float(config.get("POLL_INTERVAL", 10))
        data_source = data_source or MetaMaskData(config, client=self.client)
        super().__init__(
            name="metamask", config=config, data_source=data_source, connect_stream=connect_stream, **kwargs
        )
        self.market = "24/7"

    def close(self):
        """Release this broker after its Strategy/Trader execution has stopped.

        Stop dispatch, wait for owned polling/submission workers, then release
        the native session and journal. Never close from an owned worker.
        """
        workers = (getattr(self, "_orders_thread", None), self._stream_thread)
        if current_thread() in workers:
            raise RuntimeError("Close MetaMask from its owner after stopping Strategy/Trader execution")
        with self._close_lock:
            if self._closed:
                return
            self.cleanup_streams()
            self._stream_ready.wait()
            for worker in (getattr(self, "_orders_thread", None), self._stream_thread):
                if worker is not None:
                    worker.join()
            self.client.close()
            self._closed = True

    def _submit_order(self, order):
        if self.mode != "perp" or order.asset.asset_type != "crypto_future":
            raise ValueError("Use swap(input_asset, output_asset, input_amount) for exact-input spot swaps")
        if order.order_type not in (Order.OrderType.MARKET, Order.OrderType.LIMIT):
            raise ValueError("MetaMask supports market and limit orders; conditional orders are not emulated")
        if order.order_class not in (None, "", Order.OrderClass.SIMPLE):
            raise ValueError("MetaMask does not support bracket or multi-leg orders")
        if order.quote is not None and order.quote.symbol != "USDC":
            raise ValueError("Hyperliquid perpetuals settle in USDC")
        if order.asset.multiplier != 1:
            raise ValueError("Hyperliquid quantities are base units with multiplier=1")
        if order.side not in (Order.OrderSide.BUY, Order.OrderSide.SELL):
            raise ValueError("Use buy/sell with custom_params={'reduce_only': True} to reduce a position")
        params = order.custom_params or {}
        extra = set(params) - {"reduce_only", "leverage"}
        if extra:
            raise ValueError(f"Unsupported MetaMask order parameters: {sorted(extra)}")
        tif = order.time_in_force or "gtc"
        if order.order_type == Order.OrderType.MARKET and tif == "day":
            tif = "ioc"
        if tif not in ("gtc", "ioc", "alo"):
            raise ValueError("MetaMask time_in_force must be gtc, ioc, or alo")
        request = {
            "kind": "perp",
            "id": str(order.identifier),
            "symbol": order.asset.symbol,
            "side": str(order.side),
            "quantity": format(decimal_value(order.quantity), "f"),
            "orderType": str(order.order_type),
            "leverage": params.get("leverage", order.asset.leverage),
            "reduceOnly": order.reduce_only or params.get("reduce_only", False),
            "tif": tif,
        }
        if order.order_type == Order.OrderType.LIMIT:
            request["limitPrice"] = format(decimal_value(order.limit_price), "f")
        self.client.verify()
        try:
            response = self.client.submit(request)
        except (requests.Timeout, requests.ConnectionError):
            response = {
                "id": str(order.identifier),
                "request": request,
                "state": "unknown",
                "filledQuantity": "0",
                "message": "Submission outcome unknown; poll the same ID. Do not create a replacement order.",
            }
        with self._event_lock:
            if str(order.identifier) not in self._observations and self.get_tracked_order(order.identifier) is None:
                self._unprocessed_orders.append(order)
            self._observe(order, response)
        return self.get_tracked_order(order.identifier) or order

    def _submit_orders(self, orders, **kwargs):
        if kwargs.pop("is_multileg", False) or kwargs:
            raise NotImplementedError("MetaMask batch submission accepts independent orders only")
        # A wallet has one signing operation in flight at a time.
        return [self.submit_order(order) for order in orders]

    def swap(self, input_asset, output_asset, input_amount, *, slippage_bps=50, identifier=None):
        """Submit a same-chain exact-input swap; return its durable operation.

        This does not create an exact-output LumiBot buy order. Poll using
        ``get_swap(identifier)``. Reuse the ID after transport uncertainty.
        """
        if self.mode != "spot":
            raise ValueError("Set MODE='spot' for onchain swaps")
        request = {
            "kind": "swap",
            "id": identifier or uuid4().hex,
            "input": token_payload(input_asset),
            "output": token_payload(output_asset),
            "inputAmount": format(decimal_value(input_amount), "f"),
            "slippageBps": slippage_bps,
        }
        try:
            return self.client.submit(request)
        except (requests.Timeout, requests.ConnectionError):
            return {
                "id": request["id"],
                "request": request,
                "state": "unknown",
                "message": "Poll this ID; submission may have reached MetaMask",
            }

    def get_swap(self, identifier):
        return next(
            (op for op in self.client.orders() if op["id"] == identifier and op["request"]["kind"] == "swap"),
            None,
        )

    def _pull_broker_all_orders(self):
        return [op for op in self.client.orders() if op["request"]["kind"] == "perp"]

    def _pull_broker_order(self, identifier):
        return next((op for op in self._pull_broker_all_orders() if op["id"] == str(identifier)), None)

    def _parse_broker_order(self, response, strategy_name, strategy_object=None):
        request = response["request"]
        if request["kind"] != "perp":
            raise ValueError("Swap operations are retrieved with get_swap(), not exact-output orders")
        order = Order(
            strategy_name,
            Asset(request["symbol"], asset_type="crypto_future", leverage=request["leverage"]),
            decimal_value(request["quantity"]),
            request["side"],
            order_type=request["orderType"],
            limit_price=request.get("limitPrice"),
            time_in_force=request["tif"],
            quote=Asset("USDC", asset_type="crypto"),
            identifier=response["id"],
            reduce_only=request.get("reduceOnly", False),
        )
        order.update_raw(response)
        self._set_submission_outcome(order, response)
        order.status = {
            "filled": "fill",
            "canceled": "canceled",
            "rejected": "error",
            "partial_fill": "partial_fill",
            "open": "open",
        }.get(response["state"], "submitted")
        if response["state"] == "rejected":
            order.error_message = response.get("message", "Provider rejected order")
        if response.get("averagePrice"):
            order.avg_fill_price = float(decimal_value(response["averagePrice"]))
        quantity = decimal_value(response["filledQuantity"])
        if quantity and response.get("averagePrice"):
            price = decimal_value(response["averagePrice"])
            order.add_transaction(price, quantity)
        with self._event_lock:
            identifier = str(order.identifier)
            if identifier not in self._observations and self.get_tracked_order(identifier) is None:
                # Seed restored history once. Parsing a newer snapshot must not consume pending callbacks.
                value = Context(prec=160).multiply(quantity, decimal_value(response.get("averagePrice", "0")))
                self._observations[identifier] = (quantity, value, response["state"])
                # Register cumulative snapshots before shared executor synchronization
                # can treat them as new fills and add the full order size again.
                if self._first_iteration or order.is_active():
                    self._process_broker_synced_order(order)
        return order

    def _flatten_order(self, order):
        return [order]

    def _apply_direct_order_observation(self, order_lumi, matched_order):
        with self._event_lock:
            previous = self._observations.get(str(order_lumi.identifier))
            self._observe(order_lumi, matched_order._raw)
            return previous != self._observations.get(str(order_lumi.identifier))

    def _process_broker_synced_order(self, order):
        """Restore a cumulative snapshot without replaying fills into account state."""
        with self._lock:
            if self.get_tracked_order(order.identifier) is not None:
                return
            order.set_new()
            if order.is_filled():
                order.set_filled()
                tracker = self._filled_orders
            elif order.status == Order.OrderStatus.ERROR:
                order.set_error(order.error_message or "Provider rejected order")
                tracker = self._error_orders
            elif order.is_canceled():
                order.set_canceled()
                tracker = self._canceled_orders
            elif order.status == Order.OrderStatus.PARTIALLY_FILLED:
                order.set_partially_filled()
                tracker = self._partially_filled_orders
            else:
                tracker = self._new_orders if order.is_active() else self._unprocessed_orders
            tracker.append(order)
            self._invalidate_order_caches()

    def _modify_order(self, order, **kwargs):
        raise NotImplementedError("Cancel and confirm cancellation before placing a replacement order")

    def cancel_order(self, order):
        response = self.client.cancel(str(order.identifier))
        self._observe(order, response)
        return order

    def get_historical_account_value(self):
        raise NotImplementedError("MetaMask does not expose historical account equity through this adapter")

    def get_funding_payments(self, start_time, end_time, symbol=None):
        """Read funding ledger (Unix milliseconds); balances already include these cash flows."""
        if self.mode != "perp":
            raise ValueError("Funding payments apply to perpetuals only")
        return self.client.funding(start_time, end_time, symbol)

    def _get_balances_at_broker(self, quote_asset, strategy):
        balance = self.client.account(self.mode)
        if quote_asset is not None and quote_asset.symbol != balance["currency"]:
            raise ValueError(f"MetaMask account valuation is denominated in {balance['currency']}")
        return tuple(float(decimal_value(balance[k])) for k in ("cash", "positionsValue", "equity"))

    def _pull_positions(self, strategy):
        balance = self.client.account(self.mode)
        result = []
        for row in balance["positions"]:
            if self.mode == "perp":
                asset = Asset(row["symbol"], asset_type="crypto_future")
            else:
                token = row.get("asset")
                if token is None:
                    raise MetaMaskAPIError(
                        "UNBOUND_ASSET", "Wallet holds a token absent from the approved asset registry"
                    )
                asset = Asset(
                    token["symbol"],
                    asset_type="crypto",
                    chain_id=token["chainId"],
                    token_address=token["address"],
                    decimals=token["decimals"],
                )
            position = Position(
                strategy,
                asset,
                decimal_value(row["quantity"]),
                avg_fill_price=float(decimal_value(row["entryPrice"])) if row.get("entryPrice") is not None else None,
            )
            position.market_value = float(decimal_value(row["marketValue"]))
            position.pnl = float(decimal_value(row["unrealizedPnl"])) if row.get("unrealizedPnl") is not None else None
            result.append(position)
        return result

    def _pull_position(self, strategy, asset):
        return next((p for p in self._pull_positions(strategy) if p.asset == asset), None)

    def _get_stream_object(self):
        return PollingStream(self._poll_interval)

    def _register_stream_events(self):
        self.stream.add_action(self.stream.POLL_EVENT)(self.do_polling)

    def _run_stream(self):
        self._stream_thread = current_thread()
        self._stream_ready.set()
        self._stream_established()
        self.stream._run()

    def do_polling(self):
        for response in self._pull_broker_all_orders():
            if response["request"]["kind"] != "perp":
                continue
            order = self.get_tracked_order(response["id"])
            if order is not None:
                self._observe(order, response)

    def _process_partially_filled_order(self, order, price, quantity):
        with self._lock:
            terminal_status = order.status if order.is_canceled() or order.status == self.ERROR_ORDER else None
            result = super()._process_partially_filled_order(order, price, quantity)
            if terminal_status is not None:
                # Late execution evidence must reach callbacks without reopening the order.
                order.status = terminal_status
                self._clean_order_trackers(order)
            return result

    @staticmethod
    def _set_submission_outcome(order, response):
        state = response["state"]
        certainty = (
            "confirmed_submitted"
            if state in {"open", "partial_fill", "filled"}
            else "confirmed_rejected"
            if state == "rejected"
            else "unknown"
        )
        previous = getattr(order, "submission_outcome", None)
        previous = previous if isinstance(previous, dict) else {}
        release = response.get("orderRelease")
        if release is None and "orderRelease" not in response and state == "canceled":
            release = previous.get("order_release")
        venue_id = response.get("providerOrderId")
        valid_venue_id = (type(venue_id) is int and venue_id > 0) or (
            isinstance(venue_id, str) and venue_id.isdecimal() and int(venue_id) > 0
        )
        venue_evidence = (
            valid_venue_id
            or decimal_value(response.get("filledQuantity", "0")) > 0
            or bool(order.transactions)
            or previous.get("state") in {"open", "partial_fill", "filled"}
            or previous.get("venue_acceptance_observed") is True
        )
        if state == "canceled" and venue_evidence:
            certainty = "confirmed_submitted"
        if state == "canceled" and (release is not None or "orderRelease" in response) and not venue_evidence:
            client_id = release.get("clientOrderId") if isinstance(release, dict) else None
            proven = (
                isinstance(release, dict)
                and release.get("state") == "not_released"
                and release.get("source") == "native_plan_local_cancel"
                and isinstance(client_id, str)
                and len(client_id) == 34
                and client_id.startswith("0x")
                and all(character in "0123456789abcdef" for character in client_id[2:])
                and response.get("providerOrderId") is None
                and not response.get("fees")
            )
            certainty = "confirmed_not_submitted" if proven else "unknown"
        order.submission_outcome = {
            "broker_state_certainty": certainty,
            "reconciliation_required": certainty == "unknown" or bool(response.get("reconciliationErrorCode")),
            "state": state,
        }
        if state in {"open", "partial_fill", "filled"} or venue_evidence:
            order.submission_outcome["venue_acceptance_observed"] = True
        if certainty == "confirmed_not_submitted":
            order.submission_outcome["order_release"] = dict(release)

    def _observe(self, order, response):
        with self._event_lock:
            order = self.get_tracked_order(order.identifier) or order
            money = Context(prec=160)
            state = response["state"]
            previous = self._observations.get(str(order.identifier), (Decimal(0), Decimal(0), None))
            quantity = decimal_value(response["filledQuantity"])
            if quantity < previous[0]:
                raise MetaMaskAPIError(
                    "FILL_REGRESSION", "Provider fill history is incomplete; refusing to overwrite known fills"
                )
            if quantity > decimal_value(order.quantity):
                raise MetaMaskAPIError("INVALID_FILL", "Cumulative fills exceed the original order quantity")
            if previous[2] in ("filled", "canceled", "rejected"):
                state = previous[2]
                response = {**response, "state": state}
                if quantity == previous[0]:
                    order.update_raw(response)
                    # Preserve proven terminal identity despite a stale unknown reply.
                    self._set_submission_outcome(order, response)
                    return
            value = money.multiply(quantity, decimal_value(response.get("averagePrice", "0")))
            if quantity > previous[0]:
                delta = money.subtract(quantity, previous[0])
                price = money.divide(money.subtract(value, previous[1]), delta)
                if price <= 0:
                    raise MetaMaskAPIError("INVALID_FILL", "Fill price must be positive")
                event = self.FILLED_ORDER if state == "filled" else self.PARTIALLY_FILLED_ORDER
                self._process_trade_event(order, event, price=price, filled_quantity=delta)
            elif state == "filled" and previous[2] == "partial_fill" and quantity > 0:
                self._process_trade_event(
                    order, self.FILLED_ORDER, price=decimal_value(response["averagePrice"]), filled_quantity=0
                )
            elif state == "open" and previous[2] in (None, "submitted", "awaiting_approval", "unknown"):
                self._process_trade_event(order, self.NEW_ORDER)
            if state == "canceled" and previous[2] != "canceled":
                self._process_trade_event(order, self.CANCELED_ORDER)
            elif state == "rejected" and previous[2] != "rejected":
                self._process_trade_event(
                    order,
                    self.ERROR_ORDER,
                    error=MetaMaskAPIError("REJECTED", response.get("message", "Provider rejected order")),
                )
            order.update_raw(response)
            self._set_submission_outcome(order, response)
            self._observations[str(order.identifier)] = (quantity, value, state)
