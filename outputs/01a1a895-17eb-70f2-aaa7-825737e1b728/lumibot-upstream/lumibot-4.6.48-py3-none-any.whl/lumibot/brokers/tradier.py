from __future__ import annotations

import os
import re
import base64
import time
import threading
from collections import Counter
from pathlib import Path

from lumibot._lazy_imports import LazyLogger, LazyModule, lazy_class
from .broker import Broker, LumibotBrokerAPIError
from .oauth_refresh_mode import OAUTH_REFRESH_MODE_EXTERNAL, get_oauth_refresh_mode

logger = LazyLogger(__name__)
TYPE_CHECKING = False
datetime = LazyModule("datetime")
pd = LazyModule("pandas")
requests = LazyModule("requests")
Asset = lazy_class("lumibot.entities", "Asset")
Order = lazy_class("lumibot.entities", "Order")
_Tradier = None
TradierApiError = None
OrderLeg = None

if TYPE_CHECKING:
    from lumibot.entities import CashEvent, Position


def colored(*args, **kwargs):
    from termcolor import colored as _colored

    return _colored(*args, **kwargs)


def _cash_event_class():
    from lumibot.entities import CashEvent

    return CashEvent


def _position_class():
    from lumibot.entities import Position

    return Position


def _format_exc():
    import traceback

    return traceback.format_exc()


def _inspect_module():
    import inspect

    return inspect


def _json_module():
    import json

    return json


def _get_tradier_class():
    global _Tradier
    if _Tradier is None:
        from lumiwealth_tradier import Tradier as _Tradier
    return _Tradier


def _get_tradier_api_error_class():
    global TradierApiError
    if TradierApiError is None:
        from lumiwealth_tradier.base import TradierApiError
    return TradierApiError


def _order_leg(*args, **kwargs):
    global OrderLeg
    if OrderLeg is None:
        from lumiwealth_tradier.orders import OrderLeg
    return OrderLeg(*args, **kwargs)


def _create_options_symbol(*args, **kwargs):
    from lumibot.tools.helpers import create_options_symbol

    return create_options_symbol(*args, **kwargs)


def _botspot_force_broker_token_refresh() -> bool:
    return (os.environ.get("BOTSPOT_FORCE_BROKER_TOKEN_REFRESH") or "").strip().lower() in {
        "1",
        "true",
        "yes",
        "y",
        "on",
    }


class TradierTokenPersistenceError(RuntimeError):
    """Raised when a refreshed Tradier OAuth token cannot be durably written."""


class TradierTransientBrokerReadError(RuntimeError):
    """Raised when a Tradier read endpoint returns a transient provider failure."""


class Tradier(Broker):
    """
    Broker that connects to Tradier API to place orders and retrieve data. Tradier API only supports Order streaming
    for live accounts, paper trading accounts must use a 'polling' method to retrieve order updates. This class will
    still use a CustomStream object to process order updates (which can be confusing!), but this will more seamlessly
    match what other LumiBrokers are doing without requiring changes to the stategy_executor. This
    polling method will also work for Live accounts, so it will be used by default. However, future updates will be
    made to natively support websocket streaming for Live accounts.

    ***Note: Tradier does not support Trailing StopLoss orders.
    """

    POLL_EVENT = "poll"
    CASH_ACTIVITY_TYPES = (
        "ach",
        "wire",
        "dividend",
        "fee",
        "tax",
        "journal",
        "check",
        "transfer",
        "adjustment",
        "interest",
    )

    # OAuth refresh endpoint (only available for approved Tradier partner apps).
    _OAUTH_REFRESH_URL = "https://api.tradier.com/v1/oauth/refreshtoken"
    _OAUTH_REFRESH_SKEW_SECONDS = 60  # Refresh a bit early to avoid edge-of-expiry failures.
    _TRANSIENT_READ_ERROR_RE = re.compile(
        r"(?:too many 5\d\d error responses|status(?: code)?[=: ]+5\d\d|\b5\d\d\b|internal server error)",
        re.IGNORECASE,
    )

    @classmethod
    def _is_transient_broker_read_error(cls, error: Exception) -> bool:
        return bool(cls._TRANSIENT_READ_ERROR_RE.search(str(error)))

    def _current_lumibot_positions_snapshot(self) -> list[Position]:
        filled_positions = getattr(self, "_filled_positions", None)
        if filled_positions is None:
            return []
        try:
            return list(filled_positions.get_list())
        except Exception:
            return []

    @staticmethod
    def _decode_base64url_json(payload_str: str) -> dict:
        """Decode a base64url JSON payload (no padding required)."""
        if not payload_str:
            raise ValueError("Empty payload string provided.")
        missing_padding = len(payload_str) % 4
        if missing_padding:
            payload_str += "=" * (4 - missing_padding)
        decoded_bytes = base64.urlsafe_b64decode(payload_str)
        return _json_module().loads(decoded_bytes.decode("utf-8"))

    @staticmethod
    def _encode_base64url_json(payload: dict) -> str:
        """Encode a JSON payload as unpadded base64url."""
        raw = _json_module().dumps(payload, separators=(",", ":")).encode("utf-8")
        return base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")

    @staticmethod
    def _load_token_json_from_path(token_path: str | os.PathLike[str]) -> dict:
        """Load a public Tradier OAuth token JSON file."""
        path = Path(token_path).expanduser().resolve()
        with path.open("r", encoding="utf-8") as handle:
            payload = _json_module().load(handle)
        if isinstance(payload, dict) and isinstance(payload.get("token"), dict):
            payload = payload["token"]
        if not isinstance(payload, dict):
            raise ValueError("Tradier token file must contain a JSON object.")
        return payload

    @staticmethod
    def _strip_external_oauth_token(token_json: dict) -> dict:
        """Return an access-token-only OAuth payload for parent-managed refresh mode."""
        sanitized = dict(token_json)
        for secret_key in (
            "refresh_token",
            "refresh_token_issued_at",
            "refresh_token_expires_in",
            "id_token",
        ):
            sanitized.pop(secret_key, None)
        return sanitized

    @staticmethod
    def _write_json_file_atomic(path: str | os.PathLike[str], payload: dict) -> None:
        resolved = Path(path).expanduser().resolve()
        tmp_path = resolved.with_name(f".{resolved.name}.tmp.{os.getpid()}.{threading.get_ident()}")
        try:
            resolved.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
            with tmp_path.open("w", encoding="utf-8") as handle:
                _json_module().dump(payload, handle, separators=(",", ":"))
            os.chmod(tmp_path, 0o600)
            os.replace(tmp_path, resolved)
            try:
                os.chmod(resolved, 0o600)
            except OSError:
                pass
        except Exception:
            try:
                tmp_path.unlink(missing_ok=True)
            except OSError:
                pass
            raise

    @staticmethod
    def _is_auth_error(err: Exception) -> bool:
        msg = str(err or "")
        lower_msg = msg.lower()
        # lumiwealth_tradier raises "Error: 401 - <body>". Its retry session can also
        # raise urllib3/requests retry errors such as "too many 401 error responses"
        # before lumiwealth_tradier gets a response object to wrap.
        return (
            "Error: 401" in msg
            or msg.strip().startswith("401")
            or "too many 401" in lower_msg
            or "401 error responses" in lower_msg
        )

    def _oauth_enabled(self) -> bool:
        return bool(getattr(self, "_oauth_token_payload_b64", None))

    def _oauth_token_needs_refresh(self) -> bool:
        expires_at = getattr(self, "_oauth_token_expires_at", None)
        if not expires_at:
            return False
        return time.time() >= float(expires_at) - self._OAUTH_REFRESH_SKEW_SECONDS

    def _oauth_token_file_signature(self):
        token_path = getattr(self, "_oauth_token_path", None)
        if not token_path:
            return None
        stat = Path(token_path).stat()
        return (stat.st_mtime_ns, stat.st_size)

    def _apply_oauth_token_json(self, token_json: dict) -> bool:
        if not isinstance(token_json, dict):
            return False
        if getattr(self, "_oauth_refresh_mode", None) == OAUTH_REFRESH_MODE_EXTERNAL:
            token_json = self._strip_external_oauth_token(token_json)
            self._oauth_refresh_token = None
        new_access_token = token_json.get("access_token") or token_json.get("AUTH_TOKEN")
        if not new_access_token:
            return False
        self._oauth_token_payload_b64 = self._encode_base64url_json(token_json)
        if getattr(self, "_oauth_refresh_mode", None) != OAUTH_REFRESH_MODE_EXTERNAL and token_json.get("refresh_token"):
            self._oauth_refresh_token = token_json.get("refresh_token")
        try:
            issued_at_ms = int(token_json.get("issued_at") or 0)
            expires_in_s = int(float(token_json.get("expires_in"))) if token_json.get("expires_in") is not None else None
            self._oauth_token_expires_at = issued_at_ms / 1000.0 + expires_in_s if issued_at_ms and expires_in_s else None
        except Exception:
            self._oauth_token_expires_at = None
        self._apply_access_token(new_access_token)
        return True

    def _reload_oauth_token_from_path_if_changed(self) -> bool:
        token_path = getattr(self, "_oauth_token_path", None)
        if not token_path:
            return False
        try:
            signature = self._oauth_token_file_signature()
        except Exception:
            return False
        if signature == getattr(self, "_oauth_token_path_signature", None):
            return False
        try:
            token_json = self._load_token_json_from_path(token_path)
            if not self._apply_oauth_token_json(token_json):
                return False
            self._oauth_token_path_signature = signature
            logger.info(f"[Tradier] Reloaded externally managed OAuth token file from {token_path}")
            return True
        except Exception as e:
            logger.warning(f"[Tradier] Failed to reload TRADIER_TOKEN_PATH token file: {e}")
            return False

    def _apply_access_token(self, new_access_token: str) -> None:
        """Update access token across broker + data source Tradier clients (best-effort)."""
        if not new_access_token or not isinstance(new_access_token, str):
            return

        self._tradier_access_token = new_access_token

        def _update_client(client) -> None:
            if client is None:
                return
            try:
                client.AUTH_TOKEN = new_access_token
            except Exception:
                pass
            for attr in ("account", "orders", "market"):
                try:
                    part = getattr(client, attr, None)
                    if part is None:
                        continue
                    part.AUTH_TOKEN = new_access_token
                    headers = getattr(part, "REQUESTS_HEADERS", None)
                    if isinstance(headers, dict):
                        headers["Authorization"] = f"Bearer {new_access_token}"
                except Exception:
                    continue

        _update_client(getattr(self, "tradier", None))

        ds = getattr(self, "data_source", None)
        if ds is not None:
            try:
                ds.api_key = new_access_token
            except Exception:
                pass
            _update_client(getattr(ds, "tradier", None))

    def _persist_oauth_rotation(self, token_json: dict, new_access_token: str, new_refresh_token: str | None) -> None:
        """Write rotated Tradier OAuth tokens for provider files and BotSpot persistence."""
        rotation_path = os.environ.get("BOTSPOT_TRADIER_TOKEN_ROTATION_PATH")

        refresh_token = new_refresh_token or getattr(self, "_oauth_refresh_token", None)
        payload = dict(token_json)
        payload["access_token"] = new_access_token
        if refresh_token:
            payload["refresh_token"] = refresh_token

        token_path = getattr(self, "_oauth_token_path", None)
        if token_path:
            try:
                self._write_json_file_atomic(token_path, payload)
            except Exception as e:
                raise TradierTokenPersistenceError(
                    f"[Tradier] Failed to persist refreshed OAuth token file at {token_path}: {e}"
                ) from e

        if not rotation_path:
            return

        rotated_values = {
            "TRADIER_ACCESS_TOKEN": new_access_token,
            "TRADIER_TOKEN": self._encode_base64url_json(payload),
        }
        if refresh_token:
            rotated_values["TRADIER_REFRESH_TOKEN"] = refresh_token

        try:
            self._write_json_file_atomic(rotation_path, rotated_values)
        except Exception as e:
            raise TradierTokenPersistenceError(
                f"[Tradier] Failed to persist OAuth token rotation artifact at {rotation_path}: {e}"
            ) from e

    def _refresh_oauth_token(self, *, force: bool = False) -> bool:
        """Refresh Tradier OAuth token if possible. Returns True on successful refresh."""
        if not self._oauth_enabled():
            return False
        if getattr(self, "_oauth_refresh_mode", None) == OAUTH_REFRESH_MODE_EXTERNAL:
            return False
        if not force and not self._oauth_token_needs_refresh():
            return False

        lock = getattr(self, "_oauth_refresh_lock", None)
        if lock is None:
            self._oauth_refresh_lock = threading.Lock()
            lock = self._oauth_refresh_lock

        with lock:
            if not force and not self._oauth_token_needs_refresh():
                return False

            refresh_token = getattr(self, "_oauth_refresh_token", None)
            client_id = getattr(self, "_oauth_client_id", None)
            client_secret = getattr(self, "_oauth_client_secret", None)

            if not refresh_token:
                logger.warning("[Tradier] TRADIER_REFRESH_TOKEN not configured; OAuth access token may expire.")
                return False
            if not client_id or not client_secret:
                logger.warning("[Tradier] TRADIER_OAUTH_CLIENT_ID / TRADIER_OAUTH_CLIENT_SECRET not configured; cannot refresh OAuth token.")
                return False

            try:
                resp = requests.post(
                    self._OAUTH_REFRESH_URL,
                    auth=(client_id, client_secret),
                    data={"grant_type": "refresh_token", "refresh_token": refresh_token},
                    headers={"Accept": "application/json"},
                    timeout=15,
                )
            except Exception as e:
                logger.warning(f"[Tradier] OAuth refresh request failed: {e}")
                return False

            if not resp.ok:
                logger.warning(f"[Tradier] OAuth refresh failed: {resp.status_code} - {resp.text}")
                return False

            try:
                token_json = resp.json()
            except Exception as e:
                logger.warning(f"[Tradier] OAuth refresh returned non-JSON response: {e}")
                return False

            now_ms = int(time.time() * 1000)
            if token_json.get("issued_at") is None:
                token_json["issued_at"] = now_ms

            new_access_token = token_json.get("access_token")
            if not new_access_token:
                logger.warning("[Tradier] OAuth refresh response missing access_token.")
                return False

            new_refresh_token = token_json.get("refresh_token")
            if new_refresh_token:
                self._oauth_refresh_token = new_refresh_token

            expires_in = token_json.get("expires_in")
            try:
                issued_at_ms = int(token_json.get("issued_at"))
                expires_in_s = int(float(expires_in)) if expires_in is not None else None
                if expires_in_s:
                    self._oauth_token_expires_at = issued_at_ms / 1000.0 + expires_in_s
            except Exception:
                # If we can't parse expiry, keep existing best-effort expiry (or none).
                pass

            self._apply_access_token(new_access_token)
            self._persist_oauth_rotation(token_json, new_access_token, new_refresh_token)
            return True

    def _install_oauth_refresh_hooks(self) -> None:
        """Wrap Tradier API calls to refresh on expiry / 401 (best-effort)."""
        if not self._oauth_enabled():
            return

        def _wrap_component(component) -> None:
            if component is None:
                return
            if getattr(component, "_lumibot_oauth_wrapped", False):
                return

            orig_request = getattr(component, "request", None)
            if not callable(orig_request):
                return

            def request_with_refresh(*args, **kwargs):
                if getattr(self, "_oauth_refresh_mode", None) == OAUTH_REFRESH_MODE_EXTERNAL:
                    self._reload_oauth_token_from_path_if_changed()
                else:
                    # Proactively refresh if near expiry.
                    self._refresh_oauth_token(force=False)
                try:
                    return orig_request(*args, **kwargs)
                except Exception as e:
                    if not self._is_auth_error(e):
                        raise
                    if getattr(self, "_oauth_refresh_mode", None) == OAUTH_REFRESH_MODE_EXTERNAL:
                        if self._reload_oauth_token_from_path_if_changed():
                            return orig_request(*args, **kwargs)
                    # Retry once on auth errors after forcing a refresh.
                    elif self._refresh_oauth_token(force=True):
                        return orig_request(*args, **kwargs)
                    raise

            component.request = request_with_refresh
            component._lumibot_oauth_wrapped = True

        # Broker client
        client = getattr(self, "tradier", None)
        for attr in ("account", "orders", "market"):
            _wrap_component(getattr(client, attr, None))

        # Data source client
        ds = getattr(self, "data_source", None)
        ds_client = getattr(ds, "tradier", None) if ds is not None else None
        for attr in ("account", "orders", "market"):
            _wrap_component(getattr(ds_client, attr, None))

    def __init__(
            self,
            config=None,
            account_number=None,
            access_token=None,
            paper=None,
            connect_stream=True,
            data_source=None,
            polling_interval=5.0,

            # Need sequential order submission for Tradier becuase it is very strict that buy orders exist
            # before any stoploss/limit orders.
            max_workers=1,

            # Tradier allows SPY option trading for 15 additional min after market close
            # This will need to be set directly by the strategy
            extended_trading_minutes=0,
    ):
        # Check if the user provided both config file and keys
        if (access_token is not None or account_number is not None or paper is not None) and config is not None:
            raise Exception(
                "Please provide either a config file or access_token, account_number, and paper for Tradier. "
                "You have provided both a config file and keys so we don't know which to use."
            )

        # Check if the user has provided a config file
        if config is not None:
            # Check if the user provided all the necessary keys
            if "ACCESS_TOKEN" not in config:
                raise Exception("'ACCESS_TOKEN' not found in Tradier config")
            if "ACCOUNT_NUMBER" not in config:
                raise Exception("'ACCOUNT_NUMBER' not found in Tradier config")
            if "PAPER" not in config:
                raise Exception("'PAPER' not found in Tradier config")

            # Set the values from the config file
            access_token = config["ACCESS_TOKEN"]
            account_number = config["ACCOUNT_NUMBER"]
            paper = config["PAPER"]

        # === Optional OAuth payload support (BotSpot deploy integration) ===
        # When running in BotSpot, the runtime may receive:
        # - TRADIER_TOKEN: base64url JSON payload from the OAuth token exchange
        # - TRADIER_REFRESH_TOKEN: optional (partner apps only)
        # - TRADIER_OAUTH_CLIENT_ID / TRADIER_OAUTH_CLIENT_SECRET: required to refresh
        self._oauth_token_payload_b64 = None
        self._oauth_refresh_token = None
        self._oauth_client_id = None
        self._oauth_client_secret = None
        self._oauth_token_expires_at = None  # epoch seconds
        self._oauth_token_path = None
        self._oauth_token_path_signature = None
        self._oauth_refresh_mode = get_oauth_refresh_mode(config)

        payload_b64 = None
        try:
            if isinstance(config, dict):
                payload_b64 = config.get("TRADIER_TOKEN") or config.get("OAUTH_PAYLOAD")
        except Exception:
            payload_b64 = None
        payload_b64 = payload_b64 or os.environ.get("TRADIER_TOKEN")
        token_path_value = None
        try:
            if isinstance(config, dict):
                token_path_value = config.get("TRADIER_TOKEN_PATH")
        except Exception:
            token_path_value = None
        token_path_value = token_path_value or os.environ.get("TRADIER_TOKEN_PATH")

        token_json = None
        if token_path_value:
            self._oauth_token_path = str(Path(token_path_value).expanduser().resolve())
            try:
                token_json = self._load_token_json_from_path(self._oauth_token_path)
                payload_b64 = self._encode_base64url_json(token_json)
            except Exception as e:
                logger.warning(f"[Tradier] Failed to load TRADIER_TOKEN_PATH token file: {e}")
                token_json = None

        if payload_b64 and token_json is None:
            self._oauth_token_payload_b64 = payload_b64
            try:
                token_json = self._decode_base64url_json(payload_b64)
            except Exception as e:
                logger.warning(f"[Tradier] Failed to decode TRADIER_TOKEN payload: {e}")
                token_json = None
        elif payload_b64:
            self._oauth_token_payload_b64 = payload_b64

        if token_json:
            if self._oauth_refresh_mode == OAUTH_REFRESH_MODE_EXTERNAL:
                token_json = self._strip_external_oauth_token(token_json)
                self._oauth_token_payload_b64 = self._encode_base64url_json(token_json)
            # Prefer explicit access_token argument/config; fall back to decoded payload.
            if not access_token:
                access_token = token_json.get("access_token") or token_json.get("AUTH_TOKEN")

            self._oauth_refresh_token = (
                None
                if self._oauth_refresh_mode == OAUTH_REFRESH_MODE_EXTERNAL
                else os.environ.get("TRADIER_REFRESH_TOKEN") or token_json.get("refresh_token")
            )
            self._oauth_client_id = os.environ.get("TRADIER_OAUTH_CLIENT_ID")
            self._oauth_client_secret = os.environ.get("TRADIER_OAUTH_CLIENT_SECRET")

            try:
                issued_at_ms = int(token_json.get("issued_at") or 0)
                expires_in_s = int(float(token_json.get("expires_in"))) if token_json.get("expires_in") is not None else None
                if issued_at_ms and expires_in_s:
                    self._oauth_token_expires_at = issued_at_ms / 1000.0 + expires_in_s
            except Exception:
                # No reliable expiry metadata; refresh-on-401 hook still applies.
                pass
            if self._oauth_token_path:
                try:
                    self._oauth_token_path_signature = self._oauth_token_file_signature()
                except Exception:
                    self._oauth_token_path_signature = None

        # Check if the user has provided the necessary keys (after OAuth extraction)
        if access_token is None or account_number is None or paper is None:
            raise Exception("Please provide a config file or access_token, account_number, and paper (or set TRADIER_TOKEN for OAuth)")

        # Set the values from the keys
        self._tradier_access_token = access_token
        self._tradier_account_number = account_number
        self._tradier_paper = paper
        self.polling_interval = polling_interval

        # If this is an OAuth token, refresh before building API clients. Snapshot
        # runtimes can force this so BotSpot receives fresh token material to persist.
        force_token_refresh = _botspot_force_broker_token_refresh()
        if self._oauth_enabled():
            refreshed = self._refresh_oauth_token(force=force_token_refresh)
            if force_token_refresh and self._oauth_refresh_mode != OAUTH_REFRESH_MODE_EXTERNAL and not refreshed:
                raise RuntimeError("[Tradier] Forced OAuth token refresh failed for BotSpot snapshot runtime.")

        # Create the Tradier object
        self.tradier = _get_tradier_class()(account_number, self._tradier_access_token, paper)

        # Check if the user has provided a data source, if not, create one
        if data_source is None:
            from lumibot.data_sources.tradier_data import TradierData

            data_source = TradierData(
                account_number=account_number,
                access_token=self._tradier_access_token,
                paper=paper,
                max_workers=max_workers,
                delay=15 if paper else 0,
            )

        # Install request wrappers before Broker initializes streams/threads.
        self.data_source = data_source
        self._apply_access_token(self._tradier_access_token)
        self._install_oauth_refresh_hooks()

        super().__init__(
            name="Tradier",
            data_source=data_source,
            config=config,
            max_workers=max_workers,
            connect_stream=connect_stream,
            extended_trading_minutes=extended_trading_minutes,
        )

        # Override default market setting for Tradier to be NYSE, but still respect config/env if set
        self.market = (config.get("MARKET") if config else None) or os.environ.get("MARKET") or "NYSE"

        # Telemetry counters (best-effort; used by runtime telemetry snapshots).
        self._telemetry_polls_total = 0
        self._telemetry_events_dispatched_total = 0
        self._telemetry_orders_seen_max = 0

    def _safe_stream_dispatch(self, event, **kwargs):
        """Dispatch an event to the stream if it exists.

        Tradier can run in polling mode and/or with `connect_stream=False`. Order submission and polling must not
        crash purely because a stream is unavailable.
        """

        stream = getattr(self, "stream", None)
        if stream is None:
            return
        try:
            try:
                self._telemetry_events_dispatched_total += 1
            except Exception:
                pass
            stream.dispatch(event, **kwargs)
        except Exception:
            return

    def cancel_order(self, order: Order):
        """Cancel an order at the broker with an explicit broker request."""

        if not order.identifier:
            raise ValueError("Order identifier is not set, unable to cancel order. Did you remember to submit it?")

        try:
            self.tradier.orders.cancel(order.identifier)
        except _get_tradier_api_error_class() as e:
            raise LumibotBrokerAPIError(f"Unable to cancel order at broker. {e}") from e

    def _modify_order(self, order: Order,
                      limit_price: Union[float, None] = None,
                      stop_price: Union[float, None] = None):
        """
        Modify an order at the broker. You are only allowed to change the limit
        price and/or stop price. If you want to change the quantity, you must
        cancel the order and submit a new one (Tradier limitation).
        """
        if not order.identifier:
            raise ValueError("Order identifier is not set, unable to modify order. Did you remember to submit it?")

        # Modify the order
        try:
            self.tradier.orders.modify(
                order.identifier,
                limit_price=limit_price,
                stop_price=stop_price,
            )
        except _get_tradier_api_error_class() as e:
            raise LumibotBrokerAPIError(f"Unable to modify order at broker. {e}") from e

    def _submit_orders(self, orders, is_multileg=False, order_type=None, duration="day", price=None):
        """
        Submit multiple orders to the broker. This function will submit the orders in the order they are provided.
        If any order fails to submit, the function will stop submitting orders and return the last successful order.

        Parameters
        ----------
        orders: list[Order]
            List of orders to submit
        is_multileg: bool
            Whether the order is a multi-leg order. Default is False.
        order_type: str
            The type of multi-leg order to submit, if applicable. Valid values are ('market', 'debit', 'credit', 'even'). Default is 'market'.
        duration: str
            The duration of the order. Valid values are ('day', 'gtc', 'pre', 'post'). Default is 'day'.
        price: float
            The limit price for the order. Required for 'debit' and 'credit' order types.

        Returns
        -------
            Order
                The list of processed order objects.
        """

        # Check if order_type is set, if not, set it to 'market'
        if order_type is None:
            order_type = Order.OrderType.MARKET

        # Check if the orders are empty
        if not orders or len(orders) == 0:
            return

        # Check if it is a multi-leg order
        if is_multileg:
            tag = orders[0].tag if orders[0].tag else orders[0].strategy

            # Remove anything that's not a letter, number or "-" because Tradier doesn't accept other characters
            tag = "".join([c if c.isalnum() or c == "-" else "" for c in tag])

            # Submit the multi-leg order
            parent_order = self._submit_multileg_order(orders, order_type, duration, price, tag)
            return [parent_order]

        else:
            # Submit each order
            sub_orders = []
            for order in orders:
               sub_orders.append(self._submit_order(order))

            return sub_orders

    def _submit_multileg_order(self, orders, order_type="market", duration="day", price=None, tag=None) -> Order:
        """
        Submit a multi-leg order to Tradier. This function will submit the multi-leg order to Tradier.

        Parameters
        ----------
        orders: list[Order]
            List of orders to submit
        order_type: str
            The type of multi-leg order to submit. Valid values are ('market', 'debit', 'credit', 'even')
            Default is 'market'.
        duration: str
            The duration of the order. Valid values are ('day', 'gtc', 'pre', 'post'). Default is 'day'.
        price: float
            The limit price for the order. Required for 'debit' and 'credit' order types.
        tag: str
            The tag to associate with the order.

        Returns
        -------
            parent order of the multi-leg orders
        """

        # Check if the order type is valid
        if order_type not in ["market", "debit", "credit", "even"]:
            raise ValueError(f"Invalid order type '{order_type}' for multi-leg order.")

        # Check if the duration is valid
        if duration not in ["day", "gtc", "pre", "post"]:
            raise ValueError(f"Invalid duration {duration} for multi-leg order.")

        # Check if the price is required
        if order_type in ["debit", "credit"] and price is None:
            raise ValueError(f"Price is required for '{order_type}' order type.")

        # Check that all the order objects have the same symbol
        if len(set([order.asset.symbol for order in orders])) > 1:
            raise ValueError("All orders in a multi-leg order must have the same symbol.")

        # Use broker-native class-share notation for the underlying symbol.
        symbol = self._normalize_symbol_for_broker(
            orders[0].asset.symbol,
            asset_type=orders[0].asset.asset_type,
        )

        # Create the legs for the multi-leg order
        legs = []
        for order in orders:
            # Create the options symbol
            option_symbol = _create_options_symbol(
                order.asset.symbol, order.asset.expiration, order.asset.right, order.asset.strike
            )

            # Example leg: leg1 = _order_leg(option_symbol=option_symbol_1, quantity=1, side='buy_to_open')
            leg = _order_leg(
                option_symbol=option_symbol,
                quantity=int(order.quantity), # Quantity for Tradier must be a positive integer
                side=self._lumi_side2tradier(order),
            )
            legs.append(leg)

        # Example assuming order_type and duration are required and correctly set
        order_response = self.tradier.orders.multileg_order(
            symbol=symbol,
            order_type=order_type,
            duration=duration,
            legs=legs,
            price=price,
            tag=tag,
        )

        # Each leg uses a different option asset, just use the base symbol. This matches later Tradier API response.
        parent_asset = Asset(
            symbol=self._normalize_symbol_for_internal(symbol, asset_type=Asset.AssetType.STOCK)
        )
        parent_order = Order(
            identifier=order_response["id"],
            asset=parent_asset,
            strategy=orders[0].strategy,
            order_class=Order.OrderClass.MULTILEG,
            side=orders[0].side,
            quantity=orders[0].quantity,
            order_type=orders[0].order_type,
            time_in_force=duration,
            limit_price=price,
            tag=tag,
            status=Order.OrderStatus.SUBMITTED
        )
        for o in orders:
            o.parent_identifier = parent_order.identifier

        parent_order.child_orders = orders
        parent_order.update_raw(order_response)  # This marks order as 'transmitted'
        self._unprocessed_orders.append(parent_order)
        self._safe_stream_dispatch(self.NEW_ORDER, order=parent_order)
        return parent_order

    def _submit_order(self, order: Order):
        """
        Do checking and input sanitization, then submit the order to the broker.
        Parameters
        ----------
        order: Order
            The order to submit to the broker

        Returns
        -------
            Updated order with broker identifier filled in
        """

        tag = order.tag if order.tag else order.strategy
        # Replace non-alphanumeric characters with '-', underscore "_" is not allowed by Tradier
        tag = re.sub(r'[^a-zA-Z0-9-]', '-', tag)

        order_limit_price = order.limit_price \
            if order.order_type != Order.OrderType.STOP_LIMIT else order.stop_limit_price

        try:
            # Check if the order is an OCO/OTO/Bracker order
            if order.is_advanced_order():
                # Create the legs for the Combo order. For OTO/Bracket orders, the parent (entry) order is the first
                # leg order and the children (exit) orders follow. For OCO orders, the parent is excluded from the
                # legs list because there is no entry order (i.e. it has been submitted previously).
                legs = []
                if order.order_class != Order.OrderClass.OCO:
                    # Create the stock/options symbol
                    parent_option_symbol = _create_options_symbol(
                        order.asset.symbol, order.asset.expiration, order.asset.right, order.asset.strike
                    ) if order.asset.asset_type == Asset.AssetType.OPTION else None
                    parent_stock_symbol = self._normalize_symbol_for_broker(order.asset.symbol, asset_type=order.asset.asset_type) \
                        if order.asset.asset_type != Asset.AssetType.OPTION else None

                    # Add the parent order to the legs list
                    legs.append(_order_leg(
                        stock_symbol=parent_stock_symbol,  # None if option order
                        option_symbol=parent_option_symbol,  # None if stock order
                        quantity=int(order.quantity),
                        side=self._lumi_side2tradier(order),
                        price=order_limit_price,
                        stop=order.stop_price,
                        type=order.order_type,
                    ))

                for child_order in order.child_orders:
                    if child_order.asset is None:
                        logger.error(f"Asset {child_order.asset} not supported by Tradier.")
                        return None

                    # Check if the child order is a stop limit order
                    # Note: Tradier does not support Trailing Stop orders
                    child_limit_price = child_order.limit_price \
                        if child_order.order_type != Order.OrderType.STOP_LIMIT else child_order.stop_limit_price

                    # Create the stock/options symbol
                    child_option_symbol = _create_options_symbol(
                        child_order.asset.symbol,
                        child_order.asset.expiration,
                        child_order.asset.right,
                        child_order.asset.strike,
                    ) if child_order.asset.asset_type == Asset.AssetType.OPTION else None
                    child_stock_symbol = self._normalize_symbol_for_broker(
                        child_order.asset.symbol,
                        asset_type=child_order.asset.asset_type,
                    ) \
                        if child_order.asset.asset_type != Asset.AssetType.OPTION else None

                    # Create the leg
                    leg = _order_leg(
                        stock_symbol=child_stock_symbol,  # None if option order
                        option_symbol=child_option_symbol,  # None if stock order
                        quantity=int(child_order.quantity),
                        side=self._lumi_side2tradier(child_order),
                        price=round(child_limit_price, 2) if child_limit_price else child_limit_price,
                        stop=round(child_order.stop_price, 2) if child_order.stop_price else child_order.stop_price,
                        type=child_order.order_type,
                    )
                    legs.append(leg)

                # Place the Advanced order
                try:
                    # Tradier calls parent Bracket orders an OTOCO. OCO/OTO names still match
                    tradier_class = 'otoco' if order.order_class == Order.OrderClass.BRACKET else order.order_class
                    order_response = self.tradier.orders.advanced_order(
                        duration=order.time_in_force,
                        order_class=tradier_class,
                        legs=legs,
                        tag=tag,
                    )
                except _get_tradier_api_error_class() as e:
                    msg = colored(f"Error submitting order {order}: {e}", color="red")
                    self._safe_stream_dispatch(self.ERROR_ORDER, order=order, error_msg=msg)
                    return None

            elif order.asset is not None and order.asset.asset_type == Asset.AssetType.STOCK:
                symbol = self._normalize_symbol_for_broker(order.asset.symbol, asset_type=order.asset.asset_type)

                # Place the order
                order_response = self.tradier.orders.order(
                    symbol,
                    self._lumi_side2tradier(order),
                    order.quantity,
                    order_type=order.order_type,
                    duration=order.time_in_force,
                    limit_price=order_limit_price,
                    stop_price=order.stop_price,
                    tag=tag,
                )

            elif order.asset is not None and order.asset.asset_type == Asset.AssetType.OPTION:
                tradier_side = self._lumi_side2tradier(order)
                stock_symbol = self._normalize_symbol_for_broker(order.asset.symbol, asset_type=order.asset.asset_type)
                option_symbol = _create_options_symbol(
                    order.asset.symbol, order.asset.expiration, order.asset.right, order.asset.strike
                )

                if not tradier_side or not option_symbol:
                    logger.error(f"Unable to parse order {order} for Tradier.")
                    return None

                order_response = self.tradier.orders.order_option(
                    stock_symbol,
                    option_symbol,
                    tradier_side,
                    order.quantity,
                    order_type=order.order_type,
                    duration=order.time_in_force,
                    limit_price=order_limit_price,
                    stop_price=order.stop_price,
                    tag=tag,
                )
            else:
                # Log the error and return None
                logger.error(f"Asset {order.asset} not supported by Tradier.")
                return None

            order.identifier = order_response["id"]
            order.status = Order.OrderStatus.SUBMITTED
            order.update_raw(order_response)  # This marks order as 'transmitted'
            self._unprocessed_orders.append(order)
            self._safe_stream_dispatch(self.NEW_ORDER, order=order)

        except _get_tradier_api_error_class() as e:
            msg = colored(f"Error submitting order {order}: {e}", color="red")
            self._safe_stream_dispatch(self.ERROR_ORDER, order=order, error_msg=msg)

        return order

    def _get_balances_at_broker(self, quote_asset: Asset, strategy):
        try:
            df = self.tradier.account.get_account_balance()
        except _get_tradier_api_error_class() as e:
            # Check if the error is a 401 or 403, if so, the access token is invalid
            error = str(e)
            if "401" in error or "403" in error:
                # Check if the access token or account number is invalid
                if (self._tradier_access_token is None or self._tradier_account_number is None or
                        len(self._tradier_access_token) == 0 or len(self._tradier_account_number) == 0):
                    colored_message = colored("Your TRADIER_ACCOUNT_NUMBER or TRADIER_ACCESS_TOKEN are blank. "
                                              "Please check your keys.", color="red")
                    raise ValueError(colored_message) from e

                # Conceal the end of the access token
                access_token = self._tradier_access_token[:7] + "*" * 7
                colored_message = colored(f"Your TRADIER_ACCOUNT_NUMBER or TRADIER_ACCESS_TOKEN are invalid. "
                                          f"Your account number is: {self._tradier_account_number} and your "
                                          f"access token is: {access_token}", color="red")
                raise ValueError(colored_message) from e
            raise e
        except Exception as e:
            logger.error(f"Error pulling balances from Tradier: {e}")
            # Add traceback to the error message
            logger.error(_format_exc())
            return None

        # Get the portfolio value (total_equity) column
        portfolio_value = float(df["total_equity"].iloc[0])

        # Get the cash (total_cash) column
        cash = float(df["total_cash"].iloc[0])

        # Calculate the gross positions value
        positions_value = portfolio_value - cash

        return cash, positions_value, portfolio_value

    def get_historical_account_value(self):
        logger.error("The function get_historical_account_value is not implemented yet for Tradier.")
        return {"hourly": None, "daily": None}

    @staticmethod
    def _extract_history_amount(row: dict) -> float:
        CashEvent = _cash_event_class()
        for key in ("amount", "net_amount", "total", "cash", "value"):
            if key in row and row.get(key) not in (None, ""):
                return CashEvent.coerce_amount(row.get(key))
        return 0.0

    @staticmethod
    def _extract_history_field(row: dict, raw_type: str, field_name: str):
        nested_key = f"{raw_type}.{field_name}"
        value = row.get(nested_key)
        if value not in (None, ""):
            return value
        return row.get(field_name)

    @classmethod
    def _extract_history_description(cls, row: dict, raw_type: str) -> str | None:
        description = cls._extract_history_field(row, raw_type, "description")
        if description not in (None, ""):
            return str(description)
        symbol = cls._extract_history_field(row, raw_type, "symbol")
        if symbol not in (None, ""):
            return str(symbol)
        return None

    @classmethod
    def _extract_history_symbol(cls, row: dict, raw_type: str) -> str | None:
        symbol = cls._extract_history_field(row, raw_type, "symbol")
        if symbol in (None, ""):
            return None
        return str(symbol)

    @classmethod
    def _extract_history_quantity(cls, row: dict, raw_type: str) -> str | None:
        quantity = cls._extract_history_field(row, raw_type, "quantity")
        if quantity in (None, ""):
            return None
        return str(quantity)

    @staticmethod
    def _override_cash_event_type_from_description(description: str | None) -> str | None:
        normalized_description = str(description or "").strip().lower()
        if not normalized_description:
            return None
        if "tax" in normalized_description:
            return "tax"
        if "fee" in normalized_description or "subscription" in normalized_description:
            return "fee"
        return None

    @staticmethod
    def _is_tradier_external_transfer(raw_type: str, description: str | None) -> bool:
        normalized_raw_type = str(raw_type or "").strip().lower()
        normalized_description = str(description or "").strip().lower()

        if normalized_raw_type in {"ach", "wire", "check"}:
            return True
        if normalized_raw_type == "journal":
            return "journal to account" in normalized_description or "journal from account" in normalized_description
        if normalized_raw_type != "transfer":
            return False

        internal_markers = (
            "annual ira fee",
            "pro subscription",
            "clearing fee",
            "clearing fees",
            "mark to market",
            "tfr to type",
            "tfr from type",
        )
        if any(marker in normalized_description for marker in internal_markers):
            return False

        external_markers = (
            "journal to account",
            "journal from account",
            "cash transfer",
            "account transfer",
            "wire transfer",
            "ach transfer",
        )
        return any(marker in normalized_description for marker in external_markers)

    @classmethod
    def _map_cash_event_type(cls, raw_type: str, amount: float, description: str | None = None) -> tuple[str, bool]:
        normalized_raw_type = str(raw_type or "").strip().lower()
        description_override = cls._override_cash_event_type_from_description(description)
        if description_override is not None:
            return description_override, False
        if normalized_raw_type in {"ach", "wire", "check", "transfer", "journal"}:
            if cls._is_tradier_external_transfer(normalized_raw_type, description):
                return ("deposit" if amount >= 0 else "withdrawal"), True
            if normalized_raw_type == "journal":
                return "journal", False
            if normalized_raw_type == "transfer":
                return "adjustment", False
        if normalized_raw_type == "dividend":
            return "dividend", False
        if normalized_raw_type == "interest":
            return "interest", False
        if normalized_raw_type == "fee":
            return "fee", False
        if normalized_raw_type == "tax":
            return "tax", False
        if normalized_raw_type == "journal":
            return "journal", False
        if normalized_raw_type == "adjustment":
            return "adjustment", False
        return "other_cash", False

    @classmethod
    def _normalize_history_row_to_cash_event(cls, row: dict) -> CashEvent | None:
        if not isinstance(row, dict):
            return None
        CashEvent = _cash_event_class()

        raw_type = str(row.get("type") or "").strip().lower()
        if not raw_type or raw_type in {"trade", "option"}:
            return None

        amount = cls._extract_history_amount(row)
        if raw_type in {"ach", "wire", "check", "transfer"} and amount == 0:
            return None
        description = cls._extract_history_description(row, raw_type) or raw_type
        symbol = cls._extract_history_symbol(row, raw_type)
        quantity = cls._extract_history_quantity(row, raw_type)
        event_type, is_external_cash_flow = cls._map_cash_event_type(raw_type, amount, description)
        occurred_at = (
            row.get("date")
            or row.get("created_at")
            or row.get("settlement_date")
            or row.get("transaction_date")
        )
        broker_event_id = row.get("id") or row.get("event_id") or row.get("transaction_id")

        return CashEvent(
            event_id=CashEvent.build_event_id(
                broker_name="tradier",
                broker_event_id=broker_event_id,
                raw_type=raw_type,
                raw_subtype=row.get("status"),
                occurred_at=occurred_at,
                amount=amount,
                description=description,
                extra_components=[symbol, quantity],
            ),
            broker_event_id=broker_event_id,
            broker_name="tradier",
            event_type=event_type,
            raw_type=raw_type,
            raw_subtype=row.get("status"),
            amount=amount,
            currency=row.get("currency") or "USD",
            occurred_at=occurred_at,
            description=description,
            direction=CashEvent._infer_direction(amount),
            is_external_cash_flow=is_external_cash_flow,
        )

    @staticmethod
    def _normalize_history_payload_to_df(data) -> pd.DataFrame:
        if not isinstance(data, dict):
            return pd.DataFrame()

        history = data.get("history")
        if not history or history == "null" or not isinstance(history, dict):
            return pd.DataFrame()

        events = history.get("event")
        if not events or events == "null":
            return pd.DataFrame()
        if isinstance(events, dict):
            events = [events]
        if not isinstance(events, list):
            return pd.DataFrame()

        rows = [event for event in events if isinstance(event, dict)]
        if not rows:
            return pd.DataFrame()
        return pd.json_normalize(rows)

    def _get_tradier_history_page(
        self,
        *,
        start_date: datetime.date | None,
        end_date: datetime.date | None,
        limit: int,
        page: int,
        activity_type: str,
        supports_page: bool,
    ) -> pd.DataFrame:
        account = self.tradier.account
        request = getattr(account, "request", None)
        endpoint = getattr(account, "ACCOUNT_HISTORY_ENDPOINT", None)
        if endpoint is None:
            endpoint = f"v1/accounts/{getattr(self, '_tradier_account_number', '')}/history"

        if callable(request):
            params = {
                "start": account.date2str(start_date),
                "end": account.date2str(end_date),
                "limit": limit,
                "page": page,
                "type": activity_type.lower(),
            }
            params = {key: value for key, value in params.items() if value is not None}
            try:
                data = request(endpoint=endpoint, params=params)
            except Exception as exc:
                logger.warning(
                    "Tradier cash-event history fetch failed: %s (activity_type=%s, page=%s, "
                    "limit=%s, endpoint=%s, since_set=%s)",
                    exc,
                    activity_type,
                    page,
                    limit,
                    endpoint,
                    start_date is not None,
                )
                raise
            return self._normalize_history_payload_to_df(data)

        # Compatibility fallback for alternate clients. Some published lumiwealth_tradier versions
        # throw TypeError("string indices must be integers") when the API returns {"history": "null"}.
        kwargs = {
            "start_date": start_date,
            "end_date": end_date,
            "limit": limit,
            "activity_type": activity_type,
        }
        if supports_page:
            kwargs["page"] = page

        try:
            history_df = account.get_history(**kwargs)
        except TypeError as exc:
            if "string indices must be integers" in str(exc):
                logger.debug(
                    "Tradier cash-event history returned an empty/null payload through the wrapper "
                    "(activity_type=%s, page=%s, limit=%s). Treating as empty.",
                    activity_type,
                    page,
                    limit,
                )
                return pd.DataFrame()
            raise

        if isinstance(history_df, pd.DataFrame):
            return history_df
        return self._normalize_history_payload_to_df(history_df)

    def get_cash_events(
        self,
        *,
        since: datetime.datetime | None = None,
        limit: int | None = 100,
    ) -> list[CashEvent]:
        CashEvent = _cash_event_class()
        start_date = CashEvent.coerce_datetime(since).date() if since is not None else None
        end_date = datetime.datetime.now(datetime.timezone.utc).date()
        per_type_limit = max(int(limit or 100), 1)
        per_page_limit = min(per_type_limit, 1000)
        max_pages = max((per_type_limit - 1) // per_page_limit + 1, 1)
        account = self.tradier.account
        supports_page = callable(getattr(account, "request", None))
        if not supports_page:
            try:
                inspect = _inspect_module()
                signature = inspect.signature(account.get_history)
                supports_page = "page" in signature.parameters or any(
                    parameter.kind is inspect.Parameter.VAR_KEYWORD
                    for parameter in signature.parameters.values()
                )
            except Exception:
                supports_page = False
        request_limit = per_page_limit if supports_page else per_type_limit
        page_count = max_pages if supports_page else 1

        event_by_id: dict[str, CashEvent] = {}
        raw_row_count = 0
        raw_type_counts = Counter()
        for activity_type in self.CASH_ACTIVITY_TYPES:
            for page in range(1, page_count + 1):
                history_df = self._get_tradier_history_page(
                    start_date=start_date,
                    end_date=end_date,
                    limit=request_limit,
                    page=page,
                    activity_type=activity_type,
                    supports_page=supports_page,
                )

                if history_df is None or history_df.empty:
                    break

                raw_row_count += len(history_df.index)
                if "type" in history_df.columns:
                    raw_type_counts.update(
                        str(raw_type or "").lower().strip()
                        for raw_type in history_df["type"].dropna().tolist()
                    )
                for row in history_df.to_dict(orient="records"):
                    event = self._normalize_history_row_to_cash_event(row)
                    if event is not None:
                        event_by_id[event.event_id] = event

                if len(history_df.index) < per_page_limit:
                    break

        normalized_events = sorted(
            event_by_id.values(),
            key=lambda event: (event.occurred_at, event.event_id),
        )
        logger.debug(
            "Tradier returned %s normalized cash events from %s raw history rows "
            "(supports_page=%s, raw_types=%s)",
            len(normalized_events),
            raw_row_count,
            supports_page,
            dict(raw_type_counts),
        )
        return normalized_events

    def _pull_positions(self, strategy):
        try:
            positions_df = self.tradier.account.get_positions()
        except _get_tradier_api_error_class() as e:
            # Check if the error is a 401 or 403, if so, the access token is invalid
            error = str(e)
            if "401" in error or "403" in error:
                # Check if the access token or account number is invalid
                if self._tradier_access_token is None or self._tradier_account_number is None or len(self._tradier_access_token) == 0 or len(self._tradier_account_number) == 0:
                    colored_message = colored("Your TRADIER_ACCOUNT_NUMBER or TRADIER_ACCESS_TOKEN are blank. Please check your keys.", color="red")
                    raise ValueError(colored_message) from e

                # Conceal the end of the access token
                access_token = self._tradier_access_token[:7] + "*" * 7
                colored_message = colored(f"Your TRADIER_ACCOUNT_NUMBER or TRADIER_ACCESS_TOKEN are invalid. Your account number is: {self._tradier_account_number} and your access token is: {access_token}", color="red")
                raise ValueError(colored_message) from e
            raise e
        except Exception as e:
            if self._is_transient_broker_read_error(e):
                logger.warning(
                    "Transient Tradier positions read failure; preserving existing Lumibot positions for this poll: %s",
                    e,
                    exc_info=True,
                )
                return self._current_lumibot_positions_snapshot()
            logger.error(f"Error pulling positions from Tradier: {e}")
            return []

        positions_ret = []
        Position = _position_class()

        if strategy is None:
            strategy_name = "Unknown"
        elif isinstance(strategy, str):
            strategy_name = strategy
        else:
            strategy_name = getattr(strategy, "name", str(strategy))

        # Loop through each row in the dataframe
        for _, row in positions_df.iterrows():
            # Get the symbol/quantity and create the position asset
            symbol = row.get("symbol") if hasattr(row, "get") else row["symbol"]
            quantity = row["quantity"]
            asset = self._asset_from_tradier_row(row, symbol=symbol, context="position")
            if asset is None:
                logger.warning(
                    "Skipping Tradier position with no usable symbol; shape=%s",
                    self._tradier_position_shape_for_log(row),
                )
                continue

            # Create the position
            position = Position(
                strategy=strategy_name,
                asset=asset,
                quantity=quantity,
            )
            self._attach_tradier_parse_metadata(
                position,
                raw_asset_type=getattr(asset, "raw_asset_type", None),
                raw_symbol=getattr(asset, "raw_symbol", None),
                broker_parse_warning=getattr(asset, "broker_parse_warning", None),
                broker_parse_degraded=getattr(asset, "broker_parse_degraded", False),
            )
            positions_ret.append(position)  # Add the position to the list

        return positions_ret

    def _pull_position(self, strategy, asset):
        """
        Pull a single position from the broker that matches the asset and strategy. If no position is found, None is
        returned.

        Parameters
        ----------
        strategy: Strategy
            The strategy object that placed the order to pull
        asset: Asset
            The asset to pull the position for

        Returns
        -------
        Position
            The position object for the asset and strategy if found, otherwise None
        """
        all_positions = self._pull_positions(strategy)

        # Loop through each position and check if it matches the asset
        for position in all_positions:
            if position.asset == asset:
                # We found the position, return it
                return position

        return None

    def _parse_broker_order_dict(self, response: dict, strategy_name: str, strategy_object=None):
        """
        Parse a broker order representation to a Lumi order object or objects. Once the Lumi order has been created,
        it will be dispatched to our "stream" queue for processing until a time when Live Streaming can be implemented.

        Parameters
        ----------
        response: dict
            The output from TradierAPI call returned by pull_broker_order()
        strategy_name: str
            The name of the strategy that placed the order
        strategy_object: Strategy
            The strategy object that placed the order

        Returns
        -------
        Order
            The Lumibot order object created from the response. For multileg orders, the parent order will be returned
            with child orders internally attached.
        """
        try:
            order_class = self._tradier_class2lumi(response.get("class"))
            legs = response["leg"] if "leg" in response and isinstance(response["leg"], list) else []
            if order_class is Order.OrderClass.BRACKET and legs:
                return self._parse_tradier_bracket_order_dict(response, legs, strategy_name, strategy_object)

            # First try to parse the parent order
            parent_order = self._parse_broker_order(response, strategy_name, strategy_object)

            # Check if the order is a multileg order
            if "leg" in response and isinstance(response["leg"], list):
                # Reset child orders and replace them with the parsed child orders from broker
                parent_order.child_orders = []

                # Loop through each leg in the response
                for leg in response["leg"]:
                    # Create the order object
                    child_order = self._parse_broker_order(leg, strategy_name, strategy_object)
                    child_order.parent_identifier = parent_order.identifier

                    # Add the order to the list
                    parent_order.add_child_order(child_order)

            return parent_order
        except Exception:
            self._log_tradier_order_parse_failure(response)
            raise

    def _parse_tradier_bracket_order_dict(self, response: dict, legs: list, strategy_name: str, strategy_object=None):
        """
        Tradier returns bracket orders as OTOCO: the entry leg first, then the limit/stop exits.
        LumiBot represents that as one BRACKET parent with the exit legs attached as children.
        """
        entry_leg = self._select_tradier_bracket_entry_leg(legs)
        exit_legs = [leg for leg in legs if leg is not entry_leg]
        child_orders = []
        for leg in exit_legs:
            child_order = self._parse_broker_order(
                leg,
                strategy_name,
                strategy_object,
                order_class_override=Order.OrderClass.SIMPLE,
            )
            child_orders.append(child_order)

        parent_response = self._merge_tradier_parent_with_entry_leg(response, entry_leg)
        parent_order = self._parse_broker_order(
            parent_response,
            strategy_name,
            strategy_object,
            child_orders=child_orders,
            order_class_override=Order.OrderClass.BRACKET,
        )
        for child_order in parent_order.child_orders:
            child_order.parent_identifier = parent_order.identifier
        return parent_order

    @staticmethod
    def _select_tradier_bracket_entry_leg(legs: list):
        if not legs:
            return {}
        for leg in legs:
            leg_type = str(leg.get("type") or "").strip().lower() if isinstance(leg, dict) else ""
            if leg_type not in {"limit", "stop", "stop_limit"}:
                return leg
        return legs[0]

    @classmethod
    def _merge_tradier_parent_with_entry_leg(cls, response: dict, entry_leg: dict):
        parent_response = dict(response)
        parent_response.pop("leg", None)
        for key in ("symbol", "option_symbol", "side", "type", "quantity", "duration", "price", "stop_price"):
            if key in entry_leg and not cls._is_missing_broker_value(entry_leg.get(key)):
                parent_response[key] = entry_leg.get(key)
        for key in ("status", "create_date", "transaction_date", "avg_fill_price", "exec_quantity", "remaining_quantity"):
            if cls._is_missing_broker_value(parent_response.get(key)) and key in entry_leg:
                parent_response[key] = entry_leg.get(key)
        return parent_response

    def _parse_broker_order(
        self,
        response: dict,
        strategy_name: str,
        strategy_object=None,
        child_orders: list | None = None,
        order_class_override=None,
    ):
        """
        Parse a broker order representation to a Lumi order object. Once the Lumi order has been created, it will
        be dispatched to our "stream" queue for processing until a time when Live Streaming can be implemented.

        Tradier API Documentation:
        https://documentation.tradier.com/brokerage-api/reference/response/orders

        :param response: The output from TradierAPI call returned _by pull_broker_order()
        :param strategy_name: The name of the strategy that placed the order
        :param strategy_object: The strategy object that placed the order
        """
        strategy_name = (
            strategy_name if strategy_name else strategy_object.name if strategy_object else None
        )

        order_class = order_class_override or self._tradier_class2lumi(response.get("class")) or Order.OrderClass.SIMPLE

        # For OCO/OTOCO orders, Tradier leaves many parent fields empty. Pull values from legs where needed.
        legs = response["leg"] if "leg" in response and isinstance(response["leg"], list) else []
        entry_order = self._select_tradier_bracket_entry_leg(legs) if order_class in {
            Order.OrderClass.BRACKET,
            Order.OrderClass.OTO,
        } else {}
        exit_legs = [leg for leg in legs if leg is not entry_order] if entry_order else legs
        limit_order = next((o for o in exit_legs if o.get("type") == "limit"), {})
        stop_order = next((o for o in exit_legs if o.get("type") in {"stop", "stop_limit"}), {})
        value_order = limit_order if order_class is Order.OrderClass.OCO else entry_order
        stop_value_order = stop_order if order_class is Order.OrderClass.OCO else entry_order

        # Parse the symbol & side
        symbol = self._extract_order_value(response, value_order, "symbol")
        option_symbol = self._extract_order_value(response, value_order, "option_symbol")
        side = self._extract_order_value(response, value_order, "side")
        asset = self._asset_from_tradier_row(
            response,
            symbol=symbol,
            option_symbol=option_symbol,
            context="order row",
        )

        # Get the reason_description if it exists
        reason_description = response.get("reason_description", "")

        # Tradier sometimes returns None for avg_fill_price and sometimes $0.0. It mostly appears that:
        #    - 0.0 occurs during submission (mostly for OCO child orders it seems)
        #    - None while the order is active/cancelled
        #    - A value when the order is filled
        # Lumibot treats 0.0 as a valid fill amount, so need to convert to None when it is just a placeholder
        #    value for non-filled orders.
        avg_fill_price = response["avg_fill_price"] if "avg_fill_price" in response else None
        if avg_fill_price == 0.0 and not Order.is_equivalent_status(response["status"], Order.OrderStatus.FILLED):
            avg_fill_price = None

        # Map Tradier order types to Lumi order types
        lumi_order_type = self._tradier_type2lumi(self._extract_order_value(response, value_order, "type"))

        # Create the order object
        order = Order(
            identifier=response["id"],
            strategy=strategy_name,
            status=response["status"],  # Status conversion happens automatically in Order
            asset=asset,
            side=self._tradier_side2lumi(side),
            quantity=self._extract_order_value(response, value_order, "quantity"),
            order_type=lumi_order_type,
            time_in_force=self._extract_order_value(response, value_order, "duration"),
            limit_price=self._extract_order_value(response, value_order, "price"),
            stop_price=self._extract_order_value(response, stop_value_order, "stop_price"),
            secondary_limit_price=limit_order.get("price") if not child_orders else None,
            secondary_stop_price=stop_order.get("stop_price") if not child_orders else None,
            tag=response["tag"] if "tag" in response and response["tag"] else None,
            date_created=response["create_date"],
            avg_fill_price=avg_fill_price,
            error_message=reason_description,
            child_orders=child_orders,
            order_class=order_class,
        )
        self._attach_tradier_parse_metadata(
            order,
            raw_asset_type=getattr(asset, "raw_asset_type", None),
            raw_symbol=getattr(asset, "raw_symbol", None),
            broker_parse_warning=getattr(asset, "broker_parse_warning", None),
            broker_parse_degraded=getattr(asset, "broker_parse_degraded", False),
        )
        # Example Tradier Date Value: '2024-10-04T15:46:14.946Z'
        order.broker_create_date = response["create_date"] if "create_date" in response else None
        order.broker_update_date = response["transaction_date"] if "transaction_date" in response else None
        order.broker_status = response["status"]
        executed = self._extract_order_value(response, value_order, "exec_quantity")
        if not self._is_missing_broker_value(executed):
            order.filled_quantity = executed
        remaining = self._extract_order_value(response, value_order, "remaining_quantity")
        if not self._is_missing_broker_value(remaining):
            order.remaining_quantity = remaining
        order.update_raw(response)  # This marks order as 'transmitted'
        return order

    @staticmethod
    def _attach_tradier_parse_metadata(entity, **metadata):
        entity.broker_parse_warning = metadata.pop("broker_parse_warning", None)
        entity.broker_parse_degraded = metadata.pop("broker_parse_degraded", False)
        for key, value in metadata.items():
            if value is not None:
                setattr(entity, key, value)
        return entity

    def _asset_from_tradier_row(self, row, *, symbol=None, option_symbol=None, context: str = "broker row"):
        raw_symbol = self._clean_tradier_symbol(symbol if symbol is not None else row.get("symbol"))
        raw_option_symbol = self._clean_tradier_symbol(
            option_symbol if option_symbol is not None else row.get("option_symbol")
        )
        raw_asset_type = self._extract_tradier_asset_type(row)
        raw_asset_type_key = str(raw_asset_type or "").strip().lower().replace(" ", "_")

        if raw_option_symbol:
            try:
                asset = Asset.symbol2asset(raw_option_symbol)
            except Exception:
                asset = Asset(raw_symbol or raw_option_symbol, asset_type=Asset.AssetType.UNKNOWN)
                self._attach_tradier_parse_metadata(
                    asset,
                    raw_asset_type=raw_asset_type or "option",
                    raw_symbol=raw_symbol or raw_option_symbol,
                    broker_parse_warning=f"Could not parse Tradier option symbol for {context}",
                    broker_parse_degraded=True,
                )
            else:
                self._attach_tradier_parse_metadata(
                    asset,
                    raw_asset_type=raw_asset_type or "option",
                    raw_symbol=raw_symbol or raw_option_symbol,
                )
            return asset

        if not raw_symbol:
            return None

        if raw_asset_type_key == "option":
            try:
                asset = Asset.symbol2asset(raw_symbol)
            except Exception:
                logger.warning(
                    "Could not parse Tradier option symbol for %s; preserving broker row as unknown.",
                    context,
                )
                return self._attach_tradier_parse_metadata(
                    Asset(raw_symbol, asset_type=Asset.AssetType.UNKNOWN),
                    raw_asset_type=raw_asset_type,
                    raw_symbol=raw_symbol,
                    broker_parse_warning=f"Could not parse Tradier option symbol: {raw_symbol}",
                    broker_parse_degraded=True,
                )
            return self._attach_tradier_parse_metadata(
                asset,
                raw_asset_type=raw_asset_type,
                raw_symbol=raw_symbol,
            )

        future_asset_types = {"future", "futures", "cont_future", "continuous_future", "future_contract"}
        if raw_asset_type_key in future_asset_types or raw_symbol.startswith("/"):
            future_symbol = raw_symbol[1:] if raw_symbol.startswith("/") else raw_symbol
            is_continuous = raw_asset_type_key in {"cont_future", "continuous_future"}
            if not is_continuous:
                try:
                    from lumibot.tools.futures_symbols import parse_contract_symbol

                    is_continuous = parse_contract_symbol(future_symbol) is None
                except Exception:
                    is_continuous = True
            asset_type = Asset.AssetType.CONT_FUTURE if is_continuous else Asset.AssetType.FUTURE
            return self._attach_tradier_parse_metadata(
                Asset(future_symbol, asset_type=asset_type),
                raw_asset_type=raw_asset_type or "future",
                raw_symbol=raw_symbol,
            )

        known_asset_types = {
            "equity": Asset.AssetType.STOCK,
            "stock": Asset.AssetType.STOCK,
            "option": Asset.AssetType.OPTION,
            "index": Asset.AssetType.INDEX,
            "forex": Asset.AssetType.FOREX,
            "cash": Asset.AssetType.FOREX,
            "crypto": Asset.AssetType.CRYPTO,
        }
        if (
            raw_asset_type_key in known_asset_types
            and known_asset_types[raw_asset_type_key] is not Asset.AssetType.OPTION
        ):
            asset_type = known_asset_types[raw_asset_type_key]
            normalized_symbol = (
                self._normalize_symbol_for_internal(raw_symbol, asset_type=asset_type)
                if asset_type in {Asset.AssetType.STOCK, Asset.AssetType.INDEX}
                else raw_symbol
            )
            return self._attach_tradier_parse_metadata(
                Asset(normalized_symbol, asset_type=asset_type),
                raw_asset_type=raw_asset_type,
                raw_symbol=raw_symbol,
            )

        if raw_asset_type_key and raw_asset_type_key not in {"equity", "stock"}:
            logger.warning(
                "Unknown Tradier asset type %r for %s; preserving broker row as unknown.",
                raw_asset_type,
                context,
            )
            return self._attach_tradier_parse_metadata(
                Asset(raw_symbol, asset_type=Asset.AssetType.UNKNOWN),
                raw_asset_type=raw_asset_type,
                raw_symbol=raw_symbol,
                broker_parse_warning=f"Unknown Tradier asset type: {raw_asset_type}",
                broker_parse_degraded=True,
            )

        normalized_symbol = self._normalize_symbol_for_internal(raw_symbol, asset_type=Asset.AssetType.STOCK)
        asset = Asset.symbol2asset(normalized_symbol)
        return self._attach_tradier_parse_metadata(
            asset,
            raw_asset_type=raw_asset_type,
            raw_symbol=raw_symbol,
        )

    @classmethod
    def _extract_tradier_asset_type(cls, row):
        for key in (
            "asset_type",
            "assetType",
            "asset_class",
            "assetClass",
            "security_type",
            "securityType",
            "instrument_type",
            "instrumentType",
        ):
            value = row.get(key) if hasattr(row, "get") else None
            if not cls._is_missing_broker_value(value):
                return str(value).strip()
        broker_class = row.get("class") if hasattr(row, "get") else None
        if isinstance(broker_class, str) and broker_class.strip().lower() in {"equity", "option"}:
            return broker_class.strip()
        return None

    @classmethod
    def _clean_tradier_symbol(cls, value):
        if cls._is_missing_broker_value(value):
            return None
        return str(value).strip().upper() or None

    @staticmethod
    def _tradier_type2lumi(order_type):
        """
        Map Tradier order types to Lumi order types.
        Tradier may return 'debit', 'credit', or 'even' for multi-leg orders, which should be treated as 'limit'.
        """
        if order_type in ("debit", "credit", "even"):
            return "limit"
        return order_type

    @classmethod
    def _extract_order_value(cls, response, child_response, key):
        """
        OCO orders have empty values for many fields. This function will pull the value from the child order if
        the value is empty in the parent order.
        """
        order_class = response.get("class")
        is_oco = isinstance(order_class, str) and order_class.strip().lower() == "oco"
        value = response.get(key)
        if not is_oco and not cls._is_missing_broker_value(value):
            return value
        return child_response.get(key, None)

    @staticmethod
    def _is_missing_broker_value(value):
        if value is None:
            return True
        if isinstance(value, (dict, list, tuple)):
            return False
        try:
            return bool(pd.isna(value))
        except Exception:
            return False

    @classmethod
    def _tradier_position_shape_for_log(cls, row):
        return {
            "symbol_present": not cls._is_missing_broker_value(row.get("symbol") if hasattr(row, "get") else None),
            "asset_type": cls._extract_tradier_asset_type(row),
            "quantity_present": not cls._is_missing_broker_value(row.get("quantity") if hasattr(row, "get") else None),
        }

    @classmethod
    def _tradier_order_shape_for_log(cls, row):
        legs = row.get("leg") if isinstance(row, dict) and isinstance(row.get("leg"), list) else []

        def one_shape(order_row):
            return {
                "class": order_row.get("class"),
                "type": order_row.get("type"),
                "status": order_row.get("status"),
                "symbol_present": not cls._is_missing_broker_value(order_row.get("symbol")),
                "option_symbol_present": not cls._is_missing_broker_value(order_row.get("option_symbol")),
                "side_present": not cls._is_missing_broker_value(order_row.get("side")),
                "duration_present": not cls._is_missing_broker_value(order_row.get("duration")),
                "price_present": not cls._is_missing_broker_value(order_row.get("price")),
                "stop_price_present": not cls._is_missing_broker_value(order_row.get("stop_price")),
            }

        return {
            **one_shape(row),
            "leg_count": len(legs),
            "legs": [one_shape(leg) for leg in legs if isinstance(leg, dict)],
        }

    @classmethod
    def _log_tradier_order_parse_failure(cls, response):
        logger.warning(
            "Failed to parse Tradier order row; sanitized_shape=%s",
            cls._tradier_order_shape_for_log(response),
            exc_info=True,
        )

    def _pull_broker_order(self, identifier):
        """
        This function pulls a single order from the broker by its identifier. Order is converted to a dictionary,
        and then returned. It is expected that the caller will convert the dictionary to an Order object by
        calling parse_broker_order() on the dictionary. Parsing the order will also dispatch it to the stream for
        processing.
        """
        orders = self._clean_order_records(self.tradier.orders.get_order(identifier))
        return orders[0] if len(orders) > 0 else None

    def _pull_broker_all_orders(self):
        """
        This function pulls all orders from the broker. Orders are converted to a list of dictionaries,
        and then returned. It is expected that the caller will convert each dictionary to an Order object by
        calling parse_broker_order() on the dictionary.
        """
        try:
            df = self.tradier.orders.get_orders()
        except Exception as e:
            if self._is_transient_broker_read_error(e):
                logger.warning(
                    "Transient Tradier orders read failure; skipping order reconciliation for this poll: %s",
                    e,
                    exc_info=True,
                )
                raise TradierTransientBrokerReadError(str(e)) from e
            logger.info(f"Error pulling orders from Tradier: {e}", exc_info=True)
            return []

        # Check if the dataframe is empty or None
        if df is None or df.empty:
            return []

        return self._clean_order_records(df)

    @staticmethod
    def _clean_order_records(df):
        """
        Cleans the order records DataFrame by rounding float values to 2 decimal places,
        replacing missing values with None, and converting the DataFrame to a list of dictionaries.

        Parameters
        ----------
        df : pandas.DataFrame
            The DataFrame containing order records.

        Returns
        -------
        list[dict]
            A list of dictionaries representing the cleaned order records.
        """
        # NOTE: This code path runs in a long-lived polling loop. Avoid full-DataFrame copies (apply/replace),
        # which can multiply peak memory when Tradier returns many rows.
        try:
            records = df.to_dict("records")
        except Exception:
            return []

        cleaned: list[dict] = []
        for rec in records:
            if not isinstance(rec, dict):
                continue
            out: dict = {}
            for k, v in rec.items():
                try:
                    if isinstance(v, float):
                        v = round(v, 2)
                    # Handle pandas missing sentinels (NA/NaT/nan) without materializing full copies.
                    if v is pd.NA or v is pd.NaT or (isinstance(v, float) and pd.isna(v)) or pd.isna(v):
                        v = None
                except Exception:
                    pass
                out[k] = v
            cleaned.append(out)
        return cleaned

    def _lumi_side2tradier(self, order: Order) -> str:
        # Set the side that we will return
        side = order.side

        if order.asset.asset_type == Asset.AssetType.STOCK:
            # Map extended side values to for Tradier API
            if side in ("buy_to_open"):
                side = "buy"
            elif side in ("sell_to_close"):
                side = "sell"
            elif side in ("buy_to_cover", "buy_to_close"):
                side = "buy_to_cover"
            elif side in ("sell_to_open", "sell_short"):
                side = "sell_short"
            return side

        # Convert the side to the Tradier side for options orders if necessary
        if side == Order.OrderSide.BUY or side == Order.OrderSide.SELL:
            self.resolve_option_order_intent(order)
            side = order.side

        # Check if the side is a valid Tradier side
        if side not in ["buy_to_open", "buy_to_close", "sell_to_open", "sell_to_close"]:
            logger.error(f"Invalid option order side for Tradier: {order.side}")
            return ""

        return side

    @staticmethod
    def _tradier_class2lumi(order_class):
        """
        Converts a Tradier order class to a Lumi order class.
        Valid Tradier clases: One of: equity, option, combo, multileg
        Valid Lumi Order Classes: simple, bracket, oco, multileg, etc
        """
        if order_class is None or not isinstance(order_class, str):
            return None

        order_class = order_class.strip().lower()
        if order_class in ['equity', 'option']:
            return Order.OrderClass.SIMPLE
        if order_class == "otoco":
            return Order.OrderClass.BRACKET
        if order_class == "combo":
            return Order.OrderClass.MULTILEG

        # Check if the order class is a valid Lumi order class
        try:
            return Order.OrderClass(order_class)
        except ValueError:
            return None

    @staticmethod
    def _tradier_side2lumi(side):
        """
        Converts a Tradier side to a Lumi side.
        Valid Stock Sides: buy, buy_to_cover, sell, sell_short
        Valid Option Sides: buy_to_open, buy_to_close, sell_to_open, sell_to_close
        """
        # Check that the side is valid
        if not side or not isinstance(side, str):
            return None

        try:
            return Order.OrderSide(side)
        except ValueError:
            if "buy" in side:
                return Order.OrderSide.BUY
            elif "sell" in side:
                return Order.OrderSide.SELL
            else:
                raise ValueError(f"Invalid side {side} for Tradier.") from None

    # ==========Processing streams data=======================

    def do_polling(self):
        """
        This function is called every time the broker polls for new orders. It checks for new orders and
        dispatches them to the stream for processing.
        """
        # Pull the current Tradier positions and sync them with Lumibot's positions
        self.sync_positions(None)

        # Get current orders from Tradier and dispatch them to the stream for processing. Need to see all
        # lumi orders (not just active "tracked" ones) to catch any orders that might have changed final
        # status in Tradier.
        # df_orders = self.tradier.orders.get_orders()
        try:
            raw_orders = self._pull_broker_all_orders()
        except TradierTransientBrokerReadError:
            logger.info("Skipping Tradier polling reconciliation after transient broker read failure")
            return
        try:
            self._telemetry_polls_total += 1
            self._telemetry_orders_seen_max = max(int(self._telemetry_orders_seen_max), len(raw_orders or []))
        except Exception:
            pass
        stored_orders = {x.identifier: x for x in self.get_all_orders()}
        strategy_name = self._strategy_name
        if not strategy_name and len(self._subscribers) == 1:
            strategy_name = self._subscribers[0].name
        for order_row in raw_orders:
            row_id = order_row.get("id")
            row_tag = order_row.get("tag")
            # Shared-account safety: never ingest foreign-tagged activity into this
            # strategy. A sole local subscriber must not claim MOS fills as STM.
            already_tracked = row_id in stored_orders
            if (
                strategy_name
                and row_tag
                and not self.strategy_tag_matches(row_tag, strategy_name)
                and not already_tracked
            ):
                if logger.isEnabledFor(20):
                    logger.info(
                        "Skipping foreign Tradier order id=%s tag=%r for local strategy %r",
                        row_id,
                        row_tag,
                        strategy_name,
                    )
                continue

            parse_strategy = strategy_name
            if already_tracked and stored_orders[row_id].strategy:
                parse_strategy = stored_orders[row_id].strategy
            elif row_tag and strategy_name and self.strategy_tag_matches(row_tag, strategy_name):
                parse_strategy = strategy_name
            elif row_tag and strategy_name and not self.strategy_tag_matches(row_tag, strategy_name):
                # Tracked-but-foreign should not rewrite strategy to local name.
                parse_strategy = stored_orders[row_id].strategy if already_tracked else None

            order = self._parse_broker_order_dict(order_row, strategy_name=parse_strategy)
            # Process child orders first so they are tracked in the Lumi system before the parent order
            all_orders = [child for child in order.child_orders] + [order]

            # Keep the historical closed-order memory bound; hydrate active partials.
            for order in all_orders:
                if order.identifier not in stored_orders:
                    if self._first_iteration and not order.is_active() and order.status != Order.OrderStatus.NEW:
                        continue
                    self._process_broker_synced_order(order)
                    stored_orders[order.identifier] = order
                else:
                    # Always Update Quantity and Children. Children can change as they are assigned an identifier
                    # for the first time.
                    stored_order = stored_orders[order.identifier]

                    # Repair missing strategy using tag field (mirrors fix in projectx.py).
                    # Tradier stores the order tag as the strategy name with underscores replaced by hyphens.
                    if not stored_order.strategy:
                        tag = getattr(stored_order, 'tag', None) or getattr(order, 'tag', None)
                        matched_sub = False
                        if tag and hasattr(self, '_subscribers') and self._subscribers:
                            for sub in self._subscribers:
                                sub_name = getattr(sub, 'name', '') or str(sub)
                                if self.strategy_tag_matches(tag, sub_name) or sub_name == tag:
                                    stored_order.strategy = sub_name
                                    matched_sub = True
                                    break
                        # Only claim untagged orders via sole-subscriber fallback.
                        # Foreign tags must never be attributed to the local strategy.
                        if (
                            not stored_order.strategy
                            and not tag
                            and not matched_sub
                            and hasattr(self, '_subscribers')
                            and len(self._subscribers) == 1
                        ):
                            only_sub = self._subscribers[0]
                            stored_order.strategy = getattr(only_sub, 'name', '') or str(only_sub)

                    stored_order.quantity = order.quantity  # Update the quantity in case it has changed
                    stored_order.broker_create_date = order.broker_create_date
                    stored_order.broker_update_date = order.broker_update_date
                    if order.avg_fill_price:
                        stored_order.avg_fill_price = order.avg_fill_price
                    stored_children = [stored_orders[o.identifier] if o.identifier in stored_orders else o
                                       for o in order.child_orders]
                    stored_order.child_orders = stored_children

                    stored_order.broker_status = getattr(order, "broker_status", order.status)
                    cumulative = getattr(order, "filled_quantity", None)
                    if cumulative is None and order.status == Order.OrderStatus.FILLED:
                        cumulative = order.quantity
                    if order.order_class != Order.OrderClass.OCO and cumulative is not None and order.avg_fill_price is not None:
                        reconciled = self._reconcile_cumulative_execution(
                            stored_order, cumulative, order.avg_fill_price,
                            terminal=order.status == Order.OrderStatus.FILLED, raw=order._raw,
                        )
                        if reconciled and stored_order.is_filled():
                            continue
                    if stored_order.is_filled():
                        continue
                    # Status changes cannot substitute for cumulative execution progress.
                    if not order.equivalent_status(stored_order):
                        match order.status.lower():
                            case "submitted" | "open":
                                self._safe_stream_dispatch(self.NEW_ORDER, order=stored_order)
                            case "partial_fill":
                                stored_order.status = order.status
                            case "fill":
                                # Check if the order has an avg_fill_price, if not use the order_row price
                                if order.avg_fill_price is None:
                                    fill_price = order_row["avg_fill_price"]
                                else:
                                    fill_price = order.avg_fill_price

                                # Check if the order has a quantity
                                if order.quantity is None:
                                    fill_qty = order_row["exec_quantity"]
                                else:
                                    fill_qty = order.quantity

                                # For OCO orders - Parent order never gets filled values populated by Tradier API.
                                # Need to look at the child orders to get the necessary fill values.
                                if order.order_class == Order.OrderClass.OCO:
                                    filled_children = [o for o in order.child_orders if o.is_filled()]
                                    if filled_children:
                                        fill_price = filled_children[0].avg_fill_price
                                        fill_qty = filled_children[0].quantity

                                # There's race condition where Tradier API is marking status=filled but has not yet
                                # populated the avg_fill_price and other fill data. At some time in the future these
                                # values will be filled in by Tradier, so do not trigger a 'filled' event until
                                # all the needed data has been populated.
                                if fill_price is not None and fill_qty is not None:
                                    self._safe_stream_dispatch(
                                        self.FILLED_ORDER,
                                        order=stored_order,
                                        price=fill_price,
                                        filled_quantity=fill_qty,
                                    )
                            case "canceled":
                                self._safe_stream_dispatch(self.CANCELED_ORDER, order=stored_order)
                            case "error":
                                default_msg = f"{self.name} encountered an error with order {order.identifier} | {order}"
                                msg = order_row["reason_description"] if "reason_description" in order_row else default_msg
                                self._safe_stream_dispatch(self.ERROR_ORDER, order=stored_order, error_msg=msg)
                            case _:
                                self._process_broker_synced_order(order)
                    else:
                        # Status hasn't changed, but make sure we use the broker's status.
                        # I.e. 'submitted' becomes 'open'
                        stored_order.status = order.status

        # A broad-list miss is not proof of cancellation; resolve the exact order.
        tracked_orders = {x.identifier: x for x in self.get_tracked_orders()}
        broker_ids = self._get_broker_id_from_raw_orders(raw_orders)
        for order_id, order in tracked_orders.items():
            if order_id not in broker_ids:
                logger.debug(
                    f"Poll Update: {self.name} no longer has order {order}, but Lumibot does. "
                    f"Checking its exact broker status."
                )
                # Only dispatch orders that have not been filled or cancelled. Likely the broker has simply
                # stopped tracking them. This is particularly true with Paper Trading where orders are not tracked
                # overnight.
                if order.is_active():
                    self._refresh_missing_active_order_from_broker(
                        order, order.strategy or strategy_name, broker_order_count=len(raw_orders), logger_obj=logger,
                    )

        if self._first_iteration:
            self._first_iteration = False

    def _get_broker_id_from_raw_orders(self, raw_orders):
        ids = []
        for o in raw_orders:
            if "id" in o:
                ids.append(o["id"])
            if "leg" in o and isinstance(o["leg"], list):
                for leg in o["leg"]:
                    if "id" in leg:
                        ids.append(leg["id"])

        return ids

    def _get_stream_object(self):
        """get the broker stream connection"""
        from lumibot.trading_builtins import PollingStream

        stream = PollingStream(self.polling_interval)
        return stream

    def _register_stream_events(self):
        """Register the function on_trade_event
        to be executed on each trade_update event"""
        broker = self

        @broker.stream.add_action(broker.POLL_EVENT)
        def on_trade_event_poll():
            self.do_polling()

        @broker.stream.add_action(broker.NEW_ORDER)
        def on_trade_event_new(order):
            # Log that the order was submitted
            logger.info(f"Processing action for new order {order}")

            try:
                broker._process_trade_event(
                    order,
                    broker.NEW_ORDER,
                )
                return True
            except:
                logger.error(_format_exc())

        @broker.stream.add_action(broker.FILLED_ORDER)
        def on_trade_event_fill(order, price, filled_quantity):
            # Log that the order was filled
            logger.info(f"Processing action for filled order {order} | {price} | {filled_quantity}")

            try:
                broker._process_trade_event(
                    order,
                    broker.FILLED_ORDER,
                    price=price,
                    filled_quantity=filled_quantity,
                    multiplier=order.asset.multiplier,
                )
                return True
            except:
                logger.error(_format_exc())

        @broker.stream.add_action(broker.CANCELED_ORDER)
        def on_trade_event_cancel(order):
            # Log that the order was cancelled
            logger.info(f"Processing action for cancelled order {order}")

            try:
                broker._process_trade_event(
                    order,
                    broker.CANCELED_ORDER,
                )
            except:
                logger.error(_format_exc())

        @broker.stream.add_action(broker.CASH_SETTLED)
        def on_trade_event_cash(order, price, filled_quantity):
            # Log that the order was cash settled
            logger.info(f"Processing action for cash settled order {order} | {price} | {filled_quantity}")

            try:
                broker._process_trade_event(
                    order,
                    broker.CASH_SETTLED,
                    price=price,
                    filled_quantity=filled_quantity,
                    multiplier=order.asset.multiplier,
                )
            except:
                logger.error(_format_exc())

        @broker.stream.add_action(broker.ERROR_ORDER)
        def on_trade_event_error(order, error_msg):
            # Log that the order had an error
            logger.error(f"Processing action for error order {order} | {error_msg}")
            try:
                if order.is_active():
                    # If the order has children, cancel them first upon error
                    if order.child_orders:
                        for child_order in order.child_orders:
                            child_order.set_error(error_msg)
                            broker._process_trade_event(
                                child_order,
                                broker.ERROR_ORDER,
                            )

                    # Then cancel the parent order
                    broker._process_trade_event(
                        order,
                        broker.ERROR_ORDER,
                    )
                logger.error(error_msg)
                order.set_error(error_msg)
            except:
                logger.error(_format_exc())

    def _run_stream(self):
        self._stream_established()
        # Try to run the stream
        try:
            self.stream._run()
        except _get_tradier_api_error_class() as e:
            # Check if the error is a 401 or 403, if so, the access token is invalid
            error = str(e)
            if "401" in error or "403" in error:
                # Check if the access token or account number is invalid
                if self._tradier_access_token is None or self._tradier_account_number is None or len(self._tradier_access_token) == 0 or len(self._tradier_account_number) == 0:
                    colored_message = colored("Your TRADIER_ACCOUNT_NUMBER or TRADIER_ACCESS_TOKEN are blank. Please check your keys.", color="red")
                    raise ValueError(colored_message)

                # Conceal the end of the access token
                access_token = self._tradier_access_token[:7] + "*" * 7
                colored_message = colored(f"Your TRADIER_ACCOUNT_NUMBER or TRADIER_ACCESS_TOKEN are invalid. Your account number is: {self._tradier_account_number} and your access token is: {access_token}", color="red")
                raise ValueError(colored_message)

    def _flatten_order(self, order):
        """Some submitted orders may trigger other orders.
        _flatten_order returns a list containing the main order
        and all the derived ones"""
        orders = [order]

        # TODO: Need to implement this for Tradier

        return orders
