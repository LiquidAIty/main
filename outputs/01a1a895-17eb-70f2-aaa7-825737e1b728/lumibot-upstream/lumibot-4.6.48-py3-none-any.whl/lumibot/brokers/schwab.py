from __future__ import annotations

import base64
import hashlib
import os
import re
import threading
import time
from pathlib import Path
from threading import Thread

from lumibot._lazy_imports import LazyLogger, lazy_class

from .broker import Broker, LumibotBrokerAPIError
from .oauth_refresh_mode import is_external_oauth_refresh_mode

logger = LazyLogger(__name__)
TYPE_CHECKING = False
datetime = lazy_class("datetime", "datetime")
timedelta = lazy_class("datetime", "timedelta")
Asset = lazy_class("lumibot.entities", "Asset")
Order = lazy_class("lumibot.entities", "Order")

Client = None
StreamClient = None
SchwabData = None

if TYPE_CHECKING:
    from lumibot.entities import Position


def colored(*args, **kwargs):
    from termcolor import colored as _colored

    return _colored(*args, **kwargs)


def _position_class():
    from lumibot.entities import Position

    return Position


def _format_exc():
    import traceback

    return traceback.format_exc()


def _json_module():
    import json

    return json


# ---- Lumiwealth default Schwab app configuration ----
LUMI_DEFAULT_APP_KEY = "RfUVxotUc8p6CbeCwFmophgNZSat0TLv"
LUMI_DEFAULT_CALLBACK = "https://api.botspot.trade/broker_oauth/schwab"


def _schwab_helper():
    from lumibot.tools import SchwabHelper

    return SchwabHelper


def _load_dotenv(*args, **kwargs):
    if os.environ.get("LUMIBOT_DISABLE_DOTENV", "").strip().lower() in ("1", "true", "yes", "on"):
        return False
    import dotenv

    return dotenv.load_dotenv(*args, **kwargs)


def _get_client_class():
    global Client
    if Client is None:
        from schwab.client import Client
    return Client


def _get_stream_client_class():
    global StreamClient
    if StreamClient is None:
        from schwab.streaming import StreamClient
    return StreamClient


def _get_schwab_data_class():
    global SchwabData
    if SchwabData is None:
        from lumibot.data_sources import SchwabData
    return SchwabData


def _botspot_force_broker_token_refresh() -> bool:
    return (os.environ.get("BOTSPOT_FORCE_BROKER_TOKEN_REFRESH") or "").strip().lower() in {
        "1",
        "true",
        "yes",
        "y",
        "on",
    }


def _schwab_cancel_diagnostics_enabled() -> bool:
    """Post-cancel direct order reads double the round trips on every cancel.

    They were added as always-on incident diagnostics; they now run only when
    explicitly enabled so latency-sensitive cancels pay for one HTTP call.
    """
    return (os.environ.get("SCHWAB_CANCEL_DIAGNOSTICS") or "").strip().lower() in {
        "1",
        "true",
        "yes",
        "on",
    }


# Refresh this many seconds before the access token actually expires so no
# latency-sensitive broker call (quotes, cancels) absorbs the OAuth handshake.
_SCHWAB_PROACTIVE_REFRESH_MARGIN_SECONDS = 300
_SCHWAB_PROACTIVE_REFRESH_POLL_SECONDS = 30
_SCHWAB_PROACTIVE_REFRESH_RETRY_SECONDS = 60
_SCHWAB_HTTP_TIMEOUT_SECONDS = 30.0


def _apply_default_request_timeout(oauth_session, timeout_seconds: float = _SCHWAB_HTTP_TIMEOUT_SECONDS) -> None:
    """Give every request through the OAuth session an explicit default timeout.

    requests has no default timeout, so a stalled TLS/proxy connection would
    block the trading loop indefinitely (including cancels).
    """
    original_request = getattr(oauth_session, "request", None)
    if not callable(original_request):
        # Some supported schwab-py transports and test doubles expose the
        # request path through their client wrapper instead of directly on the
        # OAuth session. Do not turn the timeout safety enhancement into an
        # initialization failure for those sessions.
        return

    def _request_with_default_timeout(*args, **kwargs):
        if kwargs.get("timeout") is None:
            kwargs["timeout"] = timeout_seconds
        return original_request(*args, **kwargs)

    oauth_session.request = _request_with_default_timeout


def _start_schwab_proactive_token_refresh(
    oauth_session,
    token_dict_for_session: dict,
    refresh_kwargs: dict,
    update_token_callback,
) -> threading.Event:
    """Refresh the Schwab access token in the background before it expires.

    Schwab access tokens live ~30 minutes and oauthlib only refreshes lazily
    inside whatever request first crosses the expiry boundary. That made the
    refresh handshake (and any transient failure) land on an arbitrary broker
    call - historically a cancel or quote - and could take seconds. This daemon
    thread rotates the token ahead of expiry instead. The stop event is returned
    so owners can shut the thread down with the broker.
    """
    stop_event = threading.Event()

    def _seconds_until_expiry():
        expires_at = token_dict_for_session.get("expires_at")
        try:
            return float(expires_at) - time.time()
        except (TypeError, ValueError):
            # Unknown expiry: poll periodically and let oauthlib decide lazily.
            return None

    def _refresh_once():
        refresh_token_value = token_dict_for_session.get("refresh_token")
        if not refresh_token_value:
            raise RuntimeError("missing refresh_token")
        refreshed = oauth_session.refresh_token(
            oauth_session.auto_refresh_url,
            refresh_token=refresh_token_value,
            **refresh_kwargs,
        )
        if not isinstance(refreshed, dict) or not refreshed.get("access_token"):
            raise RuntimeError("refresh response did not include access_token")
        update_token_callback(refreshed)

    def _run():
        while not stop_event.is_set():
            remaining = _seconds_until_expiry()
            if remaining is None or remaining <= _SCHWAB_PROACTIVE_REFRESH_MARGIN_SECONDS:
                try:
                    _refresh_once()
                    logger.info("[Schwab] Proactive background token refresh completed.")
                except Exception as exc:
                    logger.warning(f"[Schwab] Proactive background token refresh failed, will retry: {exc}")
                stop_event.wait(_SCHWAB_PROACTIVE_REFRESH_RETRY_SECONDS)
            else:
                stop_event.wait(min(remaining - _SCHWAB_PROACTIVE_REFRESH_MARGIN_SECONDS, _SCHWAB_PROACTIVE_REFRESH_POLL_SECONDS))

    thread = Thread(target=_run, name="schwab-token-refresher", daemon=True)
    thread.start()
    return stop_event


def _is_external_schwab_token_file_valid(token_path: Path) -> bool:
    if not token_path.exists():
        return False
    try:
        with token_path.open("r", encoding="utf-8") as fp:
            payload = _json_module().load(fp)
        token = payload.get("token") if isinstance(payload.get("token"), dict) else payload
        if not isinstance(token, dict):
            return False
        return bool(token.get("access_token"))
    except Exception as exc:
        logger.warning(f"[Schwab] Failed to validate externally managed token file {token_path}: {exc}")
        return False


def _strip_external_schwab_token(token: dict) -> dict:
    """Return an access-token-only Schwab token payload for parent-managed refresh mode."""
    sanitized = dict(token)
    for secret_key in (
        "refresh_token",
        "refresh_token_issued_at",
        "refresh_token_expires_in",
        "id_token",
    ):
        sanitized.pop(secret_key, None)
    return sanitized


def _schwab_token_issued_at_seconds(value):
    if value is None:
        return None
    try:
        raw = float(value)
    except (TypeError, ValueError):
        return None
    return raw / 1000.0 if raw > 1_000_000_000_000 else raw


def _normalize_schwab_token_expiry_metadata(token: dict) -> None:
    if not isinstance(token, dict):
        return
    issued_at = _schwab_token_issued_at_seconds(token.get("issued_at") or token.get("creation_timestamp"))
    try:
        expires_in = float(token.get("expires_in"))
    except (TypeError, ValueError):
        expires_in = None
    if issued_at is not None and expires_in is not None:
        token["expires_at"] = int(issued_at + expires_in - 30)


def _apply_external_schwab_token_to_session(oauth_session, token: dict) -> None:
    """Synchronize requests-oauthlib's public token and oauthlib client cache."""
    if not isinstance(token, dict):
        return
    oauth_session.token = dict(token)
    client = getattr(oauth_session, "_client", None)
    if client is None:
        return
    if token.get("access_token"):
        try:
            client.access_token = token.get("access_token")
        except Exception:
            pass
    if token.get("token_type"):
        try:
            client.token_type = token.get("token_type")
        except Exception:
            pass
    if token.get("scope"):
        try:
            client.scope = token.get("scope")
        except Exception:
            pass
    if token.get("expires_at") is not None:
        try:
            client.expires_at = float(token.get("expires_at"))
        except (TypeError, ValueError):
            pass


class SchwabTokenPersistenceError(RuntimeError):
    """Raised when a refreshed Schwab OAuth token cannot be durably written."""


class Schwab(Broker):
    """
    Broker implementation for Schwab API.
    
    This class provides the integration with Schwab's trading platform,
    implementing all necessary methods required by the Lumibot framework
    to interact with the broker.

    Link to Schwab API documentation: https://developer.schwab.com/ and create an account to get API doc access.
    Link to the Python client library: https://schwab-py.readthedocs.io/en/latest/
    """

    NAME = "Schwab"
    CASH_FUNDING_TRANSACTION_TYPES = {
        "ACH_RECEIPT", "ACH_DISBURSEMENT", "CASH_RECEIPT",
        "CASH_DISBURSEMENT", "WIRE_IN", "WIRE_OUT", "ELECTRONIC_FUND",
    }
    ACTIVE_SCHWAB_ORDER_STATUSES = {
        "AWAITING_PARENT_ORDER",
        "AWAITING_CONDITION",
        "AWAITING_STOP_CONDITION",
        "AWAITING_MANUAL_REVIEW",
        "ACCEPTED",
        "AWAITING_UR_OUT",
        "PENDING_ACTIVATION",
        "QUEUED",
        "WORKING",
        "NEW",
    }
    POLL_EVENT = "poll"

    @staticmethod
    def _mask_account_number(account_number):
        if account_number is None:
            return "<missing>"
        account_number = str(account_number)
        return f"****{account_number[-4:]}" if len(account_number) > 4 else "****"

    @staticmethod
    def _mask_hash_value(hash_value):
        if hash_value is None:
            return "<missing>"
        hash_value = str(hash_value)
        if len(hash_value) <= 10:
            return "<set>"
        return f"{hash_value[:6]}...{hash_value[-4:]}"

    def _schwab_order_ref(self, order_or_identifier) -> str:
        """Return a per-broker-process opaque order reference for shared logs."""
        identifier = getattr(order_or_identifier, "identifier", order_or_identifier)
        if not hasattr(self, "_schwab_telemetry_salt"):
            self._schwab_telemetry_salt = os.urandom(16)
        return hashlib.sha256(self._schwab_telemetry_salt + str(identifier).encode("utf-8")).hexdigest()[:16]

    def _log_schwab_lifecycle_event(self, event: str, order_or_identifier, **fields) -> None:
        safe_fields = " ".join(
            f"{key}={value}"
            for key, value in fields.items()
            if value is not None
        )
        logger.info(
            f"[SchwabLifecycle] event={event} order_ref={self._schwab_order_ref(order_or_identifier)}"
            + (f" {safe_fields}" if safe_fields else "")
        )

    def _schwab_now_value(self) -> float:
        clock = getattr(self, "_schwab_now", None)
        return float(clock()) if callable(clock) else time.monotonic()

    def _schwab_request_allowed(self, endpoint_family: str) -> bool:
        deadlines = getattr(self, "_schwab_rate_limit_deadlines", {})
        return self._schwab_now_value() >= float(deadlines.get(endpoint_family, 0.0))

    def _record_schwab_rate_limit(self, response, endpoint_family: str) -> None:
        import random

        if not hasattr(self, "_schwab_rate_limit_deadlines"):
            self._schwab_rate_limit_deadlines = {}
        if not hasattr(self, "_schwab_rate_limit_attempts"):
            self._schwab_rate_limit_attempts = {}

        retry_after = None
        headers = getattr(response, "headers", {}) or {}
        try:
            retry_after = float(headers.get("Retry-After"))
        except (TypeError, ValueError):
            retry_after = None
        attempts = int(self._schwab_rate_limit_attempts.get(endpoint_family, 0)) + 1
        self._schwab_rate_limit_attempts[endpoint_family] = attempts
        if retry_after is None:
            retry_after = min(2 ** min(attempts, 5), 30) + random.uniform(0, 1)
        retry_after = max(0.25, min(float(retry_after), 60.0))
        self._schwab_rate_limit_deadlines[endpoint_family] = self._schwab_now_value() + retry_after
        logger.warning(
            f"[SchwabLifecycle] event=broker.rate_limited endpoint_family={endpoint_family} "
            f"retry_after_seconds={retry_after:.3f}"
        )

    def _clear_schwab_rate_limit(self, endpoint_family: str) -> None:
        getattr(self, "_schwab_rate_limit_attempts", {}).pop(endpoint_family, None)
        getattr(self, "_schwab_rate_limit_deadlines", {}).pop(endpoint_family, None)

    @classmethod
    def _redact_schwab_payload(cls, payload):
        if isinstance(payload, dict):
            redacted = {}
            for key, value in payload.items():
                key_lower = str(key).lower()
                if key_lower in {"accountnumber", "account_number"}:
                    redacted[key] = cls._mask_account_number(value)
                elif key_lower in {"hashvalue", "hash_value", "accounthash", "account_hash"}:
                    redacted[key] = cls._mask_hash_value(value)
                else:
                    redacted[key] = cls._redact_schwab_payload(value)
            return redacted
        if isinstance(payload, list):
            return [cls._redact_schwab_payload(item) for item in payload]
        return payload

    def __init__(
            self,
            config=None,
            data_source=None,
            connect_stream=True,
    ):
        # === Initialize error flag very early ===
        self.schwab_authorization_error = False
        self._broker_fully_ready = False # Initialize new flag
        self._connect_stream = connect_stream
        # === End Initialize error flag ===

        # === Prepare Data Source ===
        # Determine if SchwabData is intended or if a specific one was passed
        schwab_data_class = _get_schwab_data_class()
        is_schwab_data_intended = data_source is None or isinstance(data_source, schwab_data_class)
        final_data_source = data_source

        if is_schwab_data_intended:
            if data_source is None:
                # Create a SchwabData instance now, client will be set later
                logger.debug("[Schwab] Creating initial SchwabData instance (client will be set later).")
                final_data_source = schwab_data_class(auto_create_client=False)
            # If a SchwabData instance was passed, use it directly
            else:
                logger.debug("[Schwab] Using provided SchwabData instance.")
                # final_data_source is already data_source
        else:
            # If a different, non-SchwabData source was explicitly passed, use it
            logger.debug(f"[Schwab] Using explicitly provided non-SchwabData source: {type(data_source).__name__}")
            # final_data_source is already data_source

        # Call super().__init__ with the determined data source
        super().__init__(
            name=self.NAME,
            data_source=final_data_source, # Pass the actual intended or created data source
            config=config,
            connect_stream=False,
        )
        # === End Prepare Data Source ===

        # Initialize Schwab specific attributes
        self._subscribers = []
        # Use standard logging module's logger
        # self.logger = get_logger(__name__)
        self.extended_trading_minutes = 0
        # self.schwab_authorization_error = False # Moved earlier
        self.client = None
        self.hash_value = None
        self.account_number = None
        self.stream_client = None
        self.stream = None
        # Broker observations from REST snapshots and the Schwab account stream
        # converge through one monotonic reducer.  These high-water marks keep
        # duplicate/replayed snapshots from emitting duplicate strategy callbacks.
        self._schwab_observed_fill_quantities = {}
        self._schwab_terminal_observations = set()
        self._schwab_order_transition_lock = threading.RLock()
        self._schwab_telemetry_salt = os.urandom(16)
        self._schwab_activity_wakeup = threading.Event()
        self._schwab_activity_stop = threading.Event()
        # Store if SchwabData was the goal for later client assignment
        self._is_schwab_data_intended = is_schwab_data_intended

        # --- Market calendar setting ---
        # StrategyExecutor relies on broker.market to decide whether trading is
        # 24/7 or should follow an exchange calendar.  Derive it from config or
        # env, else default to "NASDAQ" which is compatible with pandas-market-calendars.
        self.market = (config.get("MARKET") if config else None) or os.environ.get("MARKET") or "NASDAQ"

        # Load environment variables (still useful for fallback if config is missing keys)
        _load_dotenv()
        logger.debug("==== Schwab Broker Initialization (New OAuth Flow) ====")
        config = config or {}

        # Account Number (Required) - Prioritize config, fallback to env
        account_number = config.get("SCHWAB_ACCOUNT_NUMBER") or os.environ.get("SCHWAB_ACCOUNT_NUMBER")
        if not account_number:
            # Set error flag before raising
            self.schwab_authorization_error = True
            raise ValueError("Schwab account number (SCHWAB_ACCOUNT_NUMBER) not found in config or environment variables.")
        self.account_number = str(account_number)

        # API Key (Required) - Prioritize config, fallback to env
        api_key = config.get("SCHWAB_APP_KEY") or os.environ.get("SCHWAB_APP_KEY") or LUMI_DEFAULT_APP_KEY
        if not api_key:
            self.schwab_authorization_error = True
            raise ValueError("Schwab App Key (SCHWAB_APP_KEY) not found in config or environment variables.")

        logger.info("[Schwab] SCHWAB_APP_SECRET is used only for OAuth token refresh when configured.")

        schwab_backend_redirect_uri = (
            config.get("SCHWAB_BACKEND_CALLBACK_URL")
            or os.environ.get("SCHWAB_BACKEND_CALLBACK_URL")
            or LUMI_DEFAULT_CALLBACK
        )
        if not schwab_backend_redirect_uri:
            self.schwab_authorization_error = True
            raise ValueError(
                "SCHWAB_BACKEND_CALLBACK_URL not found in config or environment variables. "
                "This URL is your backend endpoint that Schwab redirects to after user authorization "
                "(e.g., https://api.botspot.trade/broker_oauth/schwab) and is required for the new OAuth flow."
            )
        logger.info(f"[Schwab] Using SCHWAB_BACKEND_CALLBACK_URL: {schwab_backend_redirect_uri}")

        token_payload_env = config.get("SCHWAB_TOKEN") or os.environ.get("SCHWAB_TOKEN")
        logger.debug(f"account_number (final): {self._mask_account_number(self.account_number)}")
        logger.debug(f"api_key (final): {'<set>' if api_key else '<not set>'}")
        logger.debug(f"SCHWAB_BACKEND_CALLBACK_URL (final): {schwab_backend_redirect_uri}")
        logger.debug(f"SCHWAB_TOKEN (env/config): {'<set>' if token_payload_env else '<not set>'}")
        logger.debug("==== [END Schwab Broker Initialization] ====")
        external_token_refresh = is_external_oauth_refresh_mode(config)

        # Determine where to store the Schwab token file.
        # Priority:
        #   1. Config value SCHWAB_TOKEN_PATH
        #   2. Env var  SCHWAB_TOKEN_PATH
        #   3. Fallback to the current working directory as "schwab_token.json"
        token_path_value = (
            config.get("SCHWAB_TOKEN_PATH") if config else None
        ) or os.environ.get("SCHWAB_TOKEN_PATH")

        if token_path_value:
            token_path = Path(token_path_value).expanduser().resolve()
        else:
            token_path = Path.cwd() / "schwab_token.json"

        # Ensure the directory exists (especially if a custom path was provided)
        try:
            token_path.parent.mkdir(parents=True, exist_ok=True)
        except Exception as _mkdir_e:
            logger.warning(f"[Schwab] Could not create token directory {token_path.parent}: {_mkdir_e}")

        token_available_and_valid = False

        if token_payload_env:
            logger.info("[Schwab] SCHWAB_TOKEN environment variable found. Processing it.")
            try:
                schwab_helper = _schwab_helper()
                schwab_helper._save_payload_str_to_token_file(token_payload_env, token_path)
                if schwab_helper._is_token_valid_for_schwab_py(token_path):
                    schwab_helper._ensure_token_metadata(token_path)
                    if schwab_helper._is_token_valid_for_schwab_py(token_path):
                        token_available_and_valid = True
                        logger.info(f"[Schwab] Token from SCHWAB_TOKEN env var processed, validated, and saved to {token_path}")
                    else:
                        logger.error("[Schwab] Imported token failed metadata validation; saved file retained.")
                else:
                    logger.error("[Schwab] Imported token failed validation; saved file retained.")
            except Exception:
                logger.error("[Schwab] Unable to process SCHWAB_TOKEN; saved file retained.")

        if not token_available_and_valid and token_path.exists() and token_path.stat().st_size > 0:
            logger.info(f"[Schwab] Existing token file found at {token_path}. Validating...")
            try:
                schwab_helper = _schwab_helper()
                schwab_helper._ensure_token_metadata(token_path)
                token_file_valid = (
                    _is_external_schwab_token_file_valid(token_path)
                    if external_token_refresh
                    else schwab_helper._is_token_valid_for_schwab_py(token_path)
                )
                if token_file_valid:
                    token_available_and_valid = True
                    logger.info(f"[Schwab] Existing token file {token_path} is valid after metadata check.")
                else:
                    raise ValueError("Saved token is invalid")
            except Exception:
                self.schwab_authorization_error = True
                raise ConnectionError(
                    "Unable to validate or persist saved Schwab token; file preserved. "
                    "Check token storage or explicitly complete normal Schwab reauthorization."
                ) from None

        if not token_available_and_valid:
            logger.info("[Schwab] No valid token found. Initiating user authorization flow to obtain token payload.")
            schwab_helper = _schwab_helper()
            auth_success = schwab_helper._initiate_schwab_auth_and_get_token_payload(api_key, schwab_backend_redirect_uri, token_path)
            if not auth_success:
                self.schwab_authorization_error = True
                raise ConnectionError(
                    "Schwab token acquisition failed via user authorization flow. "
                    "Please check logs, ensure SCHWAB_APP_KEY and SCHWAB_BACKEND_CALLBACK_URL are correct, "
                    "and that the backend OAuth flow is functioning. Restart to try again."
                )
            if schwab_helper._is_token_valid_for_schwab_py(token_path):
                schwab_helper._ensure_token_metadata(token_path)
                if schwab_helper._is_token_valid_for_schwab_py(token_path):
                    token_available_and_valid = True
                else:
                    logger.error("[Schwab] Token failed validation after authorization; saved file retained.")
            else:
                self.schwab_authorization_error = True
                raise ConnectionError("Schwab token file is missing or invalid even after successful authorization flow.")

        if not token_available_and_valid:
            self.schwab_authorization_error = True
            raise ConnectionError(f"Critical error: Schwab token could not be made available or validated at {token_path}.")

        try:
            logger.info(f"[Schwab] Loading token from {token_path} for manual client setup.")
            with open(token_path, encoding='utf-8') as f:
                wrapped_token_data = _json_module().load(f)
            token_dict_for_session = wrapped_token_data.get('token')
            if not token_dict_for_session or 'access_token' not in token_dict_for_session:
                raise ValueError("Token file is missing the 'token' object or 'access_token' within it.")
            if external_token_refresh:
                token_dict_for_session = _strip_external_schwab_token(token_dict_for_session)
            token_file_state = {"signature": None}

            def _token_file_signature():
                stat = token_path.stat()
                return (stat.st_mtime_ns, stat.st_size)

            def _load_token_file_for_session():
                with open(token_path, encoding="utf-8") as fp:
                    latest_wrapped = _json_module().load(fp)
                latest_token = latest_wrapped.get("token") if isinstance(latest_wrapped, dict) else latest_wrapped
                if not isinstance(latest_token, dict) or not latest_token.get("access_token"):
                    raise ValueError("Token file is missing a usable access_token.")
                if external_token_refresh:
                    latest_token = _strip_external_schwab_token(latest_token)
                elif not latest_token.get("refresh_token") and token_dict_for_session.get("refresh_token"):
                    latest_token["refresh_token"] = token_dict_for_session["refresh_token"]
                _normalize_schwab_token_expiry_metadata(latest_token)
                token_dict_for_session.clear()
                token_dict_for_session.update(latest_token)
                token_file_state["signature"] = _token_file_signature()
                return token_dict_for_session

            # Build an OAuth2Session that can automatically refresh the Schwab token.
            from requests_oauthlib import OAuth2Session as _OAS

            def _update_token(updated_token):
                """Write refreshed token back to token.json so it persists across restarts."""
                try:
                    if not isinstance(updated_token, dict):
                        raise ValueError("Refreshed Schwab token payload is not a JSON object.")
                    if not isinstance(updated_token.get("access_token"), str) or not updated_token["access_token"].strip():
                        raise ValueError("Refreshed Schwab token is missing a usable access token.")
                    next_token = dict(token_dict_for_session)
                    next_token.update(updated_token)
                    if not next_token.get("refresh_token") and token_dict_for_session.get("refresh_token"):
                        next_token["refresh_token"] = token_dict_for_session["refresh_token"]
                    if not isinstance(next_token.get("refresh_token"), str) or not next_token["refresh_token"].strip():
                        raise ValueError("Refreshed Schwab token is missing a usable refresh token.")
                    now_ms = int(time.time() * 1000)
                    if updated_token.get("access_token") and not updated_token.get("issued_at"):
                        next_token["issued_at"] = now_ms
                    next_token.setdefault("issued_at", now_ms)
                    next_token.setdefault("refresh_token_issued_at", token_dict_for_session.get("refresh_token_issued_at", now_ms))
                    next_token.setdefault("expires_in", token_dict_for_session.get("expires_in", 1800))
                    next_token.setdefault(
                        "refresh_token_expires_in",
                        token_dict_for_session.get("refresh_token_expires_in", 7 * 24 * 3600),
                    )
                    next_token.setdefault("token_type", token_dict_for_session.get("token_type", "Bearer"))
                    next_token.setdefault("scope", token_dict_for_session.get("scope", "api"))
                    next_token.pop("id_token", None)

                    wrapped = {
                        "creation_timestamp": wrapped_token_data.get("creation_timestamp", int(time.time())),
                        "token": next_token,
                    }
                    # Use the same private atomic writer as initial login.
                    # Advance the adapter's token state only after persistence.
                    _schwab_helper()._write_token_file(token_path, wrapped)
                    token_dict_for_session.clear()
                    token_dict_for_session.update(next_token)
                    logger.info(f"[Schwab] Token automatically refreshed and written to {token_path}")
                except Exception:
                    logger.error("[Schwab] Failed to persist refreshed token; saved file retained.")
                    raise SchwabTokenPersistenceError(
                        "[Schwab] Failed to persist refreshed token; saved file retained."
                    ) from None

            # Build kwargs for token refresh – only include client_secret if it actually exists
            refresh_kwargs = {
                "client_id": api_key,
                # "grant_type": "refresh_token",  #breaks refresh in oauth2session as it creates a dupe param type error
            }
            client_secret_env = config.get("SCHWAB_APP_SECRET") or os.environ.get("SCHWAB_APP_SECRET")
            if client_secret_env:
                refresh_kwargs["client_secret"] = client_secret_env

            # Add expires_at so OAuth2Session sees externally issued tokens as current.
            _normalize_schwab_token_expiry_metadata(token_dict_for_session)

            if external_token_refresh:
                oauth_session = _OAS(client_id=api_key, token=token_dict_for_session)
                _apply_external_schwab_token_to_session(oauth_session, token_dict_for_session)
            else:
                oauth_session = _OAS(
                    client_id=api_key,
                    token=token_dict_for_session,
                    auto_refresh_url="https://api.schwabapi.com/v1/oauth/token",
                    auto_refresh_kwargs=refresh_kwargs,
                    token_updater=_update_token,
                )
            _apply_default_request_timeout(oauth_session)
            token_file_state["signature"] = _token_file_signature()

            if api_key and client_secret_env and not external_token_refresh:
                def _refresh_token_hook(token_url, headers, body):
                    headers['Authorization'] = f"Basic {base64.b64encode(f'{api_key}:{client_secret_env}'.encode()).decode()}"
                    logger.info(f"[Schwab] Refreshing token with auth headers")
                    return token_url, headers, body

                #create refresh hook. This is beacuse oa2session does not perform refreshes with auth headers, only with json bodies. 
                oauth_session.register_compliance_hook("refresh_token_request", _refresh_token_hook)

            # Rotate the access token before expiry so the OAuth handshake never
            # lands inside a latency-sensitive broker call. Without SCHWAB_APP_SECRET
            # Schwab rejects refresh exchanges, so the thread would only spin and warn.
            prior_refresh_stop = getattr(self, "_schwab_token_refresh_stop", None)
            if prior_refresh_stop is not None:
                prior_refresh_stop.set()
            self._schwab_token_refresh_stop = None
            if (
                not external_token_refresh
                and not _botspot_force_broker_token_refresh()
                and client_secret_env
                and token_dict_for_session.get("refresh_token")
            ):
                try:
                    self._schwab_token_refresh_stop = _start_schwab_proactive_token_refresh(
                        oauth_session,
                        token_dict_for_session,
                        refresh_kwargs,
                        _update_token,
                    )
                except Exception as exc:
                    logger.warning(f"[Schwab] Could not start proactive token refresher: {exc}")
            elif not external_token_refresh and not client_secret_env:
                logger.error(
                    "[Schwab] SCHWAB_APP_SECRET is not configured; automatic token refresh is NOT possible "
                    "and the connection will fail ~30 minutes after each re-authentication. Configure "
                    "SCHWAB_APP_SECRET or plan to re-authenticate before then."
                )

            if external_token_refresh:
                original_request = oauth_session.request

                def _reload_external_token_file(force=False):
                    try:
                        current_signature = _token_file_signature()
                    except Exception:
                        return False
                    if not force and current_signature == token_file_state.get("signature"):
                        return False
                    try:
                        _load_token_file_for_session()
                        _apply_external_schwab_token_to_session(oauth_session, token_dict_for_session)
                        logger.info(f"[Schwab] Reloaded externally managed token file from {token_path}")
                        return True
                    except Exception as reload_error:
                        logger.warning(f"[Schwab] Failed to reload externally managed token file: {reload_error}")
                        return False

                def _reload_if_token_file_changed():
                    return _reload_external_token_file(force=False)

                def _request_with_external_token_reload(*args, **kwargs):
                    _reload_if_token_file_changed()
                    try:
                        response = original_request(*args, **kwargs)
                    except Exception as request_error:
                        if request_error.__class__.__name__ == "TokenExpiredError" and _reload_external_token_file(force=True):
                            return original_request(*args, **kwargs)
                        raise
                    status_code = getattr(response, "status_code", None)
                    if status_code in {401, 403} and _reload_if_token_file_changed():
                        return original_request(*args, **kwargs)
                    return response

                oauth_session.request = _request_with_external_token_reload
                logger.info("[Schwab] OAuth refresh mode is external; using externally managed SCHWAB_TOKEN_PATH reloads.")

            if _botspot_force_broker_token_refresh() and not external_token_refresh:
                refresh_token_value = token_dict_for_session.get("refresh_token")
                if not refresh_token_value:
                    raise ConnectionError("[Schwab] Forced token refresh requires a refresh_token.")
                if not client_secret_env:
                    raise ConnectionError("[Schwab] Forced token refresh requires SCHWAB_APP_SECRET.")
                try:
                    refreshed_token = oauth_session.refresh_token(
                        oauth_session.auto_refresh_url,
                        refresh_token=refresh_token_value,
                        **refresh_kwargs,
                    )
                except Exception as e_refresh:
                    raise ConnectionError("[Schwab] Forced token refresh failed for BotSpot snapshot runtime.") from e_refresh
                if not isinstance(refreshed_token, dict) or not refreshed_token.get("access_token"):
                    raise ConnectionError("[Schwab] Forced token refresh response did not include access_token.")
                _update_token(refreshed_token)

            # NOTE: schwab-py >=1.6 removed the app_secret parameter from the Client constructor.
            # Passing it raises: TypeError: BaseClient.__init__() got an unexpected keyword argument 'app_secret'.
            # The secret is only needed when REFRESHING a token via the auth helpers, not when we already
            # have a full token dict and build the OAuth2Session ourselves, so we can safely omit it here.
            # schwab-py's REST client accepts a raw OAuth session, but its
            # StreamClient login reads ``client.token_metadata.token``. Keep
            # metadata attached when constructing the manual REST client so
            # REST and account-activity streaming share the same live token.
            # The metadata references token_dict_for_session itself; refresh
            # updates mutate that dict in place, so stream reconnects see the
            # latest access token without creating a competing token owner.
            from schwab.auth import TokenMetadata as _TokenMetadata

            token_metadata = _TokenMetadata(
                token=token_dict_for_session,
                creation_timestamp=wrapped_token_data.get("creation_timestamp", int(time.time())),
                unwrapped_token_write_func=_update_token,
            )
            self.client = _get_client_class()(
                api_key=api_key,
                session=oauth_session,
                token_metadata=token_metadata,
            )
            logger.info(f"[Schwab] Successfully initialized Schwab client from {token_path} (app_secret not used).")
            # Check if SCHWAB_APP_SECRET is available for auto-refresh warning
            app_secret_for_refresh = config.get("SCHWAB_APP_SECRET") or os.environ.get("SCHWAB_APP_SECRET")
            if not external_token_refresh and not app_secret_for_refresh:
                logger.warning(
                    "[Schwab] Token auto-refresh by this client may not work as SCHWAB_APP_SECRET is not configured. "
                    "You may need to complete normal Schwab reauthorization when the current token expires."
                )
        except Exception:
            # An SDK exception mentioning 'token', or even a 401, does not
            # authorize destroying saved credentials. Provider exceptions can
            # also contain request URLs or token payloads, so keep them private.
            logger.error("[Schwab] Client initialization failed; saved token file retained.")
            self.schwab_authorization_error = True
            refresh_stop = getattr(self, "_schwab_token_refresh_stop", None)
            if refresh_stop is not None:
                refresh_stop.set()
                self._schwab_token_refresh_stop = None
            raise ConnectionError(
                "Failed to initialize Schwab client; saved token file retained. "
                "Check app configuration and token storage, or complete normal Schwab reauthorization."
            ) from None

        # -------------------------------------------------------------
        # Retrieve account hash (needed for all subsequent endpoints)
        # -------------------------------------------------------------
        try:
            resp_accounts = self.client.get_account_numbers()
            if hasattr(resp_accounts, 'status_code') and resp_accounts.status_code == 200:
                accounts_json = resp_accounts.json()
                if not isinstance(accounts_json, list) or not all(isinstance(acc, dict) for acc in accounts_json):
                    raise ValueError("Invalid Schwab account discovery response")
                # Find entry matching our account number. BotSpot often passes
                # the last 3-4 account digits, so allow a unique suffix match.
                target_acc = None
                for acc in accounts_json:
                    if str(acc.get('accountNumber')) == str(self.account_number):
                        target_acc = acc
                        break
                if not target_acc and accounts_json:
                    account_lookup = str(self.account_number)
                    min_suffix_length = 3
                    suffix_matches = []
                    if len(account_lookup) >= min_suffix_length:
                        suffix_matches = [
                            acc for acc in accounts_json
                            if str(acc.get('accountNumber', '')).endswith(account_lookup)
                        ]
                    if len(suffix_matches) == 1:
                        target_acc = suffix_matches[0]
                        self.account_number = str(target_acc.get('accountNumber'))
                        logger.info(
                            "[Schwab] Matched account suffix %s to account %s.",
                            self._mask_account_number(str(self.account_number)[-4:]),
                            self._mask_account_number(self.account_number),
                        )
                    elif len(suffix_matches) > 1:
                        raise ValueError(
                            f"Schwab account suffix {self._mask_account_number(self.account_number)} "
                            "matched multiple accounts. Provide the full account number."
                        )
                    else:
                        raise ValueError(
                            f"Could not match Schwab account {self._mask_account_number(self.account_number)} "
                            "to any account returned by Schwab."
                        )

                if target_acc and isinstance(target_acc.get('hashValue'), str) and target_acc['hashValue'].strip():
                    hash_value = target_acc['hashValue']
                    logger.info(
                        "[Schwab] Retrieved account hash %s for account %s.",
                        self._mask_hash_value(hash_value),
                        self._mask_account_number(self.account_number),
                    )
                    # Complete remaining setup (stream, data source linking, etc.)
                    # Set hash_value on self before signaling readiness
                    self.hash_value = hash_value
                    self._broker_fully_ready = True # Signal readiness
                    self._finish_initialization(config, self.data_source, self.account_number, hash_value)
                else:
                    logger.error("[Schwab] Unable to locate a usable account hash in account discovery.")
                    self.schwab_authorization_error = True
            else:
                code = getattr(resp_accounts, 'status_code', 'n/a')
                status_label = str(code) if type(code) is int and 100 <= code <= 599 else "unavailable"
                logger.error(f"[Schwab] Failed to fetch account numbers (HTTP {status_label}); saved token retained.")
                self.schwab_authorization_error = True
        except Exception:
            logger.error("[Schwab] Account discovery or initialization failed; saved token retained.")
            self.hash_value = None
            self._broker_fully_ready = False
            self.schwab_authorization_error = True

        if self.schwab_authorization_error:
            refresh_stop = getattr(self, "_schwab_token_refresh_stop", None)
            if refresh_stop is not None:
                refresh_stop.set()
                self._schwab_token_refresh_stop = None

    def cleanup_streams(self):
        activity_stop = getattr(self, "_schwab_activity_stop", None)
        if activity_stop is not None:
            activity_stop.set()
        activity_wakeup = getattr(self, "_schwab_activity_wakeup", None)
        if activity_wakeup is not None:
            activity_wakeup.set()
        refresh_stop = getattr(self, "_schwab_token_refresh_stop", None)
        if refresh_stop is not None:
            refresh_stop.set()
            self._schwab_token_refresh_stop = None
        super().cleanup_streams()

    # Account and balance methods
    @staticmethod
    def _normalize_transaction_to_cash_event(transaction):
        """Normalize only transactions with an unambiguous cash classification.

        An unresolved journal or security transfer is a coverage failure, not
        a zero-dollar deposit. Journal labels below are exact provider labels;
        arbitrary descriptions must not become external funding guesses.
        """
        import datetime as dt

        from lumibot.entities import CashEvent

        if not isinstance(transaction, dict):
            raise ValueError("Invalid Schwab transaction payload")
        kind = transaction.get("type")
        if not isinstance(kind, str):
            raise ValueError("Invalid Schwab transaction category")
        if kind == "TRADE":
            # Trade proceeds and embedded commissions already affect value.
            return None
        # A correction can replace a prior observation rather than represent
        # new capital. The cash-list contract cannot retract an acknowledged
        # event, so do not silently add its amount a second time. Older valid
        # provider responses omit this optional action field altogether.
        action = transaction.get("activityType")
        if action is not None and action not in ("TRANSFER", "EXECUTION"):
            raise ValueError("Schwab transaction action requires reconciliation")
        description = transaction.get("description")
        if description is not None and not isinstance(description, str):
            raise ValueError("Invalid Schwab transaction description")
        funding_types = Schwab.CASH_FUNDING_TRANSACTION_TYPES
        journal_type = None
        if kind == "JOURNAL":
            description = transaction.get("description")
            internal_labels = {
                "BANK SWEEP TO BROKERAGE", "BROKERAGE SWEEP FR BANK",
                "BANK SWEEP FR BROKERAGE", "BROKERAGE SWEEP TO BANK",
            }
            if isinstance(description, str) and (
                description in internal_labels or re.fullmatch(r"TRF FDS (?:TO|FRM) TYPE [0-9]+", description)
            ):
                journal_type = "journal"
            elif description == "FED INC TAX WHLD IRA":
                # Withholding is part of an IRA distribution leaving the
                # account, distinct from tax on investment income.
                journal_type = "tax"
        if kind not in funding_types | {"DIVIDEND_OR_INTEREST"} and journal_type is None:
            raise ValueError("Schwab transaction requires cash-flow classification")
        if transaction.get("status") != "VALID":
            raise ValueError("Schwab transaction status requires reconciliation")
        identifier = transaction.get("activityId")
        if not isinstance(identifier, (str, int)) or isinstance(identifier, bool) or not str(identifier).strip():
            raise ValueError("Schwab transaction is missing a stable activity identifier")
        amount = transaction.get("netAmount")
        if amount is None or isinstance(amount, bool) or (isinstance(amount, str) and not amount.strip()):
            raise ValueError("Schwab transaction is missing a cash amount")
        try:
            # Schwab declares a numeric double, not a formatted money string.
            # Generic CashEvent coercion also accepts '$' and ',' as zero.
            amount = CashEvent.coerce_amount(float(amount))
            provider_time = transaction.get("time")
            if not isinstance(provider_time, str) or not re.fullmatch(
                r"[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}"
                r"(?:\.[0-9]+)?(?:Z|[+-][0-9]{2}:?[0-9]{2})", provider_time,
            ):
                raise ValueError("Invalid provider timestamp")
            provider_time = provider_time.replace("Z", "+00:00")
            # Schwab returns +0000 offsets, which fromisoformat only accepts
            # with a colon on supported Python 3.10 runtimes.
            provider_time = re.sub(r"([+-][0-9]{2})([0-9]{2})$", r"\1:\2", provider_time)
            occurred_at = dt.datetime.fromisoformat(provider_time)
            if occurred_at.tzinfo is None or occurred_at.utcoffset() is None:
                raise ValueError("Missing timezone")
        except (TypeError, ValueError, OverflowError):
            raise ValueError("Schwab transaction has an invalid amount or timestamp") from None
        transfer_items = transaction.get("transferItems")
        if not isinstance(transfer_items, list) or not transfer_items:
            raise ValueError("Schwab transaction currency is unavailable")
        currencies = set()
        for item in transfer_items:
            if not isinstance(item, dict):
                raise ValueError("Invalid Schwab transfer item")
            instrument = item.get("instrument")
            if not isinstance(instrument, dict):
                raise ValueError("Schwab transaction currency is unavailable")
            if instrument.get("assetType") != "CURRENCY":
                # A cash dividend may reference the paying security; an external
                # transfer containing securities needs an independently verified valuation.
                if kind in funding_types or kind == "JOURNAL":
                    raise ValueError("Schwab in-kind transfer requires valuation and classification")
                continue
            symbol = instrument.get("symbol", "")
            if not isinstance(symbol, str) or not re.fullmatch(r"CURRENCY_[A-Z]{3}", symbol):
                raise ValueError("Schwab transaction currency is unavailable")
            currencies.add(symbol.removeprefix("CURRENCY_"))
        if len(currencies) != 1:
            raise ValueError("Schwab transaction requires currency-conversion classification")
        external = kind in funding_types or journal_type == "tax"
        event_type = journal_type or (("deposit" if amount >= 0 else "withdrawal") if external else "other_cash")
        return CashEvent(
            broker_name="schwab",
            broker_event_id=str(identifier),
            event_type=event_type,
            raw_type=kind,
            amount=amount,
            currency=next(iter(currencies)),
            occurred_at=occurred_at,
            raw_subtype=transaction["status"],
            description=transaction.get("description"),
            is_external_cash_flow=external,
        )

    def get_cash_events(self, *, since=None, limit=100):
        """Read cash transactions in bounded, at-most-one-year request windows.

        This list is cash event evidence, not a certificate of all-time or
        in-kind funding coverage. Security transfers need separate valuation.
        The default start is 60 days ago, not a provider retention guarantee.
        Explicit older starts are sliced to the official one-year request
        maximum. Unresolved classifications, saturated responses and caller
        limits that would discard events fail explicitly.
        No strategy, order, stream or OAuth setup is started by this method.
        """
        events, _ = self._read_cash_events(since=since, limit=limit)
        return events

    def get_cash_event_sync(self, *, since=None, limit=5000):
        """Audit a selected account's cash and security-transfer activity.

        Security transfers, corrections and ambiguous journals retain known
        cash evidence but make coverage partial. No cost basis or zero cash
        amount is substituted for a missing transfer valuation.
        """
        import datetime as dt

        from lumibot.entities import CashEventSync

        # The SDK serializes bounds to whole seconds; never certify a
        # fractional tail that was not sent to the provider.
        end = dt.datetime.now(dt.timezone.utc).replace(microsecond=0)
        start = since if since is not None else end - dt.timedelta(days=60)
        # Validate caller parameters and identity before any broker read.
        arguments = dict(events=(), broker_name="schwab", account_id=getattr(self, "account_number", None),
                         mode="live", start=start, end=end, fetched_at=end, state="complete")
        CashEventSync(**arguments)
        if limit is not None and (type(limit) is not int or limit <= 0):
            raise ValueError("Schwab cash-event limit must be a positive integer or None")
        try:
            events, unresolved = self._read_cash_events(since=start, limit=limit, end=end, audit=True)
        except (ConnectionError, ValueError):
            return CashEventSync(**{**arguments, "fetched_at": dt.datetime.now(dt.timezone.utc),
                                    "state": "unavailable", "reason_code": "broker_history_unavailable"})
        return CashEventSync(**{**arguments, "events": tuple(events),
                                "fetched_at": dt.datetime.now(dt.timezone.utc),
                                "state": "partial" if unresolved else "complete",
                                "reason_code": "unresolved_transaction" if unresolved else None})

    def _read_cash_events(self, *, since=None, limit=100, end=None, audit=False):
        import datetime as dt

        if not getattr(self, "client", None) or not getattr(self, "hash_value", None):
            raise ConnectionError("Schwab transaction client or selected account is unavailable")
        if limit is not None and (isinstance(limit, bool) or not isinstance(limit, int) or limit <= 0):
            raise ValueError("Schwab cash-event limit must be a positive integer or None")
        end = end or dt.datetime.now(dt.timezone.utc).replace(microsecond=0)
        if since is None:
            start = end - dt.timedelta(days=60)
        else:
            if not isinstance(since, dt.datetime) or since.tzinfo is None or since.utcoffset() is None:
                raise ValueError("Schwab cash-event start must have an explicit timezone")
            start = since.astimezone(dt.timezone.utc)
            if start > end:
                raise ValueError("Schwab cash-event start is after the request end")
        requests_remaining = 127
        # 365 days is at most one calendar year even across leap years. Check
        # the initial work before contacting Schwab; all later splits share
        # this same finite budget. Inclusive boundaries are deduplicated below.
        # Audits reserve one second for an inclusive-start overlap without
        # exceeding the provider's one-year request maximum.
        max_window = dt.timedelta(days=365) - (dt.timedelta(seconds=1) if audit else dt.timedelta())
        if end - start > max_window * requests_remaining:
            raise ValueError("Schwab cash-event history exceeds the bounded request budget")
        windows = []
        cursor = start
        while cursor < end:
            next_end = min(cursor + max_window, end)
            windows.append((cursor, next_end))
            cursor = next_end
        if not windows:
            windows = [(start, end)]
        events = {}
        unresolved = False
        # Request cash categories explicitly: neither trade cash nor a
        # security transfer's zero netAmount measures external cash funding.
        cash_types = self.CASH_FUNDING_TRANSACTION_TYPES | {"JOURNAL", "DIVIDEND_OR_INTEREST"}
        if audit:
            cash_types = {value.value for value in _get_client_class().Transactions.TransactionType
                          if value.value != "TRADE"}
        transaction_types = [
            value for value in _get_client_class().Transactions.TransactionType
            if value.value in cash_types
        ]
        timeouts_remaining = 8
        while windows:
            window_start, window_end = windows.pop()
            if requests_remaining <= 0:
                raise ValueError("Schwab cash-event response could not be completely drained")
            requests_remaining -= 1
            try:
                response = self.client.get_transactions(
                    self.hash_value, start_date=window_start - dt.timedelta(seconds=1) if audit else window_start,
                    end_date=window_end,
                    transaction_types=transaction_types,
                )
            except Exception as exc:
                from httpx import TimeoutException

                # Large activity windows can time out even for a valid login.
                # Retry smaller complete windows rather than returning partial
                # cash evidence or retrying an identical expensive request.
                timeouts_remaining -= isinstance(exc, TimeoutException)
                span = int((window_end - window_start).total_seconds())
                if isinstance(exc, TimeoutException) and timeouts_remaining > 0 and span > 86400:
                    midpoint = window_start + dt.timedelta(seconds=span // 2)
                    windows.extend([(window_start, midpoint), (midpoint, window_end)])
                    continue
                # Provider exception text can contain URLs, hashes and credentials.
                raise ConnectionError("Schwab transaction request failed") from None
            status = getattr(response, "status_code", None)
            if type(status) is not int or status != 200:
                status_label = str(status) if type(status) is int and 100 <= status <= 599 else "unavailable"
                raise ConnectionError(f"Schwab transaction request failed (HTTP {status_label})")
            try:
                rows = response.json()
            except Exception:
                raise ValueError("Invalid Schwab transaction response") from None
            if not isinstance(rows, list):
                raise ValueError("Invalid Schwab transaction response")
            # The endpoint has no page cursor in the supported SDK. Split a
            # possibly capped response, overlapping boundaries and deduping IDs.
            if len(rows) >= 3000:
                span = int((window_end - window_start).total_seconds())
                if span <= 1:
                    raise ValueError("Schwab transaction response remains saturated at its time boundary")
                midpoint = window_start + dt.timedelta(seconds=span // 2)
                windows.extend([(window_start, midpoint), (midpoint, window_end)])
                continue
            for row in rows:
                try:
                    event = self._normalize_transaction_to_cash_event(row)
                except ValueError:
                    if not audit:
                        raise
                    unresolved = True
                    continue
                if event is None or not start <= event.occurred_at <= end:
                    continue
                if audit and event.occurred_at == end:
                    continue
                existing = events.get(event.event_id)
                if existing is not None and existing.to_dict() != event.to_dict():
                    raise ValueError("Schwab returned conflicting observations for one activity")
                events[event.event_id] = event
                if limit is not None and len(events) > limit:
                    raise ValueError("Schwab cash-event limit would discard funding events")
        return sorted(events.values(), key=lambda event: (event.occurred_at, event.event_id)), unresolved

    def _get_balances_at_broker(self, quote_asset: Asset, strategy) -> tuple:
        """
        Get the actual cash balance at the broker.
        
        Parameters
        ----------
        quote_asset : Asset
            The quote asset to get the balance of (e.g., USD, EUR).
        strategy : Strategy
            The strategy object that is requesting the balance.

        Returns
        -------
        tuple of float
            A tuple containing (cash, positions_value, total_liquidation_value).
            - Cash = cash in the account (whatever the quote asset is).
            - Positions value = the value of all the positions in the account.
            - Portfolio value = the total equity value of the account (aka. portfolio value).
        """
        # Add check for authorization error first
        if not self._broker_fully_ready:
            logger.warning(colored("[Schwab] Broker not fully ready. Cannot get balances.", "yellow"))
            return None
        if self.schwab_authorization_error:
            logger.warning(colored("Schwab authorization failed previously. Cannot get balances.", "yellow"))
            return None

        # Add check for valid client and hash_value
        if not self.client or not self.hash_value:
            logger.error(colored("Schwab client or account hash not initialized. Cannot get balances.", "red"))
            return None

        try:
            # Get account information using the hash_value stored during initialization
            response = self.client.get_account(self.hash_value, fields=[self.client.Account.Fields.POSITIONS])

            if response.status_code != 200:
                logger.error(colored(f"Error getting account information: {response.status_code}", "red"))
                # Modify the error message slightly for clarity
                raise ConnectionError(
                    "Failed to get account information for hash "
                    f"{self._mask_hash_value(self.hash_value)}; HTTP status {response.status_code}"
                )

            account_data = response.json()

            # Try to use aggregated balance first if available
            if 'aggregatedBalance' in account_data:
                # Use aggregated balance data
                aggregated_balance = account_data['aggregatedBalance']
                portfolio_value = self._get_required_balance_float(aggregated_balance, 'currentLiquidationValue')

                # Get cash from securitiesAccount
                securities_account = account_data.get('securitiesAccount', {})
                balances = securities_account.get('currentBalances', {})
                cash = self._get_required_balance_float(balances, 'cashBalance')
            else:
                # Fall back to original implementation
                securities_account = account_data.get('securitiesAccount', {})
                account_type = securities_account.get('type', '')

                # Get balances based on account type
                balances = securities_account.get('currentBalances', {})
                if account_type.lower() == 'margin':
                    cash = self._get_required_balance_float(balances, 'cashBalance')
                    portfolio_value = self._get_required_balance_float(balances, 'liquidationValue', 'equity')
                else: # Assuming CASH account type or similar
                    cash = self._get_required_balance_float(balances, 'cashBalance')
                    portfolio_value = self._get_required_balance_float(balances, 'accountValue')

            if cash is None or portfolio_value is None:
                logger.warning(colored(
                    f"Schwab balance response missing required balance fields; cash={cash}, "
                    f"portfolio_value={portfolio_value}. Leaving cached balances unchanged.",
                    "yellow",
                ))
                return None

            # Calculate positions value (portfolio value minus cash)
            positions_value = portfolio_value - cash

            return cash, positions_value, portfolio_value

        except Exception as e:
            logger.error(colored(f"Error getting balances from Schwab: {str(e)}", "red"))
            logger.error(_format_exc())

            return None

    @staticmethod
    def _attach_raw_broker_data(entity, raw_payload, **metadata):
        entity._raw = raw_payload
        entity.raw_broker_payload = raw_payload
        entity.broker_parse_warning = metadata.pop("broker_parse_warning", None)
        entity.broker_parse_degraded = metadata.pop("broker_parse_degraded", False)
        for key, value in metadata.items():
            setattr(entity, key, value)
        return entity

    @staticmethod
    def _coerce_float(value, *, field_name: str, context: str):
        try:
            return float(value or 0)
        except (TypeError, ValueError) as exc:
            raise ValueError(f"Invalid Schwab {field_name} for {context}: {value!r}") from exc

    @staticmethod
    def _get_required_balance_float(balances: dict, *keys):
        for key in keys:
            if key in balances and balances.get(key) is not None:
                return float(balances.get(key))
        return None

    def _asset_from_schwab_instrument(self, instrument: dict, raw_asset_type: str, raw_payload: dict, *, context: str):
        symbol = instrument.get("symbol") or instrument.get("underlyingSymbol") or instrument.get("cusip") or ""
        raw_asset_type = raw_asset_type or "UNKNOWN"

        if not symbol:
            return None

        if raw_asset_type == "EQUITY":
            return self._attach_raw_broker_data(
                Asset(
                    symbol=self._normalize_symbol_for_internal(symbol, asset_type=Asset.AssetType.STOCK),
                    asset_type=Asset.AssetType.STOCK,
                ),
                raw_payload,
                raw_asset_type=raw_asset_type,
            )

        if raw_asset_type == "OPTION":
            option_symbol = instrument.get("symbol")
            option_parts = _schwab_helper()._parse_option_symbol(option_symbol)
            if option_parts:
                return self._attach_raw_broker_data(
                    Asset(
                        symbol=self._normalize_symbol_for_internal(
                            option_parts["underlying"], asset_type=Asset.AssetType.OPTION
                        ),
                        asset_type=Asset.AssetType.OPTION,
                        expiration=option_parts["expiry_date"],
                        strike=option_parts["strike_price"],
                        right=option_parts["option_type"],
                    ),
                    raw_payload,
                    raw_asset_type=raw_asset_type,
                )

            logger.warning(colored(
                f"Could not parse Schwab option symbol {option_symbol!r} for {context}; "
                "returning unknown asset instead.",
                "yellow",
            ))

        known_asset_types = {
            "FUTURE": Asset.AssetType.FUTURE,
            "FOREX": Asset.AssetType.FOREX,
            "INDEX": Asset.AssetType.INDEX,
            "COLLECTIVE_INVESTMENT": Asset.AssetType.STOCK,
            "ETF": Asset.AssetType.STOCK,
            "CASH_EQUIVALENT": Asset.AssetType.FOREX,
            "MONEY_MARKET_FUND": Asset.AssetType.FOREX,
            "CASH": Asset.AssetType.FOREX,
        }
        known_unsupported_asset_types = {"MUTUAL_FUND"}
        mapped_asset_type = known_asset_types.get(raw_asset_type, Asset.AssetType.UNKNOWN)
        is_known_unsupported = raw_asset_type in known_unsupported_asset_types
        if mapped_asset_type == Asset.AssetType.STOCK:
            symbol = self._normalize_symbol_for_internal(symbol, asset_type=Asset.AssetType.STOCK)

        if mapped_asset_type == Asset.AssetType.UNKNOWN and not is_known_unsupported:
            logger.warning(colored(
                f"Unknown Schwab asset type {raw_asset_type!r} for {context}; preserving broker row as unknown.",
                "yellow",
            ))

        return self._attach_raw_broker_data(
            Asset(symbol=symbol, asset_type=mapped_asset_type),
            raw_payload,
            raw_asset_type=raw_asset_type,
            broker_parse_warning=(
                f"Unknown Schwab asset type: {raw_asset_type}"
                if mapped_asset_type == Asset.AssetType.UNKNOWN and not is_known_unsupported
                else None
            ),
            broker_parse_degraded=(mapped_asset_type == Asset.AssetType.UNKNOWN and not is_known_unsupported),
        )

    # Position methods
    def _pull_positions(self, strategy: 'Strategy') -> List[Position]:
        self._last_positions_refresh_degraded = False
        # Add check for authorization error first
        if not self._broker_fully_ready:
            logger.warning(colored("[Schwab] Broker not fully ready. Cannot pull positions.", "yellow"))
            self._last_positions_refresh_degraded = True
            return []
        if self.schwab_authorization_error:
            logger.warning(colored("Schwab authorization failed previously. Cannot pull positions.", "yellow"))
            self._last_positions_refresh_degraded = True
            return []

        Position = _position_class()

        try:
            # Add check for valid client and hash_value
            if not self.client or not self.hash_value:
                logger.error(colored("Schwab client or account hash not initialized. Cannot pull positions.", "red"))
                self._last_positions_refresh_degraded = True
                return [] # Return empty list

            # Get account details with positions
            response = self.client.get_account(self.hash_value, fields=[self.client.Account.Fields.POSITIONS])

            if response.status_code != 200:
                logger.error(colored(f"Error fetching positions from Schwab: {response.status_code}", "red"))
                self._last_positions_refresh_degraded = True
                return []

            account_data = response.json()

            # Extract positions
            securities_account = account_data.get('securitiesAccount', {})
            schwab_positions = securities_account.get('positions', [])

            pos_dict = {}  # key: (symbol, asset_type, expiration, strike, right)
            strategy_name = strategy.name if strategy is not None else "Unknown"

            for schwab_position in schwab_positions:
                # Extract instrument details
                instrument = schwab_position.get('instrument', {})
                asset_type = instrument.get('assetType', '')
                symbol = instrument.get('symbol', '')

                asset = self._asset_from_schwab_instrument(
                    instrument,
                    asset_type,
                    schwab_position,
                    context=f"position symbol {symbol or '<missing>'}",
                )
                if asset is None:
                    self._last_positions_refresh_degraded = True
                    logger.warning(colored(
                        f"Skipping Schwab position with no usable symbol/instrument identifier: {schwab_position}",
                        "yellow",
                    ))
                    continue

                # Calculate net quantity (long - short)
                long_quantity = schwab_position.get('longQuantity', 0) or 0
                short_quantity = schwab_position.get('shortQuantity', 0) or 0
                try:
                    net_quantity = (
                        self._coerce_float(long_quantity, field_name="longQuantity", context=f"position {symbol}")
                        - self._coerce_float(short_quantity, field_name="shortQuantity", context=f"position {symbol}")
                    )
                except ValueError as exc:
                    self._last_positions_refresh_degraded = True
                    logger.warning(colored(
                        f"Skipping Schwab position with invalid quantity for asset type: {asset_type}, "
                        f"symbol: {symbol}: {exc}",
                        "yellow",
                    ))
                    continue

                # Skip positions with zero quantity
                if net_quantity == 0:
                    continue

                # Extract position-specific details
                average_price = schwab_position.get('averagePrice', 0.0)
                pnl = schwab_position.get('longOpenProfitLoss') or schwab_position.get('shortOpenProfitLoss') or None
                market_value = schwab_position.get('marketValue', None)

                # Only create position object if we have a valid asset
                if asset is not None:
                    # Create a unique key for the asset to avoid duplicates
                    key = (asset.symbol, asset.asset_type,
                          getattr(asset, 'expiration', None),
                          getattr(asset, 'strike', None),
                          getattr(asset, 'right', None))

                    # If we already have this asset in our dict, update the quantity
                    if key in pos_dict:
                        existing_position = pos_dict[key]
                        existing_position.quantity += net_quantity
                        if pnl is not None:
                            existing_position.pnl = (existing_position.pnl or 0) + pnl
                        if market_value is not None:
                            existing_position.market_value += market_value
                    else:
                        # Create a new Position object
                        pos_dict[key] = Position(
                            strategy_name,
                            asset=asset,
                            quantity=net_quantity,
                            avg_fill_price=average_price,
                        )
                        self._attach_raw_broker_data(
                            pos_dict[key],
                            schwab_position,
                            raw_asset_type=asset_type,
                            broker_parse_warning=getattr(asset, "broker_parse_warning", None),
                            broker_parse_degraded=getattr(asset, "broker_parse_degraded", False),
                        )
                        
                        pos_dict[key].pnl = pnl
                        pos_dict[key].market_value = market_value

            # Log the number of positions found
            logger.debug(f"Pulled {len(pos_dict)} unique positions from Schwab")

            return list(pos_dict.values())

        except Exception as e:
            logger.error(colored(f"Error pulling positions from Schwab: {str(e)}", "red"))
            logger.error(_format_exc())
            self._last_positions_refresh_degraded = True
            return []

    def _pull_position(self, strategy: 'Strategy', asset: Asset) -> Optional[Position]:
        """
        Pull a single position from the broker that matches the asset and strategy.

        Parameters
        ----------
        strategy: Strategy
            The strategy object that placed the order to pull.
        asset: Asset
            The asset to pull the position for.

        Returns
        -------
        Position
            The position object for the asset and strategy if found, otherwise None.
            
        Notes
        -----
        This method compares different attributes based on asset type:
        - For stocks and futures: Compares only the symbol
        - For options: Compares symbol, strike, right, and expiration
        """
        # Add check for authorization error first
        if self.schwab_authorization_error:
            logger.warning(colored("Schwab authorization failed previously. Cannot pull position.", "yellow"))
            return None

        positions = self._pull_positions(strategy)

        for position in positions:
            # For stocks, just compare the symbol
            if asset.asset_type == Asset.AssetType.STOCK and position.asset.symbol == asset.symbol:
                return position
            # For options, compare all option details
            elif asset.asset_type == Asset.AssetType.OPTION:
                if (position.asset.symbol == asset.symbol and
                    position.asset.strike == asset.strike and
                    position.asset.right == asset.right and
                    position.asset.expiration == asset.expiration):
                    return position
            # For futures, compare symbol
            elif asset.asset_type == Asset.AssetType.FUTURE and position.asset.symbol == asset.symbol:
                return position

        return None

    # Order methods
    def _pull_broker_all_orders(self) -> list:
        """
        Get the broker's open orders.

        Returns
        -------
        list
            A list of order responses from the broker query. These will be passed to 
            _parse_broker_order() to be converted to Order objects.
            
        Notes
        -----
        This method retrieves orders from the past 7 days by default to limit the
        volume of data returned while still capturing relevant recent orders.
        """
        # Add check for authorization error first
        if not self._broker_fully_ready:
            logger.warning(colored("[Schwab] Broker not fully ready. Cannot pull all orders.", "yellow"))
            return []
        if self.schwab_authorization_error:
            logger.warning(colored("Schwab authorization failed previously. Cannot pull all orders.", "yellow"))
            return []

        # Add check for valid client and hash_value
        if not self.client or not self.hash_value:
            logger.error(colored("Schwab client or account hash not initialized. Cannot pull all orders.", "red"))
            return [] # Return empty list

        if not self._schwab_request_allowed("order_history"):
            return []

        try:
            # Get orders from last 7 days
            from pytz import timezone

            seek_start = datetime.now(timezone('UTC')) - timedelta(days=7)

            response = self.client.get_orders_for_account(
                self.hash_value,
                from_entered_datetime=seek_start
            )

            if response.status_code == 429:
                self._record_schwab_rate_limit(response, "order_history")
                return []
            if response.status_code != 200:
                logger.error(colored(f"Error fetching orders from Schwab: {response.status_code}", "red"))
                return []

            self._clear_schwab_rate_limit("order_history")
            schwab_orders = response.json()

            return schwab_orders

        except Exception as e:
            logger.error(colored(f"Error pulling orders from Schwab: {str(e)}", "red"))
            logger.error(_format_exc())
            return []

    def _pull_broker_order(self, identifier: str) -> dict:
        """
        Get a broker order representation by its id.

        Parameters
        ----------
        identifier : str
            The identifier of the order to pull.

        Returns
        -------
        dict
            The order representation from the broker, or None if not found.
        """
        # Add check for authorization error first
        if self.schwab_authorization_error:
            logger.warning(colored(f"Schwab authorization failed previously. Cannot pull order {identifier}.", "yellow"))
            return None

        # Add check for valid client and hash_value
        if not self.client or not self.hash_value:
            logger.error(colored(f"Schwab client or account hash not initialized. Cannot pull order {identifier}.", "red"))
            return None # Return None

        if not self._schwab_request_allowed("order_read"):
            return None

        try:
            response = self.client.get_order(
                identifier,
                self.hash_value,
            )

            if response.status_code == 429:
                self._record_schwab_rate_limit(response, "order_read")
                return None
            if response.status_code != 200:
                logger.error(colored(f"Error fetching Schwab order {identifier}: {response.status_code}", "red"))
                return None

            self._clear_schwab_rate_limit("order_read")
            return response.json()

        except Exception as e:
            logger.error(colored(f"Error pulling order {identifier} from Schwab: {str(e)}", "red"))
            logger.error(_format_exc())
            return None

    def _parse_broker_order(self, response: dict, strategy_name: str, strategy_object: 'Strategy' = None) -> Order:
        """
        Parse a broker order representation to an order object.

        Parameters
        ----------
        response : dict
            The broker order representation, typically from API response.
        strategy_name : str
            The name of the strategy that placed the order.
        strategy_object : Strategy, optional
            The strategy object that placed the order.

        Returns
        -------
        Order
            The order object created from the broker's response, or None if parsing fails.
            
        Notes
        -----
        This method handles complex order structures including:
        - Simple orders (direct conversion to Lumibot orders)
        - OCO (One-Cancels-Other) orders with child orders
        - Other order strategies with child orders
        """
        try:
            # Check if there are child order strategies
            child_order_strategies = response.get("childOrderStrategies", None)

            # If there are child order strategies, process them
            if child_order_strategies is not None:
                # Create a list to hold the child order objects

                child_order_objects = []
                skipped_child_orders = 0

                # Loop through the childOrderStrategies
                for child_order_strategy in child_order_strategies:
                    if child_order_strategy.get("childOrderStrategies") is not None:
                        child_order = self._parse_broker_order(child_order_strategy, strategy_name)
                        if child_order:
                            child_order_objects.append(child_order)
                        else:
                            skipped_child_orders += 1
                        continue

                    child_orders = self._parse_simple_order(child_order_strategy, strategy_name)
                    if child_orders:
                        child_order_objects.extend(child_orders)
                    else:
                        skipped_child_orders += 1

                # Check if the orderStrategyType is OCO
                order_strategy_type = response.get("orderStrategyType", None)
                if order_strategy_type == "OCO" and len(child_order_objects) > 0:
                    # Get the asset object from the child_order_objects
                    asset = child_order_objects[0].asset

                    # Make sure this is the same asset for all the child orders
                    same_asset = True
                    for child_order_object in child_order_objects:
                        if child_order_object.asset != asset:
                            logger.error(colored("ERROR: Asset for all child orders in OCO order is not the same", "red"))
                            same_asset = False
                            break

                    if same_asset:
                        # Create an OCO order (using order_type parameter instead of deprecated type)
                        order = Order(
                            strategy=strategy_name,
                            order_class=Order.OrderClass.OCO,
                            asset=asset,  # Include asset parameter
                            child_orders=child_order_objects,
                            identifier=response.get("orderId"),
                        )
                        order.status = self._schwab_status_to_lumibot(response.get("status", "UNKNOWN"))
                        return order

                if order_strategy_type == "TRIGGER" and len(child_order_objects) > 0:
                    parent_orders = self._parse_simple_order(response, strategy_name)
                    if parent_orders:
                        parent_order = parent_orders[0]
                        if (
                            len(child_order_objects) == 1
                            and child_order_objects[0].order_class is Order.OrderClass.OCO
                        ):
                            parent_order.order_class = Order.OrderClass.BRACKET
                            parent_order.child_orders = child_order_objects[0].child_orders
                        else:
                            parent_order.order_class = Order.OrderClass.OTO
                            parent_order.child_orders = child_order_objects
                        return parent_order

                # If we get here and have child orders, return the first one
                if child_order_objects:
                    active_children = [child for child in child_order_objects if child.is_active()]
                    return active_children[0] if active_children else child_order_objects[0]
                if skipped_child_orders == len(child_order_strategies):
                    return None
            else:
                # Process simple order
                simple_orders = self._parse_simple_order(response, strategy_name)
                if simple_orders:
                    return simple_orders[0]  # Return the first order

            logger.warning(colored(
                f"Could not parse any valid Schwab orders from response for order ID: {response.get('orderId', '')}",
                "yellow",
            ))
            return None

        except Exception as e:
            logger.warning(colored(f"Skipping malformed Schwab broker order: {str(e)}", "yellow"))
            logger.debug(_format_exc())
            return None

    def _schwab_order_type_to_lumibot(self, raw_order_type):
        order_type_map = {
            "LIMIT": Order.OrderType.LIMIT,
            "MARKET": Order.OrderType.MARKET,
            "STOP": Order.OrderType.STOP,
            "STOP_LIMIT": Order.OrderType.STOP_LIMIT,
            "TRAILING_STOP": Order.OrderType.TRAIL,
        }
        if raw_order_type in order_type_map:
            return order_type_map[raw_order_type]

        known_non_strategy_history_types = {"EXERCISE"}
        if raw_order_type in known_non_strategy_history_types:
            return Order.OrderType.UNKNOWN

        logger.warning(colored(
            f"Unknown Schwab order type {raw_order_type!r}; preserving broker order as unknown.",
            "yellow",
        ))
        return Order.OrderType.UNKNOWN

    def _schwab_status_to_lumibot(self, raw_status):
        status_map = {
            "ACCEPTED": Order.OrderStatus.NEW,
            "AWAITING_PARENT_ORDER": Order.OrderStatus.NEW,
            "AWAITING_CONDITION": Order.OrderStatus.NEW,
            "AWAITING_STOP_CONDITION": Order.OrderStatus.NEW,
            "AWAITING_MANUAL_REVIEW": Order.OrderStatus.NEW,
            "AWAITING_UR_OUT": Order.OrderStatus.NEW,
            "PENDING_ACTIVATION": Order.OrderStatus.NEW,
            "QUEUED": Order.OrderStatus.NEW,
            "WORKING": Order.OrderStatus.NEW,
            "NEW": Order.OrderStatus.NEW,
            "REJECTED": Order.OrderStatus.ERROR,
            "PENDING_CANCEL": Order.OrderStatus.CANCELLING,
            "CANCELED": Order.OrderStatus.CANCELED,
            "PENDING_REPLACE": Order.OrderStatus.CANCELLING,
            "REPLACED": Order.OrderStatus.CANCELED,
            "EXPIRED": Order.OrderStatus.EXPIRED,
            "PARTIALLY_FILLED": Order.OrderStatus.PARTIALLY_FILLED,
            "FILLED": Order.OrderStatus.FILLED,
            "UNKNOWN": Order.OrderStatus.UNKNOWN,
        }
        if raw_status in status_map:
            return status_map[raw_status]

        logger.warning(colored(
            f"Unknown Schwab order status {raw_status!r}; preserving broker order with unknown status.",
            "yellow",
        ))
        return Order.OrderStatus.UNKNOWN

    @staticmethod
    def _schwab_execution_summary(schwab_order: dict, leg_id=None):
        """Return cumulative executed quantity and VWAP from a Schwab snapshot.

        Schwab order-history responses describe executions as cumulative activity.
        LumiBot callbacks require the newly observed delta, so parsing keeps the
        cumulative broker value on the observed Order and the reducer calculates
        the delta against a per-order high-water mark.
        """
        execution_rows = []
        for activity in schwab_order.get("orderActivityCollection") or schwab_order.get("activityCollection") or []:
            if str(activity.get("activityType", "")).upper() not in {"EXECUTION", "ORDER_EXECUTION"}:
                continue
            for execution in activity.get("executionLegs") or []:
                execution_leg_id = execution.get("legId")
                if leg_id is not None and execution_leg_id is not None and str(execution_leg_id) != str(leg_id):
                    continue
                try:
                    quantity = float(execution.get("quantity") or 0)
                    price = float(execution.get("price"))
                except (TypeError, ValueError):
                    continue
                if quantity > 0:
                    execution_rows.append((quantity, price))

        if execution_rows:
            cumulative = sum(quantity for quantity, _ in execution_rows)
            average_price = sum(quantity * price for quantity, price in execution_rows) / cumulative
            return cumulative, average_price

        try:
            cumulative = float(schwab_order.get("filledQuantity") or 0)
        except (TypeError, ValueError):
            cumulative = 0.0
        average_price = schwab_order.get("averagePrice") or schwab_order.get("price")
        try:
            average_price = float(average_price) if average_price is not None else None
        except (TypeError, ValueError):
            average_price = None
        return cumulative, average_price

    def _schwab_instruction_to_side(self, instruction):
        side_mapping = {
            "BUY": Order.OrderSide.BUY,
            "SELL": Order.OrderSide.SELL,
            "BUY_TO_COVER": Order.OrderSide.BUY_TO_COVER,
            "SELL_SHORT": Order.OrderSide.SELL_SHORT,
            "BUY_TO_OPEN": Order.OrderSide.BUY_TO_OPEN,
            "BUY_TO_CLOSE": Order.OrderSide.BUY_TO_CLOSE,
            "SELL_TO_OPEN": Order.OrderSide.SELL_TO_OPEN,
            "SELL_TO_CLOSE": Order.OrderSide.SELL_TO_CLOSE,
        }
        if instruction in side_mapping:
            return side_mapping[instruction]

        logger.warning(colored(
            f"Unknown Schwab order instruction {instruction!r}; preserving broker order with unknown side.",
            "yellow",
        ))
        return Order.OrderSide.UNKNOWN

    def _parse_simple_order(self, schwab_order: dict, strategy_name: str) -> List[Order]:
        """
        Parse a simple Schwab order (non-OCO) into Lumibot Order objects.
        
        Parameters
        ----------
        schwab_order : dict
            The Schwab order data.
        strategy_name : str
            The name of the strategy for which to create the order.
            
        Returns
        -------
        List[Order]
            A list of parsed order objects, or an empty list if parsing fails.
            
        Notes
        -----
        This method handles conversion of:
        - Order types (LIMIT, MARKET, STOP, etc.)
        - Order statuses (NEW, FILLED, CANCELED, etc.)
        - Asset types (STOCK, OPTION, FUTURE, etc.)
        - Order sides (BUY, SELL, BUY_TO_OPEN, etc.)
        
        It also extracts important order details such as:
        - Timestamps (entry and close)
        - Prices (limit price, stop price)
        - Order legs for multi-leg orders
        """
        try:
            schwab_order_type = schwab_order.get("orderType", None)
            order_type = self._schwab_order_type_to_lumibot(schwab_order_type)

            entered_time = None
            raw_entered_time = schwab_order.get("enteredTime")
            if raw_entered_time:
                try:
                    entered_time = datetime.strptime(raw_entered_time, "%Y-%m-%dT%H:%M:%S%z")
                except Exception as exc:
                    logger.warning(colored(
                        f"Could not parse Schwab enteredTime {raw_entered_time!r} "
                        f"for order ID: {schwab_order.get('orderId', '')}: {exc}",
                        "yellow",
                    ))

            close_time = None
            if "closeTime" in schwab_order:
                try:
                    close_time = datetime.strptime(schwab_order["closeTime"], "%Y-%m-%dT%H:%M:%S%z")
                except Exception as exc:
                    logger.warning(colored(
                        f"Could not parse Schwab closeTime {schwab_order.get('closeTime')!r} "
                        f"for order ID: {schwab_order.get('orderId', '')}: {exc}",
                        "yellow",
                    ))

            schwab_order_status = schwab_order.get("status", None)
            status = self._schwab_status_to_lumibot(schwab_order_status)

            # Get the order id
            order_id = schwab_order.get("orderId", None)
            if order_id is None:
                logger.warning(colored(f"Skipping Schwab order without orderId: {schwab_order}", "yellow"))
                return []

            # Get prices
            price = schwab_order.get("price", None)
            stop_price = schwab_order.get("stopPrice", None)

            # Get the schwab legs
            schwab_legs = schwab_order.get("orderLegCollection", [])
            if not schwab_legs:
                logger.warning(colored(f"No order legs found for Schwab order ID: {order_id}", "yellow"))
                return []

            # Process each leg as a separate order
            order_objects = []
            for leg_index, schwab_leg in enumerate(schwab_legs):
                # Get the asset information
                instrument = schwab_leg.get("instrument", {})

                # Get the symbol - prefer underlyingSymbol for options if available
                if "underlyingSymbol" in instrument:
                    symbol = instrument["underlyingSymbol"]
                else:
                    symbol = instrument.get("symbol", "") or instrument.get("cusip", "")

                if not symbol:
                    logger.warning(colored(f"No symbol found for Schwab order leg in order ID: {order_id}", "yellow"))
                    continue

                asset_type_str = schwab_leg.get("orderLegType", "")

                # Get the quantity
                quantity = schwab_leg.get("quantity", 0)
                try:
                    quantity = self._coerce_float(quantity, field_name="quantity", context=f"order {order_id}")
                except ValueError as exc:
                    logger.warning(colored(str(exc), "yellow"))
                    continue
                if quantity <= 0:
                    logger.warning(colored(f"Invalid quantity ({quantity}) for Schwab order ID: {order_id}", "yellow"))
                    continue

                instruction = schwab_leg.get("instruction", "")
                side = self._schwab_instruction_to_side(instruction)

                asset = self._asset_from_schwab_instrument(
                    instrument,
                    asset_type_str,
                    schwab_order,
                    context=f"order {order_id} leg {symbol}",
                )
                if asset is None:
                    logger.warning(colored(
                        f"No usable asset found for Schwab order leg in order ID: {order_id}",
                        "yellow",
                    ))
                    continue

                # Create order object - using order_type instead of type
                order = Order(
                    strategy=strategy_name,
                    asset=asset,
                    quantity=quantity,
                    side=side,
                    order_type=order_type,  # Changed from type to order_type
                    limit_price=price,
                    stop_price=stop_price,
                    identifier=order_id,
                )

                cumulative_filled, average_fill_price = self._schwab_execution_summary(
                    schwab_order,
                    leg_id=schwab_leg.get("legId", leg_index + 1),
                )
                order._schwab_cumulative_filled_quantity = cumulative_filled
                order._schwab_average_fill_price = average_fill_price
                if average_fill_price is not None:
                    order.avg_fill_price = average_fill_price

                # Set the status and timestamps
                order.status = status
                order.broker_create_date = entered_time
                order.created_at = order.broker_create_date
                order.broker_update_date = close_time if close_time else entered_time
                self._attach_raw_broker_data(
                    order,
                    schwab_order,
                    raw_order_type=schwab_order_type,
                    raw_order_status=schwab_order_status,
                    raw_order_side=instruction,
                    raw_asset_type=asset_type_str,
                    broker_parse_warning=(
                        "Unknown Schwab order field(s)"
                        if (
                            order_type == Order.OrderType.UNKNOWN
                            or status == Order.OrderStatus.UNKNOWN
                            or side == Order.OrderSide.UNKNOWN
                            or asset.asset_type == Asset.AssetType.UNKNOWN
                        )
                        else getattr(asset, "broker_parse_warning", None)
                    ),
                    broker_parse_degraded=(
                        order_type == Order.OrderType.UNKNOWN
                        or status == Order.OrderStatus.UNKNOWN
                        or side == Order.OrderSide.UNKNOWN
                        or asset.asset_type == Asset.AssetType.UNKNOWN
                    ),
                )

                order_objects.append(order)

            return order_objects

        except Exception as e:
            logger.warning(colored(f"Skipping malformed Schwab simple order: {str(e)}", "yellow"))
            logger.debug(_format_exc())
            return []

    def _process_schwab_order_snapshot(self, observed_order: Order) -> None:
        """Serialize every REST/stream observation through one reducer."""
        if not hasattr(self, "_schwab_order_transition_lock"):
            self._schwab_order_transition_lock = threading.RLock()
        with self._schwab_order_transition_lock:
            self._reduce_schwab_order_snapshot(observed_order)

    def _apply_direct_order_observation(self, order_lumi, matched_order):
        # Setting terminal status first makes the reducer skip the callback and
        # loses both rejection reasons and fills. All observations use one owner.
        previous_status = order_lumi.status
        self._process_schwab_order_snapshot(matched_order)
        changed = not order_lumi.equivalent_status(previous_status)
        for attr in ("quantity", "limit_price", "stop_price"):
            value = getattr(matched_order, attr, None)
            if getattr(order_lumi, attr, None) != value:
                setattr(order_lumi, attr, value)
                changed = True
        return changed

    def _reduce_schwab_order_snapshot(self, observed_order: Order) -> None:
        """Reduce one broker-observed Schwab order snapshot into lifecycle events.

        HTTP submit/cancel acceptance is deliberately excluded: only a later
        broker snapshot or stream observation may make an order terminal.
        """
        identifier = getattr(observed_order, "identifier", None)
        if not identifier:
            return

        if not hasattr(self, "_schwab_observed_fill_quantities"):
            self._schwab_observed_fill_quantities = {}
        if not hasattr(self, "_schwab_terminal_observations"):
            self._schwab_terminal_observations = set()

        stored_order = self.get_tracked_order(identifier)
        observed_status = getattr(observed_order, "status", Order.OrderStatus.UNKNOWN)

        # A seven-day healing snapshot contains unrelated historical orders.
        # Never adopt untracked account orders into this strategy. Locally
        # submitted orders are tracked at submit time; seeding foreign NEW
        # orders previously let a shared-account MOS fill reach an STM
        # on_filled_order hedge path.
        if stored_order is None:
            if self.order_is_foreign_to_local_strategy(observed_order, getattr(self, "_strategy_name", None)):
                return
            local_name = getattr(self, "_strategy_name", None)
            tag = getattr(observed_order, "tag", None)
            # Only re-bind untracked active orders when the broker tag proves
            # ownership. Untagged snapshots are ignored so shared-account
            # activity cannot become this strategy's tracked order.
            if (
                local_name
                and tag
                and self.strategy_tag_matches(tag, local_name)
                and (
                    Order.is_equivalent_status(observed_status, self.NEW_ORDER)
                    or Order.is_equivalent_status(observed_status, Order.OrderStatus.CANCELLING)
                )
            ):
                self._process_new_order(observed_order)
                if Order.is_equivalent_status(observed_status, Order.OrderStatus.CANCELLING):
                    observed_order.status = Order.OrderStatus.CANCELLING
            return

        if stored_order.is_filled():
            return
        stored_terminal_status = stored_order.status
        stored_terminal_reason = getattr(stored_order, "error_message", None)
        was_terminal = (
            stored_order.is_canceled()
            or Order.is_equivalent_status(stored_terminal_status, self.ERROR_ORDER)
            or Order.is_equivalent_status(stored_terminal_status, Order.OrderStatus.EXPIRED)
        )
        confirmed_terminal = (
            Order.is_equivalent_status(stored_terminal_status, self.CANCELED_ORDER)
            or Order.is_equivalent_status(stored_terminal_status, Order.OrderStatus.EXPIRED)
            or (identifier, str(self.ERROR_ORDER)) in self._schwab_terminal_observations
            or (identifier, str(Order.OrderStatus.EXPIRED)) in self._schwab_terminal_observations
        )
        # ERROR can originate from a local transport failure, while canceled
        # snapshots can later gain execution details. Neither may suppress new
        # confirmed fill quantity. Stale active snapshots cannot reopen them.
        if was_terminal and (
            Order.is_equivalent_status(observed_status, self.NEW_ORDER)
            or Order.is_equivalent_status(observed_status, Order.OrderStatus.CANCELLING)
        ):
            return

        raw_payload = getattr(observed_order, "raw_broker_payload", None)
        if isinstance(raw_payload, dict):
            self._attach_raw_broker_data(
                stored_order, raw_payload,
                raw_order_status=getattr(observed_order, "raw_order_status", None),
            )

        if Order.is_equivalent_status(observed_status, self.NEW_ORDER):
            # Never regress a local/broker cancel-pending order back to NEW when
            # an older snapshot arrives out of order.
            if not Order.is_equivalent_status(stored_order.status, Order.OrderStatus.CANCELLING):
                stored_order.status = Order.OrderStatus.NEW
            return

        if Order.is_equivalent_status(observed_status, Order.OrderStatus.CANCELLING):
            stored_order.status = Order.OrderStatus.CANCELLING
            return

        terminal_after_fill = any(Order.is_equivalent_status(observed_status, status) for status in (
            self.CANCELED_ORDER, self.ERROR_ORDER, Order.OrderStatus.EXPIRED,
        ))
        if terminal_after_fill or Order.is_equivalent_status(observed_status, self.PARTIALLY_FILLED_ORDER) or Order.is_equivalent_status(
            observed_status, self.FILLED_ORDER
        ):
            try:
                cumulative_filled = float(getattr(observed_order, "_schwab_cumulative_filled_quantity", 0) or 0)
            except (TypeError, ValueError):
                cumulative_filled = 0.0
            if Order.is_equivalent_status(observed_status, self.FILLED_ORDER) and cumulative_filled <= 0:
                cumulative_filled = float(stored_order.quantity or observed_order.quantity or 0)

            recorded_filled = sum(float(item.quantity) for item in stored_order.transactions)
            prior_filled = max(
                float(self._schwab_observed_fill_quantities.get(identifier, 0.0)),
                recorded_filled,
            )
            if cumulative_filled <= prior_filled and not terminal_after_fill:
                if (was_terminal and Order.is_equivalent_status(observed_status, self.FILLED_ORDER)
                        and recorded_filled == float(stored_order.quantity)):
                    # The fill was already delivered before a local ERROR
                    # moved this object to the error bucket. Restore confirmed
                    # terminal state without a zero-quantity/fabricated fill.
                    with self._lock:
                        self._error_orders.remove(identifier, key="identifier")
                        self._canceled_orders.remove(identifier, key="identifier")
                        self._partially_filled_orders.remove(identifier, key="identifier")
                        stored_order.status = self.FILLED_ORDER
                        stored_order.set_filled()
                        if stored_order not in self._filled_orders:
                            self._filled_orders.append(stored_order)
                return
            fill_delta = cumulative_filled - prior_filled
            price = (
                getattr(observed_order, "_schwab_average_fill_price", None)
                or getattr(observed_order, "avg_fill_price", None)
                or getattr(observed_order, "limit_price", None)
            )
            if price is None and fill_delta > 0:
                logger.warning(
                    "[SchwabLifecycle] event=order.lifecycle.deferred "
                    f"order_ref={self._schwab_order_ref(identifier)} reason=missing_fill_price"
                )
                return

            if fill_delta > 0:
                self._schwab_observed_fill_quantities[identifier] = cumulative_filled
                event = (
                    self.FILLED_ORDER
                    if Order.is_equivalent_status(observed_status, self.FILLED_ORDER)
                    else self.PARTIALLY_FILLED_ORDER
                )
                # One atomic native bucket move; no I/O or Strategy execution.
                with self._lock:
                    if was_terminal:
                        self._error_orders.remove(identifier, key="identifier")
                        self._canceled_orders.remove(identifier, key="identifier")
                        if not confirmed_terminal and event == self.PARTIALLY_FILLED_ORDER:
                            # Local set_error closed this order before its broker
                            # outcome was known. Fresh partial fill proves it is
                            # still open; do not leave wait-for-close signaled.
                            stored_order._closed_event.clear()
                    self._process_trade_event(
                        stored_order,
                        event,
                        price=price,
                        filled_quantity=fill_delta,
                        multiplier=getattr(getattr(stored_order, "asset", None), "multiplier", 1) or 1,
                    )
                    self._log_schwab_lifecycle_event(
                        "order.lifecycle.callback",
                        stored_order,
                        callback=event,
                        broker_status=observed_status,
                        local_status=stored_order.status,
                    )
                    if was_terminal and confirmed_terminal and event != self.FILLED_ORDER:
                        # Keep the established terminal outcome after recording
                        # new fills, without a second terminal callback.
                        if Order.is_equivalent_status(stored_terminal_status, self.CANCELED_ORDER):
                            self._process_canceled_order(stored_order)
                        else:
                            self._process_error_order(
                                stored_order, LumibotBrokerAPIError(stored_terminal_reason or "Terminal broker order")
                            )
                            # Expiry uses the same terminal bucket as errors;
                            # retain its exact previously confirmed status.
                            stored_order.status = stored_terminal_status
            if not terminal_after_fill:
                return

        if Order.is_equivalent_status(observed_status, self.CANCELED_ORDER):
            terminal_key = (identifier, self.CANCELED_ORDER)
            if terminal_key not in self._schwab_terminal_observations:
                self._schwab_terminal_observations.add(terminal_key)
                self._process_trade_event(stored_order, self.CANCELED_ORDER)
                self._log_schwab_lifecycle_event(
                    "order.lifecycle.callback",
                    stored_order,
                    callback=self.CANCELED_ORDER,
                    broker_status=observed_status,
                    local_status=stored_order.status,
                )
            return

        if Order.is_equivalent_status(observed_status, self.ERROR_ORDER) or Order.is_equivalent_status(
            observed_status, Order.OrderStatus.EXPIRED
        ):
            terminal_key = (identifier, str(observed_status))
            if terminal_key not in self._schwab_terminal_observations:
                self._schwab_terminal_observations.add(terminal_key)
                raw_status = getattr(observed_order, "raw_order_status", None) or str(observed_status)
                raw_payload = getattr(observed_order, "raw_broker_payload", None)
                description = raw_payload.get("statusDescription") if isinstance(raw_payload, dict) else None
                message = f"Schwab order became terminal: {raw_status}"
                if isinstance(description, str) and description.strip():
                    message += f" ({description.strip()})"
                self._process_trade_event(
                    stored_order,
                    self.ERROR_ORDER,
                    error=LumibotBrokerAPIError(message),
                )
                self._log_schwab_lifecycle_event(
                    "order.lifecycle.callback",
                    stored_order,
                    callback=self.ERROR_ORDER,
                    broker_status=observed_status,
                    local_status=stored_order.status,
                )

    def _finish_initialization(self, config, data_source, account_number, hash_value):
        """
        Complete the essential initialization required to run a strategy.
        This must be called after the Schwab client and tokens are ready.
        Base class __init__ should already be called.
        """
        self.account_number = account_number
        self.hash_value = hash_value
        if data_source is not None and account_number:
            # History cached for this account is shared by its charts, bots and backtests.
            from lumibot.tools.shared_bar_cache import credential_scope

            data_source.shared_bars_scope = credential_scope("schwab", account_number)

        # Only create stream client if client exists and stream startup was requested.
        if self._connect_stream and self.client:
            try:
                self.stream_client = _get_stream_client_class()(self.client, account_id=account_number)
            except Exception as e:
                logger.error(colored(f"Failed to create Schwab StreamClient: {e}", "red"))
                self.stream_client = None
                self.schwab_authorization_error = True # Indicate potential issue

        # --- Removed schwab_token_status.json creation ---

        # === Configure Data Source Client ===
        # The data_source passed here is the one set in self.data_source by super().__init__
        # self.data_source should already be the correct instance (either passed in or created in __init__)
        schwab_data_class = _get_schwab_data_class()
        if self._is_schwab_data_intended and isinstance(self.data_source, schwab_data_class):
            if self.client:
                # Set the client on the existing SchwabData instance
                if not hasattr(self.data_source, 'client') or self.data_source.client is None:
                    self.data_source.set_client(self.client)
                    logger.debug("[Schwab] Client set on the existing SchwabData instance.")
                else:
                    # This case might happen if SchwabData was passed in already configured
                    logger.debug("[Schwab] Client seems already set on the SchwabData instance.")
            else:
                # This case indicates a problem earlier in initialization
                logger.error(colored("[Schwab] Cannot assign client to SchwabData source because broker client is missing.", "red"))
                self.schwab_authorization_error = True # Indicate potential issue
        elif not self._is_schwab_data_intended:
            # If a non-SchwabData source was intended and provided, no client assignment is needed here.
            logger.debug(f"[Schwab] Using non-SchwabData source: {type(self.data_source).__name__}. No client assignment needed here.")
        else:
            # This case should ideally not happen if __init__ logic is correct
            logger.warning(f"[Schwab] SchwabData was intended, but self.data_source is type {type(self.data_source).__name__}. Cannot set client.")
            self.schwab_authorization_error = True # Indicate potential mismatch
        # === End Configure Data Source Client ===


        # Only launch stream if stream_client was created
        if self._connect_stream and self.stream_client:
            self.stream = self._get_stream_object()
            self._launch_stream()
        elif not self._connect_stream:
            self.stream = None
        else:
            logger.warning(colored("[Schwab] Stream not launched because StreamClient failed to initialize.", "yellow"))
            self.stream = None # Ensure stream is None if not launched

    # Unimplemented methods with stubs
    def _get_stream_object(self):
        """Return the slow REST healing stream used behind account activity."""
        from lumibot.trading_builtins import PollingStream

        stream = PollingStream(30.0)
        return stream

    def _handle_schwab_account_activity(self, message) -> None:
        """Wake exact-order reconciliation without logging opaque account data."""
        message_type = "unknown"
        try:
            content = message.get("content") or []
            if content and isinstance(content[0], dict):
                message_type = content[0].get("MESSAGE_TYPE") or content[0].get("message_type") or "unknown"
        except Exception:
            pass
        message_type = re.sub(r"[^A-Za-z0-9_.:-]", "_", str(message_type))[:64] or "unknown"
        logger.info(f"[SchwabLifecycle] account_activity_received type={message_type}")
        wakeup = getattr(self, "_schwab_activity_wakeup", None)
        if wakeup is not None:
            wakeup.set()

    async def _configure_schwab_account_activity_stream(self, stream_client) -> None:
        """Register the handler before login/subscription so no event is dropped."""
        stream_client.add_account_activity_handler(self._handle_schwab_account_activity)
        await stream_client.login()
        await stream_client.account_activity_sub()
        # A reconnect may have missed events. Reconcile currently tracked active
        # orders immediately instead of waiting for the next activity message or
        # the slow broad-history healing poll.
        self._schwab_activity_wakeup.set()

    def _reconcile_active_schwab_orders(self) -> None:
        """Re-read only locally active orders after an account-activity event."""
        for stored_order in list(self.get_active_tracked_orders()):
            identifier = getattr(stored_order, "identifier", None)
            if not identifier:
                continue
            raw_order = self._pull_broker_order(identifier)
            if not raw_order:
                continue
            observed_order = self._parse_broker_order(raw_order, stored_order.strategy)
            if observed_order is not None:
                self._process_schwab_order_snapshot(observed_order)

    def _run_schwab_activity_reconciler(self) -> None:
        stop_event = self._schwab_activity_stop
        wakeup = self._schwab_activity_wakeup
        while not stop_event.is_set():
            wakeup.wait(1.0)
            if stop_event.is_set():
                return
            if not wakeup.is_set():
                continue
            wakeup.clear()
            try:
                self._reconcile_active_schwab_orders()
            except Exception:
                logger.error(_format_exc())

    async def _run_schwab_account_activity_async(self) -> None:
        import asyncio

        backoff_seconds = 1.0
        while not self._schwab_activity_stop.is_set():
            stream_client = self.stream_client
            try:
                await self._configure_schwab_account_activity_stream(stream_client)
                logger.info("[SchwabLifecycle] account_activity_stream_connected")
                connected_at = time.monotonic()
                while not self._schwab_activity_stop.is_set():
                    await stream_client.handle_message()
                    # Login success alone does not mean the stream recovered.
                    # Keep backoff across rapid login/disconnect cycles.
                    if time.monotonic() - connected_at >= 60.0:
                        backoff_seconds = 1.0
            except Exception as exc:
                if self._schwab_activity_stop.is_set():
                    return
                logger.warning(
                    f"[SchwabLifecycle] account_activity_stream_disconnected retry_seconds={backoff_seconds:g} "
                    f"error_type={type(exc).__name__}"
                )
                await asyncio.sleep(backoff_seconds)
                backoff_seconds = min(backoff_seconds * 2, 30.0)
                try:
                    self.stream_client = _get_stream_client_class()(self.client, account_id=self.account_number)
                except Exception:
                    logger.error(_format_exc())

    def _run_schwab_account_activity_stream(self) -> None:
        import asyncio

        try:
            asyncio.run(self._run_schwab_account_activity_async())
        except Exception:
            if not self._schwab_activity_stop.is_set():
                logger.error(_format_exc())

    def _register_stream_events(self):
        """Register callbacks for broker stream events"""
        broker = self

        @broker.stream.add_action(broker.POLL_EVENT)
        def on_trade_event_poll():
            # Implement polling similar to tradier.py without referencing _orders
            try:
                # Track the last time we synced positions to avoid doing it too frequently
                current_time = datetime.now()
                if not hasattr(broker, '_last_position_sync_time') or (current_time - broker._last_position_sync_time).total_seconds() > 30:
                    # Only sync positions every 30 seconds to avoid duplication
                    broker.sync_positions(None)
                    broker._last_position_sync_time = current_time

                # Always check for new orders
                orders = broker._pull_broker_all_orders()
                for order_data in orders:
                    order = broker._parse_broker_order(order_data, broker._strategy_name)
                    if not order:
                        continue
                    # Shared-account safety: skip foreign-tagged snapshots early.
                    if broker.order_is_foreign_to_local_strategy(order, broker._strategy_name):
                        continue
                    broker._process_schwab_order_snapshot(order)
            except Exception:
                logger.error(_format_exc())

        @broker.stream.add_action(broker.FILLED_ORDER)
        def on_trade_event_fill(order, price, filled_quantity):
            logger.info(f"Processing action for filled order {order} | {price} | {filled_quantity}")
            try:
                broker._process_trade_event(
                    order,
                    broker.FILLED_ORDER,
                    price=price,
                    filled_quantity=filled_quantity,
                    multiplier=order.asset.multiplier,
                )
                return True
            except Exception:
                logger.error(_format_exc())

        @broker.stream.add_action(broker.PARTIALLY_FILLED_ORDER)
        def on_trade_event_partial_fill(order, price, filled_quantity):
            logger.info(f"Processing action for partially filled order {order} | {price} | {filled_quantity}")
            try:
                broker._process_trade_event(
                    order,
                    broker.PARTIALLY_FILLED_ORDER,
                    price=price,
                    filled_quantity=filled_quantity,
                    multiplier=order.asset.multiplier,
                )
                return True
            except Exception:
                logger.error(_format_exc())

        @broker.stream.add_action(broker.CANCELED_ORDER)
        def on_trade_event_cancel(order):
            logger.info(f"Processing action for cancelled order {order}")
            try:
                broker._process_trade_event(order, broker.CANCELED_ORDER)
            except Exception:
                logger.error(_format_exc())

        @broker.stream.add_action(broker.ERROR_ORDER)
        def on_trade_event_error(order, error_msg):
            logger.error(f"Processing action for error order {order} | {error_msg}")
            try:
                broker._process_trade_event(
                    order,
                    broker.ERROR_ORDER,
                    error=LumibotBrokerAPIError(str(error_msg)),
                )
            except Exception:
                logger.error(_format_exc())

    def _run_stream(self):
        stream = getattr(self, "stream", None)
        if not stream:
            logger.warning(colored("Schwab stream object not initialized, skipping stream runner.", "yellow"))
            return
        self._stream_established()
        try:
            logger.info(colored("Starting Schwab stream...", "green"))
            stream._run()
        except Exception as e:
            logger.error(f"Error running Schwab stream: {e}")
            logger.error(_format_exc())

    def _stream_established(self):
        """
        Called when the stream is established.
        This method is required by the broker framework to indicate the stream is ready.
        """
        logger.info(colored("Schwab stream connection established", "green"))
        # Clear only the _unprocessed_orders since _orders is not defined
        for item in self._unprocessed_orders.get_list():
            self._unprocessed_orders.remove(item)
        self._initialized = True

        # First time initialization - sync positions
        self.sync_positions(None)

    def _safe_stream_dispatch(self, event, **kwargs):
        stream = getattr(self, "stream", None)
        if stream is not None and hasattr(stream, "dispatch"):
            stream.dispatch(event, **kwargs)

    def _submit_order(self, order: Order) -> Order:
        """
        Submit an order to the broker after necessary checks and input sanitization.
        
        Parameters
        ----------
        order : Order
            The order to submit to the broker.

        Returns
        -------
        Order
            Updated order with broker identifier filled in, or None if submission failed.
        """
        # Add check for authorization error first
        if self.schwab_authorization_error:
            logger.error(colored(f"Schwab authorization failed previously. Cannot submit order {order}.", "red"))
            self._safe_stream_dispatch(self.ERROR_ORDER, order=order, error_msg="Schwab authorization failed previously")
            return None

        # Add check for valid client and hash_value
        if not self.client or not self.hash_value:
            logger.error(colored(f"Schwab client or account hash not initialized. Cannot submit order {order}.", "red"))
            self._safe_stream_dispatch(self.ERROR_ORDER, order=order, error_msg="Schwab client/hash not initialized")
            return None

        try:
            # Create tag for the order (use strategy name if tag not provided)
            tag = order.tag if order.tag else order.strategy

            # Replace any characters that might cause issues
            tag = re.sub(r'[^a-zA-Z0-9-]', '-', tag)

            if order.order_class is Order.OrderClass.OTO:
                order_builder = self._prepare_oto_order_builder(order)
            elif order.order_class is Order.OrderClass.OCO:
                order_builder = self._prepare_oco_order_builder(order)
            elif order.order_class is Order.OrderClass.BRACKET:
                order_builder = self._prepare_bracket_order_builder(order)
            elif order.is_advanced_order():
                logger.error(colored("Only OTO, OCO, and bracket advanced orders are implemented for Schwab broker.", "red"))
                return None
            else:
                order_builder = self._prepare_schwab_single_order_builder(order)

            if not order_builder:
                logger.error(colored(f"Failed to create order builder for {order}", "red"))
                return None

            order_spec = self._build_order_spec_from_builder(
                order_builder,
                order.time_in_force,
                apply_defaults=order.order_class is not Order.OrderClass.OCO,
                session=self._schwab_session_for_order(order),
            )
            if not order_spec:
                return None

            # Log the final order request - reduce verbosity
            logger.info(colored(f"Sending order to Schwab: {order.asset.symbol, order.quantity} @ {order.limit_price or 'market'}", "cyan"))

            # Submit the order to Schwab
            response = self.client.place_order(self.hash_value, order_spec)

            # Log the response - reduce verbosity
            logger.info(colored(f"Schwab order response status: {response.status_code}", "cyan"))

            # If we get an error response, extract details and return
            if response.status_code >= 400:
                error_msg = f"Error submitting order: HTTP {response.status_code}"
                if hasattr(response, 'text') and response.text:
                    try:
                        error_data = _json_module().loads(response.text)
                        if 'message' in error_data:
                            error_msg += f" - {error_data['message']}"
                    except:
                        error_msg += f" - {response.text}"

                logger.error(colored(error_msg, "red"))

                # Dispatch error event
                self._safe_stream_dispatch(self.ERROR_ORDER, order=order, error_msg=error_msg)
                return None

            # Extract order ID from response
            order_id = None
            try:
                # Use the Schwab utility function to extract order ID if available
                #this fails because we are using Oauth2Session which uses Requests which uses "ok", whereas schwab-py uses HTTPX which has (undocumented) "is_error" to check the response. 
                # try:
                #     from schwab.utils import Utils
                #     # Create a Utils instance with required client and account_hash parameters
                #     utils_instance = Utils(self.client, self.hash_value)
                #     order_id = utils_instance.extract_order_id(response)
                #     if order_id:
                #         logger.info(colored(f"Extracted order ID using Utils.extract_order_id: {order_id}", "green"))
                # except (ImportError, Exception) as e:
                #     logger.warning(colored(f"Could not use Utils.extract_order_id: {e}", "yellow"))

                # Fallback methods if Utils.extract_order_id fails
                if not order_id and hasattr(response, 'headers') and 'Location' in response.headers:
                    location = response.headers.get('Location', '')
                    order_id = location.split('/')[-1] if '/' in location else location.strip()
                    logger.info(colored(f"Extracted order ID from Location header: {order_id}", "green"))

                # If still no order ID and we have text, try to use it directly
                if not order_id and hasattr(response, 'text') and response.text and response.text.strip():
                    order_id = response.text.strip()
                    logger.info(colored(f"Using response text as order ID: {order_id}", "green"))
            except Exception as e:
                logger.error(colored(f"Error extracting order ID: {e}", "red"))

            if not order_id:
                logger.error(colored("Failed to get order ID from response", "red"))
                return None

            # Update the order with the identifier
            order.identifier = order_id
            order.status = Order.OrderStatus.SUBMITTED

            # Store the raw response data
            order_data = {"id": order_id, "status": "SUBMITTED"}
            order.update_raw(order_data)

            # Add to unprocessed orders and dispatch to stream
            self._unprocessed_orders.append(order)
            self._safe_stream_dispatch(self.NEW_ORDER, order=order)

            return order

        except Exception as e:
            error_msg = f"Error submitting order {order}: {str(e)}"
            logger.error(colored(error_msg, "red"))
            logger.error(_format_exc())

            # Dispatch error event
            self._safe_stream_dispatch(self.ERROR_ORDER, order=order, error_msg=error_msg)

            return None

    def _prepare_schwab_single_order_builder(self, order):
        """Prepare a Schwab OrderBuilder for one non-advanced stock/option/future order."""
        try:
            from schwab.orders.equities import (
                equity_buy_limit,
                equity_buy_market,
                equity_buy_to_cover_limit,
                equity_buy_to_cover_market,
                equity_sell_limit,
                equity_sell_market,
                equity_sell_short_limit,
                equity_sell_short_market,
            )
            from schwab.orders.generic import OrderBuilder
            from schwab.orders.options import (
                OptionSymbol,
                option_buy_to_close_limit,
                option_buy_to_close_market,
                option_buy_to_open_limit,
                option_buy_to_open_market,
                option_sell_to_close_limit,
                option_sell_to_close_market,
                option_sell_to_open_limit,
                option_sell_to_open_market,
            )
        except ImportError:
            logger.error(colored("Failed to import Schwab order templates. Make sure the schwab-py library is installed.", "red"))
            return None

        if order.asset.asset_type == Asset.AssetType.STOCK:
            return self._prepare_stock_order_builder(
                order,
                equity_buy_market,
                equity_buy_limit,
                equity_sell_market,
                equity_sell_limit,
                equity_sell_short_market,
                equity_sell_short_limit,
                equity_buy_to_cover_market,
                equity_buy_to_cover_limit,
            )

        if order.asset.asset_type == Asset.AssetType.OPTION:
            return self._prepare_option_order_builder(
                order,
                option_buy_to_open_market,
                option_buy_to_open_limit,
                option_sell_to_open_market,
                option_sell_to_open_limit,
                option_buy_to_close_market,
                option_buy_to_close_limit,
                option_sell_to_close_market,
                option_sell_to_close_limit,
                OptionSymbol,
            )

        if order.asset.asset_type == Asset.AssetType.FUTURE:
            return self._prepare_futures_order_builder(order, OrderBuilder)

        logger.error(colored(f"Asset type {order.asset.asset_type} is not supported by Schwab broker.", "red"))
        return None

    def _prepare_oto_order_builder(self, order):
        """Prepare a Schwab TRIGGER order for Lumibot OTO orders."""
        if len(order.child_orders) != 1:
            logger.error(colored("Schwab OTO orders require exactly one child order.", "red"))
            return None

        try:
            from schwab.orders.common import first_triggers_second
        except ImportError:
            logger.error(colored("Failed to import Schwab OTO helpers. Make sure the schwab-py library is installed.", "red"))
            return None

        parent_builder = self._prepare_schwab_single_order_builder(order)
        child_builder = self._prepare_schwab_single_order_builder(order.child_orders[0])
        if not parent_builder or not child_builder:
            return None

        return first_triggers_second(parent_builder, child_builder)

    def _prepare_oco_order_builder(self, order):
        """Prepare a Schwab OCO order for exactly two child orders."""
        if len(order.child_orders) != 2:
            logger.error(colored("Schwab OCO orders require exactly two child orders.", "red"))
            return None

        try:
            from schwab.orders.common import one_cancels_other
        except ImportError:
            logger.error(colored("Failed to import Schwab OCO helpers. Make sure the schwab-py library is installed.", "red"))
            return None

        first_builder = self._prepare_schwab_single_order_builder(order.child_orders[0])
        second_builder = self._prepare_schwab_single_order_builder(order.child_orders[1])
        if not first_builder or not second_builder:
            return None

        return one_cancels_other(first_builder, second_builder)

    def _prepare_bracket_order_builder(self, order):
        """Prepare a Schwab bracket as parent order triggering an OCO exit pair."""
        if len(order.child_orders) != 2:
            logger.error(colored("Schwab bracket orders require exactly two child orders.", "red"))
            return None

        try:
            from schwab.orders.common import first_triggers_second
        except ImportError:
            logger.error(colored("Failed to import Schwab bracket helpers. Make sure the schwab-py library is installed.", "red"))
            return None

        parent_builder = self._prepare_schwab_single_order_builder(order)
        oco_builder = self._prepare_oco_order_builder(order)
        if not parent_builder or not oco_builder:
            return None

        return first_triggers_second(parent_builder, oco_builder)

    def _prepare_stock_order_builder(self, order, equity_buy_market, equity_buy_limit,
                                   equity_sell_market, equity_sell_limit,
                                   equity_sell_short_market, equity_sell_short_limit,
                                   equity_buy_to_cover_market, equity_buy_to_cover_limit):
        """
        Prepare the order builder for stock orders using Schwab order templates.
        
        Parameters
        ----------
        order : Order
            The order to prepare the builder for
        equity_buy_market, equity_buy_limit, etc. : function
            Schwab order template functions
            
        Returns
        -------
        OrderBuilder
            The order builder object for Schwab API
        """

        # Get order parameters
        symbol = self._normalize_symbol_for_broker(order.asset.symbol, asset_type=order.asset.asset_type)
        from decimal import Decimal

        requested_quantity = Decimal(str(order.quantity))
        if not requested_quantity.is_finite() or requested_quantity <= 0:
            raise ValueError("Schwab stock quantity must be finite and positive")
        # Preserve the requested decimal in JSON; never round a position close.
        if requested_quantity == requested_quantity.to_integral_value():
            quantity = int(requested_quantity)
        else:
            quantity = float(requested_quantity)
        if Decimal(str(quantity)) != requested_quantity:
            raise ValueError("Schwab stock quantity cannot be represented without losing precision")
        limit_price = order.limit_price
        if order.order_type == Order.OrderType.STOP_LIMIT:
            limit_price = order.stop_limit_price

        # Create the appropriate order builder based on order side and type
        order_builder = None

        # Market orders
        if order.order_type == Order.OrderType.MARKET:
            if order.side == Order.OrderSide.BUY:
                order_builder = equity_buy_market(symbol, quantity)
            elif order.side == Order.OrderSide.SELL:
                order_builder = equity_sell_market(symbol, quantity)
            elif order.side == Order.OrderSide.SELL_SHORT:
                order_builder = equity_sell_short_market(symbol, quantity)
            elif order.side == Order.OrderSide.BUY_TO_COVER:
                order_builder = equity_buy_to_cover_market(symbol, quantity)

        # Limit orders
        elif order.order_type == Order.OrderType.LIMIT:
            if order.side == Order.OrderSide.BUY:
                order_builder = equity_buy_limit(symbol, quantity, limit_price)
            elif order.side == Order.OrderSide.SELL:
                order_builder = equity_sell_limit(symbol, quantity, limit_price)
            elif order.side == Order.OrderSide.SELL_SHORT:
                order_builder = equity_sell_short_limit(symbol, quantity, limit_price)
            elif order.side == Order.OrderSide.BUY_TO_COVER:
                order_builder = equity_buy_to_cover_limit(symbol, quantity, limit_price)

        # Stop and stop limit orders aren't directly supported by the templates, so we need a workaround
        elif order.order_type in [Order.OrderType.STOP, Order.OrderType.STOP_LIMIT]:
            logger.warning(colored("Using workaround for stop/stop-limit orders with Schwab templates", "yellow"))

            # Start with a market or limit order based on type
            if order.order_type == Order.OrderType.STOP:
                if order.side == Order.OrderSide.BUY:
                    order_builder = equity_buy_market(symbol, quantity)
                elif order.side == Order.OrderSide.SELL:
                    order_builder = equity_sell_market(symbol, quantity)
                elif order.side == Order.OrderSide.SELL_SHORT:
                    order_builder = equity_sell_short_market(symbol, quantity)
                elif order.side == Order.OrderSide.BUY_TO_COVER:
                    order_builder = equity_buy_to_cover_market(symbol, quantity)
            else:  # STOP_LIMIT
                if order.side == Order.OrderSide.BUY:
                    order_builder = equity_buy_limit(symbol, quantity, limit_price)
                elif order.side == Order.OrderSide.SELL:
                    order_builder = equity_sell_limit(symbol, quantity, limit_price)
                elif order.side == Order.OrderSide.SELL_SHORT:
                    order_builder = equity_sell_short_limit(symbol, quantity, limit_price)
                elif order.side == Order.OrderSide.BUY_TO_COVER:
                    order_builder = equity_buy_to_cover_limit(symbol, quantity, limit_price)

            # Then try to add stop price to the builder object through manual modification
            if order_builder:
                try:
                    from schwab.orders.common import OrderType

                    if order.order_type == Order.OrderType.STOP:
                        order_builder = order_builder.set_order_type(OrderType.STOP)
                    else:
                        order_builder = order_builder.set_order_type(OrderType.STOP_LIMIT)
                    order_builder = order_builder.set_stop_price(str(order.stop_price))
                except Exception as e:
                    logger.error(colored(f"Failed to modify order builder for stop/stop-limit order: {e}", "red"))
                    return None
        else:
            logger.error(colored(f"Order type {order.order_type} not supported for stocks with Schwab templates.", "red"))
            return None

        if not order_builder:
            logger.error(colored(f"Failed to create order builder for side: {order.side}", "red"))
            return None

        return order_builder

    def _prepare_option_order_builder(self, order, option_buy_to_open_market, option_buy_to_open_limit,
                                   option_sell_to_open_market, option_sell_to_open_limit,
                                   option_buy_to_close_market, option_buy_to_close_limit,
                                   option_sell_to_close_market, option_sell_to_close_limit,
                                   OptionSymbol):
        """
        Prepare the order builder for option orders using Schwab order templates.
        
        Parameters
        ----------
        order : Order
            The order to prepare the builder for
        option_buy_to_open_market, option_buy_to_open_limit, etc. : function
            Schwab option order template functions
        OptionSymbol : class
            The Schwab OptionSymbol class for constructing option symbols
            
        Returns
        -------
        OrderBuilder
            The order builder object for Schwab API
        """
        if order.side in (Order.OrderSide.BUY, Order.OrderSide.SELL):
            self.resolve_option_order_intent(order)
        try:
            # Get order parameters
            quantity = int(order.quantity)
            limit_price = order.limit_price

            # Construct the option symbol in Schwab format
            # Get option data from the order's asset
            underlying_symbol = self._normalize_symbol_for_broker(order.asset.symbol, asset_type=order.asset.asset_type)
            expiration_date = order.asset.expiration
            strike_price = order.asset.strike
            option_type = 'C' if order.asset.right == 'CALL' else 'P'

            # Format strike price as string with proper decimal format
            strike_price_str = f"{strike_price:.2f}"

            # Create option symbol using Schwab's OptionSymbol builder
            option_symbol = OptionSymbol(
                underlying_symbol,
                expiration_date,
                option_type,
                strike_price_str
            ).build()

            logger.info(colored(f"Created option symbol: {option_symbol}", "cyan"))

            # Create the order builder based on order side and type
            order_builder = None

            # First determine if this is an opening or closing transaction
            is_opening = False
            if order.side in [Order.OrderSide.BUY_TO_OPEN, Order.OrderSide.SELL_TO_OPEN]:
                is_opening = True
            elif order.side in [Order.OrderSide.BUY_TO_CLOSE, Order.OrderSide.SELL_TO_CLOSE]:
                is_opening = False
            elif order.side == Order.OrderSide.BUY:
                # Default to opening transaction for BUY
                is_opening = True
            elif order.side == Order.OrderSide.SELL:
                # Default to closing transaction for SELL
                is_opening = False
            else:
                logger.error(colored(f"Unsupported order side for options: {order.side}", "red"))
                return None

            # Second, determine if this is a buy or sell action
            is_buy = False
            if order.side in [Order.OrderSide.BUY, Order.OrderSide.BUY_TO_OPEN, Order.OrderSide.BUY_TO_CLOSE]:
                is_buy = True
            elif order.side in [Order.OrderSide.SELL, Order.OrderSide.SELL_TO_OPEN, Order.OrderSide.SELL_TO_CLOSE]:
                is_buy = False
            else:
                logger.error(colored(f"Unsupported order side for options: {order.side}", "red"))
                return None

            # Select the appropriate template function based on side, opening/closing, and order type
            if order.order_type == Order.OrderType.MARKET:
                if is_buy and is_opening:
                    order_builder = option_buy_to_open_market(option_symbol, quantity)
                elif is_buy and not is_opening:
                    order_builder = option_buy_to_close_market(option_symbol, quantity)
                elif not is_buy and is_opening:
                    order_builder = option_sell_to_open_market(option_symbol, quantity)
                elif not is_buy and not is_opening:
                    order_builder = option_sell_to_close_market(option_symbol, quantity)

            elif order.order_type == Order.OrderType.LIMIT:
                if limit_price is None:
                    logger.error(colored("Limit price is required for limit orders", "red"))
                    return None

                if is_buy and is_opening:
                    order_builder = option_buy_to_open_limit(option_symbol, quantity, limit_price)
                elif is_buy and not is_opening:
                    order_builder = option_buy_to_close_limit(option_symbol, quantity, limit_price)
                elif not is_buy and is_opening:
                    order_builder = option_sell_to_open_limit(option_symbol, quantity, limit_price)
                elif not is_buy and not is_opening:
                    order_builder = option_sell_to_close_limit(option_symbol, quantity, limit_price)

            # Handle stop and stop-limit orders
            elif order.order_type in [Order.OrderType.STOP, Order.OrderType.STOP_LIMIT]:
                               # # For stop orders, we start with a market or limit order template
                if order.order_type == Order.OrderType.STOP:
                    if is_buy and is_opening:
                        order_builder = option_buy_to_open_market(option_symbol, quantity)
                    elif is_buy and not is_opening:
                        order_builder = option_buy_to_close_market(option_symbol, quantity)
                    elif not is_buy and is_opening:
                        order_builder = option_sell_to_open_market(option_symbol, quantity)
                    elif not is_buy and not is_opening:
                        order_builder = option_sell_to_close_market(option_symbol, quantity)
                else:  # STOP_LIMIT
                    if limit_price is None:
                        logger.error(colored("Limit price is required for stop-limit orders", "red"))
                        return None

                    if is_buy and is_opening:
                        order_builder = option_buy_to_open_limit(option_symbol, quantity, limit_price)
                    elif is_buy and not is_opening:
                        order_builder = option_buy_to_close_limit(option_symbol, quantity, limit_price)
                    elif not is_buy and is_opening:
                        order_builder = option_sell_to_open_limit(option_symbol, quantity, limit_price)
                    elif not is_buy and not is_opening:
                        order_builder = option_sell_to_close_limit(option_symbol, quantity, limit_price)

                # Then modify the order spec to add stop price
                if order_builder and order.stop_price is not None:
                    try:
                        from schwab.orders.common import OrderType

                        if order.order_type == Order.OrderType.STOP:
                            order_builder = order_builder.set_order_type(OrderType.STOP)
                        else:
                            order_builder = order_builder.set_order_type(OrderType.STOP_LIMIT)
                        order_builder = order_builder.set_stop_price(str(order.stop_price))
                    except Exception as e:
                        logger.error(colored(f"Failed to modify order builder for stop/stop-limit option order: {e}", "red"))
                        return None
            else:
                logger.error(colored(f"Order type {order.order_type} not supported for options with Schwab templates.", "red"))
                return None



            if not order_builder:
                logger.error(colored(f"Failed to create option order builder for side: {order.side}", "red"))
                return None

            return order_builder

        except Exception as e:
            logger.error(colored(f"Error creating option order builder: {e}", "red"))
            logger.error(_format_exc())
            return None

    def _schwab_session_for_order(self, order):
        """Return the Schwab session to use for an order."""
        try:
            from schwab.orders.common import Session
        except ImportError:
            logger.error(colored("Failed to import Schwab order enums. Make sure the schwab-py library is installed.", "red"))
            return None

        order_type = getattr(order, "order_type", None)
        order_type_value = getattr(order_type, "value", order_type)
        if isinstance(order_type_value, str):
            order_type_value = order_type_value.lower()

        if (
            order
            and getattr(order, "asset", None)
            and order.asset.asset_type == Asset.AssetType.STOCK
            and (
                order_type == Order.OrderType.LIMIT
                or order_type_value == "limit"
            )
        ):
            return Session.SEAMLESS

        return Session.NORMAL

    def _build_order_spec_from_builder(self, order_builder, time_in_force=None, apply_defaults=True, session=None):
        """Apply Schwab defaults and return the final API order spec."""
        if not order_builder:
            return None

        try:
            from schwab.orders.common import Duration, Session
        except ImportError:
            logger.error(colored("Failed to import Schwab order enums. Make sure the schwab-py library is installed.", "red"))
            return None

        try:
            tif = time_in_force or "day"
            if apply_defaults:
                if tif == "day":
                    order_builder = order_builder.set_duration(Duration.DAY)
                elif tif == "gtc":
                    order_builder = order_builder.set_duration(Duration.GOOD_TILL_CANCEL)
                elif tif == "opg":
                    order_builder = order_builder.set_duration(Duration.ON_THE_OPEN)
                elif tif == "cls":
                    order_builder = order_builder.set_duration(Duration.ON_THE_CLOSE)

                order_builder = order_builder.set_session(session or Session.NORMAL)
            order_spec = order_builder.build()

            if "order_spec" in order_spec:
                order_spec = order_spec["order_spec"]

            return order_spec
        except Exception as e:
            logger.error(colored(f"Error building Schwab order specification: {e}", "red"))
            logger.error(_format_exc())
            return None

    def _prepare_stock_order_spec(self, order, limit_price=None, stop_price=None, tag=None):
        """
        Prepare a Schwab replacement order spec for a stock order.

        Schwab modifies orders by replacing them, so this reuses the same
        builder path used for new stock submissions and only temporarily applies
        the requested replacement prices while building the spec.
        """
        try:
            from schwab.orders.equities import (
                equity_buy_limit,
                equity_buy_market,
                equity_buy_to_cover_limit,
                equity_buy_to_cover_market,
                equity_sell_limit,
                equity_sell_market,
                equity_sell_short_limit,
                equity_sell_short_market,
            )
        except ImportError:
            logger.error(colored("Failed to import Schwab stock order templates. Make sure the schwab-py library is installed.", "red"))
            return None

        original_limit_price = order.limit_price
        original_stop_price = order.stop_price
        original_tag = order.tag

        try:
            if limit_price is not None:
                order.limit_price = limit_price
            if stop_price is not None:
                order.stop_price = stop_price
            if tag is not None:
                order.tag = tag

            order_builder = self._prepare_stock_order_builder(
                order,
                equity_buy_market,
                equity_buy_limit,
                equity_sell_market,
                equity_sell_limit,
                equity_sell_short_market,
                equity_sell_short_limit,
                equity_buy_to_cover_market,
                equity_buy_to_cover_limit,
            )
            return self._build_order_spec_from_builder(
                order_builder,
                order.time_in_force,
                session=self._schwab_session_for_order(order),
            )
        finally:
            order.limit_price = original_limit_price
            order.stop_price = original_stop_price
            order.tag = original_tag

    def _prepare_option_order_spec(self, order, limit_price=None, stop_price=None, tag=None):
        """
        Prepare a Schwab replacement order spec for an option order.

        This is the replacement-side equivalent of `_prepare_option_order_builder`.
        It intentionally uses the same Schwab option templates as new submits so
        option modify/replace does not drift from normal option order creation.
        """
        try:
            from schwab.orders.options import (
                OptionSymbol,
                option_buy_to_close_limit,
                option_buy_to_close_market,
                option_buy_to_open_limit,
                option_buy_to_open_market,
                option_sell_to_close_limit,
                option_sell_to_close_market,
                option_sell_to_open_limit,
                option_sell_to_open_market,
            )
        except ImportError:
            logger.error(colored("Failed to import Schwab option order templates. Make sure the schwab-py library is installed.", "red"))
            return None

        original_limit_price = order.limit_price
        original_stop_price = order.stop_price
        original_tag = order.tag

        try:
            if limit_price is not None:
                order.limit_price = limit_price
            if stop_price is not None:
                order.stop_price = stop_price
            if tag is not None:
                order.tag = tag

            order_builder = self._prepare_option_order_builder(
                order,
                option_buy_to_open_market,
                option_buy_to_open_limit,
                option_sell_to_open_market,
                option_sell_to_open_limit,
                option_buy_to_close_market,
                option_buy_to_close_limit,
                option_sell_to_close_market,
                option_sell_to_close_limit,
                OptionSymbol,
            )
            return self._build_order_spec_from_builder(
                order_builder,
                order.time_in_force,
                session=self._schwab_session_for_order(order),
            )
        finally:
            order.limit_price = original_limit_price
            order.stop_price = original_stop_price
            order.tag = original_tag

    def _prepare_futures_order_builder(self, order, OrderBuilder):
        """
        Prepare the order builder for futures orders using Schwab generic order builder.
        
        Parameters
        ----------
        order : Order
            The order to prepare the builder for
        OrderBuilder : class
            Schwab OrderBuilder class
            
        Returns
        -------
        OrderBuilder
            The order builder object for Schwab API
        """

        # Get order parameters

        symbol = order.asset.symbol
        quantity = int(order.quantity)

        # Futures symbols in Schwab sometimes need special formatting
        # Most common futures symbols include a slash, e.g., "/ES" for E-mini S&P 500
        if not symbol.startswith('/') and ':' not in symbol and '.' not in symbol:
            logger.info(colored(f"Converting futures symbol from {symbol} to /{symbol}", "cyan"))
            symbol = f"/{symbol}"

        try:
            # Create order spec directly (without using OrderBuilder methods)
            # This ensures we have the exact structure the API expects
            order_spec = {
                "session": "NORMAL",
                "duration": "GOOD_TILL_CANCEL",
                "orderStrategyType": "SINGLE",
                "orderLegCollection": [
                    {
                        "orderLegType": "FUTURE",
                        "instruction": "BUY" if order.side in [Order.OrderSide.BUY, Order.OrderSide.BUY_TO_OPEN, Order.OrderSide.BUY_TO_COVER] else "SELL",
                        "quantity": quantity,
                        "instrument": {
                            "assetType": "FUTURE",
                            "symbol": symbol
                        }
                    }
                ]
            }

            # Set order type
            if order.order_type == Order.OrderType.MARKET:
                order_spec["orderType"] = "MARKET"
            elif order.order_type == Order.OrderType.LIMIT:
                order_spec["orderType"] = "LIMIT"
                order_spec["price"] = float(order.limit_price)
            elif order.order_type == Order.OrderType.STOP:
                order_spec["orderType"] = "STOP"
                order_spec["stopPrice"] = float(order.stop_price)
            elif order.order_type == Order.OrderType.STOP_LIMIT:
                order_spec["orderType"] = "STOP_LIMIT"
                order_spec["price"] = float(order.stop_limit_price)
                order_spec["stopPrice"] = float(order.stop_price)
            else:
                logger.error(colored(f"Order type {order.order_type} not supported for futures with Schwab.", "red"))
                return None

            # Log the manually constructed order spec for debugging
            logger.info(colored(f"Manually constructed futures order spec: {_json_module().dumps(order_spec, indent=2)}", "cyan"))

            # Create a new OrderBuilder with the direct spec
            # This bypasses all the OrderBuilder methods completely
            new_builder = OrderBuilder()
            # Important: We're directly setting the order spec as the final product
            # That will be returned by build() later, not creating a nested structure


            new_builder._order_spec = order_spec

            # No need to call any setter methods since we've directly set the spec
            return new_builder

        except Exception as e:
            logger.error(colored(f"Error creating futures order builder: {e}", "red"))
            logger.error(_format_exc())
            return None

    def _modify_order(self, order: Order, limit_price: Union[float, None] = None,
                      stop_price: Union[float, None] = None):
        """
        Modify an order at the broker by sending an explicit replace request to
        Schwab. The broker response is the source of truth even if local status
        appears terminal. Only limit and/or stop price can be changed. If you
        want to change the quantity, you must cancel the order and submit a new
        one.
        
        Parameters
        ----------
        order : Order
            The order to modify.
        limit_price : float, optional
            The new limit price for the order.
        stop_price : float, optional
            The new stop price for the order.
        """
        # Add check for authorization error first
        if self.schwab_authorization_error:
            logger.error(colored(f"Schwab authorization failed previously. Cannot modify order {order.identifier}.", "red"))
            return

        # Add check for valid client and hash_value
        if not self.client or not self.hash_value:
            logger.error(colored(f"Schwab client or account hash not initialized. Cannot modify order {order.identifier}.", "red"))
            return # Return early

        if not order.identifier:
            logger.error(colored("Order identifier is not set, unable to modify order. Did you remember to submit it?", "red"))
            return

        try:
            # Get the original order first to use as base for modification
            original_order_data = self._pull_broker_order(order.identifier) # Already checks hash_value

            if not original_order_data:
                logger.error(colored(f"Unable to fetch original order {order.identifier} for modification", "red"))
                return

            # Create a new order spec based on the original order
            new_order_spec = self._prepare_replacement_order_spec(order, original_order_data, limit_price, stop_price)

            if not new_order_spec:
                logger.error(colored(f"Failed to create replacement order specification for {order}", "red"))
                return

            # Replace the order
            response = self.client.replace_order(self.hash_value, order.identifier, new_order_spec)

            # Extract new order ID from response (the replaced order will have a new ID)
            new_order_id = None
            try:
                if hasattr(response, 'headers') and 'Location' in response.headers:
                    # Extract order ID from the Location header
                    location = response.headers['Location']
                    new_order_id = location.split('/')[-1]
                elif response.status_code == 200 or response.status_code == 201:
                    # Try to extract from text if possible
                    new_order_id = response.text.strip() if response.text else None
            except Exception as e:
                logger.error(colored(f"Error extracting new order ID: {e}", "red"))

            if not new_order_id:
                logger.error(colored("Failed to get new order ID after replacement", "red"))
                return

            # Update the order with the new identifier

            order.previous_identifiers = getattr(order, "previous_identifiers", None) or []
            order.previous_identifiers.append(order.identifier)
            order.identifier = new_order_id
            # Update price information
            if limit_price is not None:
                order.limit_price = limit_price
            if stop_price is not None:
                order.stop_price = stop_price

            # No need to dispatch any events as the order is still considered the same from Lumibot's perspective

        except Exception as e:
            logger.error(colored(f"Error modifying order {order.identifier}: {str(e)}", "red"))
            logger.error(_format_exc())

    def _prepare_replacement_order_spec(self, order, original_order_data, limit_price, stop_price):
        """
        Prepare a replacement order specification for order modification.
        
        Parameters
        ----------
        order : Order
            The order to modify
        original_order_data : dict
            The original order data from the broker
        limit_price : float or None
            The new limit price, or None to keep original
        stop_price : float or None
            The new stop price, or None to keep original
            
        Returns
        -------
        dict
            The replacement order specification
        """
        # This will need to be implemented based on the actual structure of Schwab's order specs
        # For now, let's create a basic implementation

        # Start with tag for the order
        tag = order.tag if order.tag else order.strategy
        tag = re.sub(r'[^a-zA-Z0-9-]', '-', tag)

        # Use original values for prices if new ones are not provided
        final_limit_price = limit_price if limit_price is not None else order.limit_price
        final_stop_price = stop_price if stop_price is not None else order.stop_price

        # Create the replacement order spec based on asset type
        if order.asset.asset_type == Asset.AssetType.STOCK:
            return self._prepare_stock_order_spec(order, final_limit_price, final_stop_price, tag)
        elif order.asset.asset_type == Asset.AssetType.OPTION:
            return self._prepare_option_order_spec(order, final_limit_price, final_stop_price, tag)
        else:
            logger.error(colored(f"Asset type {order.asset.asset_type} is not supported for order modification", "red"))
            return None

    def get_historical_account_value(self) -> dict:
        """
        Get the historical account value.
        
        Returns
        -------
        dict
            A dictionary containing the historical account value with keys 'hourly' and 'daily'.
        """
        logger.error(colored("Method 'get_historical_account_value' is not yet implemented.", "red"))
        return {"hourly": None, "daily": None}

    def cancel_order(self, order: Order) -> None:
        """
        Cancel an order at the broker by sending an explicit cancel request to
        Schwab. The broker response is the source of truth even if local status
        appears terminal.
        
        Parameters
        ----------
        order : Order
            The order to cancel.

        Returns
        -------
        None
        """
        if not order.identifier:
            logger.error(
                "[SchwabCancelTelemetry] missing_identifier "
                f"symbol={getattr(getattr(order, 'asset', None), 'symbol', '<missing>')} "
                f"side={getattr(order, 'side', '<missing>')} "
                f"quantity={getattr(order, 'quantity', '<missing>')} "
                f"local_status={getattr(order, 'status', '<missing>')}"
            )
            raise ValueError("Order identifier is not set, unable to cancel order. Did you remember to submit it?")

        # Add check for authorization error first
        if self.schwab_authorization_error:
            error_msg = f"Schwab authorization failed previously. Cannot cancel order {order.identifier}."
            logger.error(
                "[SchwabCancelTelemetry] auth_blocked "
                f"order_id={order.identifier} "
                f"symbol={getattr(getattr(order, 'asset', None), 'symbol', '<missing>')} "
                f"local_status={getattr(order, 'status', '<missing>')}"
            )
            logger.error(colored(error_msg, "red"))
            raise LumibotBrokerAPIError(error_msg)

        # Add check for valid client and hash_value
        if not self.client or not self.hash_value:
            error_msg = f"Schwab client or account hash not initialized. Cannot cancel order {order.identifier}."
            logger.error(
                "[SchwabCancelTelemetry] client_not_ready "
                f"order_id={order.identifier} "
                f"has_client={bool(self.client)} "
                f"has_hash={bool(self.hash_value)}"
            )
            logger.error(colored(error_msg, "red"))
            raise LumibotBrokerAPIError(error_msg)

        self._log_schwab_lifecycle_event(
            "order.cancel.request",
            order,
            local_status=getattr(order, "status", "<missing>"),
        )
        cancel_started = time.perf_counter()
        try:
            # schwab-py expects (order_id, account_hash) and issues
            # DELETE /trader/v1/accounts/{account_hash}/orders/{order_id}.
            response = self.client.cancel_order(order.identifier, self.hash_value)
        except Exception as exc:
            error_msg = f"Error canceling Schwab order {order.identifier}: {exc}"
            logger.error(colored(error_msg, "red"))
            raise LumibotBrokerAPIError(error_msg) from exc

        status_code = getattr(response, "status_code", None)
        elapsed_ms = int((time.perf_counter() - cancel_started) * 1000)
        if status_code is None:
            error_msg = f"Error canceling Schwab order {order.identifier}: unexpected response {type(response).__name__}"
            logger.error(
                "[SchwabCancelTelemetry] response_missing_status "
                f"order_id={order.identifier} "
                f"response_type={type(response).__name__} "
                f"elapsed_ms={elapsed_ms}"
            )
            logger.error(colored(error_msg, "red"))
            raise LumibotBrokerAPIError(error_msg)

        response_text = getattr(response, "text", "")
        self._log_schwab_lifecycle_event(
            "order.cancel.response",
            order,
            http_status=status_code,
            elapsed_ms=elapsed_ms,
            result="accepted" if 200 <= int(status_code) < 300 else "rejected",
        )

        if not 200 <= int(status_code) < 300:
            if int(status_code) in (400, 409):
                # A cancel can lose a race to a fill or another cancel. Only an
                # authoritative terminal snapshot resolves it; never infer this
                # from an HTTP code or the response text alone.
                raw_order = self._pull_broker_order(order.identifier)
                observed = self._parse_broker_order(raw_order, order.strategy) if raw_order else None
                if observed is not None and any(
                    Order.is_equivalent_status(observed.status, status)
                    for status in (self.FILLED_ORDER, self.CANCELED_ORDER)
                ):
                    self._process_schwab_order_snapshot(observed)
                    return
            error_msg = f"Error canceling Schwab order {order.identifier}: HTTP {status_code}"
            if response_text:
                error_msg += f" - {response_text}"
            logger.error(colored(error_msg, "red"))
            raise LumibotBrokerAPIError(error_msg)

        logger.info(colored(f"Schwab cancel accepted for order {order.identifier}.", "green"))
        if _schwab_cancel_diagnostics_enabled():
            # Incident diagnostics only: this is an extra full round trip on the
            # cancel hot path. Enable SCHWAB_CANCEL_DIAGNOSTICS to restore it.
            self._log_cancel_direct_read(order.identifier, "after_cancel_accept")

        # A successful DELETE means Schwab accepted the request, not that the
        # order is terminal.  Preserve cancel-pending state and let a later
        # broker snapshot/stream observation emit CANCELED_ORDER or FILLED_ORDER.
        if (
            not order.is_filled()
            and not order.is_canceled()
            and not Order.is_equivalent_status(order.status, self.ERROR_ORDER)
            and not Order.is_equivalent_status(order.status, Order.OrderStatus.EXPIRED)
        ):
            order.status = Order.OrderStatus.CANCELLING
        return None

    def _log_cancel_direct_read(self, order_id: str, context: str) -> None:
        """Best-effort direct order read used only for Schwab cancel diagnostics."""
        if not self.client or not self.hash_value or not hasattr(self.client, "get_order"):
            logger.info(
                "[SchwabCancelTelemetry] direct_read_skipped "
                f"order_id={order_id} context={context} reason=client_not_capable"
            )
            return

        try:
            response = self.client.get_order(order_id, self.hash_value)
        except Exception as exc:
            logger.warning(
                "[SchwabCancelTelemetry] direct_read_exception "
                f"order_id={order_id} context={context} error={exc}"
            )
            return

        status_code = getattr(response, "status_code", None)
        if status_code != 200:
            logger.warning(
                "[SchwabCancelTelemetry] direct_read_http_error "
                f"order_id={order_id} context={context} http_status={status_code} "
                f"body={getattr(response, 'text', '')[:500]}"
            )
            return

        try:
            raw = response.json()
        except Exception as exc:
            logger.warning(
                "[SchwabCancelTelemetry] direct_read_json_error "
                f"order_id={order_id} context={context} error={exc}"
            )
            return

        logger.info(
            "[SchwabCancelTelemetry] direct_read "
            f"order_id={order_id} context={context} "
            f"broker_status={raw.get('status', '<missing>')} "
            f"order_type={raw.get('orderType', '<missing>')} "
            f"strategy_type={raw.get('orderStrategyType', '<missing>')} "
            f"entered_time={raw.get('enteredTime', '<missing>')} "
            f"close_time={raw.get('closeTime', '<missing>')} "
            f"cancelable={raw.get('cancelable', '<missing>')} "
            f"editable={raw.get('editable', '<missing>')} "
            f"child_count={len(raw.get('childOrderStrategies') or [])}"
        )

    def _mark_order_tree_canceled(self, order: Order) -> None:
        """Mark a canceled Schwab parent order and all local child legs terminal."""
        order.status = self.CANCELED_ORDER
        order.set_canceled()
        for child_order in getattr(order, "child_orders", []) or []:
            self._mark_order_tree_canceled(child_order)

    def _launch_stream(self):
        """Set the asynchronous actions to be executed when events are sent via socket streams"""
        self._register_stream_events()
        t = Thread(target=self._run_stream, daemon=True, name=f"broker_{self.name}_thread")
        t.start()
        activity_worker = Thread(
            target=self._run_schwab_activity_reconciler,
            daemon=True,
            name=f"broker_{self.name}_activity_reconciler",
        )
        activity_worker.start()
        activity_stream = Thread(
            target=self._run_schwab_account_activity_stream,
            daemon=True,
            name=f"broker_{self.name}_account_activity",
        )
        activity_stream.start()
        # Removed blocking wait for stream connection establishment
        return

    def sync_positions(self, strategy):
        """
        Override the default sync_positions method to prevent duplicate positions.

        This method ensures that positions are properly synchronized without creating duplicates.
        """
        # Add check for initialization status
        # This check should now work reliably as schwab_authorization_error always exists
        if not self._broker_fully_ready: # Check new flag first
            logger.debug(colored("[Schwab] Broker not fully ready, skipping position sync.", "yellow"))
            return
        if not hasattr(self, '_filled_positions') or self.schwab_authorization_error:
             logger.warning(colored("[Schwab] Broker not fully initialized or in error state, skipping position sync.", "yellow"))
             return

        # Get current tracked positions for this strategy
        strategy_name = strategy.name if strategy else None
        tracked = self.get_tracked_positions(strategy_name)
        tracked_dict = {}

        # Create a dict of tracked positions keyed by their unique asset identifiers
        for position in tracked:
            asset = position.asset
            key = (asset.symbol, asset.asset_type,
                  getattr(asset, 'expiration', None),
                  getattr(asset, 'strike', None),
                  getattr(asset, 'right', None))
            tracked_dict[key] = position

        # Pull fresh positions from the broker
        new_positions = self._pull_positions(strategy)
        new_dict = {}
        for position in new_positions:
            asset = position.asset
            key = (asset.symbol, asset.asset_type,
                  getattr(asset, 'expiration', None),
                  getattr(asset, 'strike', None),
                  getattr(asset, 'right', None))
            new_dict[key] = position

        if getattr(self, "_last_positions_refresh_degraded", False):
            logger.warning(colored(
                "Schwab position refresh was degraded; updating parsed positions but not removing "
                "tracked positions that were missing from the partial broker parse.",
                "yellow",
            ))
        else:
            # Remove positions that no longer exist only after a complete broker parse.
            for key, position in tracked_dict.items():
                if key not in new_dict:
                    # Use the proper method to remove positions from filled_positions list
                    if position in self._filled_positions.get_list():
                        self._filled_positions.remove(position)

        # Update or add positions
        for key, position in new_dict.items():
            if key in tracked_dict:
                # Update existing position
                tracked_position = tracked_dict[key]
                self._sync_position_fields_from_broker(tracked_position, position)
            else:
                # Add new position
                self._filled_positions.append(position)

        logger.debug(f"Synchronized {len(new_positions)} positions for strategy {strategy_name if strategy_name else 'None'}")
