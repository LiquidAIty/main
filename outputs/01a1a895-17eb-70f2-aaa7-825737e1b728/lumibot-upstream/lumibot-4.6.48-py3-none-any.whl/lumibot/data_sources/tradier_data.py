from __future__ import annotations

from collections import defaultdict

from lumibot._lazy_imports import LazyLogger, LazyModule, lazy_class, lazy_typing

from .data_source import DataSource

logger = LazyLogger(__name__)
TYPE_CHECKING = False
dt = LazyModule("datetime")
pd = LazyModule("pandas")
shared_bar_cache = LazyModule("lumibot.tools.shared_bar_cache")
Asset = lazy_class("lumibot.entities", "Asset")
Decimal = lazy_class("decimal", "Decimal")
Quote = lazy_class("lumibot.entities", "Quote")
Union = lazy_typing("Union")
LUMIBOT_DEFAULT_TIMEZONE = "America/New_York"

if TYPE_CHECKING:
    from lumibot.entities import Quote


def _create_options_symbol(*args, **kwargs):
    from lumibot.tools.helpers import create_options_symbol

    return create_options_symbol(*args, **kwargs)


def _date_n_trading_days_from_date(*args, **kwargs):
    from lumibot.tools.helpers import date_n_trading_days_from_date

    return date_n_trading_days_from_date(*args, **kwargs)


def _parse_timestep_qty_and_unit(*args, **kwargs):
    from lumibot.tools.helpers import parse_timestep_qty_and_unit

    return parse_timestep_qty_and_unit(*args, **kwargs)


def _black_scholes():
    from lumibot.tools import black_scholes

    return black_scholes


class TradierAPIError(Exception):
    pass


class TradierData(DataSource):

    MIN_TIMESTEP = "minute"
    SOURCE = "Tradier"
    TIMESTEP_MAPPING = [
        {
            "timestep": "tick",
            "representations": [
                "tick",
            ],
        },
        {
            "timestep": "minute",
            "representations": [
                "minute",
            ],
        },
        {
            "timestep": "day",
            "representations": [
                "daily",
            ],
        },
        {
            "timestep": "week",
            "representations": [
                "weekly",
            ],
        },
        {
            "timestep": "month",
            "representations": [
                "monthly",
            ],
        },
    ]

    def __init__(
            self,
            account_number: str,
            access_token: str,
            paper: bool = True,
            max_workers: int = 20,
            delay: int = None,
            tzinfo=None,
            remove_incomplete_current_bar: bool = False,
            **kwargs
    ) -> None:
        """
        Initializes the trading account with the specified parameters.

        Parameters:
        - account_number (str): The account number used for accessing the trading account.
        - access_token (str): The access token for authenticating requests.
        - paper (bool, optional): Indicates whether to use the paper trading environment.
          Defaults to True.
        - max_workers (int, optional): The maximum number of workers for parallel processing.
          Defaults to 20.
        - delay (int, optional): A delay parameter to control how many minutes to delay non-crypto data for.
          If not specified, uses DATA_SOURCE_DELAY environment variable or defaults to 0.
        - tzinfo (pytz.timezone, optional): Timezone for data adjustments. Determines how datetime objects
          are adjusted when retrieving historical data. Defaults to the `LUMIBOT_DEFAULT_TIMEZONE`.
        - remove_incomplete_current_bar (bool, optional): Default False.
          Whether to remove the incomplete current bar from the data.
          Tradier includes incomplete bars for the current bar (ie: it gives you a daily bar for the current day even if
          the day isn't over yet). Some Lumibot users night not expect that, so this option will remove the incomplete
          bar from the data.

        Returns:
        - None
        """

        if tzinfo is None:
            import pytz

            tzinfo = pytz.timezone(LUMIBOT_DEFAULT_TIMEZONE)

        super().__init__(api_key=access_token, delay=delay, tzinfo=tzinfo)
        self._account_number = account_number
        self._paper = paper
        # Sandbox (paper) market data is delayed, so it is a different series from live data.
        self.shared_bars_scope = shared_bar_cache.credential_scope(
            "tradier", account_number, "paper" if paper else "live"
        )
        self.max_workers = min(max_workers, 50)
        from lumiwealth_tradier import Tradier

        self.tradier = Tradier(account_number, access_token, paper)
        self._remove_incomplete_current_bar = remove_incomplete_current_bar

    def _sanitize_base_and_quote_asset(self, base_asset, quote_asset) -> tuple[Asset, Asset]:
        if isinstance(base_asset, tuple):
            quote = base_asset[1]
            asset = base_asset[0]
        else:
            asset = base_asset
            quote = quote_asset

        if isinstance(asset, str):
            raise NotImplementedError(f"TradierData doesn't support string assets like: {asset} yet.")

        return asset, quote

    def get_chains(self, asset: Asset, quote: Asset = None, exchange: str = None):
        """
        Obtains option chain information for the asset (stock) from each
        of the exchanges the options trade on and returns a dictionary
        for each exchange.

        Parameters
        ----------
        asset : Asset
            The asset to get the option chains for
        quote : Asset | None
            The quote asset to get the option chains for
        exchange: str | None
            The exchange to get the option chains for

        Returns
        -------
        dictionary of dictionary
            Format:
            - `Multiplier` (str) eg: `100`
            - 'Chains' - paired Expiration/Strike info to guarentee that the strikes are valid for the specific
                         expiration date.
                         Format:
                           chains['Chains']['CALL'][exp_date] = [strike1, strike2, ...]
                         Expiration Date Format: 2023-07-31
        """
        df_chains = self.tradier.market.get_option_expirations(asset.symbol)
        if not isinstance(df_chains, pd.DataFrame) or df_chains.empty:
            raise LookupError(f"Could not find Tradier option chains for {asset.symbol}")

        # Tradier doesn't report multiple exchanges, just use SMART
        multiplier = int(df_chains.contract_size.mode()[0])  # Use most common, should always be 100
        chains = {"Multiplier": multiplier, "Exchange": "unknown",
                  "Chains": {"CALL": defaultdict(list), "PUT": defaultdict(list)}}
        for row in df_chains.reset_index().to_dict("records"):
            exp_date = row["date"].strftime('%Y-%m-%d')
            strikes = row["strikes"]
            try:
                strikes = sorted(float(s) for s in strikes)
            except Exception:
                try:
                    strikes = sorted(strikes)
                except Exception:
                    pass
            chains["Chains"]["CALL"][exp_date] = strikes
            chains["Chains"]["PUT"][exp_date] = strikes

        return chains

    def get_chain_full_info(self, asset: Asset, expiry: str, chains=None, underlying_price=float, risk_free_rate=float,
                            strike_min=None, strike_max=None) -> pd.DataFrame:
        """
        Get the full chain information for an option asset, including: greeks, bid/ask, open_interest, etc. For
        brokers that do not support this, greeks will be calculated locally. For brokers like Tradier this function
        is much faster as only a single API call can be done to return the data for all options simultaneously.

        Parameters
        ----------
        asset : Asset
            The option asset to get the chain information for.
        expiry : str | dt.datetime | dt.date
            The expiry date of the option chain.
        chains : dict
            The chains dictionary created by `get_chains` method. This is used
            to get the list of strikes needed to calculate the greeks.
        underlying_price : float
            Price of the underlying asset.
        risk_free_rate : float
            The risk-free rate used in interest calculations.
        strike_min : float
            The minimum strike price to return in the chain. If None, will return all strikes.
            This is not necessary for Tradier as all option data is returned in a single query.
        strike_max : float
            The maximum strike price to return in the chain. If None, will return all strikes.
            This is not necessary for Tradier as all option data is returned in a single query.

        Returns
        -------
        pd.DataFrame
            A DataFrame containing the full chain information for the option asset. Greeks columns will be named as
            'greeks.delta', 'greeks.theta', etc.
        """
        df = self.tradier.market.get_option_chains(asset.symbol, expiry, greeks=True)

        # Filter the dataframe by strike_min and strike_max
        if strike_min is not None:
            df = df[df.strike >= strike_min]
        if strike_max is not None:
            df = df[df.strike <= strike_max]

        return df

    def get_historical_prices(
        self, asset, length, timestep="", timeshift=None, quote=None, exchange=None, include_after_hours=True, return_polars: bool = False
    ):
        """
        Get bars for a given asset

        Parameters
        ----------
        asset : Asset
            The asset to get the bars for.
        length : int
            The number of bars to get.
        timestep : str
            The timestep to get the bars at. Accepts "day" or "minute".
        timeshift : dt.timedelta
            The amount of time to shift the bars by. For example, if you want the bars from 1 hour ago to now,
            you would set timeshift to 1 hour.
        quote : Asset
            The quote asset to get the bars for.
        exchange : str
            The exchange to get the bars for.
        include_after_hours : bool
            Whether to include after hours data.
        """
        asset, quote = self._sanitize_base_and_quote_asset(asset, quote)
        timestep = timestep if timestep else self.MIN_TIMESTEP

        # Parse the timestep
        timestep_qty, timestep_unit = _parse_timestep_qty_and_unit(timestep)

        parsed_timestep_unit = self._parse_source_timestep(timestep_unit, reverse=True)

        if asset.asset_type == "option":
            symbol = _create_options_symbol(
                asset.symbol,
                asset.expiration,
                asset.right,
                asset.strike,
            )
        else:
            symbol = asset.symbol

        # Create end time
        now = dt.datetime.now(self.tzinfo)
        if self._delay:
            end_dt = now - self._delay
        else:
            end_dt = now

        if timeshift is not None:
            if not isinstance(timeshift, dt.timedelta):
                raise TypeError("timeshift must be a timedelta")
            end_dt = end_dt - timeshift

        if timestep == 'day':
            days_needed = length
        else:
            # For minute bars, calculate additional days needed accounting for weekends/holidays
            # minutes_per_day = 390  # ~6.5 hours of trading per day
            minutes_per_day = 24 * 60 / timestep_qty  # Need to include premarket and after hours
            days_needed = int(length // minutes_per_day) + 1

        start_date = _date_n_trading_days_from_date(
            n_days=days_needed,
            start_datetime=end_dt,
            # TODO: pass market into DataSource
            # This works for now. Crypto gets more bars but throws them out.
            market='NYSE'
        )
        start_dt = self.tzinfo.localize(dt.datetime.combine(start_date, dt.datetime.min.time()))

        def fetch(range_start, range_end):
            """One Tradier history read for [range_start, range_end]. Errors raise; nothing is cached."""
            range_start = range_start.tz_convert(self.tzinfo).to_pydatetime()
            range_end = range_end.tz_convert(self.tzinfo).to_pydatetime()
            if parsed_timestep_unit == "minute":
                frame = self.tradier.market.get_timesales(
                    symbol,
                    interval=timestep_qty,
                    start_date=range_start,
                    end_date=range_end,
                    session_filter="all" if include_after_hours else "open",
                )
            else:
                frame = self.tradier.market.get_historical_quotes(
                    symbol,
                    interval=parsed_timestep_unit,
                    start_date=range_start,
                    end_date=range_end,
                    session_filter="all" if include_after_hours else "open",
                )
            if frame is None or frame.empty:
                return None
            frame = frame.drop(columns=[c for c in ("time", "timestamp") if c in frame.columns])
            index = pd.to_datetime(frame.index)
            # Daily rows are dates in the data source time zone; intraday rows keep their instant.
            index = index.tz_localize(self.tzinfo) if index.tz is None else index.tz_convert(self.tzinfo)
            frame.index = index
            return frame

        # Charts, bots and broker-backed backtests share one bar cache per connection.
        series = shared_bar_cache.BarSeries.make(
            "tradier",
            symbol,
            shared_bar_cache.normalize_timestep(timestep_qty if parsed_timestep_unit == "minute" else 1,
                                                "minute" if parsed_timestep_unit == "minute" else timestep_unit),
            scope=self.shared_bars_scope,
            adjusted=True,
            assetType=str(asset.asset_type),
            interval=str(parsed_timestep_unit),
            session="all" if include_after_hours else "open",
            delayed=bool(self._delay),
        )
        try:
            df = shared_bar_cache.read_bars(
                series, start_dt, end_dt, fetch, now=now - self._delay if self._delay else now
            )
        except Exception as e:
            logger.error(f"Error getting historical prices for {symbol}: {e}")
            return None
        if df.empty:
            return None
        df = shared_bar_cache.to_timezone(df, self.tzinfo)

        # Check for incomplete bars
        if self._remove_incomplete_current_bar:
            if timestep == "minute":
                # For minute bars, remove the current minute
                current_minute = now.replace(second=0, microsecond=0)
                df = df[df.index < current_minute]
            else:
                # For daily bars, remove today's bar if market is open
                current_date = now.date()
                df = df[df.index.date < current_date]

        # Ensure df only contains the last N bars
        if len(df) > length:
            df = df.iloc[-length:]

        # Convert the dataframe to a Bars object
        from lumibot.entities import Bars

        bars = Bars(df, self.SOURCE, asset, raw=df, quote=quote)

        return bars

    def get_last_price(self, asset, quote=None, exchange=None) -> Union[float, Decimal, None]:
        """
        This function returns the last price of an asset.
        Parameters
        ----------
        asset: Asset
            The asset to get the last price for
        quote: Asset
            The quote asset to get the last price for (currently not used for Tradier)
        exchange: str
            The exchange to get the last price for (currently not used for Tradier)

        Returns
        -------
        float or Decimal or none
           Price of the asset
        """
        asset, quote = self._sanitize_base_and_quote_asset(asset, quote)

        symbol = None
        try:
            if asset.asset_type == "option":
                symbol = _create_options_symbol(
                    asset.symbol,
                    asset.expiration,
                    asset.right,
                    asset.strike,
                )
            elif asset.asset_type == "index":
                symbol = f"I:{asset.symbol}"
            else:
                symbol = asset.symbol

            price = self.tradier.market.get_last_price(symbol)
            return price

        except Exception as e:
            logger.error(f"Error getting last price for {symbol or asset.symbol}: {e}")
            return None

    def get_quote(self, asset, quote=None, exchange=None) -> Quote:
        """
        This function returns the quote of an asset.
        Parameters
        ----------
        asset: Asset
            The asset to get the quote for
        quote: Asset
            The quote asset to get the quote for (currently not used for Tradier)
        exchange: str
            The exchange to get the quote for (currently not used for Tradier)

        Returns
        -------
        Quote
           Quote object containing bid, ask, last price and other information
        """

        asset, quote = self._sanitize_base_and_quote_asset(asset, quote)

        if asset.asset_type == "option":
            symbol = _create_options_symbol(
                asset.symbol,
                asset.expiration,
                asset.right,
                asset.strike,
            )
        else:
            symbol = asset.symbol

        quotes_df = self.tradier.market.get_quotes([symbol])

        # If the dataframe is empty, return an empty Quote
        if quotes_df is None or quotes_df.empty:
            from lumibot.entities import Quote

            return Quote(asset=asset)

        # Get the quote from the dataframe
        quote_dict = quotes_df.iloc[0].to_dict()

        # Extract relevant fields for the Quote object
        from lumibot.entities import Quote

        return Quote(
            asset=asset,
            price=quote_dict.get('last'),
            bid=quote_dict.get('bid'),
            ask=quote_dict.get('ask'),
            volume=quote_dict.get('volume'),
            timestamp=dt.datetime.now(dt.timezone.utc),
            bid_size=quote_dict.get('bidsize'),
            ask_size=quote_dict.get('asksize'),
            change=quote_dict.get('change'),
            percent_change=quote_dict.get('change_percentage'),
            raw_data=quote_dict
        )

    def query_greeks(self, asset: Asset):
        """
        This function returns the greeks of an option as reported by the Tradier API.

        Parameters
        ----------
        asset : Asset
            The option asset to get the greeks for.

        Returns
        -------
        dict
            A dictionary containing the greeks of the option.
        """
        greeks = {}
        stock_symbol = asset.symbol
        expiration = asset.expiration
        option_symbol = _create_options_symbol(stock_symbol, expiration, asset.right, asset.strike)
        df_chains = self.tradier.market.get_option_chains(stock_symbol, expiration, greeks=True)
        df = df_chains[df_chains["symbol"] == option_symbol]
        if df.empty:
            return {}

        for col in [x for x in df.columns if 'greeks' in x]:
            greek_name = col.replace('greeks.', '')
            greeks[greek_name] = df[col].iloc[0]

        # Tradier can round extremely small deltas to 0.0 for far OTM options.
        # When we have IV available, compute a more precise delta as a best-effort fallback
        # so callers (and legacy tests) can rely on delta sign being correct.
        try:
            delta = float(greeks.get("delta", 0.0) or 0.0)
        except Exception:
            delta = 0.0

        if asset.right.upper() == "CALL" and delta == 0.0:
            try:
                iv = float(greeks.get("mid_iv") or greeks.get("ask_iv") or greeks.get("bid_iv") or 0.0)
            except Exception:
                iv = 0.0

            if iv > 0:
                try:
                    underlying_price = self.get_last_price(Asset(stock_symbol, asset_type="stock"))
                    underlying_price = float(underlying_price) if underlying_price is not None else None
                except Exception:
                    underlying_price = None

                if underlying_price is not None:
                    expiration = asset.expiration
                    if isinstance(expiration, str):
                        expiration = dt.datetime.strptime(expiration, "%Y-%m-%d").date()
                    if isinstance(expiration, dt.datetime):
                        expiration = expiration.date()

                    if isinstance(expiration, dt.date):
                        expiration_dt = dt.datetime.combine(expiration, dt.time.min)
                        expiration_dt = self.tzinfo.localize(expiration_dt).replace(hour=16, minute=0, second=0, microsecond=0)
                        now = self.get_datetime()
                        days_to_expiration = (expiration_dt - now).total_seconds() / (60 * 60 * 24)
                        # Options can be queried after market close in CI/local runs. Avoid a near-zero
                        # time-to-expiration that would underflow deltas to 0.0 for slightly OTM calls.
                        days_to_expiration = max(days_to_expiration, 1.0 / 24.0)

                        interest = 0.0
                        c = _black_scholes().BS(
                            [underlying_price, float(asset.strike), interest, days_to_expiration],
                            volatility=iv * 100,
                        )
                        greeks["delta"] = float(c.callDelta)
        return greeks
